/** Standard disclaimer copy used across the web app, API and AI responses. */

export const PLATFORM_DISCLAIMER =
  'VESTORA is an educational prototype. All balances, tokens and transactions are simulated or use testnet tokens with no monetary value. Nothing here is an offer of securities, investment advice, or a claim on any physical commodity, property or bond.';

export const KYC_DISCLAIMER =
  'This platform is an educational prototype. KYC is simulated and does not constitute actual identity verification or regulatory approval.';

export const CALCULATOR_DISCLAIMER =
  'Illustrative calculations only. Not a representation of a legally enforceable ownership claim.';

export const AI_DISCLAIMER =
  'VESTORA Intelligence provides general educational information, not financial advice. It is not a licensed financial adviser, does not know your circumstances and cannot predict or guarantee returns.';

export const TOKEN_PRICE_DISCLAIMER =
  'Token prices are illustrative: sample asset value ÷ token supply. They are not market prices and do not equal the commodity price.';

export const DATA_DISCLAIMER =
  'Market data comes from third-party sources and may be delayed, incomplete or unavailable. Demo values are static and never live.';

export const SIMULATION_LABEL = 'Simulated — no on-chain record';
