import type { AssetCategory, RiskInputs } from './types';

/**
 * How a sample asset's illustrative value is derived.
 *
 * - `reference`: a fixed illustrative quantity of a market instrument
 *   (e.g. 50 troy oz of gold). Sample value = quantity × reference price.
 * - `bond`: a sample fixed-coupon bond priced from a live reference yield.
 * - `fixed`: a fully simulated asset with a fixed illustrative valuation.
 *
 * In every case: token price = sample asset value ÷ token supply.
 * The token price is illustrative — it is NOT the commodity price.
 */
export type PricingModel =
  | {
      kind: 'reference';
      instrumentId: string;
      quantity: number;
      quantityUnit: string;
    }
  | {
      kind: 'bond';
      yieldInstrumentId: string;
      faceValue: number;
      couponRate: number;
      maturity: string;
      paymentsPerYear: number;
      /** Illustrative spread over the reference yield, in basis points. */
      spreadBps: number;
      /** Yield (percent) used when no reference yield is available — labelled demo. */
      fallbackYield: number;
    }
  | {
      kind: 'fixed';
      value: number;
      valuationNote: string;
    };

export interface TokenisedAsset {
  id: string;
  /** ERC-1155 token id used by AssetToken.sol (id 0 is reserved for demo credits). */
  tokenId: number;
  symbol: string;
  name: string;
  category: AssetCategory;
  /** `market-referenced` assets derive value from real market data; `simulated` ones are fully fictional samples. */
  kind: 'market-referenced' | 'simulated';
  tagline: string;
  description: string;
  methodology: string;
  pricing: PricingModel;
  /** Sample token supply. */
  totalSupply: number;
  /** Simulated tokens already issued to other (fictional) participants — demo mode only. */
  sampleIssued: number;
  /** Minimum simulated investment in USD. */
  minInvestment: number;
  /** Integer issuance price in vUSD demo credits used by the testnet contract. */
  onchainPrice: number;
  risk: RiskInputs;
  highlights: string[];
  /** Explicit illustrative assumptions for simulated assets. */
  assumptions?: string[];
  /** Accent colour for charts. */
  color: string;
  /** Icon key (mapped to a Lucide icon in the web app). */
  icon: 'gold' | 'silver' | 'platinum' | 'oil' | 'flame' | 'copper' | 'factory' | 'coffee' | 'wheat' | 'landmark' | 'briefcase' | 'home' | 'warehouse' | 'bitcoin' | 'ethereum';
}

export const CATEGORY_LABELS: Record<AssetCategory, string> = {
  'precious-metals': 'Precious Metals',
  energy: 'Energy',
  'industrial-metals': 'Industrial Metals',
  agriculture: 'Agriculture',
  bonds: 'Bonds',
  'real-estate': 'Real Estate',
  'digital-assets': 'Digital Assets',
};

export const CATEGORY_DESCRIPTIONS: Record<AssetCategory, string> = {
  'precious-metals': 'Sample pools referencing live gold, silver and platinum prices.',
  energy: 'Sample baskets referencing crude oil and natural gas benchmarks.',
  'industrial-metals': 'Sample pools referencing copper and aluminium prices.',
  agriculture: 'Sample lots referencing coffee and wheat prices.',
  bonds: 'Educational tokenised bond samples priced from live reference yields.',
  'real-estate': 'Fully simulated fractional property samples with fixed valuations.',
  'digital-assets': 'Sample index units referencing live crypto-asset prices.',
};

const COMMON_METHOD =
  'Token price = sample asset value ÷ token supply. The sample asset is a fictional pool defined for education; no commodity is purchased, stored or custodied, and holding a token confers no legal claim.';

export const TOKENISED_ASSETS: TokenisedAsset[] = [
  {
    id: 'vgld',
    tokenId: 1,
    symbol: 'vGLD',
    name: 'Gold Reserve Pool',
    category: 'precious-metals',
    kind: 'market-referenced',
    tagline: 'A sample 50 oz gold pool split into 20,000 tokens.',
    description:
      'An educational sample pool that references 50 troy ounces of gold. Each token represents an illustrative 0.0025 oz share of the sample pool, so its illustrative value moves with the gold price.',
    methodology: `Sample asset value = 50 troy oz × live XAU/USD reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'XAU', quantity: 50, quantityUnit: 'troy oz' },
    totalSupply: 20_000,
    sampleIssued: 12_480,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 2, structure: 5, macro: 4, typicalVolatility: 0.15, typicalDrawdown: 0.25 },
    highlights: [
      '1 token ≈ 0.0025 troy oz of the sample pool',
      'Value tracks the XAU/USD reference price',
      'No yield: gold produces no cash flow',
    ],
    color: '#D6B36A',
    icon: 'gold',
  },
  {
    id: 'vslv',
    tokenId: 2,
    symbol: 'vSLV',
    name: 'Silver Reserve Pool',
    category: 'precious-metals',
    kind: 'market-referenced',
    tagline: 'A sample 2,000 oz silver pool split into 10,000 tokens.',
    description:
      'An educational sample pool that references 2,000 troy ounces of silver. Each token represents an illustrative 0.2 oz share. Silver is part precious metal, part industrial input, which tends to make it more volatile than gold.',
    methodology: `Sample asset value = 2,000 troy oz × live XAG/USD reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'XAG', quantity: 2000, quantityUnit: 'troy oz' },
    totalSupply: 10_000,
    sampleIssued: 4_210,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 3, structure: 5, macro: 5, typicalVolatility: 0.28, typicalDrawdown: 0.45 },
    highlights: ['1 token ≈ 0.2 troy oz of the sample pool', 'Industrial + investment demand', 'Historically more volatile than gold'],
    color: '#C3CAD6',
    icon: 'silver',
  },
  {
    id: 'vplt',
    tokenId: 3,
    symbol: 'vPLT',
    name: 'Platinum Pool',
    category: 'precious-metals',
    kind: 'market-referenced',
    tagline: 'A sample 50 oz platinum pool split into 7,500 tokens.',
    description:
      'An educational sample pool referencing 50 troy ounces of platinum, a metal whose demand is closely tied to automotive catalysts and industry. Each token represents an illustrative 1/150 oz share.',
    methodology: `Sample asset value = 50 troy oz × live XPT/USD reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'XPT', quantity: 50, quantityUnit: 'troy oz' },
    totalSupply: 7_500,
    sampleIssued: 2_115,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 4, structure: 5, macro: 6, typicalVolatility: 0.25, typicalDrawdown: 0.5 },
    highlights: ['Small, concentrated supply base', 'Demand linked to autos and industry', '1 token ≈ 0.0067 troy oz'],
    color: '#9AA7BA',
    icon: 'platinum',
  },
  {
    id: 'vwti',
    tokenId: 4,
    symbol: 'vWTI',
    name: 'WTI Crude Basket',
    category: 'energy',
    kind: 'market-referenced',
    tagline: 'A sample 2,000-barrel crude basket split into 12,000 tokens.',
    description:
      'An educational basket referencing 2,000 barrels of WTI crude oil. Each token represents an illustrative 1/6 barrel. Real oil exposure usually involves futures contracts, storage and roll costs that this sample does not model.',
    methodology: `Sample asset value = 2,000 barrels × WTI reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'WTI', quantity: 2000, quantityUnit: 'barrels' },
    totalSupply: 12_000,
    sampleIssued: 7_960,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 3, structure: 6, macro: 7, typicalVolatility: 0.4, typicalDrawdown: 0.6 },
    highlights: ['Highly sensitive to OPEC+ and demand news', '1 token ≈ 0.167 barrels', 'Futures roll costs are not modelled'],
    color: '#5B6B8C',
    icon: 'oil',
  },
  {
    id: 'vngs',
    tokenId: 5,
    symbol: 'vNGS',
    name: 'Natural Gas Strip',
    category: 'energy',
    kind: 'market-referenced',
    tagline: 'A sample 30,000 MMBtu gas strip split into 12,000 tokens.',
    description:
      'An educational sample referencing 30,000 MMBtu of Henry Hub natural gas. Gas prices are strongly seasonal and weather-driven, making this one of the most volatile samples on the platform.',
    methodology: `Sample asset value = 30,000 MMBtu × Henry Hub reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'NATGAS', quantity: 30000, quantityUnit: 'MMBtu' },
    totalSupply: 12_000,
    sampleIssued: 3_640,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 4, structure: 6, macro: 7, typicalVolatility: 0.55, typicalDrawdown: 0.65 },
    highlights: ['Weather and storage driven', '1 token ≈ 2.5 MMBtu', 'Very high historical volatility'],
    color: '#4E8FD9',
    icon: 'flame',
  },
  {
    id: 'vcpr',
    tokenId: 6,
    symbol: 'vCPR',
    name: 'Copper Cathode Pool',
    category: 'industrial-metals',
    kind: 'market-referenced',
    tagline: 'A sample 20-tonne copper pool split into 20,000 tokens.',
    description:
      'An educational pool referencing 20 metric tons of copper — a bellwether for construction, electrification and global growth. Each token represents an illustrative 1 kg share.',
    methodology: `Sample asset value = 20 metric tons × copper reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'COPPER', quantity: 20, quantityUnit: 'metric tons' },
    totalSupply: 20_000,
    sampleIssued: 9_870,
    minInvestment: 11,
    onchainPrice: 11,
    risk: { liquidity: 3, structure: 5, macro: 6, typicalVolatility: 0.22, typicalDrawdown: 0.4 },
    highlights: ['1 token ≈ 1 kg of the sample pool', 'Linked to global growth and electrification', 'Reference data may be monthly'],
    color: '#C07A4E',
    icon: 'copper',
  },
  {
    id: 'valu',
    tokenId: 7,
    symbol: 'vALU',
    name: 'Aluminium Ingot Pool',
    category: 'industrial-metals',
    kind: 'market-referenced',
    tagline: 'A sample 40-tonne aluminium pool split into 11,000 tokens.',
    description:
      'An educational pool referencing 40 metric tons of aluminium, an energy-intensive metal used in transport, packaging and construction.',
    methodology: `Sample asset value = 40 metric tons × aluminium reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'ALUMINIUM', quantity: 40, quantityUnit: 'metric tons' },
    totalSupply: 11_000,
    sampleIssued: 3_020,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 4, structure: 5, macro: 6, typicalVolatility: 0.2, typicalDrawdown: 0.4 },
    highlights: ['Energy costs drive production economics', '1 token ≈ 3.6 kg', 'Reference data may be monthly'],
    color: '#8FA3B8',
    icon: 'factory',
  },
  {
    id: 'vcof',
    tokenId: 8,
    symbol: 'vCOF',
    name: 'Arabica Coffee Lot',
    category: 'agriculture',
    kind: 'market-referenced',
    tagline: 'A sample 37,500 lb coffee lot split into 15,000 tokens.',
    description:
      'An educational lot referencing 37,500 lb of arabica coffee (the size of one standard exchange contract). Weather in Brazil and Colombia, crop disease and currency moves can swing prices sharply.',
    methodology: `Sample asset value = 37,500 lb × arabica reference price (converted from US cents to dollars). ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'COFFEE', quantity: 37500, quantityUnit: 'lb' },
    totalSupply: 15_000,
    sampleIssued: 5_560,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 5, structure: 6, macro: 6, typicalVolatility: 0.35, typicalDrawdown: 0.55 },
    highlights: ['Weather and harvest driven', '1 token ≈ 2.5 lb', 'Perishable, quality-graded commodity'],
    color: '#8C5E3C',
    icon: 'coffee',
  },
  {
    id: 'vwht',
    tokenId: 9,
    symbol: 'vWHT',
    name: 'Wheat Silo Sample',
    category: 'agriculture',
    kind: 'market-referenced',
    tagline: 'A sample 500-tonne wheat silo split into 11,500 tokens.',
    description:
      'An educational sample referencing 500 metric tons of wheat. Wheat prices respond to harvest forecasts, export policies and geopolitical disruption in major growing regions.',
    methodology: `Sample asset value = 500 metric tons × wheat reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'WHEAT', quantity: 500, quantityUnit: 'metric tons' },
    totalSupply: 11_500,
    sampleIssued: 6_330,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 4, structure: 6, macro: 6, typicalVolatility: 0.28, typicalDrawdown: 0.5 },
    highlights: ['Harvest and export-policy driven', '1 token ≈ 43 kg', 'Reference data may be monthly'],
    color: '#C9A75A',
    icon: 'wheat',
  },
  {
    id: 'vust10',
    tokenId: 10,
    symbol: 'vUST10',
    name: 'US Treasury 10Y Sample Note',
    category: 'bonds',
    kind: 'simulated',
    tagline: 'A sample $1M, 4.25% 10-year note split into 100,000 tokens.',
    description:
      'An educational tokenised-bond sample: a fictional $1,000,000 note with a 4.25% semi-annual coupon maturing in November 2035. Its illustrative price is calculated from the live 10-year Treasury yield, so you can see the price–yield relationship in action.',
    methodology:
      'Illustrative clean price = present value of remaining coupons and principal, discounted at the live 10-year Treasury yield. Sample value = face value × price ÷ 100. Token price = sample value ÷ 100,000 tokens. No real bond is held and no coupons are paid.',
    pricing: {
      kind: 'bond',
      yieldInstrumentId: 'UST10Y',
      faceValue: 1_000_000,
      couponRate: 0.0425,
      maturity: '2035-11-15',
      paymentsPerYear: 2,
      spreadBps: 0,
      fallbackYield: 4.05,
    },
    totalSupply: 100_000,
    sampleIssued: 61_200,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 2, structure: 5, macro: 5, typicalVolatility: 0.07, typicalDrawdown: 0.2 },
    highlights: ['Price moves inversely to yields', '1 token = $10 face value', 'Coupons are illustrative only'],
    assumptions: ['Coupon 4.25% paid semi-annually (illustrative; not paid out)', 'Priced at the live 10-year Treasury yield, no spread'],
    color: '#527BFF',
    icon: 'landmark',
  },
  {
    id: 'vigc',
    tokenId: 11,
    symbol: 'vIGC',
    name: 'Investment-Grade Credit Basket',
    category: 'bonds',
    kind: 'simulated',
    tagline: 'A sample $500k corporate bond basket split into 50,000 tokens.',
    description:
      'An educational sample representing a fictional basket of investment-grade corporate bonds with a 5% coupon maturing in mid-2032. Its illustrative price is calculated from the live ICE BofA US Corporate Index effective yield.',
    methodology:
      'Illustrative clean price = present value of remaining cash flows discounted at the live US investment-grade corporate effective yield. Token price = (face value × price ÷ 100) ÷ 50,000 tokens. The basket and its issuers are fictional.',
    pricing: {
      kind: 'bond',
      yieldInstrumentId: 'IGYIELD',
      faceValue: 500_000,
      couponRate: 0.05,
      maturity: '2032-06-30',
      paymentsPerYear: 2,
      spreadBps: 0,
      fallbackYield: 4.8,
    },
    totalSupply: 50_000,
    sampleIssued: 18_900,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 4, structure: 5, macro: 5, typicalVolatility: 0.08, typicalDrawdown: 0.22 },
    highlights: ['Credit and interest-rate risk', '1 token = $10 face value', 'Fictional issuers'],
    assumptions: ['5.00% coupon, semi-annual (illustrative)', 'Priced at the live IG corporate effective yield'],
    color: '#7B93FF',
    icon: 'briefcase',
  },
  {
    id: 'vres',
    tokenId: 12,
    symbol: 'vRES',
    name: 'Urban Residential Portfolio',
    category: 'real-estate',
    kind: 'simulated',
    tagline: 'A simulated $2.4M residential portfolio split into 240,000 tokens.',
    description:
      'A fully simulated fractional real-estate sample: a fictional portfolio of city apartments with a fixed illustrative valuation. It exists to show how fractional property structures work — and the illiquidity, valuation and legal-title risks they carry.',
    methodology:
      'Sample asset value is a fixed illustrative valuation of $2,400,000 (no appraisal, no real property). Token price = $2,400,000 ÷ 240,000 tokens = $10. In real products, investors usually hold shares of a special-purpose vehicle (SPV), not the property deed.',
    pricing: { kind: 'fixed', value: 2_400_000, valuationNote: 'Fixed illustrative valuation — simulated asset' },
    totalSupply: 240_000,
    sampleIssued: 151_000,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 9, structure: 8, macro: 6, typicalVolatility: 0.18, typicalDrawdown: 0.35 },
    highlights: ['Fully simulated asset', 'Illiquid by nature', 'Ownership via SPV in real-world structures'],
    assumptions: ['Fixed valuation of $2.4M; it does not change with any market', 'Illustrative gross rental yield assumption: 4.0% (not paid)', 'Illustrative occupancy assumption: 94%'],
    color: '#25C997',
    icon: 'home',
  },
  {
    id: 'vlog',
    tokenId: 13,
    symbol: 'vLOG',
    name: 'Logistics Warehouse',
    category: 'real-estate',
    kind: 'simulated',
    tagline: 'A simulated $5M logistics warehouse split into 250,000 tokens.',
    description:
      'A fully simulated commercial-property sample: a fictional single-tenant logistics warehouse. Single-tenant assets show concentration risk clearly — one lease decides most of the income.',
    methodology:
      'Sample asset value is a fixed illustrative valuation of $5,000,000. Token price = $5,000,000 ÷ 250,000 tokens = $20. No real property, lease or tenant exists.',
    pricing: { kind: 'fixed', value: 5_000_000, valuationNote: 'Fixed illustrative valuation — simulated asset' },
    totalSupply: 250_000,
    sampleIssued: 88_400,
    minInvestment: 20,
    onchainPrice: 20,
    risk: { liquidity: 9, structure: 8, macro: 6, typicalVolatility: 0.2, typicalDrawdown: 0.4 },
    highlights: ['Fully simulated asset', 'Single-tenant concentration risk', '1 token = $20 illustrative'],
    assumptions: ['Fixed valuation of $5M', 'Illustrative net lease yield assumption: 5.5% (not paid)', 'Single fictional tenant on a 7-year lease'],
    color: '#2FB5A5',
    icon: 'warehouse',
  },
  {
    id: 'vbtc',
    tokenId: 14,
    symbol: 'vBTC',
    name: 'Bitcoin Index Unit',
    category: 'digital-assets',
    kind: 'market-referenced',
    tagline: 'A sample 1 BTC reference split into 11,000 tokens.',
    description:
      'An educational sample referencing 1 bitcoin. Each token represents an illustrative 1/11,000 BTC share of the sample, so its illustrative value moves with the BTC/USD price — including its large swings.',
    methodology: `Sample asset value = 1 BTC × live BTC/USD reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'BTC', quantity: 1, quantityUnit: 'BTC' },
    totalSupply: 11_000,
    sampleIssued: 7_150,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 2, structure: 4, macro: 7, typicalVolatility: 0.55, typicalDrawdown: 0.75 },
    highlights: ['Trades 24/7', 'Very high historical volatility', '1 token ≈ 0.0000909 BTC'],
    color: '#F2A93B',
    icon: 'bitcoin',
  },
  {
    id: 'veth',
    tokenId: 15,
    symbol: 'vETH',
    name: 'Ether Index Unit',
    category: 'digital-assets',
    kind: 'market-referenced',
    tagline: 'A sample 25 ETH reference split into 10,000 tokens.',
    description:
      'An educational sample referencing 25 ether. Ether powers the Ethereum network that this prototype’s smart contracts run on (on a testnet). Each token represents an illustrative 0.0025 ETH share.',
    methodology: `Sample asset value = 25 ETH × live ETH/USD reference price. ${COMMON_METHOD}`,
    pricing: { kind: 'reference', instrumentId: 'ETH', quantity: 25, quantityUnit: 'ETH' },
    totalSupply: 10_000,
    sampleIssued: 4_480,
    minInvestment: 10,
    onchainPrice: 10,
    risk: { liquidity: 2, structure: 5, macro: 8, typicalVolatility: 0.7, typicalDrawdown: 0.8 },
    highlights: ['Network-usage and sentiment driven', 'Trades 24/7', '1 token ≈ 0.0025 ETH'],
    color: '#8A9BFF',
    icon: 'ethereum',
  },
];

export const ASSET_MAP: Record<string, TokenisedAsset> = Object.fromEntries(TOKENISED_ASSETS.map((a) => [a.id, a]));

export function getAsset(id: string): TokenisedAsset | undefined {
  return ASSET_MAP[id];
}

export function getAssetByTokenId(tokenId: number): TokenisedAsset | undefined {
  return TOKENISED_ASSETS.find((a) => a.tokenId === tokenId);
}

/** Market instruments an asset depends on (for fetching quotes/history). */
export function assetReferenceInstrument(asset: TokenisedAsset): string | null {
  switch (asset.pricing.kind) {
    case 'reference':
      return asset.pricing.instrumentId;
    case 'bond':
      return asset.pricing.yieldInstrumentId;
    case 'fixed':
      return null;
  }
}

/** On-chain fields consumed by the Hardhat deploy script (see data/onchain-assets.json). */
export interface OnchainAssetDefinition {
  tokenId: number;
  symbol: string;
  name: string;
  category: string;
  maxSupply: number;
  price: number;
}

export function onchainAssetDefinitions(): OnchainAssetDefinition[] {
  return TOKENISED_ASSETS.map((a) => ({
    tokenId: a.tokenId,
    symbol: a.symbol,
    name: a.name,
    category: CATEGORY_LABELS[a.category],
    maxSupply: a.totalSupply,
    price: a.onchainPrice,
  }));
}
