import type { AssetCategory, InstrumentClass } from './types';

/**
 * Curated educational knowledge base used to ground VESTORA Intelligence.
 * Content is general education, written for beginners. Historical figures are
 * approximate and describe the past only — they are not forecasts.
 */
export interface KnowledgeProfile {
  name: string;
  whatIs: string;
  valueSource: string;
  priceFactors: string[];
  risks: string[];
  volatility: string;
  beginnerNotes: string[];
  downside: string[];
  bull: string;
  bear: string;
  questions: string[];
}

type PartialProfile = Partial<KnowledgeProfile> & { name: string };

const TOKEN_NOTE =
  'On VESTORA, a token only represents an illustrative share of a sample pool on a testnet. It is not a claim on any real commodity, and real tokenised products add issuer, custody and legal risks on top of the asset’s own price risk.';

export const CLASS_PROFILES: Record<InstrumentClass | 'bonds' | 'real-estate', KnowledgeProfile> = {
  'precious-metals': {
    name: 'Precious metals',
    whatIs: 'Precious metals such as gold, silver, platinum and palladium are scarce physical commodities used for jewellery, industry and as stores of value.',
    valueSource:
      'They produce no cash flow. Their value comes from what other buyers will pay — driven by industrial demand, jewellery demand and their long-standing role as a store of value.',
    priceFactors: ['Real (inflation-adjusted) interest rates', 'Strength of the US dollar', 'Central-bank and investor demand', 'Industrial demand and mine supply', 'Geopolitical stress and risk sentiment'],
    risks: ['Price volatility over months and years', 'No income — returns come only from price changes', 'Custody and storage risk for physical-backed products', 'Tokens can trade away from the metal’s spot price'],
    volatility: 'Precious metals are generally less volatile than crypto-assets but can still move by double-digit percentages in a year, and they have had multi-year declines.',
    beginnerNotes: ['A “safe haven” is not the same as “cannot fall”.', 'Because metals pay no yield, holding them has an opportunity cost when interest rates are high.', TOKEN_NOTE],
    downside: ['Rising real interest rates', 'A strengthening US dollar', 'Investors selling safe-haven assets when fear fades', 'Weaker industrial or jewellery demand'],
    bull: 'If inflation worries, central-bank buying or geopolitical stress increase demand while supply stays tight, prices could rise.',
    bear: 'If real interest rates rise and investors rotate into income-producing assets, prices could fall for an extended period.',
    questions: ['Why do interest rates matter for gold?', 'What does a 15% drawdown mean?', 'Does owning a gold token mean I own gold?'],
  },
  energy: {
    name: 'Energy commodities',
    whatIs: 'Energy commodities such as crude oil, natural gas and gasoline are fuels traded globally, mainly through futures contracts.',
    valueSource: 'Their value comes from physical demand for transport, heating, power and industry, balanced against production, storage and transport capacity.',
    priceFactors: ['Global economic growth and travel demand', 'Production decisions (e.g. OPEC+) and shale output', 'Inventories and storage levels', 'Weather and seasonal demand', 'Geopolitical disruption and sanctions', 'The energy transition and policy'],
    risks: ['Very large price swings', 'Futures “roll” costs and contango for real investment products', 'Event risk from conflicts, sanctions and supply outages', 'Long-term demand uncertainty'],
    volatility: 'Energy is among the most volatile commodity groups. Annualised volatility has often been 30–50% for oil and higher for natural gas, with extreme spikes in crises.',
    beginnerNotes: ['Prices can fall as quickly as they rise.', 'Most investors gain energy exposure through futures, which behave differently from owning barrels.', TOKEN_NOTE],
    downside: ['Recession fears cutting demand', 'Producers increasing supply', 'Inventories building up', 'Mild weather reducing heating demand'],
    bull: 'Supply disruptions, production cuts or strong demand growth could tighten the market and lift prices.',
    bear: 'Slowing growth, higher output or faster adoption of alternatives could leave the market oversupplied and push prices down.',
    questions: ['What affects crude oil prices?', 'What happens if commodity prices fall?', 'Why is natural gas so volatile?'],
  },
  'industrial-metals': {
    name: 'Industrial metals',
    whatIs: 'Industrial (base) metals such as copper, aluminium, nickel, zinc, lead and tin are raw materials for construction, manufacturing, power grids and batteries.',
    valueSource: 'Their value comes from industrial demand weighed against mine supply, smelting capacity and inventories.',
    priceFactors: ['Global growth, especially construction and manufacturing in China', 'Electrification and energy-transition demand', 'Mine disruptions and smelter output', 'Energy costs (especially for aluminium)', 'Trade policy and tariffs'],
    risks: ['Highly cyclical demand', 'Exposure to a few large consuming economies', 'Supply shocks and policy changes', 'Storage and quality issues for physical metal'],
    volatility: 'Base metals are typically moderately volatile (often around 15–30% a year) but can fall sharply in recessions.',
    beginnerNotes: ['These metals are closely tied to the economic cycle.', 'Some reference data is published monthly, so moves can look smoother than daily trading.', TOKEN_NOTE],
    downside: ['A global slowdown or property downturn', 'New mine supply coming online', 'Trade restrictions reducing demand'],
    bull: 'Strong infrastructure, grid and electric-vehicle demand combined with constrained supply could support prices.',
    bear: 'A manufacturing slowdown or surplus supply could push prices lower.',
    questions: ['Why is copper called “Dr. Copper”?', 'What happens if commodity prices fall?', 'How do I read monthly vs daily data?'],
  },
  agriculture: {
    name: 'Agricultural commodities',
    whatIs: 'Agricultural (soft and grain) commodities such as wheat, corn, soybeans, coffee, cocoa, sugar and cotton are grown, harvested and traded globally.',
    valueSource: 'Their value comes from food, feed, fuel and fibre demand balanced against harvests, stocks and trade flows.',
    priceFactors: ['Weather, droughts and floods', 'Harvest forecasts and crop disease', 'Export policies and trade restrictions', 'Input costs such as fertiliser and fuel', 'Currency moves in producing countries'],
    risks: ['Weather-driven supply shocks', 'Seasonality', 'Perishability and quality grading for physical goods', 'Policy intervention (export bans, quotas)'],
    volatility: 'Agricultural prices often run 20–40% annualised volatility, with sudden jumps when harvests disappoint.',
    beginnerNotes: ['One bad season in a major growing region can move global prices.', 'Physical agricultural goods are costly to store and can spoil.', TOKEN_NOTE],
    downside: ['Bumper harvests', 'Rising stockpiles', 'Weaker demand or easing trade restrictions'],
    bull: 'Poor weather or disease in key regions could cut supply and lift prices.',
    bear: 'Good harvests and high inventories could keep prices under pressure.',
    questions: ['Why is coffee so volatile?', 'What happens if commodity prices fall?', 'How does weather affect prices?'],
  },
  'digital-assets': {
    name: 'Digital assets',
    whatIs: 'Crypto-assets such as bitcoin, ether, solana and XRP are digital tokens recorded on public blockchains.',
    valueSource:
      'They generally produce no cash flow. Their value comes from network adoption, utility (such as paying transaction fees), scarcity rules and market sentiment.',
    priceFactors: ['Adoption and network activity', 'Global liquidity and risk appetite', 'Regulation and enforcement actions', 'Flows into and out of investment products', 'Security incidents and technology changes'],
    risks: ['Extreme volatility', 'Regulatory uncertainty', 'Hacks, scams and smart-contract failures', 'Loss of keys means permanent loss', 'Market structure and exchange failures'],
    volatility: 'Crypto-assets are among the most volatile assets available. Annualised volatility has often been 50–80%+, and declines of 70–80% have happened more than once.',
    beginnerNotes: ['Only risk money you can afford to lose entirely.', 'Markets trade 24/7, so prices can move while you sleep.', TOKEN_NOTE],
    downside: ['Tighter global liquidity', 'Adverse regulation', 'Large hacks or exchange failures', 'Falling adoption or sentiment'],
    bull: 'Growing adoption, new investment products and supportive regulation could increase demand.',
    bear: 'Regulatory crackdowns, security failures or a risk-off market could trigger deep declines.',
    questions: ['Why is bitcoin so volatile?', 'What does a 15% drawdown mean?', 'What is a testnet token?'],
  },
  rates: {
    name: 'Interest rates and bonds',
    whatIs: 'Treasury and corporate yields show the annual return investors demand to lend money to governments and companies.',
    valueSource: 'Bonds pay interest (coupons) and return principal at maturity. Their market price moves inversely to yields.',
    priceFactors: ['Central-bank policy rates', 'Inflation and inflation expectations', 'Economic growth', 'Government borrowing needs', 'Credit spreads for corporate issuers'],
    risks: ['Interest-rate risk: prices fall when yields rise', 'Inflation risk: fixed coupons buy less over time', 'Credit/default risk for corporate issuers', 'Reinvestment and liquidity risk'],
    volatility: 'High-quality bonds are usually much less volatile than stocks or commodities, but long-dated bonds can still lose a lot when yields jump.',
    beginnerNotes: ['Price and yield move in opposite directions.', 'The longer the maturity, the more a bond’s price reacts to yield changes (duration).', TOKEN_NOTE],
    downside: ['Rising yields', 'Higher-than-expected inflation', 'Credit downgrades or defaults (for corporate bonds)'],
    bull: 'If inflation cools and central banks cut rates, yields could fall and bond prices rise.',
    bear: 'If inflation proves sticky and yields rise, bond prices could fall, especially for long maturities.',
    questions: ['How do bonds work?', 'Why do bond prices fall when yields rise?', 'What is duration?'],
  },
  indices: {
    name: 'Stock market indices',
    whatIs: 'Stock indices such as the S&P 500 track the combined value of a basket of listed companies.',
    valueSource: 'Index values reflect company earnings expectations and the price investors are willing to pay for them.',
    priceFactors: ['Corporate earnings', 'Interest rates', 'Economic growth', 'Investor sentiment'],
    risks: ['Market-wide declines', 'Valuation risk', 'Concentration in a few large companies'],
    volatility: 'Broad stock indices have historically had annualised volatility around 15–20%, with occasional bear markets of 30–50%.',
    beginnerNotes: ['Indices are shown on VESTORA as market context only.', TOKEN_NOTE],
    downside: ['Recession', 'Rising interest rates', 'Earnings disappointments'],
    bull: 'Strong earnings growth and falling rates could support higher index levels.',
    bear: 'A recession or valuation reset could lead to significant declines.',
    questions: ['What does a 15% drawdown mean?', 'How are commodities different from stocks?'],
  },
  bonds: {
    name: 'Tokenised bonds',
    whatIs: 'A tokenised bond is a digital token that represents an interest in a bond or a pool of bonds held by an issuer or custodian.',
    valueSource:
      'The underlying bond pays periodic interest (coupons) and repays face value at maturity. The token’s value depends on the bond’s market price and on the issuer correctly passing through payments.',
    priceFactors: ['Market interest rates (price moves inversely to yields)', 'Time to maturity (duration)', 'Credit quality of the borrower', 'Inflation expectations', 'Liquidity of the token itself'],
    risks: ['Interest-rate risk', 'Credit/default risk (for non-government issuers)', 'Inflation eroding fixed coupons', 'Smart-contract, custodian and issuer risk in the token wrapper', 'Thin secondary markets for the token'],
    volatility:
      'A 10-year US Treasury note’s price usually moves a few percent in a typical year. In 2020–2023, however, yields rose from about 0.5% to about 5%, and long-dated bonds suffered unusually large losses.',
    beginnerNotes: ['“Low risk” does not mean “no risk”: bond prices can fall before maturity.', 'Duration tells you roughly how much the price changes when yields move 1 percentage point.', TOKEN_NOTE],
    downside: ['Yields rising', 'The issuer’s credit quality deteriorating', 'The token issuer failing or mishandling payments'],
    bull: 'If yields fall, existing bonds with higher coupons become more valuable and prices rise.',
    bear: 'If yields rise, prices fall — the longer the maturity, the bigger the drop.',
    questions: ['How do bonds work?', 'What is duration?', 'What happens to my token if yields rise 1%?'],
  },
  'real-estate': {
    name: 'Tokenised real estate',
    whatIs:
      'Tokenised real estate splits economic interests in a property — usually via shares of a special-purpose vehicle (SPV) that owns it — into digital tokens.',
    valueSource: 'Property value comes from rental income and the price buyers will pay for the building, minus costs such as maintenance, taxes, insurance and management fees.',
    priceFactors: ['Interest and mortgage rates', 'Local rental demand and vacancies', 'Construction and maintenance costs', 'Local regulation, zoning and taxes', 'Appraisal methods and frequency'],
    risks: [
      'Illiquidity: there may be no buyer when you want to sell',
      'Legal title: token holders typically own SPV shares, not the deed',
      'Valuation lag: appraisals can hide price falls',
      'Tenant, vacancy and maintenance risk',
      'Platform, issuer and smart-contract risk',
    ],
    volatility:
      'Listed property (REITs) can be about as volatile as stocks — US REITs fell roughly 70% between 2007 and 2009. Private property looks smoother only because it is appraised infrequently.',
    beginnerNotes: ['A token is not a deed. Rights depend entirely on the legal structure behind it.', 'Smooth-looking valuations can understate risk.', TOKEN_NOTE],
    downside: ['Rising interest rates lowering property values', 'Vacancies or tenant defaults', 'Unexpected repair costs', 'Forced sales in a weak market'],
    bull: 'Strong rental demand, limited supply and falling interest rates could lift property values and income.',
    bear: 'Higher rates, rising vacancies or local oversupply could reduce values — and an illiquid token may be hard to exit.',
    questions: ['What are the risks of tokenised real estate?', 'Does owning the token mean I legally own the property?', 'What is an SPV?'],
  },
};

/** Instrument-specific refinements merged over the class profile. */
const INSTRUMENT_OVERRIDES: Record<string, PartialProfile> = {
  XAU: {
    name: 'Gold',
    whatIs: 'Gold is a scarce precious metal that has served as money, jewellery and a store of value for thousands of years. Central banks hold it as a reserve asset.',
    valueSource: 'Gold produces no income. Its value comes from demand — central banks, investors, jewellery and some industrial use — relative to slowly growing above-ground supply.',
    volatility:
      'Gold’s annualised volatility has often been around 13–17% — lower than most stocks, but not low. It fell roughly 45% between its 2011 peak and its 2015 low.',
    bull: 'If real interest rates fall, the dollar weakens, or central banks keep buying, demand for gold could rise.',
    bear: 'If real interest rates rise and safe-haven demand fades, gold could decline for years, as it did after 2011.',
    questions: ['Is gold a risky investment?', 'Why is silver more volatile than gold?', 'Does owning a gold token mean I own gold?'],
  },
  XAG: {
    name: 'Silver',
    whatIs: 'Silver is a precious metal with a split personality: roughly half of demand is industrial (electronics, solar panels), the rest is jewellery, silverware and investment.',
    valueSource: 'Silver produces no income. Its value depends on both industrial demand and investor appetite for precious metals.',
    volatility:
      'Silver is typically about twice as volatile as gold (often 25–35% a year). It fell more than 70% from its 2011 high to its 2020 low.',
    questions: ['Why is silver more volatile than gold?', 'How does solar demand affect silver?', 'What does a 15% drawdown mean?'],
  },
  XPT: {
    name: 'Platinum',
    whatIs: 'Platinum is a rare precious metal used heavily in vehicle catalytic converters, industry and jewellery. Most supply comes from South Africa.',
    volatility: 'Platinum’s annualised volatility is often 20–30%. It traded far below its 2008 peak for well over a decade.',
    questions: ['Why does platinum depend on the car industry?', 'What could cause platinum to fall?'],
  },
  XPD: {
    name: 'Palladium',
    whatIs: 'Palladium is a rare precious metal used mostly in petrol-engine catalytic converters; supply is concentrated in Russia and South Africa.',
    volatility: 'Palladium has been one of the most volatile metals, with large booms and busts tied to auto demand and supply concentration.',
  },
  WTI: {
    name: 'Crude oil (WTI)',
    whatIs: 'West Texas Intermediate (WTI) is the main US crude oil benchmark, delivered at Cushing, Oklahoma.',
    volatility:
      'Oil’s annualised volatility has often been 30–50%. In April 2020, as storage filled up, the front-month WTI futures contract briefly settled below zero.',
    questions: ['What affects crude oil prices?', 'Why did oil go negative in 2020?', 'What is futures roll cost?'],
  },
  BRENT: {
    name: 'Brent crude',
    whatIs: 'Brent is the main international crude oil benchmark, based on North Sea oil, and prices a large share of the world’s crude trade.',
    volatility: 'Brent typically moves closely with WTI, with annualised volatility often in the 30–50% range.',
    questions: ['What affects crude oil prices?', 'What is the difference between WTI and Brent?'],
  },
  NATGAS: {
    name: 'Natural gas',
    whatIs: 'Henry Hub natural gas is the main US gas benchmark. Gas is used for heating, electricity generation and industry, and increasingly exported as LNG.',
    volatility:
      'Natural gas is one of the most volatile major commodities, frequently above 50% annualised. Henry Hub prices more than doubled in 2022 and then fell sharply in 2023.',
    questions: ['Why is natural gas so volatile?', 'How does weather affect gas prices?'],
  },
  GASOLINE: { name: 'Gasoline', whatIs: 'Gasoline is a refined fuel; its price reflects crude oil costs plus refining margins, seasonal blends and driving demand.' },
  COPPER: {
    name: 'Copper',
    whatIs: 'Copper is a highly conductive metal used in wiring, construction, electronics and electric vehicles. It is often called “Dr. Copper” because demand tracks the economy.',
    volatility: 'Copper’s annualised volatility is often around 20–25%. It fell by more than 60% during the 2008 financial crisis.',
    questions: ['Why is copper called “Dr. Copper”?', 'How does electrification affect copper?'],
  },
  ALUMINIUM: {
    name: 'Aluminium',
    whatIs: 'Aluminium is a light, versatile metal used in transport, packaging and construction. Producing it requires large amounts of electricity.',
    volatility: 'Aluminium has typically been moderately volatile (around 15–25% a year), with energy-cost shocks driving sharp moves.',
  },
  NICKEL: { name: 'Nickel', whatIs: 'Nickel is used mainly in stainless steel and increasingly in electric-vehicle batteries; Indonesia is now the dominant producer.', volatility: 'Nickel can be extremely volatile — in March 2022 the LME suspended nickel trading after prices spiked.' },
  ZINC: { name: 'Zinc', whatIs: 'Zinc is used mainly to galvanise steel against corrosion, so demand follows construction and infrastructure.' },
  LEAD: { name: 'Lead', whatIs: 'Lead is used mostly in lead-acid batteries, much of it recycled, which makes supply comparatively stable.' },
  TIN: { name: 'Tin', whatIs: 'Tin is used mainly in solder for electronics; its small market and concentrated supply can cause sharp price moves.' },
  WHEAT: {
    name: 'Wheat',
    whatIs: 'Wheat is one of the world’s most important food grains, grown across the US, Europe, Russia, Ukraine, Australia and elsewhere.',
    volatility: 'Wheat often has annualised volatility of 25–35%. Prices spiked in early 2022 after Russia’s invasion of Ukraine and later retraced.',
    questions: ['How do export bans affect wheat?', 'What happens if commodity prices fall?'],
  },
  CORN: { name: 'Corn', whatIs: 'Corn (maize) is used for animal feed, food and ethanol fuel; the US is the largest producer.' },
  SOYBEANS: { name: 'Soybeans', whatIs: 'Soybeans are crushed into animal feed and vegetable oil; Brazil and the US dominate exports and China is the largest buyer.' },
  COFFEE: {
    name: 'Coffee (arabica)',
    whatIs: 'Arabica coffee is the higher-grade coffee bean, grown mainly in Brazil, Colombia and Central America.',
    volatility: 'Coffee often has annualised volatility of 30–40%. Arabica reached multi-decade highs in 2024–2025 on Brazilian supply worries.',
    questions: ['Why is coffee so volatile?', 'How does Brazil’s weather affect coffee?'],
  },
  COCOA: { name: 'Cocoa', whatIs: 'Cocoa beans are grown mainly in Côte d’Ivoire and Ghana; concentrated supply makes prices sensitive to weather and crop disease.', volatility: 'Cocoa prices have been exceptionally volatile recently, setting record highs in 2024 amid poor West African harvests.' },
  SUGAR: { name: 'Sugar', whatIs: 'Raw sugar (No. 11) is produced mainly from cane in Brazil and India; ethanol policy in Brazil also affects supply.' },
  COTTON: { name: 'Cotton', whatIs: 'Cotton is a natural fibre for textiles; prices depend on harvests in the US, India, China and Brazil and on clothing demand.' },
  BTC: {
    name: 'Bitcoin',
    whatIs: 'Bitcoin is the first and largest crypto-asset: a decentralised digital currency with a supply capped at 21 million coins.',
    valueSource: 'Bitcoin produces no cash flow. Its value rests on scarcity, network security and adoption — essentially, on what others will pay.',
    volatility: 'Bitcoin’s annualised volatility has often been 50–80%. It fell about 84% in 2018 and about 77% in 2022 from prior peaks.',
    questions: ['Why is bitcoin so volatile?', 'What does a 15% drawdown mean?', 'What could cause bitcoin to fall?'],
  },
  ETH: {
    name: 'Ethereum',
    whatIs: 'Ether is the native asset of Ethereum, a blockchain that runs smart contracts. Ether is used to pay transaction (gas) fees.',
    valueSource: 'Ether’s value is linked to demand for Ethereum block space, staking, its supply policy and market sentiment.',
    volatility: 'Ether has historically been even more volatile than bitcoin — it fell more than 90% in 2018 and roughly 80% in 2022.',
    questions: ['What is a smart contract?', 'Why are gas fees paid in ETH?', 'What is a testnet?'],
  },
  SOL: { name: 'Solana', whatIs: 'Solana is a high-throughput smart-contract blockchain; SOL pays fees and is used for staking.', volatility: 'SOL has been extremely volatile, falling more than 90% in 2022 before recovering.' },
  XRP: { name: 'XRP', whatIs: 'XRP is the native asset of the XRP Ledger, designed for payments and settlement.', volatility: 'XRP has been highly volatile and has been shaped by regulatory developments in the US.' },
  PAXG: {
    name: 'PAX Gold',
    whatIs: 'PAX Gold (PAXG) is a real-world tokenised commodity: each token is designed to represent one fine troy ounce of gold held in custody by its issuer.',
    valueSource: 'Its value should track gold, but it also depends on the issuer, the custodian and the token’s own market liquidity.',
    volatility: 'PAXG’s price mostly follows gold, though it can trade at a small premium or discount, especially in stressed crypto markets.',
    questions: ['How is a tokenised gold product different from VESTORA’s sample tokens?', 'What is custody risk?'],
  },
  UST10Y: {
    name: '10-year US Treasury',
    whatIs: 'The 10-year Treasury yield is the annual return on 10-year US government debt — a benchmark for mortgages and global borrowing costs.',
    volatility: 'Yields rose from about 0.5% in 2020 to about 5% in 2023, one of the sharpest increases in decades, causing large price falls for existing bonds.',
  },
  IGYIELD: {
    name: 'Investment-grade corporate bonds',
    whatIs: 'Investment-grade corporate bonds are loans to financially strong companies. Their yield = government yield + a credit spread.',
    volatility: 'Broad US investment-grade corporate bond indices lost roughly 15% in 2022 as yields rose.',
  },
};

/** Category profiles for marketplace categories that are not market instruments. */
export function categoryProfile(category: AssetCategory): KnowledgeProfile {
  if (category === 'bonds') return CLASS_PROFILES.bonds;
  if (category === 'real-estate') return CLASS_PROFILES['real-estate'];
  return CLASS_PROFILES[category];
}

export function instrumentProfile(instrumentId: string, cls: InstrumentClass): KnowledgeProfile {
  const base = CLASS_PROFILES[cls];
  const o = INSTRUMENT_OVERRIDES[instrumentId];
  if (!o) return base;
  return { ...base, ...o, questions: o.questions ?? base.questions };
}

/* ----------------------------------------------------------------------------
 * Concept explainers
 * ------------------------------------------------------------------------- */

export interface ConceptEntry {
  id: string;
  title: string;
  summary: string;
  sections: { heading: string; body: string }[];
  insights: string[];
  followUps: string[];
}

export const CONCEPTS: Record<string, ConceptEntry> = {
  fractional: {
    id: 'fractional',
    title: 'What is fractional ownership?',
    summary: 'Fractional ownership splits an expensive asset into many smaller units so people can take part with a small amount of money.',
    sections: [
      { heading: 'The idea', body: 'Instead of buying a whole gold bar or building, many people each hold a small share of it. Each share is worth a proportional slice of the total.' },
      {
        heading: 'Worked example',
        body: 'If a sample asset is valued at $100,000 and divided into 10,000 tokens, each token represents an illustrative $10. With $50 you could hold 5 tokens — 0.05% of the sample.',
      },
      {
        heading: 'What it does not change',
        body: 'Fractions lower the minimum ticket size; they do not lower the risk of the underlying asset. If the asset’s value falls 10%, every fraction falls 10% too.',
      },
      {
        heading: 'Real-world catch',
        body: 'In real products your rights depend on the legal structure (who holds the asset, what you can redeem, who you can sell to). On VESTORA tokens are testnet demonstrations with no legal claim.',
      },
    ],
    insights: ['Smaller tickets make diversification easier, but each fraction carries the same percentage risk as the whole.', 'Always ask: what exactly does one token entitle me to?'],
    followUps: ['What is tokenisation?', 'Does owning a token mean I legally own the asset?', 'What are the risks of tokenised real estate?'],
  },
  tokenisation: {
    id: 'tokenisation',
    title: 'How does tokenised investing work?',
    summary: 'Tokenisation records units of an asset as digital tokens on a blockchain, so ownership records can be transferred and verified like any other token.',
    sections: [
      { heading: '1. An asset is defined', body: 'An issuer defines the asset (e.g. a pool of gold) and how many tokens represent it.' },
      { heading: '2. Tokens are issued', body: 'A smart contract creates the tokens. On VESTORA this is an ERC-1155 contract on a testnet, with one token ID per sample asset.' },
      { heading: '3. Rules are enforced in code', body: 'The contract can enforce rules — for example, VESTORA only lets KYC-approved (simulated) wallets receive asset tokens.' },
      {
        heading: '4. Off-chain trust still matters',
        body: 'For real assets, someone must hold the asset, keep records and honour redemptions. The blockchain proves who holds tokens — not that the asset exists or that you can claim it.',
      },
    ],
    insights: ['A blockchain record is transparent, but it is only as good as the legal and custody arrangements behind it.', 'Smart contracts can have bugs; audits reduce but never remove that risk.'],
    followUps: ['What is smart-contract risk?', 'What is fractional ownership?', 'What is KYC and why is it required?'],
  },
  drawdown: {
    id: 'drawdown',
    title: 'What does a drawdown mean?',
    summary: 'A drawdown is the decline from a peak value to a later low, usually shown as a percentage.',
    sections: [
      { heading: 'Definition', body: 'If an investment peaks at $1,000 and later falls to $850, it has experienced a 15% drawdown.' },
      { heading: 'Why recovery is harder', body: 'Losses and gains are not symmetrical. After a 15% fall you need a gain of about 17.6% just to get back to the peak; after a 50% fall you need +100%.' },
      { heading: 'Maximum drawdown', body: 'The largest drawdown over a period is a simple way to see how painful the worst stretch was. VESTORA uses it as one of five factors in its risk score.' },
      { heading: 'How to use it', body: 'Ask yourself whether you could hold on through a fall of that size without needing to sell. Past drawdowns do not limit future ones.' },
    ],
    insights: ['Volatility tells you how bumpy the ride is; drawdown tells you how deep the potholes have been.'],
    followUps: ['What is volatility?', 'How is the VESTORA risk score calculated?', 'What happens if commodity prices fall?'],
  },
  volatility: {
    id: 'volatility',
    title: 'What is volatility?',
    summary: 'Volatility measures how much an asset’s price tends to move up and down, usually as an annualised percentage.',
    sections: [
      { heading: 'In plain words', body: 'An asset with 15% annual volatility has historically moved within roughly ±15% of its average path in about two-thirds of years — and more in the rest.' },
      { heading: 'How VESTORA measures it', body: 'We take real price history, compute the day-to-day (or month-to-month) percentage changes, and scale their standard deviation to a yearly figure.' },
      { heading: 'Why it matters', body: 'Higher volatility means a wider range of outcomes, including larger losses over short periods.' },
    ],
    insights: ['Volatility is not the same as risk of permanent loss, but highly volatile assets can fall a long way quickly.'],
    followUps: ['What does a 15% drawdown mean?', 'Why is silver more volatile than gold?', 'How is the VESTORA risk score calculated?'],
  },
  bonds: {
    id: 'bonds',
    title: 'How do bonds work?',
    summary: 'A bond is a loan: you lend money to a government or company, receive interest (coupons) and get your money back at maturity — if the borrower pays.',
    sections: [
      { heading: 'Coupon and maturity', body: 'A $1,000 bond with a 4% annual coupon pays $40 a year and returns $1,000 at maturity.' },
      {
        heading: 'Why prices move',
        body: 'If market yields rise to 5%, new bonds pay more, so an existing 4% bond becomes less attractive and its price falls. If yields fall, its price rises.',
      },
      { heading: 'Duration', body: 'Duration estimates how sensitive a bond’s price is to yield changes. A duration of 8 means a 1 percentage-point rise in yields cuts the price by roughly 8%.' },
      { heading: 'Credit risk', body: 'Government bonds of stable countries carry little default risk; corporate bonds pay extra yield for the chance the company cannot pay.' },
    ],
    insights: ['“Safe” bonds can still lose value before maturity when yields rise.', 'VESTORA’s sample notes are priced from live Treasury and corporate yields so you can watch this relationship.'],
    followUps: ['What is duration?', 'What happens to a bond token if yields rise 1%?', 'What is inflation risk?'],
  },
  fall: {
    id: 'fall',
    title: 'What happens if commodity prices fall?',
    summary: 'A token that references a commodity loses value in proportion to the fall in the reference price.',
    sections: [
      { heading: 'Direct effect', body: 'If a sample pool holds 50 oz of gold and gold falls 10%, the pool’s illustrative value falls 10% and so does every token.' },
      { heading: 'Worked example', body: 'Holding 20 tokens priced at $10 = $200. A 10% fall in the reference price → tokens at $9 → $180, an illustrative $20 loss.' },
      { heading: 'Extra risks in real products', body: 'Real tokens can also trade below the value of their backing in a panic, or become hard to sell. Fees and storage costs reduce value further.' },
      { heading: 'No floor', body: 'There is no guaranteed minimum. Prices can keep falling, sometimes for years.' },
    ],
    insights: ['Fractional size changes how much you can lose in dollars, not the percentage you can lose.'],
    followUps: ['What does a 15% drawdown mean?', 'Is gold a risky investment?', 'What is diversification?'],
  },
  legal: {
    id: 'legal',
    title: 'Does owning a token mean I legally own the asset?',
    summary: 'Not automatically. Your rights depend on the legal agreements behind the token — and on VESTORA the tokens carry no legal rights at all.',
    sections: [
      { heading: 'Token ≠ title', body: 'A blockchain records who holds a token. Whether that gives you a claim on gold, a building or a bond depends on contracts, custody arrangements and local law.' },
      { heading: 'Common real-world structures', body: 'Real-estate tokens often represent shares in an SPV that owns the property. Commodity tokens may give a claim on an issuer who holds metal in a vault.' },
      { heading: 'On VESTORA', body: 'All tokens are testnet demonstrations of sample assets. They are not securities, not redeemable and not a claim on any commodity, property or bond.' },
    ],
    insights: ['Before buying any real tokenised asset, read who the issuer is, what you can redeem, and what happens if the issuer fails.'],
    followUps: ['What are the risks of tokenised real estate?', 'What is custody risk?', 'What is tokenisation?'],
  },
  kyc: {
    id: 'kyc',
    title: 'What is KYC and why is it required?',
    summary: 'KYC (“know your customer”) is the identity verification regulated platforms must perform before letting people invest.',
    sections: [
      { heading: 'Purpose', body: 'KYC helps prevent fraud, money laundering and sanctions breaches, and confirms investors are eligible.' },
      { heading: 'On VESTORA', body: 'KYC is simulated. No documents are collected. Approval is recorded as a status in your browser and, on the testnet, as a flag in the ComplianceManager contract — no personal data goes on-chain.' },
      { heading: 'Enforced in code', body: 'The AssetToken contract checks the ComplianceManager before issuing or transferring asset tokens, so an unverified wallet cannot receive them.' },
    ],
    insights: ['This platform is an educational prototype. KYC is simulated and does not constitute actual identity verification or regulatory approval.'],
    followUps: ['What is tokenisation?', 'What is a testnet?', 'What is smart-contract risk?'],
  },
  smartContract: {
    id: 'smartContract',
    title: 'What is smart-contract risk?',
    summary: 'Smart contracts are programs on a blockchain. Bugs, design flaws or compromised admin keys can freeze, steal or mis-record tokens.',
    sections: [
      { heading: 'Code is the rulebook', body: 'Whatever the code allows can happen, even if nobody intended it. Once deployed, code is hard to change.' },
      { heading: 'Admin powers', body: 'Many tokenised-asset contracts include admin roles (e.g. to pause transfers or approve wallets). These help compliance but add trust in whoever holds the keys.' },
      { heading: 'On VESTORA', body: 'The contracts are unaudited teaching examples deployed only to testnets. They use OpenZeppelin libraries and role-based access control.' },
    ],
    insights: ['Audits reduce risk but do not eliminate it.'],
    followUps: ['What is tokenisation?', 'What is a testnet?', 'What is custody risk?'],
  },
  diversification: {
    id: 'diversification',
    title: 'What is diversification?',
    summary: 'Diversification means spreading money across assets that do not all move together, so one bad outcome hurts less.',
    sections: [
      { heading: 'Why it helps', body: 'Gold, oil, bonds and crypto react to different forces. When one falls, another may hold up — though in a crisis many assets can fall together.' },
      { heading: 'Fractions make it easier', body: 'Small minimums let you explore a spread of assets with a small budget. VESTORA’s dashboard shows allocation and risk distribution for your simulated portfolio.' },
    ],
    insights: ['Diversification reduces concentration risk; it does not guarantee against loss.'],
    followUps: ['What is volatility?', 'How is the VESTORA risk score calculated?'],
  },
  liquidity: {
    id: 'liquidity',
    title: 'What is liquidity risk?',
    summary: 'Liquidity risk is the chance you cannot sell quickly at a fair price.',
    sections: [
      { heading: 'Asset vs token liquidity', body: 'Gold trades in huge volumes, but a small tokenised gold product might have few buyers. Property is illiquid even before tokenisation.' },
      { heading: 'What it means for you', body: 'In real markets you might wait, accept a discount, or be unable to sell during lock-up periods or market stress.' },
      { heading: 'On VESTORA', body: 'Demo holdings can be sold back instantly in simulation; the testnet contract lets you redeem tokens for demo credits. Real products rarely work this smoothly.' },
    ],
    insights: ['Always ask how, when and to whom you could sell.'],
    followUps: ['What are the risks of tokenised real estate?', 'What is diversification?'],
  },
  riskScore: {
    id: 'riskScore',
    title: 'How is the VESTORA risk score calculated?',
    summary: 'Five factors scored 1–10 and weighted: volatility 30%, drawdown 20%, liquidity 15%, tokenisation & custody structure 20%, macro sensitivity 15%.',
    sections: [
      { heading: 'Measured inputs', body: 'Volatility and drawdown use real market history when at least 20 observations are available; otherwise curated long-run estimates are used and labelled.' },
      { heading: 'Curated inputs', body: 'Liquidity, structure and macro sensitivity are fixed educational judgements for each sample asset.' },
      { heading: 'Bands', body: 'Below 3 Low · 3–4.5 Moderate · 4.5–6 Elevated · 6–7.5 High · 7.5+ Very high.' },
      { heading: 'Limits', body: 'The score is a teaching aid, not a credit rating, prediction or recommendation. The AI assistant explains the score but never sets it.' },
    ],
    insights: ['Two assets with the same score can be risky for very different reasons — always read the factor breakdown.'],
    followUps: ['What is volatility?', 'What does a 15% drawdown mean?'],
  },
  testnet: {
    id: 'testnet',
    title: 'What is a testnet and what are demo credits?',
    summary: 'A testnet is a practice blockchain whose tokens have no monetary value. VESTORA uses it so you can sign real transactions without real money.',
    sections: [
      { heading: 'Testnet ETH', body: 'Transactions on Sepolia still need gas, paid in Sepolia test ETH from a faucet. It has no value.' },
      { heading: 'vUSD demo credits', body: 'The AssetToken contract lets each wallet claim 10,000 vUSD demo credits once. They can only be spent on sample asset tokens and cannot be transferred.' },
      { heading: 'Demo mode', body: 'Without a wallet, everything is simulated locally in your browser and clearly labelled as simulated.' },
    ],
    insights: ['Nothing on VESTORA can be converted into real money.'],
    followUps: ['What is tokenisation?', 'What is KYC and why is it required?'],
  },
};

export const SUGGESTED_QUESTIONS = [
  'Is gold a risky investment?',
  'Why is silver more volatile than gold?',
  'What affects crude oil prices?',
  'What are the risks of tokenised real estate?',
  'How do bonds work?',
  'What happens if commodity prices fall?',
  'What is fractional ownership?',
  'What does a 15% drawdown mean?',
];
