import type { QuoteDenomination } from './types';

const usdCache = new Map<string, Intl.NumberFormat>();

function nf(key: string, opts: Intl.NumberFormatOptions): Intl.NumberFormat {
  let f = usdCache.get(key);
  if (!f) {
    f = new Intl.NumberFormat('en-US', opts);
    usdCache.set(key, f);
  }
  return f;
}

export function formatUsd(value: number | null | undefined, decimals = 2): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return nf(`usd${decimals}`, { style: 'currency', currency: 'USD', minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(value);
}

export function formatCompactUsd(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return nf('usdc', { style: 'currency', currency: 'USD', notation: 'compact', maximumFractionDigits: 2 }).format(value);
}

export function formatNumber(value: number | null | undefined, decimals = 2): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return nf(`n${decimals}`, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(value);
}

export function formatInt(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return nf('int', { maximumFractionDigits: 0 }).format(value);
}

export function formatPct(value: number | null | undefined, decimals = 2, signed = true): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  const s = nf(`p${decimals}`, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(Math.abs(value));
  const sign = value > 0 ? '+' : value < 0 ? '−' : '';
  return `${signed ? sign : value < 0 ? '−' : ''}${s}%`;
}

/** Format a market quote in its own denomination. */
export function formatQuote(value: number | null | undefined, denomination: QuoteDenomination, decimals = 2): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  switch (denomination) {
    case 'USD':
      return formatUsd(value, decimals);
    case 'USc':
      return `${formatNumber(value, decimals)}¢`;
    case 'percent':
      return `${formatNumber(value, decimals)}%`;
    case 'points':
      return formatNumber(value, decimals);
  }
}

export function shortAddress(address: string | null | undefined, chars = 4): string {
  if (!address) return '';
  return `${address.slice(0, 2 + chars)}…${address.slice(-chars)}`;
}

export function relativeTime(iso: string | null | undefined, now: number = Date.now()): string {
  if (!iso) return '—';
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return '—';
  const s = Math.round((now - t) / 1000);
  if (Math.abs(s) < 45) return 'just now';
  const m = Math.round(s / 60);
  if (Math.abs(m) < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (Math.abs(h) < 36) return `${h}h ago`;
  const d = Math.round(h / 24);
  if (Math.abs(d) < 45) return `${d}d ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}
