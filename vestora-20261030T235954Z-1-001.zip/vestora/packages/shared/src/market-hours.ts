/**
 * Approximate market session status for the top bar.
 * NYSE regular hours 09:30–16:00 America/New_York on weekdays, excluding the
 * full-day holidays listed below. Crypto trades 24/7.
 */

const NYSE_HOLIDAYS = new Set([
  // 2026
  '2026-01-01', '2026-01-19', '2026-02-16', '2026-04-03', '2026-05-25',
  '2026-06-19', '2026-07-03', '2026-09-07', '2026-11-26', '2026-12-25',
  // 2027
  '2027-01-01', '2027-01-18', '2027-02-15', '2027-03-26', '2027-05-31',
  '2027-06-18', '2027-07-05', '2027-09-06', '2027-11-25', '2027-12-24',
]);

/** Early (13:00) closes. */
const NYSE_EARLY_CLOSE = new Set(['2026-11-27', '2026-12-24']);

export type SessionState = 'open' | 'pre-market' | 'after-hours' | 'closed' | 'holiday';

export interface MarketSession {
  state: SessionState;
  label: string;
  localTime: string;
  detail: string;
}

function nyParts(now: Date) {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });
  const parts = Object.fromEntries(fmt.formatToParts(now).map((p) => [p.type, p.value]));
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    weekday: parts.weekday as string,
    minutes: Number(parts.hour) * 60 + Number(parts.minute),
    time: `${parts.hour}:${parts.minute}`,
  };
}

export function nyseSession(now: Date = new Date()): MarketSession {
  const { date, weekday, minutes, time } = nyParts(now);
  const localTime = `${time} ET`;
  if (weekday === 'Sat' || weekday === 'Sun') return { state: 'closed', label: 'Closed', localTime, detail: 'US equity markets are closed for the weekend.' };
  if (NYSE_HOLIDAYS.has(date)) return { state: 'holiday', label: 'Holiday', localTime, detail: 'US equity markets are closed for a market holiday.' };
  const open = 9 * 60 + 30;
  const close = NYSE_EARLY_CLOSE.has(date) ? 13 * 60 : 16 * 60;
  if (minutes >= open && minutes < close) return { state: 'open', label: 'Open', localTime, detail: `NYSE regular session until ${NYSE_EARLY_CLOSE.has(date) ? '13:00' : '16:00'} ET.` };
  if (minutes >= 4 * 60 && minutes < open) return { state: 'pre-market', label: 'Pre-market', localTime, detail: 'NYSE opens at 09:30 ET.' };
  if (minutes >= close && minutes < 20 * 60) return { state: 'after-hours', label: 'After hours', localTime, detail: 'NYSE regular session has closed.' };
  return { state: 'closed', label: 'Closed', localTime, detail: 'NYSE regular session opens at 09:30 ET.' };
}
