/**
 * Shared domain types for VESTORA.
 *
 * Market data is always carried with its provenance (source, status, timestamps)
 * so the UI can clearly distinguish real-time, delayed, historical, demo and
 * unavailable data — and never mistakes an illustrative token price for a
 * commodity price.
 */

export type ProviderId =
  | 'coingecko'
  | 'fred'
  | 'goldapi'
  | 'metalsdev'
  | 'twelvedata'
  | 'alphavantage'
  | 'tradingeconomics'
  | 'demo'
  | 'none';

export type InstrumentClass =
  | 'precious-metals'
  | 'energy'
  | 'industrial-metals'
  | 'agriculture'
  | 'digital-assets'
  | 'rates'
  | 'indices';

export type AssetCategory =
  | 'precious-metals'
  | 'energy'
  | 'industrial-metals'
  | 'agriculture'
  | 'bonds'
  | 'real-estate'
  | 'digital-assets';

/** How trustworthy / fresh a value is. */
export type DataStatus = 'realtime' | 'delayed' | 'historical' | 'demo' | 'unavailable';

export type Frequency = 'realtime' | 'intraday' | 'daily' | 'weekly' | 'monthly';

/** What a percentage change is measured against. */
export type ChangeBasis = '24h' | 'previous-close' | 'previous-observation';

export type HistoryRange = '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL';
export const HISTORY_RANGES: HistoryRange[] = ['1D', '1W', '1M', '3M', '1Y', 'ALL'];

/** Denomination of an instrument's quote. */
export type QuoteDenomination = 'USD' | 'USc' | 'percent' | 'points';

export interface SourceRef {
  id: ProviderId;
  name: string;
  url?: string;
  note?: string;
}

export interface ProxyInfo {
  symbol: string;
  note: string;
}

export interface Quote {
  instrumentId: string;
  price: number | null;
  previous: number | null;
  change: number | null;
  changePct: number | null;
  changeBasis: ChangeBasis | null;
  denomination: QuoteDenomination;
  unit: string;
  status: DataStatus;
  frequency: Frequency;
  source: SourceRef;
  proxy?: ProxyInfo;
  /** Timestamp of the observation itself (provider time), ISO-8601. */
  asOf: string | null;
  /** When VESTORA fetched it, ISO-8601. */
  fetchedAt: string;
  /** Human-readable note, e.g. why data is unavailable. */
  message?: string;
}

export interface SeriesPoint {
  /** epoch milliseconds */
  t: number;
  v: number;
}

export interface Series {
  instrumentId: string;
  range: HistoryRange;
  points: SeriesPoint[];
  status: DataStatus;
  frequency: Frequency;
  denomination: QuoteDenomination;
  unit: string;
  source: SourceRef;
  proxy?: ProxyInfo;
  fetchedAt: string;
  message?: string;
}

export interface QuotesResponse {
  quotes: Quote[];
  generatedAt: string;
}

export interface ProviderHealth {
  id: ProviderId;
  name: string;
  configured: boolean;
  keyless: boolean;
  lastSuccessAt: string | null;
  lastErrorAt: string | null;
  lastError: string | null;
  coolingDownUntil: string | null;
}

export interface HealthResponse {
  ok: boolean;
  name: string;
  version: string;
  time: string;
  providers: ProviderHealth[];
  ai: { mode: 'live' | 'demo'; provider: string | null; model: string | null };
  storage: { mode: 'postgres' | 'file' | 'memory' };
  news: { enabled: boolean; feeds: number };
  demoFallback: boolean;
}

export type NewsCategory = 'energy' | 'macro' | 'digital-assets' | 'metals' | 'markets';

export interface NewsItem {
  id: string;
  title: string;
  url: string;
  source: string;
  category: NewsCategory;
  publishedAt: string | null;
  summary?: string;
}

export interface NewsResponse {
  items: NewsItem[];
  generatedAt: string;
  status: 'live' | 'unavailable';
  message?: string;
}

/* ----------------------------------------------------------------------------
 * Risk methodology
 * ------------------------------------------------------------------------- */

export type RiskLevel = 'Low' | 'Moderate' | 'Elevated' | 'High' | 'Very high';
export type RiskFactorKey = 'volatility' | 'drawdown' | 'liquidity' | 'structure' | 'macro';

export interface RiskFactorScore {
  key: RiskFactorKey;
  label: string;
  /** 1 (lowest risk) … 10 (highest risk) */
  score: number;
  weight: number;
  basis: 'measured' | 'curated';
  note: string;
}

export interface RiskAssessment {
  score: number;
  level: RiskLevel;
  factors: RiskFactorScore[];
  methodology: string;
  measured: {
    volatility: number | null;
    maxDrawdown: number | null;
    observations: number;
    window: string | null;
    source: string | null;
  };
}

/** Curated qualitative inputs (1 = low risk, 10 = high risk) plus long-run estimates. */
export interface RiskInputs {
  liquidity: number;
  structure: number;
  macro: number;
  /** Approximate long-run annualised volatility (decimal, e.g. 0.15 = 15%). */
  typicalVolatility: number;
  /** Approximate historical peak-to-trough decline seen in stress periods (decimal). */
  typicalDrawdown: number;
}

/* ----------------------------------------------------------------------------
 * AI assistant
 * ------------------------------------------------------------------------- */

export interface AssistantSection {
  heading: string;
  body: string;
}

export interface AssistantResponse {
  id: string;
  mode: 'live' | 'demo' | 'fallback';
  provider: string | null;
  model: string | null;
  question: string;
  title: string;
  summary: string;
  sections: AssistantSection[];
  risk?: RiskAssessment;
  scenarios?: { bull: string; bear: string };
  insights: string[];
  followUps: string[];
  disclaimer: string;
  notice?: string;
  createdAt: string;
  /** Asset/instrument this answer is about, when one was detected. */
  subject?: { kind: 'asset' | 'instrument'; id: string; name: string };
}

export interface AskRequest {
  question: string;
  assetId?: string;
  instrumentId?: string;
}

/** Statistics computed from real market history and passed to the assistant. */
export interface MarketStats {
  instrumentId: string;
  volatility: number | null;
  maxDrawdown: number | null;
  changeOverWindow: number | null;
  observations: number;
  window: string | null;
  source: string | null;
  status: DataStatus;
}
