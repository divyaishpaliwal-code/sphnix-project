import type { TokenisedAsset } from './assets';
import { getInstrument } from './instruments';
import type { DataStatus, Quote, SeriesPoint } from './types';

/* ----------------------------------------------------------------------------
 * Ownership calculator
 * ------------------------------------------------------------------------- */

export interface OwnershipCalculation {
  amount: number;
  tokenPrice: number;
  tokens: number;
  cost: number;
  leftover: number;
  /** Share of the sample asset's token supply, as a percentage. */
  ownershipPct: number;
  /** Illustrative value of the tokens = tokens × token price. */
  illustrativeValue: number;
  valid: boolean;
  error?: string;
}

/**
 * Converts a simulated investment amount into whole tokens.
 * Example from the brief: sample value $100,000 and supply 10,000 → $10 per token.
 */
export function calculateOwnership(params: {
  amount: number;
  tokenPrice: number;
  totalSupply: number;
  available?: number;
  minInvestment?: number;
}): OwnershipCalculation {
  const { amount, tokenPrice, totalSupply } = params;
  const base: OwnershipCalculation = {
    amount,
    tokenPrice,
    tokens: 0,
    cost: 0,
    leftover: Number.isFinite(amount) ? Math.max(0, amount) : 0,
    ownershipPct: 0,
    illustrativeValue: 0,
    valid: false,
  };
  if (!Number.isFinite(amount) || amount <= 0) return { ...base, error: 'Enter an amount greater than zero.' };
  if (!Number.isFinite(tokenPrice) || tokenPrice <= 0) return { ...base, error: 'Token price is unavailable right now.' };
  if (!Number.isFinite(totalSupply) || totalSupply <= 0) return { ...base, error: 'Token supply is not configured.' };
  if (params.minInvestment && amount < params.minInvestment) {
    return { ...base, error: `Minimum simulated investment is $${params.minInvestment.toFixed(2)}.` };
  }
  // Guard against floating point artefacts (e.g. 30 / 10.000000001).
  let tokens = Math.floor(amount / tokenPrice + 1e-9);
  if (tokens < 1) {
    return { ...base, error: `Amount is below the price of one token ($${roundTo(tokenPrice, 2).toFixed(2)}).` };
  }
  if (params.available !== undefined && tokens > params.available) {
    if (params.available <= 0) return { ...base, error: 'No sample tokens are currently available.' };
    tokens = params.available;
  }
  const cost = roundTo(tokens * tokenPrice, 6);
  return {
    amount,
    tokenPrice,
    tokens,
    cost,
    leftover: roundTo(Math.max(0, amount - cost), 6),
    ownershipPct: (tokens / totalSupply) * 100,
    illustrativeValue: cost,
    valid: true,
  };
}

export function roundTo(value: number, decimals: number): number {
  const f = 10 ** decimals;
  return Math.round(value * f) / f;
}

/* ----------------------------------------------------------------------------
 * Bond maths (educational, clean price, ignores accrued interest & day counts)
 * ------------------------------------------------------------------------- */

export function yearsBetween(from: Date, to: Date): number {
  return (to.getTime() - from.getTime()) / (365.25 * 24 * 3600 * 1000);
}

/** Clean price per 100 face. Rates are decimals (0.0425 = 4.25%). */
export function bondPrice(couponRate: number, yieldRate: number, years: number, paymentsPerYear = 2): number {
  if (years <= 0) return 100;
  const f = paymentsPerYear;
  const n = years * f;
  const c = (couponRate / f) * 100;
  const r = yieldRate / f;
  if (Math.abs(r) < 1e-12) return c * n + 100;
  const discount = Math.pow(1 + r, -n);
  return (c * (1 - discount)) / r + 100 * discount;
}

/** Modified duration via a symmetric finite difference (years). */
export function modifiedDuration(couponRate: number, yieldRate: number, years: number, paymentsPerYear = 2): number {
  const h = 0.0001;
  const p0 = bondPrice(couponRate, yieldRate, years, paymentsPerYear);
  const up = bondPrice(couponRate, yieldRate + h, years, paymentsPerYear);
  const down = bondPrice(couponRate, yieldRate - h, years, paymentsPerYear);
  return (down - up) / (2 * p0 * h);
}

/* ----------------------------------------------------------------------------
 * Illustrative token valuation
 * ------------------------------------------------------------------------- */

export type ValuationInputStatus = DataStatus | 'fixed';

export interface AssetValuation {
  assetId: string;
  /** Illustrative sample asset value in USD. */
  sampleValue: number | null;
  /** Illustrative token price in USD (sample value ÷ supply). */
  tokenPrice: number | null;
  /** Status of the market input the valuation is derived from. */
  inputStatus: ValuationInputStatus;
  /** Plain-English derivation, e.g. "50 troy oz × $4,012.30". */
  formula: string;
  referencePrice: number | null;
  referenceInstrumentId: string | null;
  asOf: string | null;
  sourceName: string | null;
  /** Bond-only extras. */
  bond?: { yieldPct: number; pricePer100: number; years: number; modifiedDuration: number };
  /** 24h / previous-observation change of the input, applied to the token. */
  changePct: number | null;
}

function usdFromQuote(price: number, denomination: Quote['denomination']): number {
  return denomination === 'USc' ? price / 100 : price;
}

/**
 * Derive an illustrative token price from the latest quotes.
 * Falls back to the instrument's demo value (status "demo") when no live quote exists.
 */
export function valueAsset(asset: TokenisedAsset, quotes: Record<string, Quote | undefined>, now: Date = new Date()): AssetValuation {
  const p = asset.pricing;
  if (p.kind === 'fixed') {
    return {
      assetId: asset.id,
      sampleValue: p.value,
      tokenPrice: p.value / asset.totalSupply,
      inputStatus: 'fixed',
      formula: `$${p.value.toLocaleString('en-US')} fixed illustrative valuation ÷ ${asset.totalSupply.toLocaleString('en-US')} tokens`,
      referencePrice: null,
      referenceInstrumentId: null,
      asOf: null,
      sourceName: 'Simulated valuation',
      changePct: 0,
    };
  }

  if (p.kind === 'reference') {
    const inst = getInstrument(p.instrumentId);
    const q = quotes[p.instrumentId];
    let price: number | null = null;
    let status: ValuationInputStatus = 'unavailable';
    let asOf: string | null = null;
    let sourceName: string | null = null;
    let changePct: number | null = null;
    if (q && q.price !== null && q.status !== 'unavailable') {
      price = q.price;
      status = q.status;
      asOf = q.asOf;
      sourceName = q.proxy ? `${q.source.name} (${q.proxy.symbol} proxy)` : q.source.name;
      changePct = q.changePct;
    } else if (inst && inst.demo !== null) {
      price = inst.demo;
      status = 'demo';
      sourceName = 'Static demo value';
    }
    if (price === null || !inst) {
      return {
        assetId: asset.id,
        sampleValue: null,
        tokenPrice: null,
        inputStatus: 'unavailable',
        formula: `${p.quantity.toLocaleString('en-US')} ${p.quantityUnit} × reference price (unavailable)`,
        referencePrice: null,
        referenceInstrumentId: p.instrumentId,
        asOf: null,
        sourceName: null,
        changePct: null,
      };
    }
    const unitUsd = usdFromQuote(price, inst.denomination);
    const sampleValue = p.quantity * unitUsd;
    const priceText =
      inst.denomination === 'USc' ? `${price.toLocaleString('en-US', { maximumFractionDigits: 2 })}¢` : `$${price.toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
    return {
      assetId: asset.id,
      sampleValue,
      tokenPrice: sampleValue / asset.totalSupply,
      inputStatus: status,
      formula: `${p.quantity.toLocaleString('en-US')} ${p.quantityUnit} × ${priceText} ÷ ${asset.totalSupply.toLocaleString('en-US')} tokens`,
      referencePrice: price,
      referenceInstrumentId: p.instrumentId,
      asOf,
      sourceName,
      changePct,
    };
  }

  // Bond
  const q = quotes[p.yieldInstrumentId];
  let yieldPct = p.fallbackYield;
  let status: ValuationInputStatus = 'demo';
  let asOf: string | null = null;
  let sourceName: string | null = 'Static demo yield';
  if (q && q.price !== null && q.status !== 'unavailable') {
    yieldPct = q.price;
    status = q.status;
    asOf = q.asOf;
    sourceName = q.source.name;
  }
  const effectiveYield = (yieldPct + p.spreadBps / 100) / 100;
  const years = Math.max(0, yearsBetween(now, new Date(p.maturity)));
  const pricePer100 = bondPrice(p.couponRate, effectiveYield, years, p.paymentsPerYear);
  const sampleValue = (p.faceValue * pricePer100) / 100;
  let changePct: number | null = null;
  if (q && q.price !== null && q.previous !== null && q.status !== 'unavailable') {
    const prevPrice = bondPrice(p.couponRate, (q.previous + p.spreadBps / 100) / 100, years, p.paymentsPerYear);
    changePct = ((pricePer100 - prevPrice) / prevPrice) * 100;
  }
  return {
    assetId: asset.id,
    sampleValue,
    tokenPrice: sampleValue / asset.totalSupply,
    inputStatus: status,
    formula: `$${p.faceValue.toLocaleString('en-US')} face × ${pricePer100.toFixed(2)}% (priced at ${yieldPct.toFixed(2)}% yield) ÷ ${asset.totalSupply.toLocaleString('en-US')} tokens`,
    referencePrice: yieldPct,
    referenceInstrumentId: p.yieldInstrumentId,
    asOf,
    sourceName,
    bond: {
      yieldPct,
      pricePer100,
      years,
      modifiedDuration: modifiedDuration(p.couponRate, effectiveYield, years, p.paymentsPerYear),
    },
    changePct,
  };
}

/**
 * Convert a reference-instrument series into an illustrative token-price series.
 * Returns [] for fixed-value assets (no market history exists for them).
 */
export function tokenPriceSeries(asset: TokenisedAsset, series: SeriesPoint[]): SeriesPoint[] {
  const p = asset.pricing;
  if (p.kind === 'fixed') return [];
  if (p.kind === 'reference') {
    const inst = getInstrument(p.instrumentId);
    if (!inst) return [];
    return series.map((pt) => ({ t: pt.t, v: (p.quantity * usdFromQuote(pt.v, inst.denomination)) / asset.totalSupply }));
  }
  return series.map((pt) => {
    const years = Math.max(0, yearsBetween(new Date(pt.t), new Date(p.maturity)));
    const price = bondPrice(p.couponRate, (pt.v + p.spreadBps / 100) / 100, years, p.paymentsPerYear);
    return { t: pt.t, v: (p.faceValue * price) / 100 / asset.totalSupply };
  });
}

/* ----------------------------------------------------------------------------
 * Series statistics (computed only from real observations)
 * ------------------------------------------------------------------------- */

export interface SeriesStats {
  first: number | null;
  last: number | null;
  high: number | null;
  low: number | null;
  change: number | null;
  changePct: number | null;
  /** Annualised volatility of log returns (decimal). */
  volatility: number | null;
  /** Maximum peak-to-trough decline (decimal, positive). */
  maxDrawdown: number | null;
  observations: number;
  periodsPerYear: number | null;
}

export function seriesStats(points: SeriesPoint[]): SeriesStats {
  const pts = points.filter((p) => Number.isFinite(p.v)).sort((a, b) => a.t - b.t);
  const n = pts.length;
  if (n === 0) {
    return { first: null, last: null, high: null, low: null, change: null, changePct: null, volatility: null, maxDrawdown: null, observations: 0, periodsPerYear: null };
  }
  const first = pts[0].v;
  const last = pts[n - 1].v;
  let high = -Infinity;
  let low = Infinity;
  let peak = -Infinity;
  let maxDd = 0;
  for (const p of pts) {
    high = Math.max(high, p.v);
    low = Math.min(low, p.v);
    peak = Math.max(peak, p.v);
    if (peak > 0) maxDd = Math.max(maxDd, (peak - p.v) / peak);
  }
  let volatility: number | null = null;
  let periodsPerYear: number | null = null;
  const positive = pts.every((p) => p.v > 0);
  if (n >= 20 && positive) {
    const spanYears = (pts[n - 1].t - pts[0].t) / (365.25 * 24 * 3600 * 1000);
    if (spanYears > 0) {
      periodsPerYear = (n - 1) / spanYears;
      const rets: number[] = [];
      for (let i = 1; i < n; i++) rets.push(Math.log(pts[i].v / pts[i - 1].v));
      const mean = rets.reduce((s, r) => s + r, 0) / rets.length;
      const variance = rets.reduce((s, r) => s + (r - mean) ** 2, 0) / (rets.length - 1);
      volatility = Math.sqrt(variance) * Math.sqrt(periodsPerYear);
    }
  }
  return {
    first,
    last,
    high,
    low,
    change: last - first,
    changePct: first !== 0 ? ((last - first) / first) * 100 : null,
    volatility,
    maxDrawdown: n >= 2 ? maxDd : null,
    observations: n,
    periodsPerYear,
  };
}

/** Rebase a series to 100 at its first point (for performance comparisons). */
export function rebase(points: SeriesPoint[]): SeriesPoint[] {
  if (points.length === 0 || points[0].v === 0) return [];
  const base = points[0].v;
  return points.map((p) => ({ t: p.t, v: (p.v / base) * 100 }));
}

/** Gain needed to recover from a drawdown, e.g. 15% → 17.65%. */
export function recoveryGainPct(drawdownPct: number): number {
  if (drawdownPct >= 100) return Infinity;
  return (1 / (1 - drawdownPct / 100) - 1) * 100;
}
