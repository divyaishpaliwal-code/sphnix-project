import { TOKENISED_ASSETS, CATEGORY_LABELS, assetReferenceInstrument, type TokenisedAsset } from './assets';
import { INSTRUMENTS, getInstrument, type Instrument } from './instruments';
import { CONCEPTS, categoryProfile, instrumentProfile, type ConceptEntry, type KnowledgeProfile } from './knowledge';
import { recoveryGainPct } from './finance';
import { assessRisk } from './risk';
import { AI_DISCLAIMER } from './disclaimers';
import type { AskRequest, AssistantResponse, AssistantSection, MarketStats, RiskAssessment } from './types';

/**
 * Deterministic educational assistant used when no AI API key is configured
 * (and as a fallback if the live model fails). It never predicts prices,
 * never recommends buying or selling and always attaches the disclaimer.
 */

export const ASSET_SECTION_HEADINGS = [
  'What is this asset?',
  'How does it generate or derive value?',
  'What factors influence its price?',
  'What are its major risks?',
  'What is its historical volatility?',
  'What should beginners understand?',
  'What could cause its value to fall?',
] as const;

export type Subject =
  | { kind: 'asset'; asset: TokenisedAsset; instrument: Instrument | null }
  | { kind: 'instrument'; instrument: Instrument }
  | { kind: 'category'; category: 'bonds' | 'real-estate' };

const ADVICE_RE =
  /\b(should i (buy|sell|invest|put|hold)|shall i (buy|sell|invest)|do you recommend|would you (buy|invest)|best (investment|asset|stock|coin|time to)|which (one|asset|token) (should|to)|tell me what to (buy|sell)|is (it|now) a good (time|investment|idea) to|will (it|the price|gold|silver|oil|bitcoin|btc|eth|ether) (go up|rise|increase|moon|crash)|price (target|prediction|forecast)|predict|forecast|guarantee|how much (money )?should i invest)\b/i;

function newId(): string {
  const g = globalThis as { crypto?: { randomUUID?: () => string } };
  return g.crypto?.randomUUID ? g.crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function norm(s: string): string {
  return ` ${s.toLowerCase().replace(/[^a-z0-9%.\s-]/g, ' ').replace(/\s+/g, ' ')} `;
}

function mentions(q: string, keyword: string): boolean {
  const k = keyword.toLowerCase();
  if (k.length <= 3) return new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(q);
  return q.includes(k);
}

/** Find subjects mentioned in a question, most specific first. */
export function detectSubjects(question: string): Subject[] {
  const q = norm(question);
  const found: Subject[] = [];
  const seen = new Set<string>();
  // Real estate / bonds categories first (they have no instrument).
  if (/(real estate|real-estate|property|properties|reit|housing|warehouse|apartment)/.test(q)) {
    found.push({ kind: 'category', category: 'real-estate' });
    seen.add('cat:real-estate');
  }
  for (const a of TOKENISED_ASSETS) {
    if (mentions(q, a.symbol) || q.includes(a.name.toLowerCase())) {
      const ref = assetReferenceInstrument(a);
      found.push({ kind: 'asset', asset: a, instrument: ref ? getInstrument(ref) ?? null : null });
      seen.add(`asset:${a.id}`);
      if (ref) seen.add(`inst:${ref}`);
    }
  }
  for (const inst of INSTRUMENTS) {
    if (seen.has(`inst:${inst.id}`)) continue;
    const hit = inst.keywords.some((k) => mentions(q, k));
    if (hit) {
      // Prefer the gold instrument over PAXG unless PAXG is named explicitly.
      if (inst.id === 'PAXG' && !/paxg|pax gold/.test(q)) continue;
      found.push({ kind: 'instrument', instrument: inst });
      seen.add(`inst:${inst.id}`);
    }
  }
  if (!seen.has('cat:real-estate') && /\b(bond|bonds|treasury|treasuries|coupon|fixed income)\b/.test(q) && !found.some((s) => s.kind === 'instrument' && s.instrument.class === 'rates')) {
    found.push({ kind: 'category', category: 'bonds' });
  }
  return found;
}

function subjectFromContext(req: AskRequest): Subject | null {
  if (req.assetId) {
    const a = TOKENISED_ASSETS.find((x) => x.id === req.assetId);
    if (a) {
      const ref = assetReferenceInstrument(a);
      return { kind: 'asset', asset: a, instrument: ref ? getInstrument(ref) ?? null : null };
    }
  }
  if (req.instrumentId) {
    const i = getInstrument(req.instrumentId);
    if (i) return { kind: 'instrument', instrument: i };
  }
  return null;
}

export function profileForSubject(s: Subject): KnowledgeProfile {
  if (s.kind === 'category') return categoryProfile(s.category);
  if (s.kind === 'instrument') return instrumentProfile(s.instrument.id, s.instrument.class);
  if (s.asset.category === 'bonds' || s.asset.category === 'real-estate') {
    const base = categoryProfile(s.asset.category);
    if (s.instrument) {
      const ip = instrumentProfile(s.instrument.id, s.instrument.class);
      return { ...base, volatility: `${base.volatility} ${ip.volatility === base.volatility ? '' : ip.volatility}`.trim() };
    }
    return base;
  }
  return s.instrument ? instrumentProfile(s.instrument.id, s.instrument.class) : categoryProfile(s.asset.category);
}

export function subjectName(s: Subject): string {
  if (s.kind === 'asset') return `${s.asset.name} (${s.asset.symbol})`;
  if (s.kind === 'instrument') return s.instrument.name;
  return CATEGORY_LABELS[s.category];
}

function subjectRef(s: Subject): AssistantResponse['subject'] {
  if (s.kind === 'asset') return { kind: 'asset', id: s.asset.id, name: s.asset.name };
  if (s.kind === 'instrument') return { kind: 'instrument', id: s.instrument.id, name: s.instrument.name };
  return undefined;
}

/** Deterministic risk assessment for a subject, using measured stats when provided. */
export function riskForSubject(s: Subject, stats?: MarketStats | null): RiskAssessment | undefined {
  const measured = stats
    ? { volatility: stats.volatility, maxDrawdown: stats.maxDrawdown, observations: stats.observations, window: stats.window, source: stats.source }
    : {};
  if (s.kind === 'asset') return assessRisk(s.asset.risk, measured);
  if (s.kind === 'category') {
    const sample = TOKENISED_ASSETS.find((a) => a.category === s.category);
    return sample ? assessRisk(sample.risk, measured) : undefined;
  }
  const sample = TOKENISED_ASSETS.find((a) => assetReferenceInstrument(a) === s.instrument.id);
  return sample ? assessRisk(sample.risk, measured) : undefined;
}

function pct(x: number, d = 1): string {
  return `${(x * 100).toFixed(d)}%`;
}

function measuredVolatilityText(stats?: MarketStats | null): string {
  if (!stats || stats.volatility === null || stats.observations < 20) return '';
  const parts = [`Measured from ${stats.observations} real observations${stats.window ? ` over ${stats.window}` : ''}${stats.source ? ` (${stats.source})` : ''}: annualised volatility ${pct(stats.volatility)}`];
  if (stats.maxDrawdown !== null) parts.push(`largest decline ${pct(stats.maxDrawdown)}`);
  return `${parts.join(', ')}.`;
}

function bullets(items: string[]): string {
  return items.map((i) => `• ${i}`).join('\n');
}

/** Build the standard 7-part asset explainer. */
export function buildAssetExplainer(s: Subject, opts: { question?: string; stats?: MarketStats | null; mode?: AssistantResponse['mode'] } = {}): AssistantResponse {
  const p = profileForSubject(s);
  const risk = riskForSubject(s, opts.stats ?? null);
  const measured = measuredVolatilityText(opts.stats);
  const name = subjectName(s);
  let whatIs = p.whatIs;
  if (s.kind === 'asset') whatIs = `${s.asset.description}\n\nUnderlying reference: ${p.whatIs}`;
  const sections: AssistantSection[] = [
    { heading: ASSET_SECTION_HEADINGS[0], body: whatIs },
    { heading: ASSET_SECTION_HEADINGS[1], body: s.kind === 'asset' ? `${p.valueSource}\n\nOn VESTORA: ${s.asset.methodology}` : p.valueSource },
    { heading: ASSET_SECTION_HEADINGS[2], body: bullets(p.priceFactors) },
    { heading: ASSET_SECTION_HEADINGS[3], body: bullets(p.risks) },
    { heading: ASSET_SECTION_HEADINGS[4], body: [measured, p.volatility].filter(Boolean).join('\n\n') },
    { heading: ASSET_SECTION_HEADINGS[5], body: bullets(p.beginnerNotes) },
    { heading: ASSET_SECTION_HEADINGS[6], body: bullets(p.downside) },
  ];
  const level = risk ? `${risk.level} (${risk.score.toFixed(1)}/10)` : 'not scored';
  return {
    id: newId(),
    mode: opts.mode ?? 'demo',
    provider: null,
    model: null,
    question: opts.question ?? `Explain ${name}`,
    title: `Understanding ${name}`,
    summary: `${p.whatIs.split('. ')[0].replace(/[.!?]+$/, '')}. VESTORA’s educational risk score: ${level}. Smaller fractions do not reduce the percentage risk of the underlying asset.`,
    sections,
    risk,
    scenarios: { bull: p.bull, bear: p.bear },
    insights: [
      'Fractional access lowers the minimum amount needed — it does not lower the risk of the asset itself.',
      s.kind === 'asset' && s.asset.kind === 'simulated'
        ? 'This is a simulated asset: its valuation is fixed or model-based, not a market price.'
        : 'The token price shown on VESTORA is illustrative and derived from a sample pool — it is not the commodity price.',
    ],
    followUps: p.questions.slice(0, 4),
    disclaimer: AI_DISCLAIMER,
    createdAt: new Date().toISOString(),
    subject: subjectRef(s),
  };
}

function conceptResponse(c: ConceptEntry, question: string, mode: AssistantResponse['mode']): AssistantResponse {
  return {
    id: newId(),
    mode,
    provider: null,
    model: null,
    question,
    title: c.title,
    summary: c.summary,
    sections: c.sections,
    insights: c.insights,
    followUps: c.followUps,
    disclaimer: AI_DISCLAIMER,
    createdAt: new Date().toISOString(),
  };
}

function drawdownResponse(question: string, mode: AssistantResponse['mode']): AssistantResponse {
  const m = question.match(/(\d{1,2}(?:\.\d+)?)\s*%/);
  const base = conceptResponse(CONCEPTS.drawdown, question, mode);
  if (!m) return base;
  const dd = Math.min(99, parseFloat(m[1]));
  const start = 1000;
  const after = start * (1 - dd / 100);
  const need = recoveryGainPct(dd);
  base.title = `What does a ${dd}% drawdown mean?`;
  base.summary = `A ${dd}% drawdown means the value fell ${dd}% from its peak. $${start.toLocaleString('en-US')} would become $${after.toLocaleString('en-US', { maximumFractionDigits: 2 })}, and you would need a ${need.toFixed(1)}% gain to recover.`;
  base.sections = [
    { heading: 'Definition', body: `A drawdown measures the fall from a previous high. A ${dd}% drawdown is a decline of ${dd}% from the peak value.` },
    {
      heading: 'Worked example',
      body: `Peak value $${start.toLocaleString('en-US')} → after a ${dd}% drawdown: $${after.toLocaleString('en-US', { maximumFractionDigits: 2 })} (a loss of $${(start - after).toLocaleString('en-US', { maximumFractionDigits: 2 })}).`,
    },
    { heading: 'The recovery maths', body: `To get back to $${start.toLocaleString('en-US')} you need +${need.toFixed(1)}%, because the gain is calculated on the smaller amount.` },
    ...CONCEPTS.drawdown.sections.slice(2),
  ];
  return base;
}

function comparisonResponse(a: Instrument, b: Instrument, question: string, statsById: Record<string, MarketStats | undefined>, mode: AssistantResponse['mode']): AssistantResponse {
  const pa = instrumentProfile(a.id, a.class);
  const pb = instrumentProfile(b.id, b.class);
  const sa = statsById[a.id];
  const sb = statsById[b.id];
  const measuredLine =
    sa?.volatility != null && sb?.volatility != null
      ? `Measured on recent real data: ${a.shortName} ${pct(sa.volatility)} vs ${b.shortName} ${pct(sb.volatility)} annualised volatility.`
      : '';
  const sections: AssistantSection[] = [
    { heading: `${a.shortName} in brief`, body: pa.whatIs },
    { heading: `${b.shortName} in brief`, body: pb.whatIs },
    { heading: 'Historical volatility', body: [measuredLine, pa.volatility, pb.volatility].filter(Boolean).join('\n\n') },
  ];
  if ((a.id === 'XAG' && b.id === 'XAU') || (a.id === 'XAU' && b.id === 'XAG')) {
    sections.push({
      heading: 'Why silver tends to swing more than gold',
      body: bullets([
        'Smaller market: far less money flows through silver, so the same buying or selling moves the price more.',
        'Industrial demand: around half of silver demand comes from industry (electronics, solar), which rises and falls with the economy. Gold demand is dominated by investors, central banks and jewellery.',
        'Investor behaviour: silver is often treated as a “higher-beta” precious metal — when sentiment towards metals turns, silver tends to move further.',
      ]),
    });
  } else {
    sections.push({ heading: 'What drives each one', body: `${a.shortName}: ${pa.priceFactors.slice(0, 3).join('; ')}.\n${b.shortName}: ${pb.priceFactors.slice(0, 3).join('; ')}.` });
  }
  return {
    id: newId(),
    mode,
    provider: null,
    model: null,
    question,
    title: `${a.shortName} vs ${b.shortName}`,
    summary: `${a.shortName} and ${b.shortName} respond to different forces, so their price swings differ. Volatility describes the past range of moves — it is not a forecast.`,
    sections,
    insights: ['Comparing volatility helps you understand how bumpy each ride has been, not which will perform better.'],
    followUps: [`Is ${a.shortName.toLowerCase()} a risky investment?`, 'What does a 15% drawdown mean?', 'What is volatility?'],
    disclaimer: AI_DISCLAIMER,
    createdAt: new Date().toISOString(),
  };
}

const CONCEPT_RULES: { id: keyof typeof CONCEPTS; re: RegExp; needsNoSubject?: boolean }[] = [
  { id: 'riskScore', re: /(risk score|risk rating|how (is|do you calculate) (the )?risk|methodology)/ },
  { id: 'legal', re: /(legal(ly)?|own the (actual|real|physical)|deed|title|redeem|redemption|legal claim|own (real|actual) gold)/ },
  { id: 'kyc', re: /(\bkyc\b|know your customer|identity verification|verify my identity)/ },
  { id: 'testnet', re: /(testnet|demo credit|vusd|sepolia|faucet|gas fee)/ },
  { id: 'smartContract', re: /(smart contract|hack|exploit|audit|bug in the contract)/ },
  { id: 'diversification', re: /diversif/ },
  { id: 'liquidity', re: /(liquidity|liquid|sell my tokens|cash out|exit my)/ },
  { id: 'fall', re: /((prices?|value) (fall|falls|drop|drops|decline|declines|crash|crashes)|what happens if .*(fall|drop|crash))/ },
  { id: 'fractional', re: /fraction/ },
  { id: 'tokenisation', re: /(tokeni[sz](e|ed|ation|ing)|how does .*token.* work|what is a token)/, needsNoSubject: true },
  { id: 'bonds', re: /(how do bonds work|what is a bond|how does a bond work|duration|coupon)/ },
  { id: 'volatility', re: /(what is volatility|what does volatility mean|volatility mean)/ },
];

export interface AnswerOptions {
  stats?: Record<string, MarketStats | undefined>;
  mode?: AssistantResponse['mode'];
}

/** Classify whether a question asks for personal financial advice or predictions. */
export function isAdviceRequest(question: string): boolean {
  return ADVICE_RE.test(question);
}

export const ADVICE_NOTICE =
  'I can’t tell you whether to buy, sell or how much to invest, and I can’t predict prices. Here is educational context to help you think it through yourself.';

/** Resolve the primary subject for a question (explicit mention wins over page context). */
export function resolveSubject(req: AskRequest): { subject: Subject | null; all: Subject[] } {
  const all = detectSubjects(req.question);
  const ctx = subjectFromContext(req);
  return { subject: all[0] ?? ctx, all: all.length ? all : ctx ? [ctx] : [] };
}

export function answerQuestion(req: AskRequest, opts: AnswerOptions = {}): AssistantResponse {
  const mode = opts.mode ?? 'demo';
  const question = req.question.trim().slice(0, 600);
  const q = norm(question);
  const advice = isAdviceRequest(question);
  const { subject, all } = resolveSubject({ ...req, question });
  const statsFor = (s: Subject | null): MarketStats | undefined => {
    if (!s || !opts.stats) return undefined;
    const id = s.kind === 'asset' ? assetReferenceInstrument(s.asset) : s.kind === 'instrument' ? s.instrument.id : null;
    return id ? opts.stats[id] : undefined;
  };

  let res: AssistantResponse | null = null;

  // 1. Drawdown questions (with numeric parsing).
  if (/draw\s?-?down/.test(q)) res = drawdownResponse(question, mode);

  // 2. Volatility comparisons between two instruments.
  if (!res && /(volatil|swing|riskier|more risky|compare|vs|versus)/.test(q)) {
    const insts = all.flatMap((s) => (s.kind === 'instrument' ? [s.instrument] : s.kind === 'asset' && s.instrument ? [s.instrument] : []));
    if (insts.length >= 2) res = comparisonResponse(insts[0], insts[1], question, opts.stats ?? {}, mode);
  }

  // 3. Concepts.
  if (!res) {
    for (const rule of CONCEPT_RULES) {
      if (rule.needsNoSubject && subject) continue;
      if (rule.re.test(q)) {
        // "What are the risks of tokenised real estate?" → category explainer, not the generic legal concept.
        if (rule.id === 'legal' && subject?.kind === 'category' && !/(legal|deed|title)/.test(q)) continue;
        res = conceptResponse(CONCEPTS[rule.id], question, mode);
        break;
      }
    }
  }

  // 4. Generic "what is volatility" without a subject.
  if (!res && !subject && /volatil/.test(q)) res = conceptResponse(CONCEPTS.volatility, question, mode);

  // 5. Asset / instrument / category explainer.
  if (!res && subject) res = buildAssetExplainer(subject, { question, stats: statsFor(subject), mode });

  // 6. Fallback.
  if (!res) {
    res = {
      id: newId(),
      mode,
      provider: null,
      model: null,
      question,
      title: 'Let’s break it down',
      summary:
        'I’m an educational assistant focused on tokenised assets, commodities, bonds, crypto-assets and investment risk. Try asking about a specific asset or concept.',
      sections: [
        {
          heading: 'Things I can explain',
          body: bullets([
            'What an asset is and what drives its price',
            'Risks, volatility and drawdowns — with real data when available',
            'How fractional ownership and tokenisation work',
            'How VESTORA’s risk score is calculated',
          ]),
        },
        { heading: 'A golden rule', body: 'Fractional access reduces the minimum amount you need — it does not reduce the risk of the asset itself.' },
      ],
      insights: [],
      followUps: ['Is gold a risky investment?', 'What is fractional ownership?', 'How do bonds work?', 'What does a 15% drawdown mean?'],
      disclaimer: AI_DISCLAIMER,
      createdAt: new Date().toISOString(),
    };
  }

  if (subject && !res.subject) res.subject = subjectRef(subject);
  if (subject && !res.risk && res.sections.length > 0 && res.title.startsWith('Understanding')) res.risk = riskForSubject(subject, statsFor(subject));
  if (advice) res.notice = ADVICE_NOTICE;
  return res;
}

/** Contextual starter questions for an asset page. */
export function contextualQuestions(asset: TokenisedAsset): string[] {
  const ref = assetReferenceInstrument(asset);
  const p = profileForSubject({ kind: 'asset', asset, instrument: ref ? getInstrument(ref) ?? null : null });
  const name = asset.name.toLowerCase();
  return [
    `What are the main risks of the ${name}?`,
    ...p.questions.slice(0, 2),
    'What happens if commodity prices fall?',
    'Does owning a token mean I legally own the asset?',
  ].slice(0, 5);
}
