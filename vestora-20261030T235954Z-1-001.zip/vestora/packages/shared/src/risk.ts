import type { RiskAssessment, RiskFactorKey, RiskFactorScore, RiskInputs, RiskLevel } from './types';

/**
 * VESTORA risk score methodology (educational, transparent, deterministic).
 *
 * Five factors are each scored 1 (lower risk) to 10 (higher risk) and combined
 * with fixed weights. Volatility and drawdown use measured values from real
 * market history when at least 20 observations are available; otherwise they
 * fall back to curated long-run estimates, and the factor is labelled "curated".
 * The AI assistant explains the score — it never sets it.
 */
export const RISK_FACTORS: { key: RiskFactorKey; label: string; weight: number; description: string }[] = [
  {
    key: 'volatility',
    label: 'Price volatility',
    weight: 0.3,
    description: 'Annualised standard deviation of returns. Higher volatility means larger, less predictable price swings.',
  },
  {
    key: 'drawdown',
    label: 'Drawdown history',
    weight: 0.2,
    description: 'Largest peak-to-trough decline. Shows how deep losses have been in bad periods.',
  },
  {
    key: 'liquidity',
    label: 'Liquidity',
    weight: 0.15,
    description: 'How easily the underlying asset (and a token on it) can be sold without a large discount.',
  },
  {
    key: 'structure',
    label: 'Tokenisation & custody structure',
    weight: 0.2,
    description: 'Custody, legal enforceability, issuer and smart-contract risk introduced by the token wrapper.',
  },
  {
    key: 'macro',
    label: 'Macro & event sensitivity',
    weight: 0.15,
    description: 'Exposure to interest rates, growth shocks, weather, geopolitics and policy events.',
  },
];

export const RISK_METHODOLOGY =
  'Score = 30% volatility + 20% drawdown + 15% liquidity + 20% tokenisation/custody structure + 15% macro sensitivity, each scored 1–10. ' +
  'Volatility and drawdown use measured values from real market history when available (otherwise curated long-run estimates). ' +
  'Bands: below 3 Low · 3–4.5 Moderate · 4.5–6 Elevated · 6–7.5 High · 7.5+ Very high. Scores are educational and not a rating or recommendation.';

function interpolate(x: number, points: [number, number][]): number {
  if (x <= points[0][0]) return points[0][1];
  for (let i = 1; i < points.length; i++) {
    const [x1, y1] = points[i];
    const [x0, y0] = points[i - 1];
    if (x <= x1) return y0 + ((x - x0) / (x1 - x0)) * (y1 - y0);
  }
  return points[points.length - 1][1];
}

/** Annualised volatility (decimal) → 1–10 score. */
export function volatilityScore(vol: number): number {
  return interpolate(vol, [
    [0.05, 1],
    [0.1, 2.5],
    [0.2, 4.5],
    [0.35, 6.5],
    [0.6, 8.5],
    [0.9, 10],
  ]);
}

/** Max drawdown (decimal) → 1–10 score. */
export function drawdownScore(dd: number): number {
  return interpolate(dd, [
    [0.05, 1],
    [0.15, 3],
    [0.3, 5],
    [0.5, 7],
    [0.7, 9],
    [0.85, 10],
  ]);
}

export function riskLevel(score: number): RiskLevel {
  if (score < 3) return 'Low';
  if (score < 4.5) return 'Moderate';
  if (score < 6) return 'Elevated';
  if (score < 7.5) return 'High';
  return 'Very high';
}

const round1 = (x: number) => Math.round(x * 10) / 10;

export interface MeasuredInputs {
  volatility?: number | null;
  maxDrawdown?: number | null;
  observations?: number;
  window?: string | null;
  source?: string | null;
}

const pct = (x: number) => `${(x * 100).toFixed(1)}%`;

export function assessRisk(inputs: RiskInputs, measured: MeasuredInputs = {}): RiskAssessment {
  const obs = measured.observations ?? 0;
  const useVol = typeof measured.volatility === 'number' && Number.isFinite(measured.volatility) && obs >= 20;
  const useDd = typeof measured.maxDrawdown === 'number' && Number.isFinite(measured.maxDrawdown) && obs >= 20;
  const vol = useVol ? (measured.volatility as number) : inputs.typicalVolatility;
  const dd = useDd ? (measured.maxDrawdown as number) : inputs.typicalDrawdown;

  const scores: Record<RiskFactorKey, { score: number; basis: 'measured' | 'curated'; note: string }> = {
    volatility: {
      score: volatilityScore(vol),
      basis: useVol ? 'measured' : 'curated',
      note: useVol
        ? `Measured annualised volatility ${pct(vol)} over ${measured.window ?? 'the available window'}${measured.source ? ` (${measured.source})` : ''}.`
        : `Curated long-run estimate of about ${pct(vol)} a year.`,
    },
    drawdown: {
      score: drawdownScore(dd),
      basis: useDd ? 'measured' : 'curated',
      note: useDd
        ? `Largest measured decline ${pct(dd)} over ${measured.window ?? 'the available window'}.`
        : `Curated estimate: declines of around ${pct(dd)} have occurred in past stress periods.`,
    },
    liquidity: { score: inputs.liquidity, basis: 'curated', note: liquidityNote(inputs.liquidity) },
    structure: { score: inputs.structure, basis: 'curated', note: structureNote(inputs.structure) },
    macro: { score: inputs.macro, basis: 'curated', note: macroNote(inputs.macro) },
  };

  const factors: RiskFactorScore[] = RISK_FACTORS.map((f) => ({
    key: f.key,
    label: f.label,
    weight: f.weight,
    score: round1(scores[f.key].score),
    basis: scores[f.key].basis,
    note: scores[f.key].note,
  }));
  const total = round1(factors.reduce((s, f) => s + f.score * f.weight, 0));
  return {
    score: total,
    level: riskLevel(total),
    factors,
    methodology: RISK_METHODOLOGY,
    measured: {
      volatility: useVol ? vol : null,
      maxDrawdown: useDd ? dd : null,
      observations: obs,
      window: measured.window ?? null,
      source: measured.source ?? null,
    },
  };
}

function liquidityNote(s: number): string {
  if (s <= 3) return 'Deep, actively traded underlying market.';
  if (s <= 6) return 'Reasonably traded underlying, but a token may have few buyers.';
  return 'Illiquid underlying — selling quickly may require a large discount or be impossible.';
}

function structureNote(s: number): string {
  if (s <= 4) return 'Simple structure, but smart-contract and platform risk remain.';
  if (s <= 6) return 'Depends on custodians, issuers and smart contracts working as intended.';
  return 'Complex legal structure (e.g. SPV) — token holders rely heavily on the issuer and legal agreements.';
}

function macroNote(s: number): string {
  if (s <= 4) return 'Moderate sensitivity to rates and the US dollar.';
  if (s <= 6) return 'Meaningfully exposed to economic cycles and policy changes.';
  return 'Highly exposed to shocks such as weather, geopolitics, regulation or sentiment swings.';
}

export const RISK_LEVEL_ORDER: RiskLevel[] = ['Low', 'Moderate', 'Elevated', 'High', 'Very high'];
