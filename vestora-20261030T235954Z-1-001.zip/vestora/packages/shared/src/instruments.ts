import type { Frequency, InstrumentClass, ProviderId, QuoteDenomination } from './types';

/**
 * Provider-specific mapping for one instrument.
 * `multiplier` converts the provider's unit into the instrument's canonical unit
 * (e.g. Trading Economics quotes copper in USD/lb; we store USD per metric ton).
 */
export interface ProviderMapping {
  symbol: string;
  frequency?: Frequency;
  multiplier?: number;
  /** Set when the mapped instrument is a proxy rather than the instrument itself. */
  proxy?: { symbol: string; note: string };
}

export interface Instrument {
  id: string;
  symbol: string;
  name: string;
  shortName: string;
  class: InstrumentClass;
  /** Canonical unit the price is expressed per, e.g. "troy oz". */
  unit: string;
  denomination: QuoteDenomination;
  decimals: number;
  providers: Partial<Record<ProviderId, ProviderMapping>>;
  /**
   * Static, clearly-labelled demo value used only when no live provider is
   * reachable. Never presented as a live quote. `null` = no demo value.
   */
  demo: number | null;
  description: string;
  keywords: string[];
}

const TOZ_PER_TONNE = 32150.7466;
const LB_PER_TONNE = 2204.62262;
const WHEAT_BU_PER_TONNE = 36.7437;
const CORN_BU_PER_TONNE = 39.3679;
const SOY_BU_PER_TONNE = 36.7437;

export const INSTRUMENT_CLASS_LABELS: Record<InstrumentClass, string> = {
  'precious-metals': 'Precious Metals',
  energy: 'Energy',
  'industrial-metals': 'Industrial Metals',
  agriculture: 'Agriculture',
  'digital-assets': 'Digital Assets',
  rates: 'Rates & Bonds',
  indices: 'Indices',
};

/** Provider preference per asset class. The first configured provider that maps an instrument wins. */
export const PROVIDER_PREFERENCE: Record<InstrumentClass, ProviderId[]> = {
  'precious-metals': ['metalsdev', 'goldapi', 'twelvedata', 'tradingeconomics', 'coingecko'],
  energy: ['tradingeconomics', 'alphavantage', 'fred'],
  'industrial-metals': ['metalsdev', 'tradingeconomics', 'alphavantage', 'fred'],
  agriculture: ['tradingeconomics', 'alphavantage', 'fred'],
  'digital-assets': ['coingecko', 'twelvedata', 'fred'],
  rates: ['fred', 'alphavantage'],
  indices: ['fred'],
};

export const INSTRUMENTS: Instrument[] = [
  /* ------------------------------ Precious metals ------------------------------ */
  {
    id: 'XAU',
    symbol: 'XAU/USD',
    name: 'Gold',
    shortName: 'Gold',
    class: 'precious-metals',
    unit: 'troy oz',
    denomination: 'USD',
    decimals: 2,
    providers: {
      metalsdev: { symbol: 'gold' },
      goldapi: { symbol: 'XAU' },
      twelvedata: { symbol: 'XAU/USD' },
      tradingeconomics: { symbol: 'XAUUSD:CUR|Gold' },
      coingecko: {
        symbol: 'pax-gold',
        proxy: {
          symbol: 'PAXG',
          note: 'Proxy: PAX Gold (PAXG), a tokenised gold product priced on crypto markets. It is designed to track 1 troy oz of gold but can trade at a premium or discount to spot.',
        },
      },
    },
    demo: 4000,
    description: 'Spot gold priced in US dollars per troy ounce.',
    keywords: ['gold', 'xau', 'bullion', 'precious'],
  },
  {
    id: 'XAG',
    symbol: 'XAG/USD',
    name: 'Silver',
    shortName: 'Silver',
    class: 'precious-metals',
    unit: 'troy oz',
    denomination: 'USD',
    decimals: 2,
    providers: {
      metalsdev: { symbol: 'silver' },
      goldapi: { symbol: 'XAG' },
      twelvedata: { symbol: 'XAG/USD' },
      tradingeconomics: { symbol: 'XAGUSD:CUR|Silver' },
    },
    demo: 48,
    description: 'Spot silver priced in US dollars per troy ounce.',
    keywords: ['silver', 'xag'],
  },
  {
    id: 'XPT',
    symbol: 'XPT/USD',
    name: 'Platinum',
    shortName: 'Platinum',
    class: 'precious-metals',
    unit: 'troy oz',
    denomination: 'USD',
    decimals: 2,
    providers: {
      metalsdev: { symbol: 'platinum' },
      goldapi: { symbol: 'XPT' },
      twelvedata: { symbol: 'XPT/USD' },
      tradingeconomics: { symbol: 'XPTUSD:CUR|Platinum' },
    },
    demo: 1550,
    description: 'Spot platinum priced in US dollars per troy ounce.',
    keywords: ['platinum', 'xpt'],
  },
  {
    id: 'XPD',
    symbol: 'XPD/USD',
    name: 'Palladium',
    shortName: 'Palladium',
    class: 'precious-metals',
    unit: 'troy oz',
    denomination: 'USD',
    decimals: 2,
    providers: {
      metalsdev: { symbol: 'palladium' },
      goldapi: { symbol: 'XPD' },
      twelvedata: { symbol: 'XPD/USD' },
      tradingeconomics: { symbol: 'XPDUSD:CUR|Palladium' },
    },
    demo: 1400,
    description: 'Spot palladium priced in US dollars per troy ounce.',
    keywords: ['palladium', 'xpd'],
  },

  /* ------------------------------------ Energy ------------------------------------ */
  {
    id: 'WTI',
    symbol: 'WTI',
    name: 'Crude Oil (WTI)',
    shortName: 'WTI Crude',
    class: 'energy',
    unit: 'barrel',
    denomination: 'USD',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'CL1:COM|Crude Oil' },
      alphavantage: { symbol: 'WTI', frequency: 'daily' },
      fred: { symbol: 'DCOILWTICO', frequency: 'daily' },
    },
    demo: 60,
    description: 'West Texas Intermediate crude oil, US dollars per barrel.',
    keywords: ['oil', 'crude', 'wti', 'petroleum'],
  },
  {
    id: 'BRENT',
    symbol: 'BRENT',
    name: 'Brent Crude',
    shortName: 'Brent',
    class: 'energy',
    unit: 'barrel',
    denomination: 'USD',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'CO1:COM|Brent' },
      alphavantage: { symbol: 'BRENT', frequency: 'daily' },
      fred: { symbol: 'DCOILBRENTEU', frequency: 'daily' },
    },
    demo: 64,
    description: 'Brent crude oil (Europe), US dollars per barrel.',
    keywords: ['brent', 'oil', 'crude'],
  },
  {
    id: 'NATGAS',
    symbol: 'NG',
    name: 'Natural Gas (Henry Hub)',
    shortName: 'Natural Gas',
    class: 'energy',
    unit: 'MMBtu',
    denomination: 'USD',
    decimals: 3,
    providers: {
      tradingeconomics: { symbol: 'NG1:COM|Natural gas' },
      alphavantage: { symbol: 'NATURAL_GAS', frequency: 'daily' },
      fred: { symbol: 'DHHNGSP', frequency: 'daily' },
    },
    demo: 3.9,
    description: 'Henry Hub natural gas, US dollars per million British thermal units.',
    keywords: ['natural gas', 'henry hub', 'lng'],
  },
  {
    id: 'GASOLINE',
    symbol: 'RBOB',
    name: 'Gasoline',
    shortName: 'Gasoline',
    class: 'energy',
    unit: 'gallon',
    denomination: 'USD',
    decimals: 3,
    providers: {
      tradingeconomics: { symbol: 'XB1:COM|Gasoline' },
      fred: { symbol: 'DGASNYH', frequency: 'daily' },
    },
    demo: 1.95,
    description: 'US gasoline (NY Harbor conventional regular / RBOB futures), US dollars per gallon.',
    keywords: ['gasoline', 'petrol', 'rbob'],
  },

  /* ------------------------------- Industrial metals ------------------------------ */
  {
    id: 'COPPER',
    symbol: 'CU',
    name: 'Copper',
    shortName: 'Copper',
    class: 'industrial-metals',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      metalsdev: { symbol: 'copper', multiplier: TOZ_PER_TONNE },
      tradingeconomics: { symbol: 'HG1:COM|Copper', multiplier: LB_PER_TONNE },
      alphavantage: { symbol: 'COPPER', frequency: 'monthly' },
      fred: { symbol: 'PCOPPUSDM', frequency: 'monthly' },
    },
    demo: 10800,
    description: 'Global copper price, US dollars per metric ton.',
    keywords: ['copper', 'cu', 'industrial'],
  },
  {
    id: 'ALUMINIUM',
    symbol: 'AL',
    name: 'Aluminium',
    shortName: 'Aluminium',
    class: 'industrial-metals',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      metalsdev: { symbol: 'aluminum', multiplier: TOZ_PER_TONNE },
      tradingeconomics: { symbol: 'LMAHDS03:COM|Aluminum' },
      alphavantage: { symbol: 'ALUMINUM', frequency: 'monthly' },
      fred: { symbol: 'PALUMUSDM', frequency: 'monthly' },
    },
    demo: 2800,
    description: 'Global aluminium price, US dollars per metric ton.',
    keywords: ['aluminium', 'aluminum', 'al'],
  },
  {
    id: 'NICKEL',
    symbol: 'NI',
    name: 'Nickel',
    shortName: 'Nickel',
    class: 'industrial-metals',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      metalsdev: { symbol: 'nickel', multiplier: TOZ_PER_TONNE },
      tradingeconomics: { symbol: 'LMNIDS03:COM|Nickel' },
      fred: { symbol: 'PNICKUSDM', frequency: 'monthly' },
    },
    demo: 15200,
    description: 'Global nickel price, US dollars per metric ton.',
    keywords: ['nickel', 'ni'],
  },
  {
    id: 'ZINC',
    symbol: 'ZN',
    name: 'Zinc',
    shortName: 'Zinc',
    class: 'industrial-metals',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      metalsdev: { symbol: 'zinc', multiplier: TOZ_PER_TONNE },
      tradingeconomics: { symbol: 'LMZSDS03:COM|Zinc' },
      fred: { symbol: 'PZINCUSDM', frequency: 'monthly' },
    },
    demo: 3000,
    description: 'Global zinc price, US dollars per metric ton.',
    keywords: ['zinc', 'zn'],
  },
  {
    id: 'LEAD',
    symbol: 'PB',
    name: 'Lead',
    shortName: 'Lead',
    class: 'industrial-metals',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      metalsdev: { symbol: 'lead', multiplier: TOZ_PER_TONNE },
      tradingeconomics: { symbol: 'LMPBDS03:COM|Lead' },
      fred: { symbol: 'PLEADUSDM', frequency: 'monthly' },
    },
    demo: 2000,
    description: 'Global lead price, US dollars per metric ton.',
    keywords: ['lead price', 'lead metal', 'pb'],
  },
  {
    id: 'TIN',
    symbol: 'SN',
    name: 'Tin',
    shortName: 'Tin',
    class: 'industrial-metals',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      tradingeconomics: { symbol: 'LMSNDS03:COM|Tin' },
      fred: { symbol: 'PTINUSDM', frequency: 'monthly' },
    },
    demo: 36000,
    description: 'Global tin price, US dollars per metric ton.',
    keywords: ['tin', 'sn'],
  },

  /* ---------------------------------- Agriculture --------------------------------- */
  {
    id: 'WHEAT',
    symbol: 'ZW',
    name: 'Wheat',
    shortName: 'Wheat',
    class: 'agriculture',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'W 1:COM|Wheat', multiplier: WHEAT_BU_PER_TONNE / 100 },
      alphavantage: { symbol: 'WHEAT', frequency: 'monthly' },
      fred: { symbol: 'PWHEAMTUSDM', frequency: 'monthly' },
    },
    demo: 230,
    description: 'Global wheat price, US dollars per metric ton.',
    keywords: ['wheat', 'grain'],
  },
  {
    id: 'CORN',
    symbol: 'ZC',
    name: 'Corn',
    shortName: 'Corn',
    class: 'agriculture',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'C 1:COM|Corn', multiplier: CORN_BU_PER_TONNE / 100 },
      alphavantage: { symbol: 'CORN', frequency: 'monthly' },
      fred: { symbol: 'PMAIZMTUSDM', frequency: 'monthly' },
    },
    demo: 195,
    description: 'Global corn (maize) price, US dollars per metric ton.',
    keywords: ['corn', 'maize', 'grain'],
  },
  {
    id: 'SOYBEANS',
    symbol: 'ZS',
    name: 'Soybeans',
    shortName: 'Soybeans',
    class: 'agriculture',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'S 1:COM|Soybeans', multiplier: SOY_BU_PER_TONNE / 100 },
      fred: { symbol: 'PSOYBUSDM', frequency: 'monthly' },
    },
    demo: 410,
    description: 'Global soybean price, US dollars per metric ton.',
    keywords: ['soybeans', 'soy', 'soya'],
  },
  {
    id: 'COFFEE',
    symbol: 'KC',
    name: 'Coffee (Arabica)',
    shortName: 'Coffee',
    class: 'agriculture',
    unit: 'lb',
    denomination: 'USc',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'KC1:COM|Coffee' },
      alphavantage: { symbol: 'COFFEE', frequency: 'monthly' },
      fred: { symbol: 'PCOFFOTMUSDM', frequency: 'monthly' },
    },
    demo: 400,
    description: 'Arabica coffee (other mild), US cents per pound.',
    keywords: ['coffee', 'arabica'],
  },
  {
    id: 'COCOA',
    symbol: 'CC',
    name: 'Cocoa',
    shortName: 'Cocoa',
    class: 'agriculture',
    unit: 'metric ton',
    denomination: 'USD',
    decimals: 0,
    providers: {
      tradingeconomics: { symbol: 'CC1:COM|Cocoa' },
      fred: { symbol: 'PCOCOUSDM', frequency: 'monthly' },
    },
    demo: 6500,
    description: 'Global cocoa price, US dollars per metric ton.',
    keywords: ['cocoa', 'chocolate'],
  },
  {
    id: 'SUGAR',
    symbol: 'SB',
    name: 'Sugar (No. 11)',
    shortName: 'Sugar',
    class: 'agriculture',
    unit: 'lb',
    denomination: 'USc',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'SB1:COM|Sugar' },
      alphavantage: { symbol: 'SUGAR', frequency: 'monthly' },
      fred: { symbol: 'PSUGAISAUSDM', frequency: 'monthly' },
    },
    demo: 15,
    description: 'World raw sugar (No. 11), US cents per pound.',
    keywords: ['sugar'],
  },
  {
    id: 'COTTON',
    symbol: 'CT',
    name: 'Cotton',
    shortName: 'Cotton',
    class: 'agriculture',
    unit: 'lb',
    denomination: 'USc',
    decimals: 2,
    providers: {
      tradingeconomics: { symbol: 'CT1:COM|Cotton' },
      alphavantage: { symbol: 'COTTON', frequency: 'monthly' },
      fred: { symbol: 'PCOTTINDUSDM', frequency: 'monthly' },
    },
    demo: 65,
    description: 'Global cotton price, US cents per pound.',
    keywords: ['cotton'],
  },

  /* -------------------------------- Digital assets -------------------------------- */
  {
    id: 'BTC',
    symbol: 'BTC',
    name: 'Bitcoin',
    shortName: 'Bitcoin',
    class: 'digital-assets',
    unit: 'BTC',
    denomination: 'USD',
    decimals: 0,
    providers: {
      coingecko: { symbol: 'bitcoin' },
      twelvedata: { symbol: 'BTC/USD' },
      fred: { symbol: 'CBBTCUSD', frequency: 'daily' },
    },
    demo: 110000,
    description: 'Bitcoin priced in US dollars.',
    keywords: ['bitcoin', 'btc', 'crypto'],
  },
  {
    id: 'ETH',
    symbol: 'ETH',
    name: 'Ethereum',
    shortName: 'Ethereum',
    class: 'digital-assets',
    unit: 'ETH',
    denomination: 'USD',
    decimals: 2,
    providers: {
      coingecko: { symbol: 'ethereum' },
      twelvedata: { symbol: 'ETH/USD' },
      fred: { symbol: 'CBETHUSD', frequency: 'daily' },
    },
    demo: 3900,
    description: 'Ether priced in US dollars.',
    keywords: ['ethereum', 'ether', 'eth'],
  },
  {
    id: 'SOL',
    symbol: 'SOL',
    name: 'Solana',
    shortName: 'Solana',
    class: 'digital-assets',
    unit: 'SOL',
    denomination: 'USD',
    decimals: 2,
    providers: {
      coingecko: { symbol: 'solana' },
      twelvedata: { symbol: 'SOL/USD' },
    },
    demo: 190,
    description: 'Solana (SOL) priced in US dollars.',
    keywords: ['solana', 'sol'],
  },
  {
    id: 'XRP',
    symbol: 'XRP',
    name: 'XRP',
    shortName: 'XRP',
    class: 'digital-assets',
    unit: 'XRP',
    denomination: 'USD',
    decimals: 4,
    providers: {
      coingecko: { symbol: 'ripple' },
      twelvedata: { symbol: 'XRP/USD' },
    },
    demo: 2.5,
    description: 'XRP priced in US dollars.',
    keywords: ['xrp', 'ripple'],
  },
  {
    id: 'PAXG',
    symbol: 'PAXG',
    name: 'PAX Gold (tokenised gold)',
    shortName: 'PAX Gold',
    class: 'digital-assets',
    unit: 'PAXG',
    denomination: 'USD',
    decimals: 2,
    providers: {
      coingecko: { symbol: 'pax-gold' },
    },
    demo: 4000,
    description: 'A real-world example of a tokenised commodity: each PAXG is designed to represent one fine troy ounce of gold held by its issuer.',
    keywords: ['paxg', 'pax gold', 'tokenised gold', 'tokenized gold'],
  },

  /* ---------------------------------- Rates & bonds -------------------------------- */
  {
    id: 'UST3M',
    symbol: 'US3M',
    name: 'US Treasury 3-Month Yield',
    shortName: 'UST 3M',
    class: 'rates',
    unit: 'yield',
    denomination: 'percent',
    decimals: 2,
    providers: {
      fred: { symbol: 'DGS3MO', frequency: 'daily' },
      alphavantage: { symbol: 'TREASURY_YIELD:3month', frequency: 'daily' },
    },
    demo: 3.9,
    description: 'Market yield on 3-month US Treasury securities (constant maturity).',
    keywords: ['t-bill', 't-bills', '3 month', '3-month'],
  },
  {
    id: 'UST2Y',
    symbol: 'US2Y',
    name: 'US Treasury 2-Year Yield',
    shortName: 'UST 2Y',
    class: 'rates',
    unit: 'yield',
    denomination: 'percent',
    decimals: 2,
    providers: {
      fred: { symbol: 'DGS2', frequency: 'daily' },
      alphavantage: { symbol: 'TREASURY_YIELD:2year', frequency: 'daily' },
    },
    demo: 3.55,
    description: 'Market yield on 2-year US Treasury securities (constant maturity).',
    keywords: ['2 year treasury', '2-year treasury', '2y'],
  },
  {
    id: 'UST10Y',
    symbol: 'US10Y',
    name: 'US Treasury 10-Year Yield',
    shortName: 'UST 10Y',
    class: 'rates',
    unit: 'yield',
    denomination: 'percent',
    decimals: 2,
    providers: {
      fred: { symbol: 'DGS10', frequency: 'daily' },
      alphavantage: { symbol: 'TREASURY_YIELD:10year', frequency: 'daily' },
    },
    demo: 4.05,
    description: 'Market yield on 10-year US Treasury securities (constant maturity).',
    keywords: ['treasury', 'treasuries', '10 year', '10-year', 'ust'],
  },
  {
    id: 'UST30Y',
    symbol: 'US30Y',
    name: 'US Treasury 30-Year Yield',
    shortName: 'UST 30Y',
    class: 'rates',
    unit: 'yield',
    denomination: 'percent',
    decimals: 2,
    providers: {
      fred: { symbol: 'DGS30', frequency: 'daily' },
      alphavantage: { symbol: 'TREASURY_YIELD:30year', frequency: 'daily' },
    },
    demo: 4.6,
    description: 'Market yield on 30-year US Treasury securities (constant maturity).',
    keywords: ['30 year', '30-year', 'long bond'],
  },
  {
    id: 'IGYIELD',
    symbol: 'US IG',
    name: 'US Investment-Grade Corporate Yield',
    shortName: 'IG Corp Yield',
    class: 'rates',
    unit: 'yield',
    denomination: 'percent',
    decimals: 2,
    providers: {
      fred: { symbol: 'BAMLC0A0CMEY', frequency: 'daily' },
    },
    demo: 4.8,
    description: 'ICE BofA US Corporate Index effective yield — a broad reference for investment-grade bond yields.',
    keywords: ['corporate bond', 'corporate bonds', 'investment grade', 'investment-grade'],
  },

  /* ------------------------------------ Indices ----------------------------------- */
  {
    id: 'SPX',
    symbol: 'SPX',
    name: 'S&P 500',
    shortName: 'S&P 500',
    class: 'indices',
    unit: 'index',
    denomination: 'points',
    decimals: 2,
    providers: { fred: { symbol: 'SP500', frequency: 'daily' } },
    demo: 6800,
    description: 'S&P 500 index level (daily close).',
    keywords: ['s p 500', 'sp500', 'sp 500', 'stock market'],
  },
  {
    id: 'NASDAQ',
    symbol: 'IXIC',
    name: 'Nasdaq Composite',
    shortName: 'Nasdaq',
    class: 'indices',
    unit: 'index',
    denomination: 'points',
    decimals: 2,
    providers: { fred: { symbol: 'NASDAQCOM', frequency: 'daily' } },
    demo: 23500,
    description: 'Nasdaq Composite index level (daily close).',
    keywords: ['nasdaq'],
  },
  {
    id: 'DJIA',
    symbol: 'DJI',
    name: 'Dow Jones Industrial Average',
    shortName: 'Dow Jones',
    class: 'indices',
    unit: 'index',
    denomination: 'points',
    decimals: 2,
    providers: { fred: { symbol: 'DJIA', frequency: 'daily' } },
    demo: 47000,
    description: 'Dow Jones Industrial Average level (daily close).',
    keywords: ['dow jones', 'djia'],
  },
];

export const INSTRUMENT_MAP: Record<string, Instrument> = Object.fromEntries(
  INSTRUMENTS.map((i) => [i.id, i]),
);

export function getInstrument(id: string): Instrument | undefined {
  return INSTRUMENT_MAP[id];
}

/** Instruments shown in the landing-page ticker, in order. */
export const TICKER_INSTRUMENTS = ['XAU', 'XAG', 'XPT', 'WTI', 'NATGAS', 'COPPER', 'BTC', 'ETH'];

/** Human label for a quote's unit, e.g. "USD / troy oz", "US¢ / lb", "%". */
export function unitLabel(i: Pick<Instrument, 'denomination' | 'unit'>): string {
  switch (i.denomination) {
    case 'USD':
      return i.unit === i.unit.toUpperCase() && i.unit.length <= 5 ? 'USD' : `USD / ${i.unit}`;
    case 'USc':
      return `US¢ / ${i.unit}`;
    case 'percent':
      return '% yield';
    case 'points':
      return 'index points';
  }
}
