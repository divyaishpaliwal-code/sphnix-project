import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  ASSET_SECTION_HEADINGS,
  CONCEPTS,
  INSTRUMENTS,
  INSTRUMENT_MAP,
  SUGGESTED_QUESTIONS,
  TOKENISED_ASSETS,
  answerQuestion,
  assessRisk,
  assetReferenceInstrument,
  bondPrice,
  calculateOwnership,
  formatPct,
  formatQuote,
  getAsset,
  modifiedDuration,
  nyseSession,
  onchainAssetDefinitions,
  recoveryGainPct,
  seriesStats,
  tokenPriceSeries,
  valueAsset,
  type Quote,
} from '../src/index';

const here = dirname(fileURLToPath(import.meta.url));

function quote(instrumentId: string, price: number, extra: Partial<Quote> = {}): Quote {
  const inst = INSTRUMENT_MAP[instrumentId];
  return {
    instrumentId,
    price,
    previous: null,
    change: null,
    changePct: null,
    changeBasis: null,
    denomination: inst.denomination,
    unit: inst.unit,
    status: 'realtime',
    frequency: 'realtime',
    source: { id: 'coingecko', name: 'Test' },
    asOf: '2026-10-30T12:00:00.000Z',
    fetchedAt: '2026-10-30T12:00:01.000Z',
    ...extra,
  };
}

test('ownership calculator matches the brief example ($100,000 / 10,000 tokens = $10)', () => {
  const r = calculateOwnership({ amount: 55, tokenPrice: 100_000 / 10_000, totalSupply: 10_000 });
  assert.equal(r.valid, true);
  assert.equal(r.tokens, 5);
  assert.equal(r.cost, 50);
  assert.equal(r.leftover, 5);
  assert.equal(r.ownershipPct, 0.05);
  assert.equal(r.illustrativeValue, 50);
});

test('ownership calculator validates input and caps at available supply', () => {
  assert.equal(calculateOwnership({ amount: 0, tokenPrice: 10, totalSupply: 100 }).valid, false);
  assert.equal(calculateOwnership({ amount: -5, tokenPrice: 10, totalSupply: 100 }).valid, false);
  assert.equal(calculateOwnership({ amount: 9.99, tokenPrice: 10, totalSupply: 100 }).valid, false);
  assert.equal(calculateOwnership({ amount: 5, tokenPrice: 1, totalSupply: 100, minInvestment: 10 }).valid, false);
  const capped = calculateOwnership({ amount: 1000, tokenPrice: 10, totalSupply: 100, available: 30 });
  assert.equal(capped.tokens, 30);
  assert.equal(capped.leftover, 700);
  // Floating point robustness: 30 / 10 must give 3 tokens, not 2.
  assert.equal(calculateOwnership({ amount: 0.3, tokenPrice: 0.1, totalSupply: 100 }).tokens, 3);
});

test('bond maths: par when coupon equals yield, inverse price/yield, sensible duration', () => {
  assert.ok(Math.abs(bondPrice(0.05, 0.05, 10, 2) - 100) < 1e-9);
  assert.ok(bondPrice(0.04, 0.05, 10, 2) < 100);
  assert.ok(bondPrice(0.06, 0.05, 10, 2) > 100);
  const d = modifiedDuration(0.0425, 0.04, 10, 2);
  assert.ok(d > 7.5 && d < 8.6, `duration ${d}`);
});

test('valueAsset derives illustrative token prices from reference quotes', () => {
  const gold = getAsset('vgld')!;
  const v = valueAsset(gold, { XAU: quote('XAU', 4000) });
  assert.equal(v.tokenPrice, 10);
  assert.equal(v.inputStatus, 'realtime');

  const coffee = getAsset('vcof')!;
  const c = valueAsset(coffee, { COFFEE: quote('COFFEE', 400, { status: 'historical' }) });
  assert.equal(c.tokenPrice, 10); // 37,500 lb × $4.00 / 15,000
  assert.equal(c.inputStatus, 'historical');

  const res = valueAsset(getAsset('vres')!, {});
  assert.equal(res.tokenPrice, 10);
  assert.equal(res.inputStatus, 'fixed');
});

test('valueAsset falls back to labelled demo values, never to random numbers', () => {
  const gold = getAsset('vgld')!;
  const v = valueAsset(gold, { XAU: quote('XAU', 0, { price: null, status: 'unavailable' }) });
  assert.equal(v.inputStatus, 'demo');
  assert.equal(v.referencePrice, INSTRUMENT_MAP.XAU.demo);
});

test('bond sample is priced from the reference yield', () => {
  const note = getAsset('vust10')!;
  const now = new Date('2026-10-30T00:00:00Z');
  const atCoupon = valueAsset(note, { UST10Y: quote('UST10Y', 4.25, { previous: 4.2 }) }, now);
  assert.ok(atCoupon.tokenPrice! > 9.95 && atCoupon.tokenPrice! < 10.05, String(atCoupon.tokenPrice));
  const higher = valueAsset(note, { UST10Y: quote('UST10Y', 5.25) }, now);
  assert.ok(higher.tokenPrice! < atCoupon.tokenPrice!);
  assert.ok(atCoupon.changePct! < 0, 'yield up from 4.20 → price down');
});

test('tokenPriceSeries converts reference history into token prices', () => {
  const gold = getAsset('vgld')!;
  const s = tokenPriceSeries(gold, [
    { t: 1, v: 4000 },
    { t: 2, v: 4400 },
  ]);
  assert.deepEqual(s.map((p) => p.v), [10, 11]);
  assert.deepEqual(tokenPriceSeries(getAsset('vres')!, [{ t: 1, v: 1 }]), []);
});

test('seriesStats computes drawdown and volatility from observations', () => {
  const day = 24 * 3600 * 1000;
  const pts = [100, 110, 90, 95, 120].map((v, i) => ({ t: i * day, v }));
  const s = seriesStats(pts);
  assert.equal(s.high, 120);
  assert.equal(s.low, 90);
  assert.ok(Math.abs(s.maxDrawdown! - (110 - 90) / 110) < 1e-12);
  assert.equal(s.volatility, null, 'needs at least 20 observations');
  const flat = seriesStats(Array.from({ length: 30 }, (_, i) => ({ t: i * day, v: 50 })));
  assert.equal(flat.volatility, 0);
  assert.equal(flat.maxDrawdown, 0);
});

test('recovery maths for drawdowns', () => {
  assert.ok(Math.abs(recoveryGainPct(15) - 17.647) < 0.01);
  assert.equal(recoveryGainPct(50), 100);
});

test('risk methodology produces sensible bands', () => {
  const gold = assessRisk(getAsset('vgld')!.risk);
  const btc = assessRisk(getAsset('vbtc')!.risk);
  assert.equal(gold.level, 'Moderate');
  assert.ok(btc.score > gold.score);
  assert.equal(gold.factors.reduce((s, f) => s + f.weight, 0).toFixed(2), '1.00');
  const measured = assessRisk(getAsset('vgld')!.risk, { volatility: 0.6, maxDrawdown: 0.7, observations: 250, window: '1Y' });
  assert.equal(measured.factors[0].basis, 'measured');
  assert.ok(measured.score > gold.score);
});

test('catalog integrity: references, token ids and on-chain JSON stay in sync', () => {
  const ids = TOKENISED_ASSETS.map((a) => a.tokenId);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(!ids.includes(0), 'token id 0 is reserved for demo credits');
  for (const a of TOKENISED_ASSETS) {
    const ref = assetReferenceInstrument(a);
    if (ref) assert.ok(INSTRUMENT_MAP[ref], `${a.id} references unknown instrument ${ref}`);
    assert.ok(a.onchainPrice > 0 && Number.isInteger(a.onchainPrice));
    assert.ok(a.sampleIssued < a.totalSupply);
  }
  for (const i of INSTRUMENTS) assert.ok(Object.keys(i.providers).length > 0, `${i.id} has no provider`);
  const json = JSON.parse(readFileSync(resolve(here, '../data/onchain-assets.json'), 'utf8'));
  assert.deepEqual(json.assets, onchainAssetDefinitions(), 'run `npm run assets:export` to regenerate data/onchain-assets.json');
});

test('assistant routes every suggested question to a sensible answer', () => {
  const answers = SUGGESTED_QUESTIONS.map((q) => answerQuestion({ question: q }));
  for (const a of answers) {
    assert.ok(a.summary.length > 20);
    assert.ok(a.disclaimer.includes('not financial advice'));
    assert.equal(a.mode, 'demo');
  }
  const [gold, silver, oil, realEstate, bonds, fall, fractional, drawdown] = answers;
  assert.equal(gold.title, 'Understanding Gold');
  assert.deepEqual(gold.sections.map((s) => s.heading), [...ASSET_SECTION_HEADINGS]);
  assert.ok(gold.risk && gold.scenarios);
  assert.match(silver.title, /vs/);
  assert.ok(silver.sections.some((s) => s.heading.includes('silver tends to swing')));
  assert.match(oil.title, /Crude Oil/i);
  assert.equal(realEstate.title, 'Understanding Real Estate');
  assert.equal(bonds.title, CONCEPTS.bonds.title);
  assert.equal(fall.title, CONCEPTS.fall.title);
  assert.equal(fractional.title, CONCEPTS.fractional.title);
  assert.equal(drawdown.title, 'What does a 15% drawdown mean?');
  assert.match(drawdown.summary, /17\.6%/);
});

test('assistant refuses to give personal advice or predictions', () => {
  const r = answerQuestion({ question: 'Should I buy bitcoin now? Will it go up?' });
  assert.ok(r.notice && r.notice.includes('can’t tell you'));
  const all = JSON.stringify(r).toLowerCase();
  assert.ok(!all.includes('you should buy'));
  assert.ok(!all.includes('guaranteed return'));
});

test('assistant uses page context when the question has no explicit subject', () => {
  const r = answerQuestion({ question: 'What are the main risks?', assetId: 'vcof' });
  assert.equal(r.subject?.id, 'vcof');
  assert.ok(r.sections.length === 7);
});

test('NYSE session status honours weekends and holidays', () => {
  assert.equal(nyseSession(new Date('2026-10-30T14:00:00Z')).state, 'open'); // Fri 10:00 ET
  assert.equal(nyseSession(new Date('2026-10-31T15:00:00Z')).state, 'closed'); // Saturday
  assert.equal(nyseSession(new Date('2026-11-26T15:00:00Z')).state, 'holiday'); // Thanksgiving
  assert.equal(nyseSession(new Date('2026-10-30T12:00:00Z')).state, 'pre-market'); // 08:00 ET
});

test('formatting helpers', () => {
  assert.equal(formatPct(1.234), '+1.23%');
  assert.equal(formatPct(-0.5), '−0.50%');
  assert.equal(formatQuote(400.5, 'USc'), '400.50¢');
  assert.equal(formatQuote(4.05, 'percent'), '4.05%');
  assert.equal(formatQuote(null, 'USD'), '—');
});
