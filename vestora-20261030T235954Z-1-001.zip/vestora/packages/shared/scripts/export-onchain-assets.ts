/**
 * Writes data/onchain-assets.json from the canonical TypeScript asset catalog.
 * The Hardhat deploy script reads this JSON to create the same assets on-chain.
 *   npm run export:onchain -w @vestora/shared
 */
import { writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { onchainAssetDefinitions } from '../src/assets';

const here = dirname(fileURLToPath(import.meta.url));
const out = resolve(here, '../data/onchain-assets.json');
const payload = {
  _note: 'Generated from packages/shared/src/assets.ts — run `npm run assets:export` after editing the catalog.',
  creditTokenId: 0,
  assets: onchainAssetDefinitions(),
};
writeFileSync(out, `${JSON.stringify(payload, null, 2)}\n`);
console.log(`Wrote ${payload.assets.length} asset definitions to ${out}`);
