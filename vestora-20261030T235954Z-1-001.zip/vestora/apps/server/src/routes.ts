import { Router, type NextFunction, type Request, type Response } from 'express';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import { HISTORY_RANGES, INSTRUMENTS, TOKENISED_ASSETS, type HealthResponse, type NewsCategory } from '@vestora/shared';
import type { AssistantService } from './ai/service';
import type { MarketDataService } from './market/service';
import type { NewsService } from './news/service';
import { PROFILE_ID_RE, ProfileAuthError, ProfilePayloadSchema, type ProfileStore } from './storage/profiles';

export interface Services {
  market: MarketDataService;
  news: NewsService;
  ai: AssistantService;
  profiles: ProfileStore;
  version: string;
  aiRateLimitPerMinute: number;
}

type Handler = (req: Request, res: Response) => Promise<unknown>;

/** Express 4 does not catch async errors — forward them to the error handler. */
const wrap =
  (fn: Handler) =>
  (req: Request, res: Response, next: NextFunction): void => {
    fn(req, res).catch(next);
  };

const QuotesQuery = z.object({
  ids: z
    .string()
    .optional()
    .transform((v) => (v ? v.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean).slice(0, 60) : INSTRUMENTS.map((i) => i.id))),
});

const HistoryQuery = z.object({
  id: z.string().min(1).max(16).transform((s) => s.toUpperCase()),
  range: z.enum(HISTORY_RANGES as [string, ...string[]]).default('1M'),
});

const AskBody = z.object({
  question: z.string().trim().min(2, 'Ask a question of at least 2 characters.').max(600, 'Questions are limited to 600 characters.'),
  assetId: z.string().max(32).optional(),
  instrumentId: z.string().max(16).optional(),
});

const NEWS_CATEGORIES: NewsCategory[] = ['energy', 'macro', 'digital-assets', 'metals', 'markets'];

export function createApiRouter(s: Services): Router {
  const r = Router();

  r.get(
    '/health',
    wrap(async (_req, res) => {
      const body: HealthResponse = {
        ok: true,
        name: 'VESTORA API',
        version: s.version,
        time: new Date().toISOString(),
        providers: s.market.health(),
        ai: s.ai.status(),
        storage: { mode: s.profiles.mode },
        news: { enabled: s.news.feedCount > 0, feeds: s.news.feedCount },
        demoFallback: s.market.demoFallback,
      };
      res.json(body);
    }),
  );

  r.get(
    '/market/instruments',
    wrap(async (_req, res) => {
      res.json({ instruments: INSTRUMENTS, assets: TOKENISED_ASSETS, routing: s.market.routing() });
    }),
  );

  r.get(
    '/market/quotes',
    wrap(async (req, res) => {
      const q = QuotesQuery.parse(req.query);
      const quotes = await s.market.getQuotes(q.ids);
      res.set('cache-control', 'public, max-age=15');
      res.json({ quotes, generatedAt: new Date().toISOString() });
    }),
  );

  r.get(
    '/market/history',
    wrap(async (req, res) => {
      const parsed = HistoryQuery.safeParse(req.query);
      if (!parsed.success) return res.status(400).json({ error: 'Provide ?id=<instrument>&range=1D|1W|1M|3M|1Y|ALL' });
      const series = await s.market.getHistory(parsed.data.id, parsed.data.range as (typeof HISTORY_RANGES)[number]);
      if (!series) return res.status(404).json({ error: `Unknown instrument "${parsed.data.id}"` });
      res.set('cache-control', 'public, max-age=60');
      return res.json(series);
    }),
  );

  r.get(
    '/news',
    wrap(async (req, res) => {
      const cat = typeof req.query.category === 'string' && NEWS_CATEGORIES.includes(req.query.category as NewsCategory) ? (req.query.category as NewsCategory) : undefined;
      res.set('cache-control', 'public, max-age=120');
      res.json(await s.news.latest(cat));
    }),
  );

  const aiLimiter = rateLimit({
    windowMs: 60_000,
    limit: s.aiRateLimitPerMinute,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: 'Too many questions in a short time. Please wait a minute and try again.' },
  });

  r.get('/ai/status', (_req: Request, res: Response) => {
    res.json(s.ai.status());
  });

  r.post(
    '/ai/ask',
    aiLimiter,
    wrap(async (req, res) => {
      const parsed = AskBody.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message ?? 'Invalid request' });
      return res.json(await s.ai.ask(parsed.data));
    }),
  );

  r.get(
    '/ai/explain/:assetId',
    aiLimiter,
    wrap(async (req, res) => {
      const asset = TOKENISED_ASSETS.find((a) => a.id === req.params.assetId);
      if (!asset) return res.status(404).json({ error: 'Unknown asset' });
      return res.json(await s.ai.ask({ question: `Explain the ${asset.name} (${asset.symbol}) and its risks.`, assetId: asset.id }));
    }),
  );

  // Profiles: anonymous id + secret header (x-profile-key).
  const profileSecret = (req: Request): string | null => {
    const key = req.header('x-profile-key');
    return key && key.length >= 16 && key.length <= 128 ? key : null;
  };

  r.get(
    '/profile/:id',
    wrap(async (req, res) => {
      const secret = profileSecret(req);
      if (!PROFILE_ID_RE.test(req.params.id) || !secret) return res.status(400).json({ error: 'Invalid profile id or key' });
      try {
        const p = await s.profiles.get(req.params.id, secret);
        return p ? res.json(p) : res.status(404).json({ error: 'Profile not found' });
      } catch (err) {
        if (err instanceof ProfileAuthError) return res.status(403).json({ error: err.message });
        throw err;
      }
    }),
  );

  r.put(
    '/profile/:id',
    wrap(async (req, res) => {
      const secret = profileSecret(req);
      if (!PROFILE_ID_RE.test(req.params.id) || !secret) return res.status(400).json({ error: 'Invalid profile id or key' });
      const parsed = ProfilePayloadSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ error: 'Invalid profile payload' });
      try {
        return res.json(await s.profiles.put(req.params.id, secret, parsed.data));
      } catch (err) {
        if (err instanceof ProfileAuthError) return res.status(403).json({ error: err.message });
        throw err;
      }
    }),
  );

  r.use((_req: Request, res: Response) => {
    res.status(404).json({ error: 'Not found' });
  });

  return r;
}
