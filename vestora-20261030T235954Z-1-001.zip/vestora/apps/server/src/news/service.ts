import type { NewsCategory, NewsItem, NewsResponse } from '@vestora/shared';
import { TtlCache } from '../lib/cache';
import { fetchText, type FetchLike } from '../lib/http';
import { log } from '../lib/logger';

export interface FeedConfig {
  url: string;
  source: string;
  category: NewsCategory;
}

/** Public RSS/Atom feeds from official or widely used sources. Override with NEWS_FEEDS (JSON array). */
export const DEFAULT_FEEDS: FeedConfig[] = [
  { url: 'https://www.federalreserve.gov/feeds/press_all.xml', source: 'Federal Reserve', category: 'macro' },
  { url: 'https://www.eia.gov/rss/todayinenergy.xml', source: 'U.S. EIA — Today in Energy', category: 'energy' },
  { url: 'https://www.mining.com/feed/', source: 'MINING.COM', category: 'metals' },
  { url: 'https://www.coindesk.com/arc/outboundfeeds/rss/', source: 'CoinDesk', category: 'digital-assets' },
];

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

function decode(s: string): string {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&([a-z]+);/gi, (m, n) => ENTITIES[n.toLowerCase()] ?? m);
}

function stripHtml(s: string): string {
  return decode(s)
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tag(block: string, name: string): string | null {
  const m = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i'));
  return m ? m[1].trim() : null;
}

function safeUrl(u: string | null): string | null {
  if (!u) return null;
  try {
    const url = new URL(decode(u).trim());
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.toString() : null;
  } catch {
    return null;
  }
}

/** Minimal RSS 2.0 / Atom parser — enough for titles, links, dates and summaries. */
export function parseFeed(xml: string, feed: FeedConfig): NewsItem[] {
  const items: NewsItem[] = [];
  const rss = xml.match(/<item[\s>][\s\S]*?<\/item>/gi) ?? [];
  const atom = rss.length ? [] : (xml.match(/<entry[\s>][\s\S]*?<\/entry>/gi) ?? []);
  for (const block of [...rss, ...atom]) {
    const title = stripHtml(tag(block, 'title') ?? '');
    let link = safeUrl(tag(block, 'link'));
    if (!link) {
      const href = block.match(/<link[^>]*href="([^"]+)"/i);
      link = safeUrl(href ? href[1] : null);
    }
    if (!title || !link) continue;
    const dateRaw = tag(block, 'pubDate') ?? tag(block, 'updated') ?? tag(block, 'published') ?? tag(block, 'dc:date');
    const date = dateRaw ? new Date(decode(dateRaw)) : null;
    const summaryRaw = tag(block, 'description') ?? tag(block, 'summary') ?? '';
    const summary = stripHtml(summaryRaw).slice(0, 240);
    items.push({
      id: `${feed.source}:${link}`,
      title: title.slice(0, 220),
      url: link,
      source: feed.source,
      category: feed.category,
      publishedAt: date && Number.isFinite(date.getTime()) ? date.toISOString() : null,
      summary: summary || undefined,
    });
  }
  return items;
}

export class NewsService {
  private cache = new TtlCache<NewsItem[]>(24 * 3600_000);

  constructor(
    private readonly feeds: FeedConfig[],
    private readonly enabled: boolean,
    private readonly fetchImpl: FetchLike = fetch as FetchLike,
    private readonly timeoutMs = 9000,
  ) {}

  get feedCount(): number {
    return this.enabled ? this.feeds.length : 0;
  }

  async latest(category?: NewsCategory, limit = 30): Promise<NewsResponse> {
    const generatedAt = new Date().toISOString();
    if (!this.enabled) return { items: [], generatedAt, status: 'unavailable', message: 'News is disabled on this server (NEWS_ENABLED=false).' };
    const feeds = category ? this.feeds.filter((f) => f.category === category) : this.feeds;
    const results = await Promise.allSettled(
      feeds.map(async (f) => {
        try {
          return await this.cache.getOrLoad(f.url, 15 * 60_000, async () => parseFeed(await fetchText(f.url, { timeoutMs: this.timeoutMs, fetchImpl: this.fetchImpl }), f));
        } catch (err) {
          log.warn(`news feed failed: ${f.source}`, { error: (err as Error).message });
          const stale = this.cache.getStale(f.url);
          if (stale) return stale.value;
          throw err;
        }
      }),
    );
    const items = results
      .flatMap((r) => (r.status === 'fulfilled' ? r.value : []))
      .sort((a, b) => (b.publishedAt ?? '').localeCompare(a.publishedAt ?? ''));
    const seen = new Set<string>();
    const unique = items.filter((i) => (seen.has(i.url) ? false : (seen.add(i.url), true))).slice(0, limit);
    if (unique.length === 0) {
      return { items: [], generatedAt, status: 'unavailable', message: 'News feeds could not be reached right now.' };
    }
    return { items: unique, generatedAt, status: 'live' };
  }
}

export function parseFeedsEnv(raw: string | undefined): FeedConfig[] {
  if (!raw) return DEFAULT_FEEDS;
  try {
    const parsed = JSON.parse(raw) as FeedConfig[];
    const valid = parsed.filter((f) => typeof f.url === 'string' && /^https?:\/\//.test(f.url) && typeof f.source === 'string');
    return valid.length ? valid.map((f) => ({ ...f, category: f.category ?? 'markets' })) : DEFAULT_FEEDS;
  } catch {
    log.warn('NEWS_FEEDS is not valid JSON — using default feeds');
    return DEFAULT_FEEDS;
  }
}
