import { fetchJson, UpstreamError } from '../../lib/http';
import type { MarketProvider, ProviderDeps, ProviderItem, ProviderQuote } from '../types';

/**
 * GoldAPI.io — spot precious metals (XAU, XAG, XPT, XPD). One request per metal.
 * Free plans have small monthly quotas, so quotes are cached for GOLDAPI_TTL_MINUTES (default 8h).
 */
export function createGoldApi(opts: { apiKey?: string; ttlMinutes: number }, deps: ProviderDeps): MarketProvider {
  return {
    id: 'goldapi',
    name: 'GoldAPI.io',
    url: 'https://www.goldapi.io',
    keyless: false,
    configured: Boolean(opts.apiKey),
    quoteTtlMs: () => opts.ttlMinutes * 60_000,
    historyTtlMs: () => opts.ttlMinutes * 60_000,
    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      if (!opts.apiKey) return out;
      const results = await Promise.allSettled(
        items.map((item) =>
          fetchJson<{ price?: number; prev_close_price?: number; timestamp?: number; error?: string }>(
            `https://www.goldapi.io/api/${encodeURIComponent(item.mapping.symbol)}/USD`,
            { headers: { 'x-access-token': opts.apiKey as string }, timeoutMs: deps.timeoutMs, fetchImpl: deps.fetch },
          ),
        ),
      );
      let firstError: unknown = null;
      results.forEach((r, idx) => {
        if (r.status === 'rejected') {
          firstError ??= r.reason;
          return;
        }
        const d = r.value;
        if (typeof d.price !== 'number') {
          if (d.error) firstError ??= new UpstreamError(`GoldAPI: ${d.error}`);
          return;
        }
        const m = items[idx].mapping.multiplier ?? 1;
        out.set(items[idx].instrument.id, {
          price: d.price * m,
          previous: typeof d.prev_close_price === 'number' ? d.prev_close_price * m : null,
          changeBasis: typeof d.prev_close_price === 'number' ? 'previous-close' : null,
          asOf: d.timestamp ? new Date(d.timestamp * (d.timestamp > 1e12 ? 1 : 1000)).toISOString() : null,
          status: 'realtime',
          frequency: 'realtime',
        });
      });
      if (out.size === 0 && firstError) throw firstError;
      return out;
    },
  };
}

/**
 * Metals.Dev — one request returns precious and base metals (USD per troy ounce;
 * base metals are converted to USD per metric ton via the mapping multiplier).
 * The latest endpoint has no previous close, so change is shown as unavailable.
 */
export function createMetalsDev(opts: { apiKey?: string; ttlMinutes: number }, deps: ProviderDeps): MarketProvider {
  return {
    id: 'metalsdev',
    name: 'Metals.Dev',
    url: 'https://metals.dev',
    keyless: false,
    configured: Boolean(opts.apiKey),
    quoteTtlMs: () => opts.ttlMinutes * 60_000,
    historyTtlMs: () => opts.ttlMinutes * 60_000,
    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      if (!opts.apiKey || items.length === 0) return out;
      const url = `https://api.metals.dev/v1/latest?api_key=${encodeURIComponent(opts.apiKey)}&currency=USD&unit=toz`;
      const d = await fetchJson<{ status?: string; error_message?: string; metals?: Record<string, number>; timestamps?: { metal?: string } }>(url, {
        timeoutMs: deps.timeoutMs,
        fetchImpl: deps.fetch,
      });
      if (d.status && d.status !== 'success') throw new UpstreamError(`Metals.Dev: ${d.error_message ?? d.status}`);
      const metals = d.metals ?? {};
      for (const item of items) {
        const key = item.mapping.symbol;
        const raw = metals[key] ?? metals[`lme_${key}`];
        if (typeof raw !== 'number' || !Number.isFinite(raw)) continue;
        out.set(item.instrument.id, {
          price: raw * (item.mapping.multiplier ?? 1),
          previous: null,
          changeBasis: null,
          asOf: d.timestamps?.metal ?? null,
          status: 'realtime',
          frequency: 'realtime',
        });
      }
      return out;
    },
  };
}
