import type { HistoryRange, SeriesPoint } from '@vestora/shared';
import { TtlCache } from '../../lib/cache';
import { fetchJson, fetchText } from '../../lib/http';
import { DAY_MS, isoDate, parseNum, sliceToRange, type MarketProvider, type ProviderDeps, type ProviderItem, type ProviderQuote } from '../types';

/**
 * FRED (Federal Reserve Bank of St. Louis) — Treasury yields, US indices, EIA energy
 * spot prices and IMF monthly commodity prices.
 *
 * With FRED_API_KEY the official API is used. Without a key VESTORA falls back to
 * FRED's public CSV download (fredgraph.csv), which is keyless but less formal —
 * register a free key for production use.
 */
export function createFred(opts: { apiKey?: string; keyless: boolean }, deps: ProviderDeps): MarketProvider {
  const seriesCache = new TtlCache<SeriesPoint[]>(7 * DAY_MS);
  const configured = Boolean(opts.apiKey) || opts.keyless;

  const ttlFor = (item: ProviderItem) => (item.mapping.frequency === 'monthly' ? 6 * 3600_000 : 30 * 60_000);

  async function loadSeries(item: ProviderItem): Promise<SeriesPoint[]> {
    const id = item.mapping.symbol;
    return seriesCache.getOrLoad(id, ttlFor(item), async () => {
      const start = isoDate(new Date(deps.now().getTime() - 20 * 365 * DAY_MS));
      let rows: { date: string; value: number | null }[];
      if (opts.apiKey) {
        const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${encodeURIComponent(id)}&api_key=${encodeURIComponent(opts.apiKey)}&file_type=json&observation_start=${start}`;
        const data = await fetchJson<{ observations?: { date: string; value: string }[] }>(url, { timeoutMs: deps.timeoutMs, fetchImpl: deps.fetch });
        rows = (data.observations ?? []).map((o) => ({ date: o.date, value: parseNum(o.value) }));
      } else {
        const url = `https://fred.stlouisfed.org/graph/fredgraph.csv?id=${encodeURIComponent(id)}&cosd=${start}`;
        const csv = await fetchText(url, { timeoutMs: deps.timeoutMs, fetchImpl: deps.fetch });
        rows = parseFredCsv(csv);
      }
      const multiplier = item.mapping.multiplier ?? 1;
      return rows
        .filter((r): r is { date: string; value: number } => r.value !== null)
        .map((r) => ({ t: Date.parse(`${r.date}T00:00:00Z`), v: r.value * multiplier }))
        .filter((p) => Number.isFinite(p.t))
        .sort((a, b) => a.t - b.t);
    });
  }

  return {
    id: 'fred',
    name: opts.apiKey ? 'FRED (St. Louis Fed)' : 'FRED public CSV (St. Louis Fed)',
    url: 'https://fred.stlouisfed.org',
    keyless: !opts.apiKey,
    configured,
    quoteTtlMs: ttlFor,
    historyTtlMs: ttlFor,

    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      const results = await Promise.allSettled(items.map((i) => loadSeries(i)));
      let firstError: unknown = null;
      results.forEach((r, idx) => {
        const item = items[idx];
        if (r.status === 'rejected') {
          firstError ??= r.reason;
          return;
        }
        const pts = r.value;
        if (pts.length === 0) return;
        const last = pts[pts.length - 1];
        const prev = pts.length > 1 ? pts[pts.length - 2] : null;
        const monthly = item.mapping.frequency === 'monthly';
        out.set(item.instrument.id, {
          price: last.v,
          previous: prev ? prev.v : null,
          changeBasis: prev ? 'previous-observation' : null,
          asOf: new Date(last.t).toISOString(),
          status: monthly ? 'historical' : 'delayed',
          frequency: item.mapping.frequency ?? 'daily',
        });
      });
      if (out.size === 0 && firstError) throw firstError;
      return out;
    },

    async history(item: ProviderItem, range: HistoryRange) {
      const all = await loadSeries(item);
      const points = sliceToRange(all, range, deps.now());
      const monthly = item.mapping.frequency === 'monthly';
      let message: string | undefined;
      if (points.length < 2) {
        message = monthly
          ? 'This source publishes monthly averages — choose 1Y or ALL to see a meaningful history.'
          : 'This source publishes daily observations (no intraday data) — choose 1W or longer.';
      }
      return { points, status: monthly ? 'historical' : 'delayed', frequency: item.mapping.frequency ?? 'daily', message };
    },
  };
}

/** Parses FRED's fredgraph.csv (header "observation_date,<ID>" or legacy "DATE,<ID>"). */
export function parseFredCsv(csv: string): { date: string; value: number | null }[] {
  const lines = csv.trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  return lines.slice(1).flatMap((line) => {
    const [date, raw] = line.split(',');
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date.trim())) return [];
    return [{ date: date.trim(), value: parseNum(raw) }];
  });
}
