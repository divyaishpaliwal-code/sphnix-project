import type { HistoryRange } from '@vestora/shared';
import { fetchJson } from '../../lib/http';
import type { MarketProvider, ProviderDeps, ProviderItem, ProviderQuote, ProviderSeries } from '../types';

/**
 * CoinGecko — crypto prices (and PAXG as a clearly-labelled gold proxy).
 * Works without a key on the public API (rate-limited, 365 days of history);
 * set COINGECKO_API_KEY for a Demo or Pro key.
 */
export function createCoinGecko(opts: { apiKey?: string; plan: 'demo' | 'pro' }, deps: ProviderDeps): MarketProvider {
  const base = opts.apiKey && opts.plan === 'pro' ? 'https://pro-api.coingecko.com/api/v3' : 'https://api.coingecko.com/api/v3';
  const headers: Record<string, string> = {};
  if (opts.apiKey) headers[opts.plan === 'pro' ? 'x-cg-pro-api-key' : 'x-cg-demo-api-key'] = opts.apiKey;

  return {
    id: 'coingecko',
    name: 'CoinGecko',
    url: 'https://www.coingecko.com',
    keyless: true,
    configured: true,
    quoteTtlMs: () => 60_000,
    historyTtlMs: (_item, range) => (range === '1D' ? 5 * 60_000 : 30 * 60_000),

    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      if (items.length === 0) return out;
      const ids = [...new Set(items.map((i) => i.mapping.symbol))];
      const url = `${base}/simple/price?ids=${encodeURIComponent(ids.join(','))}&vs_currencies=usd&include_24hr_change=true&include_last_updated_at=true`;
      const data = await fetchJson<Record<string, { usd?: number; usd_24h_change?: number; last_updated_at?: number }>>(url, {
        headers,
        timeoutMs: deps.timeoutMs,
        fetchImpl: deps.fetch,
      });
      for (const item of items) {
        const row = data[item.mapping.symbol];
        if (!row || typeof row.usd !== 'number') continue;
        const pct = typeof row.usd_24h_change === 'number' ? row.usd_24h_change : null;
        out.set(item.instrument.id, {
          price: row.usd,
          previous: pct !== null ? row.usd / (1 + pct / 100) : null,
          changePct: pct,
          changeBasis: pct !== null ? '24h' : null,
          asOf: row.last_updated_at ? new Date(row.last_updated_at * 1000).toISOString() : null,
          status: 'realtime',
          frequency: 'realtime',
        });
      }
      return out;
    },

    async history(item: ProviderItem, range: HistoryRange): Promise<ProviderSeries | null> {
      const days = { '1D': 1, '1W': 7, '1M': 30, '3M': 90, '1Y': 365, ALL: opts.apiKey && opts.plan === 'pro' ? 'max' : 365 }[range];
      const url = `${base}/coins/${encodeURIComponent(item.mapping.symbol)}/market_chart?vs_currency=usd&days=${days}`;
      const data = await fetchJson<{ prices?: [number, number][] }>(url, { headers, timeoutMs: deps.timeoutMs, fetchImpl: deps.fetch });
      const points = (data.prices ?? []).filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1])).map(([t, v]) => ({ t, v }));
      return {
        points,
        status: range === '1D' ? 'realtime' : 'historical',
        frequency: range === '1D' || range === '1W' || range === '1M' || range === '3M' ? 'intraday' : 'daily',
        message: range === 'ALL' && days === 365 ? 'The free CoinGecko API provides up to 365 days of history.' : undefined,
      };
    },
  };
}
