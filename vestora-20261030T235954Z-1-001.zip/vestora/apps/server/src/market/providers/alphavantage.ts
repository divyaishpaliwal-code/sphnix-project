import type { HistoryRange, SeriesPoint } from '@vestora/shared';
import { TtlCache } from '../../lib/cache';
import { fetchJson, RateLimitError, UpstreamError } from '../../lib/http';
import { DAY_MS, parseNum, sliceToRange, type MarketProvider, type ProviderDeps, type ProviderItem, type ProviderQuote } from '../types';

/**
 * Alpha Vantage — commodity series (WTI, Brent, natural gas daily; metals and
 * agriculture monthly) and US Treasury yields. One request returns the full
 * series, which serves both quotes and history. The free tier allows very few
 * requests per day, so series are cached for 12 hours.
 */
export function createAlphaVantage(opts: { apiKey?: string }, deps: ProviderDeps): MarketProvider {
  const cache = new TtlCache<SeriesPoint[]>(7 * DAY_MS);
  const TTL = 12 * 3600_000;

  async function load(item: ProviderItem): Promise<SeriesPoint[]> {
    const symbol = item.mapping.symbol;
    return cache.getOrLoad(symbol, TTL, async () => {
      const [fn, maturity] = symbol.split(':');
      const interval = item.mapping.frequency === 'monthly' ? 'monthly' : 'daily';
      const url =
        `https://www.alphavantage.co/query?function=${encodeURIComponent(fn)}&interval=${interval}` +
        (maturity ? `&maturity=${encodeURIComponent(maturity)}` : '') +
        `&apikey=${encodeURIComponent(opts.apiKey as string)}`;
      const d = await fetchJson<{ data?: { date: string; value: string }[]; Note?: string; Information?: string; 'Error Message'?: string }>(url, {
        timeoutMs: deps.timeoutMs,
        fetchImpl: deps.fetch,
      });
      if (d.Note || d.Information) throw new RateLimitError(`Alpha Vantage: ${(d.Note ?? d.Information ?? '').slice(0, 140)}`, 3600_000);
      if (d['Error Message']) throw new UpstreamError(`Alpha Vantage: ${d['Error Message']}`);
      const m = item.mapping.multiplier ?? 1;
      return (d.data ?? [])
        .map((row) => ({ t: Date.parse(`${row.date}T00:00:00Z`), v: parseNum(row.value) }))
        .filter((p): p is SeriesPoint => Number.isFinite(p.t) && p.v !== null)
        .map((p) => ({ t: p.t, v: p.v * m }))
        .sort((a, b) => a.t - b.t);
    });
  }

  return {
    id: 'alphavantage',
    name: 'Alpha Vantage',
    url: 'https://www.alphavantage.co',
    keyless: false,
    configured: Boolean(opts.apiKey),
    quoteTtlMs: () => TTL,
    historyTtlMs: () => TTL,

    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      if (!opts.apiKey) return out;
      let firstError: unknown = null;
      // Sequential: the free tier rejects bursts.
      for (const item of items) {
        try {
          const pts = await load(item);
          if (pts.length === 0) continue;
          const last = pts[pts.length - 1];
          const prev = pts.length > 1 ? pts[pts.length - 2] : null;
          const monthly = item.mapping.frequency === 'monthly';
          out.set(item.instrument.id, {
            price: last.v,
            previous: prev?.v ?? null,
            changeBasis: prev ? 'previous-observation' : null,
            asOf: new Date(last.t).toISOString(),
            status: monthly ? 'historical' : 'delayed',
            frequency: item.mapping.frequency ?? 'daily',
          });
        } catch (err) {
          firstError ??= err;
          if (err instanceof RateLimitError) break;
        }
      }
      if (out.size === 0 && firstError) throw firstError;
      return out;
    },

    async history(item: ProviderItem, range: HistoryRange) {
      if (!opts.apiKey) return null;
      const points = sliceToRange(await load(item), range, deps.now());
      const monthly = item.mapping.frequency === 'monthly';
      return {
        points,
        status: monthly ? 'historical' : 'delayed',
        frequency: item.mapping.frequency ?? 'daily',
        message: points.length < 2 ? 'Not enough observations in this range for this source — try a longer range.' : undefined,
      };
    },
  };
}
