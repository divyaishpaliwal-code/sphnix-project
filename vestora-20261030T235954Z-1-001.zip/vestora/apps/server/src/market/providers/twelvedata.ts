import type { HistoryRange } from '@vestora/shared';
import { fetchJson, RateLimitError, UpstreamError } from '../../lib/http';
import { parseNum, type MarketProvider, type ProviderDeps, type ProviderItem, type ProviderQuote, type ProviderSeries } from '../types';

interface TdQuote {
  symbol?: string;
  close?: string;
  previous_close?: string;
  timestamp?: number;
  last_quote_at?: number;
  code?: number;
  message?: string;
  status?: string;
}

/**
 * Twelve Data — precious metals as forex pairs (XAU/USD …) and crypto pairs.
 * Labelled "delayed" unless TWELVEDATA_REALTIME=true (depends on your plan).
 */
export function createTwelveData(opts: { apiKey?: string; realtime: boolean }, deps: ProviderDeps): MarketProvider {
  const status = opts.realtime ? 'realtime' : 'delayed';

  function check(d: { code?: number; message?: string; status?: string }) {
    if (d.status === 'error' || (typeof d.code === 'number' && d.code >= 400)) {
      if (d.code === 429) throw new RateLimitError(`Twelve Data: ${d.message ?? 'rate limited'}`, 60_000);
      throw new UpstreamError(`Twelve Data: ${d.message ?? 'error'}`, d.code);
    }
  }

  return {
    id: 'twelvedata',
    name: 'Twelve Data',
    url: 'https://twelvedata.com',
    keyless: false,
    configured: Boolean(opts.apiKey),
    quoteTtlMs: () => 5 * 60_000,
    historyTtlMs: (_i, range) => (range === '1D' ? 10 * 60_000 : 60 * 60_000),

    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      if (!opts.apiKey || items.length === 0) return out;
      const symbols = items.map((i) => i.mapping.symbol);
      const url = `https://api.twelvedata.com/quote?symbol=${encodeURIComponent(symbols.join(','))}&apikey=${encodeURIComponent(opts.apiKey)}`;
      const raw = await fetchJson<TdQuote | Record<string, TdQuote>>(url, { timeoutMs: deps.timeoutMs, fetchImpl: deps.fetch });
      // A top-level error object (bad key, rate limit) is returned for single and batch requests alike.
      check(raw as TdQuote);
      const bySymbol: Record<string, TdQuote> = symbols.length === 1 ? { [symbols[0]]: raw as TdQuote } : (raw as Record<string, TdQuote>);
      for (const item of items) {
        const q = bySymbol[item.mapping.symbol];
        if (!q || q.status === 'error') continue;
        const price = parseNum(q.close);
        if (price === null) continue;
        const prev = parseNum(q.previous_close);
        const m = item.mapping.multiplier ?? 1;
        const ts = q.last_quote_at ?? q.timestamp;
        out.set(item.instrument.id, {
          price: price * m,
          previous: prev !== null ? prev * m : null,
          changeBasis: prev !== null ? 'previous-close' : null,
          asOf: ts ? new Date(ts * 1000).toISOString() : null,
          status,
          frequency: 'realtime',
        });
      }
      return out;
    },

    async history(item: ProviderItem, range: HistoryRange): Promise<ProviderSeries | null> {
      if (!opts.apiKey) return null;
      const spec: Record<HistoryRange, [string, number]> = {
        '1D': ['15min', 96],
        '1W': ['1h', 168],
        '1M': ['1day', 31],
        '3M': ['1day', 92],
        '1Y': ['1day', 366],
        ALL: ['1week', 520],
      };
      const [interval, size] = spec[range];
      const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(item.mapping.symbol)}&interval=${interval}&outputsize=${size}&timezone=UTC&apikey=${encodeURIComponent(opts.apiKey)}`;
      const d = await fetchJson<{ values?: { datetime: string; close: string }[]; code?: number; message?: string; status?: string }>(url, {
        timeoutMs: deps.timeoutMs,
        fetchImpl: deps.fetch,
      });
      check(d);
      const m = item.mapping.multiplier ?? 1;
      const points = (d.values ?? [])
        .map((v) => ({ t: Date.parse(v.datetime.includes(' ') ? `${v.datetime.replace(' ', 'T')}Z` : `${v.datetime}T00:00:00Z`), v: (parseNum(v.close) ?? NaN) * m }))
        .filter((p) => Number.isFinite(p.t) && Number.isFinite(p.v))
        .sort((a, b) => a.t - b.t);
      return { points, status: range === '1D' ? status : 'historical', frequency: interval.endsWith('day') || interval === '1week' ? 'daily' : 'intraday' };
    },
  };
}
