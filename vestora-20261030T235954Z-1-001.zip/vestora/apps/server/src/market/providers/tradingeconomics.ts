import type { HistoryRange } from '@vestora/shared';
import { TtlCache } from '../../lib/cache';
import { fetchJson } from '../../lib/http';
import { DAY_MS, isoDate, parseNum, RANGE_DAYS, type MarketProvider, type ProviderDeps, type ProviderItem, type ProviderQuote } from '../types';

interface TeRow {
  Symbol?: string;
  Name?: string;
  Last?: number;
  DailyChange?: number;
  LastUpdate?: string;
}

/**
 * Trading Economics — one request returns delayed quotes for most commodities.
 * Requires a paid key (the "guest:guest" sample key returns limited data).
 * Mapping symbols are "TICKER|Name" so either field can match.
 */
export function createTradingEconomics(opts: { apiKey?: string }, deps: ProviderDeps): MarketProvider {
  const listCache = new TtlCache<TeRow[]>(DAY_MS);

  function find(rows: TeRow[], mapping: string): TeRow | undefined {
    const [ticker, name] = mapping.split('|');
    return (
      rows.find((r) => r.Symbol && r.Symbol.toUpperCase() === ticker.toUpperCase()) ??
      rows.find((r) => r.Name && name && r.Name.toLowerCase() === name.toLowerCase())
    );
  }

  return {
    id: 'tradingeconomics',
    name: 'Trading Economics',
    url: 'https://tradingeconomics.com',
    keyless: false,
    configured: Boolean(opts.apiKey),
    quoteTtlMs: () => 10 * 60_000,
    historyTtlMs: () => 6 * 3600_000,

    async quotes(items: ProviderItem[]) {
      const out = new Map<string, ProviderQuote>();
      if (!opts.apiKey || items.length === 0) return out;
      const rows = await listCache.getOrLoad('commodities', 10 * 60_000, () =>
        fetchJson<TeRow[]>(`https://api.tradingeconomics.com/markets/commodities?c=${encodeURIComponent(opts.apiKey as string)}&f=json`, {
          timeoutMs: deps.timeoutMs,
          fetchImpl: deps.fetch,
        }),
      );
      for (const item of items) {
        const row = find(Array.isArray(rows) ? rows : [], item.mapping.symbol);
        const last = parseNum(row?.Last);
        if (!row || last === null) continue;
        const m = item.mapping.multiplier ?? 1;
        const change = parseNum(row.DailyChange);
        out.set(item.instrument.id, {
          price: last * m,
          previous: change !== null ? (last - change) * m : null,
          changeBasis: change !== null ? 'previous-close' : null,
          asOf: row.LastUpdate ? new Date(row.LastUpdate.endsWith('Z') ? row.LastUpdate : `${row.LastUpdate}Z`).toISOString() : null,
          status: 'delayed',
          frequency: 'realtime',
        });
      }
      return out;
    },

    async history(item: ProviderItem, range: HistoryRange) {
      if (!opts.apiKey) return null;
      const [ticker] = item.mapping.symbol.split('|');
      const from = isoDate(new Date(deps.now().getTime() - RANGE_DAYS[range] * DAY_MS));
      const rows = await fetchJson<{ Date?: string; Close?: number }[]>(
        `https://api.tradingeconomics.com/markets/historical/${encodeURIComponent(ticker)}?c=${encodeURIComponent(opts.apiKey)}&d1=${from}&f=json`,
        { timeoutMs: deps.timeoutMs, fetchImpl: deps.fetch },
      );
      const m = item.mapping.multiplier ?? 1;
      const points = (Array.isArray(rows) ? rows : [])
        .map((r) => {
          const raw = r.Date ?? '';
          const iso = raw.includes('/') ? raw.split('/').reverse().join('-') : raw;
          return { t: Date.parse(iso.length === 10 ? `${iso}T00:00:00Z` : iso), v: (parseNum(r.Close) ?? NaN) * m };
        })
        .filter((p) => Number.isFinite(p.t) && Number.isFinite(p.v))
        .sort((a, b) => a.t - b.t);
      return {
        points,
        status: 'historical',
        frequency: 'daily',
        message: range === '1D' ? 'Daily closes only — intraday history needs a higher Trading Economics plan.' : undefined,
      };
    },
  };
}
