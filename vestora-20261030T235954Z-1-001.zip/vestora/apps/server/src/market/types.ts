import type { ChangeBasis, DataStatus, Frequency, HistoryRange, Instrument, ProviderId, ProviderMapping, SeriesPoint } from '@vestora/shared';
import type { FetchLike } from '../lib/http';

export interface ProviderItem {
  instrument: Instrument;
  mapping: ProviderMapping;
}

/** A provider's raw observation, already converted to the instrument's canonical unit. */
export interface ProviderQuote {
  price: number;
  previous: number | null;
  /** Percentage change when the provider supplies it directly (e.g. CoinGecko 24h). */
  changePct?: number | null;
  changeBasis: ChangeBasis | null;
  asOf: string | null;
  status: DataStatus;
  frequency: Frequency;
}

export interface ProviderSeries {
  points: SeriesPoint[];
  status: DataStatus;
  frequency: Frequency;
  message?: string;
}

export interface ProviderDeps {
  fetch: FetchLike;
  timeoutMs: number;
  now: () => Date;
}

export interface MarketProvider {
  id: ProviderId;
  name: string;
  url: string;
  /** True when the provider works without an API key. */
  keyless: boolean;
  configured: boolean;
  quoteTtlMs(item: ProviderItem): number;
  historyTtlMs(item: ProviderItem, range: HistoryRange): number;
  /** Fetch quotes for a batch of instruments. Missing entries mean "not available from this provider". */
  quotes(items: ProviderItem[]): Promise<Map<string, ProviderQuote>>;
  history?(item: ProviderItem, range: HistoryRange): Promise<ProviderSeries | null>;
}

export const DAY_MS = 24 * 3600 * 1000;

export const RANGE_DAYS: Record<HistoryRange, number> = {
  '1D': 1,
  '1W': 7,
  '1M': 31,
  '3M': 92,
  '1Y': 366,
  ALL: 365 * 20,
};

export function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function parseNum(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v !== 'string') return null;
  const t = v.trim();
  if (t === '' || t === '.' || t.toLowerCase() === 'nan' || t.toLowerCase() === 'null') return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

/** Keep the first/last points and thin the middle so charts stay light. */
export function downsample(points: SeriesPoint[], max = 500): SeriesPoint[] {
  if (points.length <= max) return points;
  const step = (points.length - 1) / (max - 1);
  const out: SeriesPoint[] = [];
  for (let i = 0; i < max; i++) out.push(points[Math.round(i * step)]);
  return out;
}

export function sliceToRange(points: SeriesPoint[], range: HistoryRange, now: Date): SeriesPoint[] {
  const from = now.getTime() - RANGE_DAYS[range] * DAY_MS;
  return points.filter((p) => p.t >= from);
}
