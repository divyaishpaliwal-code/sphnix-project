import {
  INSTRUMENT_MAP,
  INSTRUMENTS,
  PROVIDER_PREFERENCE,
  type HistoryRange,
  type Instrument,
  type ProviderHealth,
  type ProviderId,
  type Quote,
  type Series,
  type SourceRef,
} from '@vestora/shared';
import { TtlCache } from '../lib/cache';
import { RateLimitError, redact, type FetchLike } from '../lib/http';
import { log } from '../lib/logger';
import type { AppConfig } from '../config';
import { createAlphaVantage } from './providers/alphavantage';
import { createCoinGecko } from './providers/coingecko';
import { createFred } from './providers/fred';
import { createGoldApi, createMetalsDev } from './providers/metals';
import { createTradingEconomics } from './providers/tradingeconomics';
import { createTwelveData } from './providers/twelvedata';
import { downsample, type MarketProvider, type ProviderDeps, type ProviderItem, type ProviderQuote, type ProviderSeries } from './types';

interface ProviderState {
  lastSuccessAt: string | null;
  lastErrorAt: string | null;
  lastError: string | null;
  consecutiveErrors: number;
  coolingDownUntil: number;
}

const DEMO_SOURCE: SourceRef = {
  id: 'demo',
  name: 'Static demo value',
  note: 'No live provider is configured or reachable for this instrument. This value is a fixed illustration, not a market quote.',
};

export interface MarketServiceOptions {
  providers: MarketProvider[];
  demoFallback: boolean;
  now?: () => Date;
}

export class MarketDataService {
  private readonly providers: Map<ProviderId, MarketProvider>;
  private readonly state = new Map<ProviderId, ProviderState>();
  private readonly quoteCache = new TtlCache<ProviderQuote>(24 * 3600_000);
  private readonly historyCache = new TtlCache<ProviderSeries>(3 * 24 * 3600_000);
  private readonly now: () => Date;

  constructor(private readonly opts: MarketServiceOptions) {
    this.providers = new Map(opts.providers.map((p) => [p.id, p]));
    this.now = opts.now ?? (() => new Date());
    for (const p of opts.providers) {
      this.state.set(p.id, { lastSuccessAt: null, lastErrorAt: null, lastError: null, consecutiveErrors: 0, coolingDownUntil: 0 });
    }
  }

  get demoFallback(): boolean {
    return this.opts.demoFallback;
  }

  /** Ordered candidate providers for an instrument (configured, mapped, not cooling down). */
  candidates(instrument: Instrument, opts: { needsHistory?: boolean } = {}): MarketProvider[] {
    const order = PROVIDER_PREFERENCE[instrument.class] ?? [];
    const t = this.now().getTime();
    return order
      .map((id) => this.providers.get(id))
      .filter((p): p is MarketProvider => Boolean(p && p.configured && instrument.providers[p.id]))
      .filter((p) => !opts.needsHistory || typeof p.history === 'function')
      .filter((p) => (this.state.get(p.id)?.coolingDownUntil ?? 0) <= t);
  }

  private source(p: MarketProvider, item?: ProviderItem): SourceRef {
    return {
      id: p.id,
      name: p.name,
      url: p.url,
      note: item?.mapping.proxy ? item.mapping.proxy.note : undefined,
    };
  }

  private recordSuccess(id: ProviderId) {
    const s = this.state.get(id);
    if (!s) return;
    s.lastSuccessAt = this.now().toISOString();
    s.consecutiveErrors = 0;
  }

  private recordError(id: ProviderId, err: unknown) {
    const s = this.state.get(id);
    if (!s) return;
    const message = redact(err instanceof Error ? err.message : String(err));
    s.lastErrorAt = this.now().toISOString();
    s.lastError = message;
    s.consecutiveErrors += 1;
    const t = this.now().getTime();
    if (err instanceof RateLimitError) {
      s.coolingDownUntil = t + Math.min(Math.max(err.retryAfterMs ?? 60_000, 30_000), 6 * 3600_000);
    } else if (s.consecutiveErrors >= 3) {
      s.coolingDownUntil = t + Math.min(60_000 * 2 ** (s.consecutiveErrors - 3), 15 * 60_000);
    }
    log.warn(`market provider ${id} failed`, { error: message, consecutive: s.consecutiveErrors });
  }

  private toQuote(instrument: Instrument, p: MarketProvider, item: ProviderItem, q: ProviderQuote, stale?: { storedAt: number }): Quote {
    const change = q.previous !== null ? q.price - q.previous : null;
    const changePct = q.changePct ?? (q.previous ? ((q.price - q.previous) / q.previous) * 100 : null);
    return {
      instrumentId: instrument.id,
      price: q.price,
      previous: q.previous,
      change,
      changePct,
      changeBasis: q.changeBasis,
      denomination: instrument.denomination,
      unit: instrument.unit,
      status: q.status,
      frequency: q.frequency,
      source: this.source(p, item),
      proxy: item.mapping.proxy,
      asOf: q.asOf,
      fetchedAt: stale ? new Date(stale.storedAt).toISOString() : this.now().toISOString(),
      message: stale ? `Served from cache — ${p.name} is currently unavailable.` : undefined,
    };
  }

  private fallbackQuote(instrument: Instrument, reason: string): Quote {
    const base = {
      instrumentId: instrument.id,
      previous: null,
      change: null,
      changePct: null,
      changeBasis: null,
      denomination: instrument.denomination,
      unit: instrument.unit,
      asOf: null,
      fetchedAt: this.now().toISOString(),
    } as const;
    if (this.opts.demoFallback && instrument.demo !== null) {
      return { ...base, price: instrument.demo, status: 'demo', frequency: 'daily', source: DEMO_SOURCE, message: reason };
    }
    return {
      ...base,
      price: null,
      status: 'unavailable',
      frequency: 'daily',
      source: { id: 'none', name: 'Unavailable' },
      message: reason,
    };
  }

  /** Resolve quotes for many instruments, batching per provider and falling back provider-by-provider. */
  async getQuotes(ids: string[]): Promise<Quote[]> {
    const instruments = [...new Set(ids)].map((id) => INSTRUMENT_MAP[id]).filter((i): i is Instrument => Boolean(i));
    const result = new Map<string, Quote>();
    const lastError = new Map<string, string>();
    let pending = instruments.filter((i) => {
      // Fresh cache hits first.
      for (const p of this.candidates(i)) {
        const hit = this.quoteCache.get(`${p.id}:${i.id}`);
        if (hit) {
          result.set(i.id, this.toQuote(i, p, { instrument: i, mapping: i.providers[p.id]! }, hit));
          return false;
        }
      }
      return true;
    });

    const attempted = new Map<string, Set<ProviderId>>();
    for (let round = 0; round < 6 && pending.length > 0; round++) {
      // Group by the next untried candidate.
      const groups = new Map<ProviderId, ProviderItem[]>();
      const exhausted: Instrument[] = [];
      for (const inst of pending) {
        const tried = attempted.get(inst.id) ?? new Set<ProviderId>();
        const next = this.candidates(inst).find((p) => !tried.has(p.id));
        if (!next) {
          exhausted.push(inst);
          continue;
        }
        tried.add(next.id);
        attempted.set(inst.id, tried);
        const list = groups.get(next.id) ?? [];
        list.push({ instrument: inst, mapping: inst.providers[next.id]! });
        groups.set(next.id, list);
      }
      for (const inst of exhausted) {
        result.set(inst.id, this.staleOrFallback(inst, lastError.get(inst.id)));
      }

      await Promise.all(
        [...groups.entries()].map(async ([pid, items]) => {
          const provider = this.providers.get(pid)!;
          try {
            const quotes = await provider.quotes(items);
            this.recordSuccess(pid);
            for (const item of items) {
              const q = quotes.get(item.instrument.id);
              if (!q) {
                lastError.set(item.instrument.id, `${provider.name} returned no data for ${item.instrument.name}.`);
                continue;
              }
              this.quoteCache.set(`${pid}:${item.instrument.id}`, q, provider.quoteTtlMs(item));
              result.set(item.instrument.id, this.toQuote(item.instrument, provider, item, q));
            }
          } catch (err) {
            this.recordError(pid, err);
            for (const item of items) lastError.set(item.instrument.id, `${provider.name}: ${redact((err as Error)?.message ?? String(err))}`);
          }
        }),
      );
      pending = pending.filter((i) => !result.has(i.id));
    }
    for (const inst of pending) result.set(inst.id, this.staleOrFallback(inst, lastError.get(inst.id)));
    return instruments.map((i) => result.get(i.id)!);
  }

  /** Prefer the last good (stale) value from any provider before falling back to demo/unavailable. */
  private staleOrFallback(instrument: Instrument, error?: string): Quote {
    for (const pid of PROVIDER_PREFERENCE[instrument.class] ?? []) {
      const p = this.providers.get(pid);
      if (!p || !instrument.providers[pid]) continue;
      const stale = this.quoteCache.getStale(`${pid}:${instrument.id}`);
      if (stale) return this.toQuote(instrument, p, { instrument, mapping: instrument.providers[pid]! }, stale.value, stale);
    }
    const anyConfigured = (PROVIDER_PREFERENCE[instrument.class] ?? []).some((pid) => this.providers.get(pid)?.configured && instrument.providers[pid]);
    const reason = error
      ? `Live data unavailable (${error}).`
      : anyConfigured
        ? 'Live providers for this instrument are temporarily unavailable.'
        : 'No data provider for this instrument is configured. Add an API key on the server (see docs/DATA_PROVIDERS.md).';
    return this.fallbackQuote(instrument, reason);
  }

  async getQuote(id: string): Promise<Quote | null> {
    const [q] = await this.getQuotes([id]);
    return q ?? null;
  }

  /** Historical series from the first provider that can supply it. Never fabricates data. */
  async getHistory(id: string, range: HistoryRange): Promise<Series | null> {
    const instrument = INSTRUMENT_MAP[id];
    if (!instrument) return null;
    const errors: string[] = [];
    for (const p of this.candidates(instrument, { needsHistory: true })) {
      const item: ProviderItem = { instrument, mapping: instrument.providers[p.id]! };
      const key = `${p.id}:${id}:${range}`;
      try {
        const series = await this.historyCache.getOrLoad(key, p.historyTtlMs(item, range), async () => {
          const s = await p.history!(item, range);
          if (!s) throw new Error(`${p.name} has no history for ${instrument.name}`);
          return s;
        });
        this.recordSuccess(p.id);
        if (series.points.length === 0 && !series.message) {
          errors.push(`${p.name} returned no observations`);
          continue;
        }
        return this.toSeries(instrument, range, p, item, series);
      } catch (err) {
        this.recordError(p.id, err);
        errors.push(redact((err as Error)?.message ?? String(err)));
        const stale = this.historyCache.getStale(key);
        if (stale) return { ...this.toSeries(instrument, range, p, item, stale.value), message: `Served from cache — ${p.name} is currently unavailable.` };
      }
    }
    return {
      instrumentId: id,
      range,
      points: [],
      status: 'unavailable',
      frequency: 'daily',
      denomination: instrument.denomination,
      unit: instrument.unit,
      source: { id: 'none', name: 'Unavailable' },
      fetchedAt: this.now().toISOString(),
      message: errors.length
        ? `Historical data is temporarily unavailable (${errors[0]}).`
        : 'No historical data source is configured for this instrument. VESTORA never invents price history — add a provider key to enable this chart.',
    };
  }

  private toSeries(instrument: Instrument, range: HistoryRange, p: MarketProvider, item: ProviderItem, s: ProviderSeries): Series {
    return {
      instrumentId: instrument.id,
      range,
      points: downsample(s.points, 500),
      status: s.status,
      frequency: s.frequency,
      denomination: instrument.denomination,
      unit: instrument.unit,
      source: this.source(p, item),
      proxy: item.mapping.proxy,
      fetchedAt: this.now().toISOString(),
      message: s.message,
    };
  }

  health(): ProviderHealth[] {
    return [...this.providers.values()].map((p) => {
      const s = this.state.get(p.id)!;
      return {
        id: p.id,
        name: p.name,
        configured: p.configured,
        keyless: p.keyless,
        lastSuccessAt: s.lastSuccessAt,
        lastErrorAt: s.lastErrorAt,
        lastError: s.lastError,
        coolingDownUntil: s.coolingDownUntil > this.now().getTime() ? new Date(s.coolingDownUntil).toISOString() : null,
      };
    });
  }

  /** Which provider would currently serve each instrument (for the Settings → Data sources view). */
  routing(): { instrumentId: string; providers: ProviderId[] }[] {
    return INSTRUMENTS.map((i) => ({ instrumentId: i.id, providers: this.candidates(i).map((p) => p.id) }));
  }
}

export function createMarketService(cfg: AppConfig, fetchImpl: FetchLike = fetch as FetchLike): MarketDataService {
  const deps: ProviderDeps = { fetch: fetchImpl, timeoutMs: cfg.REQUEST_TIMEOUT_MS, now: () => new Date() };
  const providers: MarketProvider[] = [
    createMetalsDev({ apiKey: cfg.METALSDEV_KEY, ttlMinutes: cfg.METALSDEV_TTL_MINUTES }, deps),
    createGoldApi({ apiKey: cfg.GOLDAPI_KEY, ttlMinutes: cfg.GOLDAPI_TTL_MINUTES }, deps),
    createTwelveData({ apiKey: cfg.TWELVEDATA_KEY, realtime: cfg.TWELVEDATA_REALTIME }, deps),
    createTradingEconomics({ apiKey: cfg.TRADINGECONOMICS_KEY }, deps),
    createAlphaVantage({ apiKey: cfg.ALPHAVANTAGE_KEY }, deps),
    createCoinGecko({ apiKey: cfg.COINGECKO_API_KEY, plan: cfg.COINGECKO_PLAN }, deps),
    createFred({ apiKey: cfg.FRED_API_KEY, keyless: cfg.FRED_KEYLESS }, deps),
  ];
  return new MarketDataService({ providers, demoFallback: cfg.MARKET_DEMO_FALLBACK });
}
