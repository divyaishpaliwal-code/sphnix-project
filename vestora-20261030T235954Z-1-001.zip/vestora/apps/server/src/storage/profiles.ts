import { createHash, timingSafeEqual } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { z } from 'zod';
import { log } from '../lib/logger';

/**
 * Persistence for user preferences, simulated portfolio state, watchlists,
 * alerts and activity. PostgreSQL (incl. Supabase) when DATABASE_URL is set,
 * otherwise a local JSON file. Personal KYC details are never stored server-side.
 *
 * Profiles are anonymous: the browser generates a random profile id and a
 * secret. The secret's hash is stored on first write and required afterwards.
 */

export const PROFILE_ID_RE = /^(?:[A-Za-z0-9_-]{12,64}|0x[a-fA-F0-9]{40})$/;

export const ProfilePayloadSchema = z.object({
  preferences: z.record(z.unknown()).default({}),
  watchlist: z.array(z.string().max(32)).max(200).default([]),
  portfolio: z.unknown().default(null),
  activity: z.array(z.unknown()).max(500).default([]),
  alerts: z.array(z.unknown()).max(100).default([]),
});

export type ProfilePayload = z.infer<typeof ProfilePayloadSchema>;

export interface ProfileRecord extends ProfilePayload {
  id: string;
  updatedAt: string;
}

export class ProfileAuthError extends Error {
  constructor() {
    super('This profile is protected by a different key.');
    this.name = 'ProfileAuthError';
  }
}

export interface ProfileStore {
  mode: 'postgres' | 'file' | 'memory';
  init(): Promise<void>;
  get(id: string, secret: string): Promise<ProfileRecord | null>;
  put(id: string, secret: string, payload: ProfilePayload): Promise<ProfileRecord>;
}

export function hashSecret(secret: string): string {
  return createHash('sha256').update(`vestora:${secret}`).digest('hex');
}

function sameHash(a: string, b: string): boolean {
  const ab = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

/** Strip anything that looks like KYC personal data before persisting. */
export function scrubPayload(p: ProfilePayload): ProfilePayload {
  const prefs = { ...p.preferences };
  for (const k of Object.keys(prefs)) {
    if (/kyc|email|fullname|full_name|name|country|document/i.test(k)) delete prefs[k];
  }
  return { ...p, preferences: prefs };
}

interface StoredProfile extends ProfileRecord {
  secretHash: string;
}

/* ------------------------------- File / memory ------------------------------- */

export class FileProfileStore implements ProfileStore {
  mode: 'file' | 'memory' = 'file';
  private data = new Map<string, StoredProfile>();
  private file: string;
  private writing: Promise<void> = Promise.resolve();

  constructor(dataDir: string) {
    this.file = join(resolve(dataDir), 'profiles.json');
  }

  async init() {
    try {
      await mkdir(dirname(this.file), { recursive: true });
      const raw = await readFile(this.file, 'utf8').catch(() => '{}');
      const parsed = JSON.parse(raw) as Record<string, StoredProfile>;
      this.data = new Map(Object.entries(parsed));
    } catch (err) {
      log.warn('profile file store unavailable — using in-memory storage', { error: (err as Error).message });
      this.mode = 'memory';
    }
  }

  async get(id: string, secret: string) {
    const p = this.data.get(id);
    if (!p) return null;
    if (!sameHash(p.secretHash, hashSecret(secret))) throw new ProfileAuthError();
    const { secretHash: _omit, ...rest } = p;
    return rest;
  }

  async put(id: string, secret: string, payload: ProfilePayload) {
    const existing = this.data.get(id);
    const h = hashSecret(secret);
    if (existing && !sameHash(existing.secretHash, h)) throw new ProfileAuthError();
    const record: StoredProfile = { id, ...scrubPayload(payload), updatedAt: new Date().toISOString(), secretHash: h };
    this.data.set(id, record);
    await this.flush();
    const { secretHash: _omit, ...rest } = record;
    return rest;
  }

  private flush(): Promise<void> {
    if (this.mode === 'memory') return Promise.resolve();
    this.writing = this.writing.then(async () => {
      const tmp = `${this.file}.tmp`;
      try {
        await writeFile(tmp, JSON.stringify(Object.fromEntries(this.data)), 'utf8');
        await rename(tmp, this.file);
      } catch (err) {
        log.warn('could not persist profiles file', { error: (err as Error).message });
      }
    });
    return this.writing;
  }
}

/* ---------------------------------- Postgres --------------------------------- */

interface PgPoolLike {
  query(text: string, params?: unknown[]): Promise<{ rows: Record<string, unknown>[] }>;
}

export const SCHEMA_SQL = `
create table if not exists vestora_profiles (
  id           text primary key,
  secret_hash  text not null,
  preferences  jsonb not null default '{}'::jsonb,
  watchlist    jsonb not null default '[]'::jsonb,
  portfolio    jsonb,
  activity     jsonb not null default '[]'::jsonb,
  alerts       jsonb not null default '[]'::jsonb,
  updated_at   timestamptz not null default now()
);`;

export class PgProfileStore implements ProfileStore {
  mode = 'postgres' as const;
  constructor(private readonly pool: PgPoolLike) {}

  async init() {
    await this.pool.query(SCHEMA_SQL);
  }

  private toRecord(row: Record<string, unknown>): ProfileRecord {
    return {
      id: String(row.id),
      preferences: (row.preferences as Record<string, unknown>) ?? {},
      watchlist: (row.watchlist as string[]) ?? [],
      portfolio: row.portfolio ?? null,
      activity: (row.activity as unknown[]) ?? [],
      alerts: (row.alerts as unknown[]) ?? [],
      updatedAt: new Date(row.updated_at as string).toISOString(),
    };
  }

  async get(id: string, secret: string) {
    const { rows } = await this.pool.query('select * from vestora_profiles where id = $1', [id]);
    if (!rows[0]) return null;
    if (!sameHash(String(rows[0].secret_hash), hashSecret(secret))) throw new ProfileAuthError();
    return this.toRecord(rows[0]);
  }

  async put(id: string, secret: string, payload: ProfilePayload) {
    const h = hashSecret(secret);
    const { rows: existing } = await this.pool.query('select secret_hash from vestora_profiles where id = $1', [id]);
    if (existing[0] && !sameHash(String(existing[0].secret_hash), h)) throw new ProfileAuthError();
    const p = scrubPayload(payload);
    const { rows } = await this.pool.query(
      `insert into vestora_profiles (id, secret_hash, preferences, watchlist, portfolio, activity, alerts, updated_at)
       values ($1, $2, $3::jsonb, $4::jsonb, $5::jsonb, $6::jsonb, $7::jsonb, now())
       on conflict (id) do update set preferences = excluded.preferences, watchlist = excluded.watchlist,
         portfolio = excluded.portfolio, activity = excluded.activity, alerts = excluded.alerts, updated_at = now()
       returning *`,
      [id, h, JSON.stringify(p.preferences), JSON.stringify(p.watchlist), JSON.stringify(p.portfolio), JSON.stringify(p.activity), JSON.stringify(p.alerts)],
    );
    return this.toRecord(rows[0]);
  }
}

export async function createProfileStore(opts: { databaseUrl?: string; ssl: boolean; dataDir: string }): Promise<ProfileStore> {
  if (opts.databaseUrl) {
    try {
      const pg = await import('pg');
      const Pool = (pg as unknown as { default?: { Pool: new (cfg: object) => PgPoolLike }; Pool?: new (cfg: object) => PgPoolLike }).default?.Pool ??
        (pg as unknown as { Pool: new (cfg: object) => PgPoolLike }).Pool;
      const pool = new Pool({ connectionString: opts.databaseUrl, ssl: opts.ssl ? { rejectUnauthorized: false } : undefined, max: 5 });
      const store = new PgProfileStore(pool);
      await store.init();
      log.info('profile storage: PostgreSQL');
      return store;
    } catch (err) {
      log.error('PostgreSQL unavailable — falling back to file storage', { error: (err as Error).message });
    }
  }
  const store = new FileProfileStore(opts.dataDir);
  await store.init();
  log.info(`profile storage: ${store.mode}`);
  return store;
}
