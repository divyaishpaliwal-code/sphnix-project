/** Small fetch helpers with timeouts and typed errors for upstream providers. */

export class UpstreamError extends Error {
  constructor(
    message: string,
    public readonly status?: number,
  ) {
    super(message);
    this.name = 'UpstreamError';
  }
}

export class RateLimitError extends UpstreamError {
  constructor(
    message: string,
    public readonly retryAfterMs?: number,
  ) {
    super(message, 429);
    this.name = 'RateLimitError';
  }
}

export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

export interface HttpOptions {
  headers?: Record<string, string>;
  timeoutMs?: number;
  fetchImpl?: FetchLike;
  method?: 'GET' | 'POST';
  body?: string;
}

function retryAfter(res: Response): number | undefined {
  const h = res.headers.get('retry-after');
  if (!h) return undefined;
  const secs = Number(h);
  if (Number.isFinite(secs)) return secs * 1000;
  const date = Date.parse(h);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : undefined;
}

async function request(url: string, opts: HttpOptions): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 9000);
  const f = opts.fetchImpl ?? (fetch as FetchLike);
  try {
    const res = await f(url, {
      method: opts.method ?? 'GET',
      headers: { accept: 'application/json, text/csv, application/xml;q=0.9, */*;q=0.8', 'user-agent': 'VESTORA/0.1 (educational prototype)', ...opts.headers },
      body: opts.body,
      signal: controller.signal,
    });
    if (res.status === 429) throw new RateLimitError(`Rate limited by ${new URL(url).host}`, retryAfter(res));
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new UpstreamError(`${new URL(url).host} responded ${res.status}${text ? `: ${text.slice(0, 160)}` : ''}`, res.status);
    }
    return res;
  } catch (err) {
    if (err instanceof UpstreamError) throw err;
    if ((err as Error)?.name === 'AbortError') throw new UpstreamError(`Timed out contacting ${new URL(url).host}`);
    throw new UpstreamError(`Network error contacting ${new URL(url).host}: ${(err as Error)?.message ?? String(err)}`);
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchJson<T = unknown>(url: string, opts: HttpOptions = {}): Promise<T> {
  const res = await request(url, opts);
  try {
    return (await res.json()) as T;
  } catch {
    throw new UpstreamError(`Invalid JSON from ${new URL(url).host}`);
  }
}

export async function fetchText(url: string, opts: HttpOptions = {}): Promise<string> {
  const res = await request(url, opts);
  return res.text();
}

/** Remove secrets (api keys, tokens) from URLs before logging or returning errors. */
export function redact(text: string): string {
  return text.replace(/([?&](?:api_?key|apikey|token|c|key|access_token))=([^&\s"]+)/gi, '$1=***');
}
