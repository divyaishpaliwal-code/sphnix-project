/**
 * TTL cache with in-flight de-duplication and stale-if-error support.
 * Values stay available after expiry (up to `staleMs`) so a failing upstream
 * can be bridged with the last good value — which keeps its original timestamp,
 * so staleness is always visible to the user.
 */
interface Entry<T> {
  value: T;
  storedAt: number;
  expiresAt: number;
}

export class TtlCache<T> {
  private store = new Map<string, Entry<T>>();
  private inflight = new Map<string, Promise<T>>();

  constructor(
    private readonly staleMs = 24 * 3600 * 1000,
    private readonly maxEntries = 2000,
    private readonly now: () => number = Date.now,
  ) {}

  get(key: string): T | undefined {
    const e = this.store.get(key);
    if (!e) return undefined;
    return e.expiresAt > this.now() ? e.value : undefined;
  }

  getStale(key: string): { value: T; storedAt: number } | undefined {
    const e = this.store.get(key);
    if (!e) return undefined;
    if (this.now() - e.expiresAt > this.staleMs) {
      this.store.delete(key);
      return undefined;
    }
    return { value: e.value, storedAt: e.storedAt };
  }

  set(key: string, value: T, ttlMs: number): void {
    if (this.store.size >= this.maxEntries) {
      const oldest = this.store.keys().next().value;
      if (oldest !== undefined) this.store.delete(oldest);
    }
    const t = this.now();
    this.store.set(key, { value, storedAt: t, expiresAt: t + ttlMs });
  }

  /** Return a fresh cached value or run `loader` once per key, sharing the promise between concurrent callers. */
  async getOrLoad(key: string, ttlMs: number, loader: () => Promise<T>): Promise<T> {
    const hit = this.get(key);
    if (hit !== undefined) return hit;
    const pending = this.inflight.get(key);
    if (pending) return pending;
    const p = loader()
      .then((v) => {
        this.set(key, v, ttlMs);
        return v;
      })
      .finally(() => this.inflight.delete(key));
    this.inflight.set(key, p);
    return p;
  }

  clear(): void {
    this.store.clear();
    this.inflight.clear();
  }
}
