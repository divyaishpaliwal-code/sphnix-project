import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import express, { type NextFunction, type Request, type Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { ZodError } from 'zod';
import { corsOrigins, type AppConfig } from './config';
import { log } from './lib/logger';
import { createApiRouter, type Services } from './routes';

export function createApp(cfg: AppConfig, services: Services) {
  const app = express();
  app.disable('x-powered-by');
  if (cfg.TRUST_PROXY) app.set('trust proxy', 1);

  app.use(
    helmet({
      // The SPA is served by this process in production; it loads Google-hosted fonts only via the bundle.
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
    }),
  );

  const origins = corsOrigins(cfg);
  app.use(
    '/api',
    cors({
      origin: (origin, cb) => cb(null, !origin || origins.includes('*') || origins.includes(origin)),
      methods: ['GET', 'POST', 'PUT', 'OPTIONS'],
      allowedHeaders: ['content-type', 'x-profile-key'],
      maxAge: 600,
    }),
  );
  app.use('/api', express.json({ limit: '300kb' }));
  app.use(
    '/api',
    rateLimit({
      windowMs: 60_000,
      limit: 300,
      standardHeaders: 'draft-7',
      legacyHeaders: false,
      message: { error: 'Too many requests — please slow down.' },
    }),
  );
  app.use('/api', createApiRouter(services));

  // Serve the built web app (apps/web/dist) when present, with SPA fallback.
  const here = dirname(fileURLToPath(import.meta.url));
  const webDist = resolve(here, '../../web/dist');
  if (cfg.SERVE_WEB && existsSync(join(webDist, 'index.html'))) {
    app.use(express.static(webDist, { index: false, maxAge: '1h' }));
    app.get('*', (_req: Request, res: Response) => res.sendFile(join(webDist, 'index.html')));
    log.info(`serving web app from ${webDist}`);
  }

  // Error handler: never leak stack traces or secrets.
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof ZodError) {
      res.status(400).json({ error: err.issues[0]?.message ?? 'Invalid request' });
      return;
    }
    const status = typeof (err as { status?: number })?.status === 'number' ? (err as { status: number }).status : 500;
    if (status >= 500) log.error('request failed', { error: (err as Error)?.message ?? String(err) });
    res.status(status >= 400 && status < 600 ? status : 500).json({ error: status >= 500 ? 'Something went wrong on the server.' : (err as Error).message });
  });

  return app;
}
