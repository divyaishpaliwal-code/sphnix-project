import 'dotenv/config';
import { loadConfig } from './config';
import { createApp } from './app';
import { AssistantService } from './ai/service';
import { log } from './lib/logger';
import { createMarketService } from './market/service';
import { NewsService, parseFeedsEnv } from './news/service';
import { createProfileStore } from './storage/profiles';

async function main() {
  const cfg = loadConfig();
  const market = createMarketService(cfg);
  const news = new NewsService(parseFeedsEnv(cfg.NEWS_FEEDS), cfg.NEWS_ENABLED, fetch, cfg.REQUEST_TIMEOUT_MS);
  const ai = new AssistantService(cfg, market);
  const profiles = await createProfileStore({ databaseUrl: cfg.DATABASE_URL, ssl: cfg.DATABASE_SSL, dataDir: cfg.DATA_DIR });

  const app = createApp(cfg, { market, news, ai, profiles, version: '0.1.0', aiRateLimitPerMinute: cfg.AI_RATE_LIMIT_PER_MINUTE });

  app.listen(cfg.PORT, cfg.HOST, () => {
    const configured = market
      .health()
      .filter((p) => p.configured)
      .map((p) => p.name)
      .join(', ');
    const aiStatus = ai.status();
    log.info(`VESTORA API listening on http://${cfg.HOST === '0.0.0.0' ? 'localhost' : cfg.HOST}:${cfg.PORT}`);
    log.info(`market providers: ${configured || 'none'}${cfg.MARKET_DEMO_FALLBACK ? ' (+ labelled demo fallback)' : ''}`);
    log.info(`AI assistant: ${aiStatus.mode === 'live' ? `${aiStatus.provider} · ${aiStatus.model}` : 'educational demo mode (no API key)'}`);
  });
}

main().catch((err) => {
  log.error('failed to start VESTORA API', { error: (err as Error).message });
  process.exit(1);
});
