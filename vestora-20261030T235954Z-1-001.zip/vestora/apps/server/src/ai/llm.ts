import { fetchJson, UpstreamError, type FetchLike } from '../lib/http';

export interface LlmClient {
  provider: 'anthropic' | 'openai';
  model: string;
  complete(system: string, user: string): Promise<string>;
}

/**
 * Anthropic Messages API. Uses API version 2026-10-21 by default, which removes
 * sampling parameters (temperature/top_p/top_k) — so none are sent.
 */
export function anthropicClient(opts: { apiKey: string; model: string; version: string; timeoutMs: number; fetchImpl?: FetchLike }): LlmClient {
  return {
    provider: 'anthropic',
    model: opts.model,
    async complete(system, user) {
      const data = await fetchJson<{ content?: { type: string; text?: string }[]; error?: { message?: string } }>('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': opts.apiKey,
          'anthropic-version': opts.version,
        },
        body: JSON.stringify({
          model: opts.model,
          max_tokens: 1600,
          system,
          messages: [{ role: 'user', content: user }],
        }),
        timeoutMs: opts.timeoutMs,
        fetchImpl: opts.fetchImpl,
      });
      const text = (data.content ?? [])
        .filter((b) => b.type === 'text' && typeof b.text === 'string')
        .map((b) => b.text)
        .join('\n')
        .trim();
      if (!text) throw new UpstreamError(`Anthropic returned no text${data.error?.message ? `: ${data.error.message}` : ''}`);
      return text;
    },
  };
}

/** OpenAI Responses API. */
export function openaiClient(opts: { apiKey: string; model: string; timeoutMs: number; fetchImpl?: FetchLike }): LlmClient {
  return {
    provider: 'openai',
    model: opts.model,
    async complete(system, user) {
      const data = await fetchJson<{ output_text?: string; output?: { type: string; content?: { type: string; text?: string }[] }[] }>(
        'https://api.openai.com/v1/responses',
        {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: `Bearer ${opts.apiKey}` },
          body: JSON.stringify({
            model: opts.model,
            instructions: system,
            input: user,
            max_output_tokens: 1600,
          }),
          timeoutMs: opts.timeoutMs,
          fetchImpl: opts.fetchImpl,
        },
      );
      const text =
        data.output_text ??
        (data.output ?? [])
          .flatMap((o) => o.content ?? [])
          .filter((c) => c.type === 'output_text' && typeof c.text === 'string')
          .map((c) => c.text)
          .join('\n');
      if (!text?.trim()) throw new UpstreamError('OpenAI returned no text');
      return text.trim();
    },
  };
}
