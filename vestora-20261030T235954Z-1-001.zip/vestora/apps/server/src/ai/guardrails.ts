import { z } from 'zod';

/**
 * Output guardrails for live model answers. If a model answer promises returns,
 * makes predictions or gives personal buy/sell instructions, VESTORA discards it
 * and serves the curated educational answer instead.
 */
// Negative lookbehind: ignore phrases such as "no one can guarantee returns" or "not a guaranteed return".
const NEGATION = String.raw`(?<!\b(?:no|not|never|cannot|can't|isn't|aren't|without|nor|nobody)\s(?:[\w']+\s){0,3})`;

const FORBIDDEN: { re: RegExp; reason: string }[] = [
  { re: new RegExp(`${NEGATION}\\bguarantee[ds]?\\s+(?:a\\s+|an\\s+|you\\s+)?(?:return|returns|profit|profits|gain|gains|income|yield)`, 'i'), reason: 'promises returns' },
  { re: new RegExp(`${NEGATION}\\b(?:risk-free|riskless)\\s+(?:investment|return|profit)`, 'i'), reason: 'claims an investment is risk-free' },
  { re: /\byou should (?:definitely |probably )?(?:buy|sell|invest in|put your money|allocate)\b/i, reason: 'gives personal buy/sell instructions' },
  { re: /\bi (?:would )?(?:recommend|advise) (?:buying|selling|investing|that you (?:buy|sell|invest))\b/i, reason: 'recommends a trade' },
  { re: /\bwill (?:definitely|certainly|surely|undoubtedly) (?:rise|increase|go up|gain|double|outperform|recover)\b/i, reason: 'makes a confident prediction' },
  { re: /\b(?:price target|target price) (?:of|is)\b/i, reason: 'gives a price target' },
  { re: /\b(?:can(?:no|')t|cannot) (?:lose|go wrong)\b/i, reason: 'claims you cannot lose' },
  { re: /\bas (?:a|your) (?:licensed |registered )?financial advis[eo]r\b/i, reason: 'claims to be a financial adviser' },
];

export function checkOutput(text: string): { ok: true } | { ok: false; reason: string } {
  for (const f of FORBIDDEN) if (f.re.test(text)) return { ok: false, reason: f.reason };
  return { ok: true };
}

/** Remove control characters and cap length. User text is always sent as data in the user turn. */
export function sanitizeQuestion(q: string): string {
  return q
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 600);
}

export const ModelAnswerSchema = z.object({
  title: z.string().min(3).max(140),
  summary: z.string().min(10).max(900),
  sections: z
    .array(z.object({ heading: z.string().min(2).max(120), body: z.string().min(2).max(2200) }))
    .min(1)
    .max(9),
  scenarios: z.object({ bull: z.string().min(5).max(700), bear: z.string().min(5).max(700) }).optional(),
  insights: z.array(z.string().min(3).max(400)).max(5).default([]),
  followUps: z.array(z.string().min(3).max(160)).max(5).default([]),
});

export type ModelAnswer = z.infer<typeof ModelAnswerSchema>;

/** Extract and validate the JSON object from a model reply. */
export function parseModelAnswer(text: string): ModelAnswer | null {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    const parsed = ModelAnswerSchema.safeParse(JSON.parse(text.slice(start, end + 1)));
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}
