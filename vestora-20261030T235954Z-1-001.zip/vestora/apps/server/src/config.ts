import { z } from 'zod';

const bool = (def: boolean) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v.trim() === '' ? def : ['1', 'true', 'yes', 'on'].includes(v.trim().toLowerCase())));

const optionalString = z
  .string()
  .optional()
  .transform((v) => (v && v.trim() !== '' ? v.trim() : undefined));

const minutes = (def: number) =>
  z
    .string()
    .optional()
    .transform((v) => {
      const n = v ? Number(v) : NaN;
      return Number.isFinite(n) && n > 0 ? n : def;
    });

const EnvSchema = z.object({
  NODE_ENV: z.string().optional().default('development'),
  PORT: z.coerce.number().int().positive().default(8787),
  HOST: z.string().default('0.0.0.0'),
  CORS_ORIGIN: z.string().default('http://localhost:5173,http://127.0.0.1:5173'),
  TRUST_PROXY: bool(false),
  SERVE_WEB: bool(true),

  // Market data
  MARKET_DEMO_FALLBACK: bool(true),
  COINGECKO_API_KEY: optionalString,
  COINGECKO_PLAN: z.enum(['demo', 'pro']).optional().default('demo'),
  FRED_API_KEY: optionalString,
  FRED_KEYLESS: bool(true),
  GOLDAPI_KEY: optionalString,
  GOLDAPI_TTL_MINUTES: minutes(480),
  METALSDEV_KEY: optionalString,
  METALSDEV_TTL_MINUTES: minutes(480),
  TWELVEDATA_KEY: optionalString,
  TWELVEDATA_REALTIME: bool(false),
  ALPHAVANTAGE_KEY: optionalString,
  TRADINGECONOMICS_KEY: optionalString,
  REQUEST_TIMEOUT_MS: z.coerce.number().int().positive().default(9000),

  // AI
  AI_PROVIDER: z.enum(['auto', 'anthropic', 'openai', 'none']).optional().default('auto'),
  ANTHROPIC_API_KEY: optionalString,
  ANTHROPIC_VERSION: z.string().optional().default('2026-10-21'),
  OPENAI_API_KEY: optionalString,
  AI_MODEL: optionalString,
  AI_RATE_LIMIT_PER_MINUTE: z.coerce.number().int().positive().default(20),

  // Persistence
  DATABASE_URL: optionalString,
  DATABASE_SSL: bool(true),
  DATA_DIR: z.string().default('.data'),

  // News
  NEWS_ENABLED: bool(true),
  NEWS_FEEDS: optionalString,
});

export type AppConfig = z.output<typeof EnvSchema>;

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const parsed = EnvSchema.safeParse(env);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
    throw new Error(`Invalid environment configuration — ${issues}`);
  }
  return parsed.data;
}

export function corsOrigins(cfg: AppConfig): string[] {
  return cfg.CORS_ORIGIN.split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}
