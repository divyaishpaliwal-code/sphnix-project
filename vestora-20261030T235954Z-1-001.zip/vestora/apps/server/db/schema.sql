-- VESTORA profile storage (PostgreSQL / Supabase).
-- The API creates this table automatically on start-up; you can also run this
-- file in the Supabase SQL editor.
--
-- Profiles are anonymous (random id generated in the browser) and protected by
-- a per-profile secret whose SHA-256 hash is stored in secret_hash.
-- Personal KYC details are never sent to or stored by the server.

create table if not exists vestora_profiles (
  id           text primary key,
  secret_hash  text not null,
  preferences  jsonb not null default '{}'::jsonb,   -- theme, refresh interval, display options
  watchlist    jsonb not null default '[]'::jsonb,   -- asset/instrument ids
  portfolio    jsonb,                                -- simulated holdings + cash (demo mode)
  activity     jsonb not null default '[]'::jsonb,   -- simulated / testnet activity log
  alerts       jsonb not null default '[]'::jsonb,   -- demo price alerts
  updated_at   timestamptz not null default now()
);

create index if not exists vestora_profiles_updated_at_idx on vestora_profiles (updated_at desc);

-- Supabase: the API connects with the database connection string (server-side),
-- so Row Level Security can stay enabled with no public policies:
alter table vestora_profiles enable row level security;
