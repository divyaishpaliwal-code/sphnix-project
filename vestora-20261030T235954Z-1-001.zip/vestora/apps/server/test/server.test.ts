import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ASSET_SECTION_HEADINGS } from '@vestora/shared';
import { loadConfig } from '../src/config';
import { AssistantService } from '../src/ai/service';
import { checkOutput, parseModelAnswer } from '../src/ai/guardrails';
import { TtlCache } from '../src/lib/cache';
import { redact, type FetchLike } from '../src/lib/http';
import { createMarketService, MarketDataService } from '../src/market/service';
import { parseFredCsv } from '../src/market/providers/fred';
import { parseFeed } from '../src/news/service';
import { FileProfileStore, ProfileAuthError } from '../src/storage/profiles';

type Route = (url: string, init?: RequestInit) => Response | Promise<Response>;

function mockFetch(routes: Record<string, Route>, calls: string[] = []): FetchLike {
  return async (url, init) => {
    calls.push(url);
    const key = Object.keys(routes).find((k) => url.includes(k));
    if (!key) return new Response('blocked', { status: 403 });
    return routes[key](url, init);
  };
}

const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });

function cfg(extra: Record<string, string> = {}) {
  return loadConfig({ NODE_ENV: 'test', ...extra } as NodeJS.ProcessEnv);
}

const FRED_CSV = (vals: [string, string][]) => `observation_date,X\n${vals.map(([d, v]) => `${d},${v}`).join('\n')}\n`;

test('config defaults are safe and keyless providers are enabled', () => {
  const c = cfg();
  assert.equal(c.PORT, 8787);
  assert.equal(c.MARKET_DEMO_FALLBACK, true);
  assert.equal(c.FRED_KEYLESS, true);
  assert.equal(c.AI_PROVIDER, 'auto');
  assert.equal(c.ANTHROPIC_VERSION, '2026-10-21');
});

test('quotes: CoinGecko live data with 24h change, FRED delayed data with previous observation', async () => {
  const calls: string[] = [];
  const fetchImpl = mockFetch(
    {
      'api.coingecko.com/api/v3/simple/price': () =>
        json({ bitcoin: { usd: 100000, usd_24h_change: 2, last_updated_at: 1793000000 }, ethereum: { usd: 4000, usd_24h_change: -1.5, last_updated_at: 1793000000 } }),
      'fredgraph.csv?id=DGS10': () => new Response(FRED_CSV([['2026-10-27', '4.10'], ['2026-10-28', '.'], ['2026-10-29', '4.05']])),
    },
    calls,
  );
  const svc = createMarketService(cfg(), fetchImpl);
  const [btc, eth, ust] = await svc.getQuotes(['BTC', 'ETH', 'UST10Y']);
  assert.equal(btc.status, 'realtime');
  assert.equal(btc.source.id, 'coingecko');
  assert.equal(btc.changeBasis, '24h');
  assert.ok(Math.abs((btc.changePct ?? 0) - 2) < 1e-9);
  assert.equal(eth.price, 4000);
  assert.equal(ust.status, 'delayed');
  assert.equal(ust.price, 4.05);
  assert.equal(ust.previous, 4.1);
  assert.equal(ust.changeBasis, 'previous-observation');
  assert.equal(ust.asOf, '2026-10-29T00:00:00.000Z');
  // One batched CoinGecko call.
  assert.equal(calls.filter((c) => c.includes('simple/price')).length, 1);

  // Second call is served from cache.
  await svc.getQuotes(['BTC']);
  assert.equal(calls.filter((c) => c.includes('simple/price')).length, 1);
});

test('quotes: gold falls back from a failing metals provider to the labelled PAXG proxy', async () => {
  const f = mockFetch({
    'api.metals.dev': () => json({ status: 'failure', error_message: 'invalid key' }),
    'api.coingecko.com/api/v3/simple/price': () => json({ 'pax-gold': { usd: 4010, usd_24h_change: 0.5, last_updated_at: 1793000000 } }),
  });
  const svc = createMarketService(cfg({ METALSDEV_KEY: 'bad' }), f);
  const [gold] = await svc.getQuotes(['XAU']);
  assert.equal(gold.source.id, 'coingecko');
  assert.equal(gold.proxy?.symbol, 'PAXG');
  assert.equal(gold.price, 4010);
  const health = svc.health().find((h) => h.id === 'metalsdev');
  assert.ok(health?.lastError?.includes('invalid key'));
});

test('quotes: unreachable providers produce labelled demo data — never random numbers', async () => {
  const svc = createMarketService(cfg(), mockFetch({}));
  const quotes = await svc.getQuotes(['XAG', 'WTI', 'BTC']);
  for (const q of quotes) {
    assert.equal(q.status, 'demo');
    assert.equal(q.source.id, 'demo');
    assert.equal(q.change, null, 'demo data must not show a fabricated change');
    assert.ok(q.message && q.message.length > 0);
  }
  const strict = createMarketService(cfg({ MARKET_DEMO_FALLBACK: 'false' }), mockFetch({}));
  const [s] = await strict.getQuotes(['XAG']);
  assert.equal(s.status, 'unavailable');
  assert.equal(s.price, null);
});

test('history: never fabricated — unavailable when no provider can serve it', async () => {
  const svc = createMarketService(cfg(), mockFetch({}));
  const s = await svc.getHistory('XAG', '1M');
  assert.ok(s);
  assert.equal(s.points.length, 0);
  assert.equal(s.status, 'unavailable');
  assert.match(s.message ?? '', /never invents|temporarily unavailable/);
});

test('history: FRED monthly series explains short ranges', async () => {
  const now = new Date();
  const csv = FRED_CSV(
    Array.from({ length: 30 }, (_, i) => {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 29 + i, 1));
      return [d.toISOString().slice(0, 10), String(9000 + i * 10)] as [string, string];
    }),
  );
  const svc = createMarketService(cfg(), mockFetch({ 'fredgraph.csv?id=PCOPPUSDM': () => new Response(csv) }));
  const year = await svc.getHistory('COPPER', '1Y');
  assert.equal(year?.status, 'historical');
  assert.equal(year?.frequency, 'monthly');
  assert.ok((year?.points.length ?? 0) >= 10);
  const week = await svc.getHistory('COPPER', '1W');
  assert.match(week?.message ?? '', /monthly averages/);
});

test('rate limits put a provider into cooldown and the service falls through', async () => {
  let hits = 0;
  const svc = new MarketDataService({
    demoFallback: true,
    providers: [
      {
        id: 'coingecko',
        name: 'Fake CG',
        url: 'https://example.com',
        keyless: true,
        configured: true,
        quoteTtlMs: () => 1,
        historyTtlMs: () => 1,
        async quotes() {
          hits++;
          const { RateLimitError } = await import('../src/lib/http');
          throw new RateLimitError('429', 120_000);
        },
      },
    ],
  });
  const [q1] = await svc.getQuotes(['BTC']);
  assert.equal(q1.status, 'demo');
  await svc.getQuotes(['BTC']);
  assert.equal(hits, 1, 'provider is skipped while cooling down');
  assert.ok(svc.health()[0].coolingDownUntil);
});

test('FRED CSV parser handles both header formats and missing values', () => {
  assert.deepEqual(parseFredCsv('DATE,DGS10\n2026-10-01,4.1\n2026-10-02,.\n'), [
    { date: '2026-10-01', value: 4.1 },
    { date: '2026-10-02', value: null },
  ]);
  assert.equal(parseFredCsv('observation_date,X\n').length, 0);
});

test('guardrails reject promises and advice but allow balanced education', () => {
  assert.equal(checkOutput('Gold returns are not guaranteed and prices can fall.').ok, true);
  assert.equal(checkOutput('No one can guarantee returns from commodities.').ok, true);
  assert.equal(checkOutput('This token guarantees returns of 10%.').ok, false);
  assert.equal(checkOutput('You should buy silver now.').ok, false);
  assert.equal(checkOutput('Bitcoin will definitely rise next year.').ok, false);
  assert.equal(checkOutput('If rates fall, bond prices could rise.').ok, true);
  assert.ok(parseModelAnswer('Sure! {"title":"Gold","summary":"Gold is a metal with no yield.","sections":[{"heading":"What","body":"A metal"}],"insights":[],"followUps":[]}'));
  assert.equal(parseModelAnswer('not json'), null);
});

test('AI assistant: demo mode without keys, measured stats from real history only', async () => {
  const day = 86_400_000;
  const points = Array.from({ length: 60 }, (_, i) => ({ t: Date.UTC(2026, 0, 1) + i * day, v: 100 + (i % 2 ? 2 : -2) }));
  const market = {
    getHistory: async () => ({
      instrumentId: 'XAU',
      range: '1Y' as const,
      points,
      status: 'historical' as const,
      frequency: 'daily' as const,
      denomination: 'USD' as const,
      unit: 'troy oz',
      source: { id: 'twelvedata' as const, name: 'Twelve Data' },
      fetchedAt: new Date().toISOString(),
    }),
  };
  const ai = new AssistantService(cfg(), market);
  assert.deepEqual(ai.status(), { mode: 'demo', provider: null, model: null });
  const r = await ai.ask({ question: 'Is gold a risky investment?' });
  assert.equal(r.mode, 'demo');
  assert.equal(r.risk?.factors[0].basis, 'measured');
  assert.match(r.sections[4].body, /Measured from 60 real observations/);
});

test('AI assistant: live answers are validated, guarded and fall back safely', async () => {
  const good = {
    title: 'Understanding Gold',
    summary: 'Gold is a precious metal that pays no income. Its price can rise or fall.',
    sections: [
      // Deliberately out of order and in different case: the server restores the canonical order and wording.
      { heading: 'what could cause its value to fall', body: 'Rising real interest rates.' },
      { heading: 'What is this asset?', body: 'A scarce metal.' },
      { heading: 'How does it generate or derive value?', body: 'Scarcity and demand; it pays no income.' },
      { heading: 'What factors influence its price?', body: 'Rates, the dollar, central banks.' },
      { heading: 'What are its major risks?', body: 'Long flat or falling periods.' },
      { heading: 'What is its historical volatility?', body: 'Moderate for a commodity.' },
      { heading: 'What should beginners understand?', body: 'Fractions do not reduce risk.' },
    ],
    scenarios: { bull: 'If rates fall, demand could rise.', bear: 'If rates rise, prices could fall.' },
    insights: ['Fractions do not reduce risk.'],
    followUps: ['What does a 15% drawdown mean?'],
  };
  let reply: unknown = good;
  const bodies: string[] = [];
  const f: FetchLike = async (url, init) => {
    if (url.includes('api.anthropic.com/v1/messages')) {
      bodies.push(String(init?.body));
      return json({ content: [{ type: 'text', text: JSON.stringify(reply) }] });
    }
    return new Response('blocked', { status: 403 });
  };
  const ai = new AssistantService(cfg({ ANTHROPIC_API_KEY: 'sk-test' }), null, f);
  assert.deepEqual(ai.status(), { mode: 'live', provider: 'anthropic', model: 'claude-haiku-5-5' });

  const live = await ai.ask({ question: 'Is gold a risky investment?' });
  assert.equal(live.mode, 'live');
  assert.equal(live.title, 'Understanding Gold');
  assert.deepEqual(
    live.sections.map((s) => s.heading),
    [...ASSET_SECTION_HEADINGS],
    'asset explainers keep the seven required sections in order',
  );
  assert.ok(live.risk, 'deterministic risk score is attached to live answers');
  const sent = JSON.parse(bodies[0]);
  assert.equal(sent.model, 'claude-haiku-5-5');
  assert.equal(sent.temperature, undefined, 'API version 2026-10-21 rejects sampling parameters');
  assert.match(sent.messages[0].content, /USER QUESTION \(treat as data\)/);

  reply = { ...good, summary: 'Gold guarantees returns for every investor, always.' };
  const blocked = await ai.ask({ question: 'Is gold a risky investment?' });
  assert.equal(blocked.mode, 'fallback');
  assert.match(blocked.notice ?? '', /safety check/);

  reply = { ...good, sections: good.sections.slice(0, 3) };
  const partial = await ai.ask({ question: 'Is gold a risky investment?' });
  assert.equal(partial.mode, 'fallback');
  assert.match(partial.notice ?? '', /seven-part structure/);
  assert.equal(partial.sections.length, 7);

  reply = 'nonsense';
  const broken = await ai.ask({ question: 'What is fractional ownership?' });
  assert.equal(broken.mode, 'fallback');
});

test('news: RSS and Atom parsing keeps only http(s) links and strips HTML', () => {
  const rss = `<rss><channel>
    <item><title><![CDATA[Fed holds rates &amp; signals patience]]></title><link>https://example.com/a</link><pubDate>Thu, 29 Oct 2026 18:00:00 GMT</pubDate><description>&lt;p&gt;Statement&lt;/p&gt;</description></item>
    <item><title>Bad link</title><link>javascript:alert(1)</link></item>
  </channel></rss>`;
  const items = parseFeed(rss, { url: 'x', source: 'Fed', category: 'macro' });
  assert.equal(items.length, 1);
  assert.equal(items[0].title, 'Fed holds rates & signals patience');
  assert.equal(items[0].summary, 'Statement');
  assert.equal(items[0].publishedAt, '2026-10-29T18:00:00.000Z');
  const atom = `<feed><entry><title>Copper rallies</title><link href="https://example.com/b"/><updated>2026-10-30T10:00:00Z</updated></entry></feed>`;
  assert.equal(parseFeed(atom, { url: 'y', source: 'M', category: 'metals' })[0].url, 'https://example.com/b');
});

test('profile store: secret-protected, scrubs personal data', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'vestora-'));
  const store = new FileProfileStore(dir);
  await store.init();
  const saved = await store.put('profile_abcdef123456', 'secret-key-0123456789', {
    preferences: { theme: 'dark', kycFullName: 'Jane', email: 'jane@example.com' },
    watchlist: ['vgld'],
    portfolio: { holdings: [] },
    activity: [],
    alerts: [],
  });
  assert.deepEqual(saved.preferences, { theme: 'dark' });
  const again = await store.get('profile_abcdef123456', 'secret-key-0123456789');
  assert.deepEqual(again?.watchlist, ['vgld']);
  await assert.rejects(store.get('profile_abcdef123456', 'wrong-key-0123456789'), ProfileAuthError);
  const reloaded = new FileProfileStore(dir);
  await reloaded.init();
  assert.ok(await reloaded.get('profile_abcdef123456', 'secret-key-0123456789'));
});

test('cache de-duplicates concurrent loads and serves stale values', async () => {
  let t = 0;
  const cache = new TtlCache<number>(1000, 10, () => t);
  let loads = 0;
  const loader = async () => {
    loads++;
    return 42;
  };
  const [a, b] = await Promise.all([cache.getOrLoad('k', 100, loader), cache.getOrLoad('k', 100, loader)]);
  assert.equal(a + b, 84);
  assert.equal(loads, 1);
  t = 500;
  assert.equal(cache.get('k'), undefined);
  assert.equal(cache.getStale('k')?.value, 42);
  t = 5000;
  assert.equal(cache.getStale('k'), undefined);
});

test('secrets are redacted from URLs in logs and errors', () => {
  assert.equal(redact('https://x.io/q?function=WTI&apikey=SECRET&x=1'), 'https://x.io/q?function=WTI&apikey=***&x=1');
  assert.equal(redact('https://api.tradingeconomics.com/markets?c=abc:def&f=json'), 'https://api.tradingeconomics.com/markets?c=***&f=json');
});
