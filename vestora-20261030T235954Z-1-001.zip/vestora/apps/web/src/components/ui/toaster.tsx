import { Toaster as Sonner } from 'sonner';
import { useIsDark } from '@/hooks/useTheme';

export function Toaster() {
  const dark = useIsDark();
  return (
    <Sonner
      theme={dark ? 'dark' : 'light'}
      position="bottom-right"
      closeButton
      toastOptions={{
        classNames: {
          toast: 'rounded-lg! border! border-border! bg-popover! text-foreground! shadow-float!',
          description: 'text-muted-foreground!',
        },
      }}
    />
  );
}
