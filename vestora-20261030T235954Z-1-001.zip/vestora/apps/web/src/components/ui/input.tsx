import * as React from 'react';
import * as LabelPrimitive from '@radix-ui/react-label';
import { cn } from '@/lib/utils';

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, type = 'text', ...props }, ref) => (
  <input
    ref={ref}
    type={type}
    className={cn(
      'flex h-[38px] w-full min-w-0 rounded-md border border-input bg-surface/60 px-3 text-sm text-foreground placeholder:text-subtle transition-colors',
      'focus-visible:border-blue focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue/25',
      'aria-[invalid=true]:border-danger aria-[invalid=true]:ring-danger/20 disabled:cursor-not-allowed disabled:opacity-50',
      className,
    )}
    {...props}
  />
));
Input.displayName = 'Input';

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    className={cn(
      'flex min-h-20 w-full rounded-md border border-input bg-surface/60 px-3 py-2.5 text-sm text-foreground placeholder:text-subtle',
      'focus-visible:border-blue focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue/25 disabled:opacity-50',
      className,
    )}
    {...props}
  />
));
Textarea.displayName = 'Textarea';

export const Label = React.forwardRef<React.ElementRef<typeof LabelPrimitive.Root>, React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>>(
  ({ className, ...props }, ref) => <LabelPrimitive.Root ref={ref} className={cn('text-[13px] font-medium text-foreground', className)} {...props} />,
);
Label.displayName = 'Label';

export function FieldHint({ children, error, id }: { children: React.ReactNode; error?: boolean; id?: string }) {
  return (
    <p id={id} className={cn('text-xs', error ? 'text-danger' : 'text-muted-foreground')} role={error ? 'alert' : undefined}>
      {children}
    </p>
  );
}
