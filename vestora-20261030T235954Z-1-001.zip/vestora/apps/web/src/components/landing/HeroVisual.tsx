import { motion } from 'framer-motion';
import { formatPct, formatQuote, formatUsd, getAsset, relativeTime } from '@vestora/shared';
import { DataStatusBadge } from '@/components/market/DataStatus';
import { Sparkline } from '@/components/market/Sparkline';
import { useAssetInsights } from '@/hooks/useAsset';
import { useQuote } from '@/hooks/useMarket';
import { useReducedMotion } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';

const COLS = 20;
const ROWS = 8;
const OWNED = new Set([46, 47]); // two cells = 250 of 20,000 tokens (each cell = 125 tokens)

/**
 * The signature visual: a gold bar literally divided into token cells.
 * 160 cells × 125 tokens = the 20,000-token sample pool; two cells are "yours".
 */
function FractionIngot({ reduced }: { reduced: boolean }) {
  const W = 440;
  const H = 230;
  const inset = 46; // trapezoid top inset
  const top = 30;
  const bottom = H - 12;
  const trapezoid = `M${inset},${top} L${W - inset},${top} L${W - 6},${bottom} L6,${bottom} Z`;
  const cells: { x: number; y: number; w: number; h: number; i: number }[] = [];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const y0 = top + ((bottom - top) / ROWS) * r;
      const y1 = top + ((bottom - top) / ROWS) * (r + 1);
      const fx0 = inset - (inset - 6) * ((y0 - top) / (bottom - top));
      const fx1 = W - fx0;
      const cw = (fx1 - fx0) / COLS;
      cells.push({ x: fx0 + cw * c + 1, y: y0 + 1, w: cw - 2, h: y1 - y0 - 2, i: r * COLS + c });
    }
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="A gold bar divided into 160 token cells; two cells, 250 of 20,000 tokens, are highlighted as an example share">
      <defs>
        <linearGradient id="ingot-face" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#E9CF8F" />
          <stop offset="45%" stopColor="#D6B36A" />
          <stop offset="100%" stopColor="#9C7A35" />
        </linearGradient>
        <linearGradient id="ingot-sheen" x1="0" x2="1" y1="0" y2="0">
          <stop offset="0%" stopColor="#fff" stopOpacity="0" />
          <stop offset="50%" stopColor="#fff" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <clipPath id="ingot-clip">
          <path d={trapezoid} />
        </clipPath>
      </defs>
      <ellipse cx={W / 2} cy={H - 4} rx={W / 2 - 30} ry={6} fill="#000" opacity="0.35" />
      <path d={trapezoid} fill="url(#ingot-face)" />
      <g clipPath="url(#ingot-clip)">
        {cells.map((c) => {
          const owned = OWNED.has(c.i);
          return (
            <motion.rect
              key={c.i}
              x={c.x}
              y={c.y}
              width={c.w}
              height={c.h}
              rx={1.5}
              fill={owned ? '#FFF4D6' : '#5A4416'}
              initial={reduced ? false : { opacity: 0 }}
              animate={{ opacity: owned ? 1 : 0.16 }}
              transition={{ delay: reduced ? 0 : 0.25 + (c.i % COLS) * 0.025 + Math.floor(c.i / COLS) * 0.015, duration: 0.35 }}
            />
          );
        })}
        {!reduced && (
          <motion.rect
            x={-160}
            y={0}
            width={160}
            height={H}
            fill="url(#ingot-sheen)"
            initial={{ x: -160 }}
            animate={{ x: W + 160 }}
            transition={{ delay: 1.1, duration: 1.4, ease: 'easeInOut' }}
          />
        )}
      </g>
      <path d={trapezoid} fill="none" stroke="#F3DDA2" strokeOpacity="0.55" strokeWidth="1" />
      <text x={W / 2} y={top - 10} textAnchor="middle" fontFamily="Manrope Variable, Manrope, sans-serif" fontSize="11" fill="currentColor" opacity="0.55" letterSpacing="1.5">
        SAMPLE POOL · 50 TROY OZ · 20,000 TOKENS
      </text>
    </svg>
  );
}

/** Decorative market lines (not data) that drift slowly behind the hero. */
function MarketLines({ reduced }: { reduced: boolean }) {
  const paths = [0, 1, 2].map((k) => {
    let d = '';
    // Periodic over 300 units so the -50% drift (300 of the 600-unit viewBox) loops seamlessly.
    for (let x = 0; x <= 1200; x += 10) {
      const y = 120 + k * 70 + Math.sin(((2 * Math.PI * x) / 300) * (k + 1) + k) * (14 + k * 6) + Math.sin((2 * Math.PI * x) / 150 + k * 2) * 5;
      d += `${x === 0 ? 'M' : 'L'}${x},${y.toFixed(1)} `;
    }
    return d;
  });
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 600 420" preserveAspectRatio="none" aria-hidden>
      <g className={cn(!reduced && 'animate-[ticker_40s_linear_infinite]')}>
        {paths.map((d, i) => (
          <path key={i} d={d} fill="none" stroke={i === 1 ? 'var(--gold)' : 'var(--blue)'} strokeOpacity={i === 1 ? 0.18 : 0.1} strokeWidth="1.2" />
        ))}
      </g>
    </svg>
  );
}

export function HeroVisual() {
  const reduced = useReducedMotion();
  const gold = getAsset('vgld')!;
  const { quote } = useQuote('XAU');
  const { valuation, tokenSeries } = useAssetInsights(gold);
  const tokenPrice = valuation.tokenPrice;
  const exampleTokens = 250;

  const float = (delay: number) =>
    reduced ? {} : { initial: { opacity: 0, y: 12 }, animate: { opacity: 1, y: 0 }, transition: { delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] as const } };

  return (
    <div className="relative mx-auto w-full max-w-[560px] select-none text-foreground">
      <div className="absolute -inset-10 rounded-full blur-3xl" style={{ background: 'radial-gradient(closest-side, var(--hero-glow), transparent)' }} aria-hidden />
      <div className="relative aspect-[600/420] w-full">
        <MarketLines reduced={reduced} />
        <div className="absolute inset-x-[6%] top-[22%]">
          <FractionIngot reduced={reduced} />
        </div>

        {/* Live reference price */}
        <motion.div {...float(0.5)} className="glass absolute left-0 top-0 w-[46%] min-w-[180px] rounded-xl border border-border-strong p-3.5 shadow-float">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-muted-foreground">Gold reference · XAU/USD</span>
            {quote && <DataStatusBadge status={quote.status} frequency={quote.frequency} withTooltip={false} />}
          </div>
          <div className="mt-1.5 font-display text-xl font-semibold tabular">{quote ? formatQuote(quote.price, 'USD', 2) : '—'}</div>
          <div className="mt-0.5 flex items-center gap-2 text-[11px] text-muted-foreground">
            {quote?.changePct != null && <span className={quote.changePct >= 0 ? 'text-success' : 'text-danger'}>{formatPct(quote.changePct)}</span>}
            <span>{quote?.proxy ? `${quote.proxy.symbol} proxy · ` : ''}{quote?.asOf ? `updated ${relativeTime(quote.asOf)}` : quote?.status === 'demo' ? 'static demo value' : ''}</span>
          </div>
        </motion.div>

        {/* Token representation */}
        <motion.div {...float(0.7)} className="glass absolute right-0 top-[30%] w-[40%] min-w-[168px] rounded-xl border border-border-strong p-3.5 shadow-float">
          <div className="text-xs text-muted-foreground">vGLD · 1 token</div>
          <div className="mt-1 font-display text-lg font-semibold tabular">{formatUsd(tokenPrice)}</div>
          <div className="text-[11px] text-muted-foreground">≈ 0.0025 troy oz · illustrative</div>
          <Sparkline points={tokenSeries} width={150} height={30} className="mt-2" label="vGLD illustrative token price, past year" />
        </motion.div>

        {/* Ownership representation */}
        <motion.div {...float(0.9)} className="glass absolute bottom-0 left-[8%] flex w-[52%] min-w-[210px] items-center gap-3 rounded-xl border border-border-strong p-3.5 shadow-float">
          <svg viewBox="0 0 36 36" className="size-11 shrink-0 -rotate-90" aria-hidden>
            <circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--border-strong)" strokeWidth="3.5" />
            <circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--gold)" strokeWidth="3.5" strokeLinecap="round" strokeDasharray={`${(1.25 / 100) * 97.4 + 2} 97.4`} />
          </svg>
          <div className="min-w-0">
            <div className="text-xs text-muted-foreground">Example share</div>
            <div className="font-display text-[15px] font-semibold tabular">
              {exampleTokens} of 20,000 tokens · 1.25%
            </div>
            <div className="text-[11px] text-muted-foreground">{tokenPrice ? `${formatUsd(exampleTokens * tokenPrice, 0)} at today’s illustrative price` : 'Illustrative example'}</div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
