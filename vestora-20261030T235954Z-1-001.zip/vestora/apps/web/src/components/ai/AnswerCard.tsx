import { Lightbulb, Sparkles, TrendingDown, TrendingUp } from 'lucide-react';
import type { AssistantResponse } from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger, Popover, PopoverContent, PopoverTrigger } from '@/components/ui/primitives';
import { Disclaimer } from '@/components/common/States';
import { RiskBreakdown, RiskMeter } from '@/components/assets/AssetBits';
import { cn } from '@/lib/utils';

export function ModeBadge({ answer }: { answer: Pick<AssistantResponse, 'mode' | 'provider' | 'model'> }) {
  if (answer.mode === 'live') {
    return (
      <Badge variant="blue">
        <Sparkles aria-hidden /> Live AI{answer.model ? ` · ${answer.model}` : ''}
      </Badge>
    );
  }
  if (answer.mode === 'fallback') return <Badge variant="warning">Curated fallback</Badge>;
  return <Badge variant="demo">Educational demo assistant</Badge>;
}

export function AnswerCard({
  answer,
  compact = false,
  onFollowUp,
  className,
}: {
  answer: AssistantResponse;
  compact?: boolean;
  onFollowUp?: (q: string) => void;
  className?: string;
}) {
  const sections = compact ? answer.sections.slice(0, 3) : answer.sections;
  return (
    <article className={cn('space-y-5 rounded-xl border border-border bg-card p-5', className)} aria-label={answer.title}>
      <header className="space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <ModeBadge answer={answer} />
          {answer.subject && <Badge variant="outline">{answer.subject.name}</Badge>}
        </div>
        <h3 className="font-display text-lg font-semibold tracking-[-0.015em]">{answer.title}</h3>
        <p className="text-sm leading-relaxed text-foreground/90">{answer.summary}</p>
      </header>

      {answer.notice && (
        <Disclaimer tone="warning" className="text-[13px]">
          {answer.notice}
        </Disclaimer>
      )}

      {answer.risk && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-muted px-4 py-3">
          <div className="flex items-center gap-3">
            <RiskMeter level={answer.risk.level} className="scale-125" />
            <div>
              <p className="text-[13px] text-muted-foreground">Educational risk score</p>
              <p className="font-display text-base font-semibold">
                {answer.risk.level} <span className="tabular text-muted-foreground">{answer.risk.score.toFixed(1)}/10</span>
              </p>
            </div>
          </div>
          <Popover>
            <PopoverTrigger className="text-[13px] text-blue underline-offset-4 hover:underline">How is this calculated?</PopoverTrigger>
            <PopoverContent className="w-[min(92vw,420px)] space-y-4">
              <p className="text-[13px] leading-relaxed text-muted-foreground">{answer.risk.methodology}</p>
              <RiskBreakdown risk={answer.risk} />
            </PopoverContent>
          </Popover>
        </div>
      )}

      {sections.length > 0 && (
        <Accordion type="multiple" defaultValue={compact ? [] : [sections[0].heading]} className="rounded-lg border border-border px-4">
          {sections.map((s) => (
            <AccordionItem key={s.heading} value={s.heading}>
              <AccordionTrigger>{s.heading}</AccordionTrigger>
              <AccordionContent className="whitespace-pre-line leading-relaxed text-muted-foreground">{s.body}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      )}
      {compact && answer.sections.length > sections.length && <p className="text-xs text-muted-foreground">+ {answer.sections.length - sections.length} more sections in VESTORA Intelligence</p>}

      {answer.scenarios && (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-lg border border-border p-3.5">
            <p className="mb-1 flex items-center gap-1.5 text-[13px] font-medium text-foreground">
              <TrendingUp className="size-4 text-success" aria-hidden /> If conditions turn favourable
            </p>
            <p className="text-[13px] leading-relaxed text-muted-foreground">{answer.scenarios.bull}</p>
          </div>
          <div className="rounded-lg border border-border p-3.5">
            <p className="mb-1 flex items-center gap-1.5 text-[13px] font-medium text-foreground">
              <TrendingDown className="size-4 text-danger" aria-hidden /> If conditions turn against it
            </p>
            <p className="text-[13px] leading-relaxed text-muted-foreground">{answer.scenarios.bear}</p>
          </div>
          <p className="text-xs text-subtle sm:col-span-2">Scenarios describe what could happen under different conditions. They are not predictions.</p>
        </div>
      )}

      {!compact && answer.insights.length > 0 && (
        <ul className="space-y-2">
          {answer.insights.map((i) => (
            <li key={i} className="flex gap-2 text-[13px] leading-relaxed text-foreground/90">
              <Lightbulb className="mt-0.5 size-4 shrink-0 text-gold" aria-hidden /> {i}
            </li>
          ))}
        </ul>
      )}

      {onFollowUp && answer.followUps.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {answer.followUps.map((q) => (
            <button
              key={q}
              onClick={() => onFollowUp(q)}
              className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-border-strong hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring"
            >
              {q}
            </button>
          ))}
        </div>
      )}

      <p className="border-t border-border pt-3 text-[11px] leading-relaxed text-subtle">{answer.disclaimer}</p>
    </article>
  );
}
