import { Link } from 'react-router';
import { TICKER_INSTRUMENTS, formatQuote, getInstrument, relativeTime } from '@vestora/shared';
import { useAllQuotes } from '@/hooks/useMarket';
import { useReducedMotion } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';
import { statusLabel } from './DataStatus';
import { PriceChange } from './PriceChange';

const DOT: Record<string, string> = {
  realtime: 'bg-success',
  delayed: 'bg-warning',
  historical: 'bg-blue',
  demo: 'bg-demo',
  unavailable: 'bg-subtle',
};

/** Scrolling live ticker. Every item carries its status and observation time. */
export function MarketTicker({ className }: { className?: string }) {
  const { quotes, isLoading, generatedAt } = useAllQuotes();
  const reduced = useReducedMotion();
  const items = TICKER_INSTRUMENTS.map((id) => ({ inst: getInstrument(id)!, q: quotes[id] }));

  const row = (ariaHidden: boolean) => (
    <ul className="flex shrink-0 items-center" aria-hidden={ariaHidden || undefined}>
      {items.map(({ inst, q }) => (
        <li key={inst.id} className="flex items-center gap-2.5 border-r border-border px-5 py-3 text-[13px] whitespace-nowrap">
          <span className={cn('size-1.5 rounded-full', DOT[q?.status ?? 'unavailable'])} aria-hidden />
          <Link to={`/markets?focus=${inst.id}`} className="font-medium text-foreground hover:underline" tabIndex={ariaHidden ? -1 : 0}>
            {inst.shortName}
          </Link>
          {isLoading ? (
            <span className="skeleton h-3.5 w-16" />
          ) : (
            <>
              <span className="tabular text-foreground/90">{q ? formatQuote(q.price, inst.denomination, inst.decimals) : '—'}</span>
              <PriceChange pct={q?.changePct} size="xs" />
              <span className="text-[11px] text-subtle">
                {q ? statusLabel(q.status, q.frequency) : 'Unavailable'}
                {q?.asOf ? ` · ${relativeTime(q.asOf)}` : ''}
              </span>
            </>
          )}
        </li>
      ))}
    </ul>
  );

  return (
    <section aria-label="Live market ticker" className={cn('group relative overflow-hidden border-y border-border bg-surface/50', className)}>
      <div className={cn('flex w-max', !reduced && 'animate-ticker group-hover:[animation-play-state:paused] group-focus-within:[animation-play-state:paused]')}>
        {row(false)}
        {!reduced && row(true)}
      </div>
      {generatedAt && <span className="sr-only">Prices last refreshed {relativeTime(generatedAt)}</span>}
    </section>
  );
}
