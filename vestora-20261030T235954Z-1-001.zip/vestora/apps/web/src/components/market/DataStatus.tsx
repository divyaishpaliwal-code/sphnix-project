import type { DataStatus, Frequency, Quote, Series } from '@vestora/shared';
import { relativeTime } from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Tooltip } from '@/components/ui/primitives';
import { cn } from '@/lib/utils';

const LABEL: Record<DataStatus, string> = {
  realtime: 'Live',
  delayed: 'Delayed',
  historical: 'Historical',
  demo: 'Demo data',
  unavailable: 'Unavailable',
};

const VARIANT = {
  realtime: 'success',
  delayed: 'warning',
  historical: 'blue',
  demo: 'demo',
  unavailable: 'neutral',
} as const;

const EXPLAIN: Record<DataStatus, string> = {
  realtime: 'Real-time or near real-time quote from the named provider.',
  delayed: 'Delayed or end-of-day data. Prices may lag the market.',
  historical: 'Periodic historical data (for example monthly averages), not a live price.',
  demo: 'Static illustrative value used because no live source is reachable. Not a market quote.',
  unavailable: 'No data source is available for this instrument right now.',
};

export function statusLabel(status: DataStatus, frequency?: Frequency): string {
  if (status === 'historical' && frequency === 'monthly') return 'Monthly';
  return LABEL[status];
}

export function DataStatusBadge({ status, frequency, className, withTooltip = true }: { status: DataStatus; frequency?: Frequency; className?: string; withTooltip?: boolean }) {
  const badge = (
    <Badge variant={VARIANT[status]} className={cn('gap-1.5', className)}>
      <span className={cn('size-1.5 rounded-full bg-current', status === 'realtime' && 'animate-pulse')} aria-hidden />
      {statusLabel(status, frequency)}
    </Badge>
  );
  if (!withTooltip) return badge;
  return (
    <Tooltip content={EXPLAIN[status]}>
      <span tabIndex={0} className="inline-flex rounded-sm focus-visible:outline-2 focus-visible:outline-ring">
        {badge}
      </span>
    </Tooltip>
  );
}

export function IllustrativeBadge({ className }: { className?: string }) {
  return (
    <Tooltip content="Illustrative token price: sample asset value ÷ token supply. Not a market price.">
      <span tabIndex={0} className="inline-flex rounded-sm">
        <Badge variant="gold" className={className}>
          Illustrative
        </Badge>
      </span>
    </Tooltip>
  );
}

export function SimulatedBadge({ className, label = 'Simulated' }: { className?: string; label?: string }) {
  return (
    <Badge variant="outline" className={cn('border-dashed', className)}>
      {label}
    </Badge>
  );
}

/** "CoinGecko · updated 2m ago" with proxy disclosure when relevant. */
export function SourceLine({ data, className }: { data: Pick<Quote, 'source' | 'asOf' | 'fetchedAt' | 'proxy' | 'message'> | Pick<Series, 'source' | 'fetchedAt' | 'proxy' | 'message'>; className?: string }) {
  const asOf = 'asOf' in data ? data.asOf : null;
  return (
    <div className={cn('flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground', className)}>
      <span>
        Source:{' '}
        {data.source.url ? (
          <a href={data.source.url} target="_blank" rel="noreferrer" className="text-foreground/80 underline-offset-2 hover:underline">
            {data.source.name}
          </a>
        ) : (
          <span className="text-foreground/80">{data.source.name}</span>
        )}
      </span>
      {asOf && <span>Observation {relativeTime(asOf)}</span>}
      <span>Fetched {relativeTime(data.fetchedAt)}</span>
      {data.proxy && (
        <Tooltip content={data.proxy.note}>
          <span tabIndex={0} className="inline-flex">
            <Badge variant="outline">{data.proxy.symbol} proxy</Badge>
          </span>
        </Tooltip>
      )}
    </div>
  );
}
