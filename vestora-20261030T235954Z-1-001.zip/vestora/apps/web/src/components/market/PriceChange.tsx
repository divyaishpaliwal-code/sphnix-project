import { ArrowDownRight, ArrowUpRight, Minus } from 'lucide-react';
import type { ChangeBasis } from '@vestora/shared';
import { formatPct } from '@vestora/shared';
import { Tooltip } from '@/components/ui/primitives';
import { cn } from '@/lib/utils';

export const BASIS_LABEL: Record<ChangeBasis, string> = {
  '24h': '24h',
  'previous-close': 'vs prev. close',
  'previous-observation': 'vs prev. obs.',
};

const BASIS_EXPLAIN: Record<ChangeBasis, string> = {
  '24h': 'Change over the last 24 hours.',
  'previous-close': 'Change versus the previous trading-day close.',
  'previous-observation': 'Change versus the previous published observation of the same series (e.g. previous day or month).',
};

export function PriceChange({
  pct,
  basis,
  className,
  showBasis = false,
  size = 'sm',
}: {
  pct: number | null | undefined;
  basis?: ChangeBasis | null;
  className?: string;
  showBasis?: boolean;
  size?: 'xs' | 'sm' | 'md';
}) {
  if (pct === null || pct === undefined || !Number.isFinite(pct)) {
    return (
      <Tooltip content="No comparable previous observation is available from this source.">
        <span tabIndex={0} className={cn('inline-flex items-center gap-1 text-subtle', size === 'xs' ? 'text-[11px]' : 'text-xs', className)}>
          <Minus className="size-3" aria-hidden /> n/a
        </span>
      </Tooltip>
    );
  }
  const up = pct > 0.0001;
  const down = pct < -0.0001;
  const Icon = up ? ArrowUpRight : down ? ArrowDownRight : Minus;
  const body = (
    <span
      className={cn(
        'inline-flex items-center gap-0.5 font-medium tabular',
        up && 'text-success',
        down && 'text-danger',
        !up && !down && 'text-muted-foreground',
        size === 'xs' && 'text-[11px]',
        size === 'sm' && 'text-xs',
        size === 'md' && 'text-sm',
        className,
      )}
    >
      <Icon className={size === 'md' ? 'size-4' : 'size-3.5'} aria-hidden />
      {formatPct(pct)}
      {showBasis && basis && <span className="ml-1 font-normal text-subtle">{BASIS_LABEL[basis]}</span>}
    </span>
  );
  if (!basis) return body;
  return (
    <Tooltip content={BASIS_EXPLAIN[basis]}>
      <span tabIndex={0} className="inline-flex rounded-sm">
        {body}
      </span>
    </Tooltip>
  );
}
