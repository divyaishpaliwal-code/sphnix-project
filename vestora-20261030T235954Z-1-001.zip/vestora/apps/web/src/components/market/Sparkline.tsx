import { useId, useMemo } from 'react';
import type { SeriesPoint } from '@vestora/shared';
import { cn } from '@/lib/utils';

/**
 * Lightweight SVG sparkline for cards and table rows (no axes by design).
 * Renders a neutral placeholder when there is no real history — never invented data.
 */
export function Sparkline({
  points,
  width = 120,
  height = 36,
  className,
  tone,
  label,
}: {
  points: SeriesPoint[] | undefined;
  width?: number;
  height?: number;
  className?: string;
  tone?: 'up' | 'down' | 'neutral';
  label?: string;
}) {
  const gid = useId().replace(/:/g, '');
  const path = useMemo(() => {
    if (!points || points.length < 2) return null;
    const xs = points.map((p) => p.t);
    const ys = points.map((p) => p.v);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);
    const sx = (x: number) => (maxX === minX ? 0 : ((x - minX) / (maxX - minX)) * (width - 2) + 1);
    const sy = (y: number) => (maxY === minY ? height / 2 : height - 2 - ((y - minY) / (maxY - minY)) * (height - 4));
    const line = points.map((p, i) => `${i ? 'L' : 'M'}${sx(p.t).toFixed(1)},${sy(p.v).toFixed(1)}`).join(' ');
    const area = `${line} L${sx(maxX).toFixed(1)},${height} L${sx(minX).toFixed(1)},${height} Z`;
    const dir = ys[ys.length - 1] >= ys[0] ? 'up' : 'down';
    return { line, area, dir };
  }, [points, width, height]);

  if (!path) {
    return (
      <div className={cn('flex items-center justify-center rounded-md border border-dashed border-border text-[10px] text-subtle', className)} style={{ width, height }}>
        No history
      </div>
    );
  }
  const t = tone ?? (path.dir as 'up' | 'down');
  const color = t === 'up' ? 'var(--success)' : t === 'down' ? 'var(--danger)' : 'var(--blue)';
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height} className={cn('overflow-visible', className)} role="img" aria-label={label ?? 'Price trend'}>
      <defs>
        <linearGradient id={`sg-${gid}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.16" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={path.area} fill={`url(#sg-${gid})`} />
      <path d={path.line} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}
