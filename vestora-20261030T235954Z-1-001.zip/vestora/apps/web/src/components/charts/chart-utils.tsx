import type { ReactNode } from 'react';
import type { HistoryRange, QuoteDenomination } from '@vestora/shared';
import { formatNumber, formatQuote } from '@vestora/shared';

const fmtCache = new Map<string, Intl.DateTimeFormat>();
function dtf(key: string, opts: Intl.DateTimeFormatOptions) {
  let f = fmtCache.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', opts);
    fmtCache.set(key, f);
  }
  return f;
}

export function timeTick(range: HistoryRange | 'auto', spanMs?: number) {
  const span = spanMs ?? 0;
  if (range === '1D' || (range === 'auto' && span <= 2 * 86_400_000)) return (t: number) => dtf('hm', { hour: '2-digit', minute: '2-digit', hour12: false }).format(t);
  if (range === '1W' || range === '1M' || range === '3M' || (range === 'auto' && span <= 120 * 86_400_000)) return (t: number) => dtf('md', { month: 'short', day: 'numeric' }).format(t);
  return (t: number) => dtf('my', { month: 'short', year: '2-digit' }).format(t);
}

export function fullTime(t: number, intraday: boolean): string {
  return intraday
    ? dtf('full-i', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }).format(t)
    : dtf('full-d', { month: 'short', day: 'numeric', year: 'numeric' }).format(t);
}

/** Compact axis ticks: full under 10,000; compact above. */
export function axisValue(v: number, denomination: QuoteDenomination | 'USD-token' | 'index'): string {
  if (denomination === 'percent') return `${formatNumber(v, 2)}%`;
  if (denomination === 'index') return formatNumber(v, 0);
  const abs = Math.abs(v);
  const prefix = denomination === 'USc' ? '' : '$';
  const suffix = denomination === 'USc' ? '¢' : '';
  if (abs >= 10_000) return `${prefix}${new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(v)}${suffix}`;
  if (abs >= 100) return `${prefix}${formatNumber(v, 0)}${suffix}`;
  if (abs >= 1) return `${prefix}${formatNumber(v, 2)}${suffix}`;
  return `${prefix}${formatNumber(v, 4)}${suffix}`;
}

export function valueLabel(v: number, denomination: QuoteDenomination | 'USD-token', decimals = 2): string {
  if (denomination === 'USD-token') return formatQuote(v, 'USD', v < 1 ? 4 : 2);
  return formatQuote(v, denomination, decimals);
}

export function TooltipShell({ title, children }: { title: ReactNode; children: ReactNode }) {
  return (
    <div className="min-w-40 rounded-lg border border-border bg-popover px-3 py-2 text-xs shadow-float">
      <div className="mb-1.5 text-muted-foreground">{title}</div>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

export function TooltipRow({ color, label, value }: { color?: string; label: ReactNode; value: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="flex items-center gap-1.5 text-foreground/90">
        {color && <span className="size-2 rounded-full" style={{ background: color }} aria-hidden />}
        {label}
      </span>
      <span className="font-medium tabular text-foreground">{value}</span>
    </div>
  );
}

export function ChartSkeleton({ height = 260 }: { height?: number }) {
  return (
    <div className="relative w-full overflow-hidden rounded-lg" style={{ height }} aria-label="Loading chart" role="status">
      <div className="skeleton absolute inset-0 opacity-60" />
    </div>
  );
}

export function ChartMessage({ height = 260, title, children }: { height?: number; title: string; children?: ReactNode }) {
  return (
    <div className="flex w-full flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed border-border px-6 text-center" style={{ height }}>
      <p className="text-sm font-medium text-foreground">{title}</p>
      {children && <p className="max-w-md text-[13px] leading-relaxed text-muted-foreground">{children}</p>}
    </div>
  );
}
