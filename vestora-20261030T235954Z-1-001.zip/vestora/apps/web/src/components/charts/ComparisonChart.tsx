import { useMemo } from 'react';
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { HistoryRange, SeriesPoint } from '@vestora/shared';
import { formatNumber, rebase } from '@vestora/shared';
import { useReducedMotion } from '@/hooks/useTheme';
import { ChartMessage, ChartSkeleton, fullTime, timeTick, TooltipRow, TooltipShell } from './chart-utils';

export interface CompareSeries {
  key: string;
  label: string;
  color: string;
  points: SeriesPoint[];
}

/**
 * Several series indexed to 100 at the start of the window — one axis, so
 * instruments with very different price levels can be compared honestly.
 */
export function ComparisonChart({ series, range, height = 300, loading }: { series: CompareSeries[]; range: HistoryRange; height?: number; loading?: boolean }) {
  const reduced = useReducedMotion();
  const { rows, usable } = useMemo(() => {
    const usable = series.filter((s) => s.points.length >= 2);
    const rebased = usable.map((s) => ({ key: s.key, pts: rebase(s.points) }));
    // Union of timestamps, carrying each series' last observation forward.
    const times = [...new Set(rebased.flatMap((s) => s.pts.map((p) => p.t)))].sort((a, b) => a - b);
    const step = Math.max(1, Math.ceil(times.length / 400));
    const sampled = times.filter((_, i) => i % step === 0 || i === times.length - 1);
    const cursors = rebased.map(() => 0);
    const rows = sampled.map((t) => {
      const row: Record<string, number | null> & { t: number } = { t };
      rebased.forEach((s, i) => {
        while (cursors[i] + 1 < s.pts.length && s.pts[cursors[i] + 1].t <= t) cursors[i]++;
        const p = s.pts[cursors[i]];
        row[s.key] = p && p.t <= t ? p.v : null;
      });
      return row;
    });
    return { rows, usable };
  }, [series]);

  if (loading) return <ChartSkeleton height={height} />;
  if (usable.length === 0 || rows.length < 2) {
    return (
      <ChartMessage height={height} title="Not enough history to compare">
        Choose instruments with available history, or a longer range. Series without real observations are left out rather than estimated.
      </ChartMessage>
    );
  }
  const span = rows[rows.length - 1].t - rows[0].t;
  const tick = timeTick(range, span);
  const intraday = range === '1D' || range === '1W';

  return (
    <div className="space-y-3">
      <div style={{ height }} className="w-full" role="img" aria-label={`Indexed performance of ${usable.map((s) => s.label).join(', ')}`}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={rows} margin={{ top: 8, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="t" type="number" scale="time" domain={['dataMin', 'dataMax']} tickFormatter={tick} tickLine={false} axisLine={false} minTickGap={48} tickMargin={8} />
            <YAxis orientation="right" domain={['auto', 'auto']} tickFormatter={(v: number) => formatNumber(v, 0)} tickLine={false} axisLine={false} width={44} />
            <ReferenceLine y={100} stroke="var(--border-strong)" strokeWidth={1} />
            <Tooltip
              cursor={{ stroke: 'var(--border-strong)', strokeWidth: 1 }}
              content={({ active, payload, label }) => {
                if (!active || !payload?.length) return null;
                return (
                  <TooltipShell title={fullTime(Number(label), intraday)}>
                    {payload.map((p) => {
                      const s = usable.find((x) => x.key === p.dataKey);
                      const v = typeof p.value === 'number' ? p.value : null;
                      return <TooltipRow key={String(p.dataKey)} color={s?.color} label={s?.label ?? String(p.dataKey)} value={v === null ? '—' : `${formatNumber(v, 1)} (${v >= 100 ? '+' : '−'}${formatNumber(Math.abs(v - 100), 1)}%)`} />;
                    })}
                  </TooltipShell>
                );
              }}
            />
            {usable.map((s) => (
              <Line
                key={s.key}
                type="monotone"
                dataKey={s.key}
                stroke={s.color}
                strokeWidth={2}
                dot={false}
                connectNulls
                activeDot={{ r: 4, strokeWidth: 2, stroke: 'var(--card)', fill: s.color }}
                isAnimationActive={!reduced}
                animationDuration={500}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <ul className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground" aria-label="Legend">
        {series.map((s) => {
          const last = rows.length ? rows[rows.length - 1][s.key] : null;
          return (
            <li key={s.key} className="flex items-center gap-1.5">
              <span className="h-0.5 w-3 rounded-full" style={{ background: s.color }} aria-hidden />
              <span className="text-foreground/90">{s.label}</span>
              {typeof last === 'number' ? (
                <span className="tabular">
                  {last >= 100 ? '+' : '−'}
                  {formatNumber(Math.abs(last - 100), 1)}%
                </span>
              ) : (
                <span className="text-subtle">no history</span>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
