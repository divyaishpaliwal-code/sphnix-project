import { RISK_LEVEL_ORDER, formatPct, formatUsd, type RiskLevel } from '@vestora/shared';
import { RISK_COLOR } from '@/lib/chart-colors';
import { Tooltip } from '@/components/ui/primitives';

/**
 * Risk distribution as one tall segmented bar (ordinal single-hue ramp:
 * recessive → prominent as risk rises), with a legend that names every level.
 */
export function RiskDistribution({ values, hideValues }: { values: Partial<Record<RiskLevel, number>>; hideValues?: boolean }) {
  const total = RISK_LEVEL_ORDER.reduce((s, l) => s + (values[l] ?? 0), 0);
  if (total <= 0) return null;
  const parts = RISK_LEVEL_ORDER.map((l) => ({ level: l, value: values[l] ?? 0 })).filter((p) => p.value > 0);
  return (
    <div className="space-y-4">
      <div className="flex h-7 w-full gap-[2px]" role="img" aria-label={`Risk distribution: ${parts.map((p) => `${p.level} ${((p.value / total) * 100).toFixed(1)}%`).join(', ')}`}>
        {parts.map((p, i) => {
          const share = (p.value / total) * 100;
          const lightText = RISK_LEVEL_ORDER.indexOf(p.level) >= 2;
          return (
            <Tooltip key={p.level} content={`${p.level}: ${formatPct(share, 1, false)}${hideValues ? '' : ` · ${formatUsd(p.value)}`}`}>
              <div
                tabIndex={0}
                className={`flex items-center px-2 text-[11px] font-medium focus-visible:outline-2 focus-visible:outline-ring ${i === 0 ? 'rounded-l-[4px]' : ''} ${i === parts.length - 1 ? 'rounded-r-[4px]' : ''}`}
                style={{ width: `${share}%`, background: RISK_COLOR[p.level], color: lightText ? '#ffffff' : '#0b1220' }}
              >
                {share >= 14 ? `${share.toFixed(0)}%` : ''}
              </div>
            </Tooltip>
          );
        })}
      </div>
      <ul className="grid gap-2 sm:grid-cols-2" aria-label="Risk legend">
        {RISK_LEVEL_ORDER.map((l) => (
          <li key={l} className="flex items-center gap-2.5 text-[13px]">
            <span className="size-2.5 shrink-0 rounded-[3px]" style={{ background: RISK_COLOR[l] }} aria-hidden />
            <span className="flex-1 text-foreground">{l}</span>
            <span className="tabular text-muted-foreground">{formatPct(((values[l] ?? 0) / total) * 100, 1, false)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
