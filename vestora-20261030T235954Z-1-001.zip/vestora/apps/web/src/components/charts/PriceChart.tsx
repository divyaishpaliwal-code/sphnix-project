import { useId, useMemo } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { HistoryRange, QuoteDenomination, SeriesPoint } from '@vestora/shared';
import { useReducedMotion } from '@/hooks/useTheme';
import { axisValue, ChartMessage, ChartSkeleton, fullTime, timeTick, TooltipRow, TooltipShell, valueLabel } from './chart-utils';

/**
 * Single-series price chart with crosshair tooltip. Only ever plots real
 * observations (or illustrative token prices derived from them).
 */
export function PriceChart({
  points,
  range,
  denomination,
  decimals = 2,
  color = 'var(--chart-1)',
  height = 280,
  loading,
  emptyTitle = 'No history to show',
  emptyMessage,
  seriesLabel = 'Price',
}: {
  points: SeriesPoint[] | undefined;
  range: HistoryRange;
  denomination: QuoteDenomination | 'USD-token';
  decimals?: number;
  color?: string;
  height?: number;
  loading?: boolean;
  emptyTitle?: string;
  emptyMessage?: string;
  seriesLabel?: string;
}) {
  const gid = useId().replace(/:/g, '');
  const reduced = useReducedMotion();
  const data = useMemo(() => (points ?? []).map((p) => ({ t: p.t, v: p.v })), [points]);
  const span = data.length > 1 ? data[data.length - 1].t - data[0].t : 0;
  const intraday = range === '1D' || range === '1W';
  const tick = timeTick(range, span);
  const axisDen = denomination === 'USD-token' ? 'USD' : denomination;

  if (loading) return <ChartSkeleton height={height} />;
  if (data.length < 2) return <ChartMessage height={height} title={emptyTitle}>{emptyMessage}</ChartMessage>;

  return (
    <div style={{ height }} className="w-full" role="img" aria-label={`${seriesLabel} chart, ${data.length} observations`}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 4, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id={`pc-${gid}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.14} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} strokeWidth={1} />
          <XAxis dataKey="t" type="number" scale="time" domain={['dataMin', 'dataMax']} tickFormatter={tick} tickLine={false} axisLine={false} minTickGap={48} tickMargin={8} />
          <YAxis
            dataKey="v"
            orientation="right"
            domain={['auto', 'auto']}
            tickFormatter={(v: number) => axisValue(v, axisDen)}
            tickLine={false}
            axisLine={false}
            width={64}
            tickCount={5}
          />
          <Tooltip
            cursor={{ stroke: 'var(--border-strong)', strokeWidth: 1 }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const row = payload[0].payload as { t: number; v: number };
              return (
                <TooltipShell title={fullTime(row.t, intraday)}>
                  <TooltipRow color={color} label={seriesLabel} value={valueLabel(row.v, denomination, decimals)} />
                </TooltipShell>
              );
            }}
          />
          <Area
            type="monotone"
            dataKey="v"
            stroke={color}
            strokeWidth={2}
            fill={`url(#pc-${gid})`}
            dot={false}
            activeDot={{ r: 4, strokeWidth: 2, stroke: 'var(--card)', fill: color }}
            isAnimationActive={!reduced}
            animationDuration={500}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
