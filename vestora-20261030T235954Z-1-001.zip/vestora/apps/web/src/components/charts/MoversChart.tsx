import { Bar, BarChart, Cell, LabelList, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatPct } from '@vestora/shared';
import { useReducedMotion } from '@/hooks/useTheme';
import { TooltipRow, TooltipShell } from './chart-utils';

export interface Mover {
  key: string;
  label: string;
  pct: number;
  basis: string;
}

/** Gainers and losers as horizontal bars from a zero baseline, value at each tip. */
export function MoversChart({ movers, height }: { movers: Mover[]; height?: number }) {
  const reduced = useReducedMotion();
  const h = height ?? Math.max(160, movers.length * 30 + 20);
  const max = Math.max(1, ...movers.map((m) => Math.abs(m.pct)));
  return (
    <div style={{ height: h }} className="w-full" role="img" aria-label={`Market movers: ${movers.map((m) => `${m.label} ${formatPct(m.pct)}`).join(', ')}`}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={movers} layout="vertical" margin={{ top: 0, right: 56, bottom: 0, left: 0 }} barCategoryGap={8}>
          <XAxis type="number" domain={[-max * 1.05, max * 1.05]} hide />
          <YAxis type="category" dataKey="label" width={104} tickLine={false} axisLine={false} interval={0} />
          <ReferenceLine x={0} stroke="var(--border-strong)" strokeWidth={1} />
          <Tooltip
            cursor={{ fill: 'var(--muted)' }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const m = payload[0].payload as Mover;
              return (
                <TooltipShell title={m.label}>
                  <TooltipRow color={m.pct >= 0 ? 'var(--success)' : 'var(--danger)'} label={m.basis} value={formatPct(m.pct)} />
                </TooltipShell>
              );
            }}
          />
          <Bar dataKey="pct" maxBarSize={14} radius={[4, 4, 4, 4]} isAnimationActive={!reduced} animationDuration={500}>
            {movers.map((m) => (
              <Cell key={m.key} fill={m.pct >= 0 ? 'var(--success)' : 'var(--danger)'} />
            ))}
            <LabelList dataKey="pct" position="right" formatter={(v: unknown) => formatPct(Number(v))} className="fill-[var(--muted-foreground)] text-[11px] tabular" />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
