import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { formatPct, formatUsd } from '@vestora/shared';
import { useReducedMotion } from '@/hooks/useTheme';
import { TooltipRow, TooltipShell } from './chart-utils';

export interface Slice {
  key: string;
  label: string;
  value: number;
  color: string;
}

/**
 * Part-to-whole allocation. Three or more parts → donut; one or two → a
 * segmented bar (a two-slice pie reads poorly). Legend lists values, so colour
 * is never the only channel.
 */
export function AllocationChart({ slices, centerLabel, hideValues }: { slices: Slice[]; centerLabel?: string; hideValues?: boolean }) {
  const reduced = useReducedMotion();
  const data = slices.filter((s) => s.value > 0);
  const total = data.reduce((s, x) => s + x.value, 0);
  if (total <= 0) return null;

  return (
    <div className="grid items-center gap-5 sm:grid-cols-[180px_1fr]">
      {data.length >= 3 ? (
        <div className="relative mx-auto size-[180px]" role="img" aria-label={`Allocation: ${data.map((d) => `${d.label} ${((d.value / total) * 100).toFixed(1)}%`).join(', ')}`}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="label"
                innerRadius={62}
                outerRadius={86}
                paddingAngle={1.5}
                stroke="var(--card)"
                strokeWidth={2}
                isAnimationActive={!reduced}
                animationDuration={500}
              >
                {data.map((d) => (
                  <Cell key={d.key} fill={d.color} />
                ))}
              </Pie>
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload as Slice;
                  return (
                    <TooltipShell title={d.label}>
                      <TooltipRow color={d.color} label="Share" value={formatPct((d.value / total) * 100, 1, false)} />
                      {!hideValues && <TooltipRow label="Value" value={formatUsd(d.value)} />}
                    </TooltipShell>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-[11px] text-muted-foreground">{centerLabel ?? 'Total'}</span>
            <span className="font-display text-base font-semibold tabular">{hideValues ? '•••••' : formatUsd(total, 0)}</span>
          </div>
        </div>
      ) : (
        <div className="flex h-7 w-full gap-[2px]" role="img" aria-label={`Allocation: ${data.map((d) => `${d.label} ${((d.value / total) * 100).toFixed(1)}%`).join(', ')}`}>
          {data.map((d) => (
            <div
              key={d.key}
              className="flex items-center px-2 text-[11px] font-medium first:rounded-l-[4px] last:rounded-r-[4px]"
              style={{ width: `${(d.value / total) * 100}%`, background: d.color, color: d.color.includes('chart-4') ? '#0b1220' : '#ffffff' }}
            >
              {(d.value / total) * 100 >= 18 ? `${((d.value / total) * 100).toFixed(0)}%` : ''}
            </div>
          ))}
        </div>
      )}
      <ul className="space-y-2" aria-label="Allocation legend">
        {data.map((d) => (
          <li key={d.key} className="flex items-center gap-3 text-[13px]">
            <span className="size-2.5 shrink-0 rounded-[3px]" style={{ background: d.color }} aria-hidden />
            <span className="min-w-0 flex-1 truncate text-foreground">{d.label}</span>
            <span className="tabular text-muted-foreground">{formatPct((d.value / total) * 100, 1, false)}</span>
            {!hideValues && <span className="w-24 text-right tabular text-foreground">{formatUsd(d.value)}</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}
