import { ArrowDownLeft, ArrowUpRight, ExternalLink, Gift, ShieldCheck } from 'lucide-react';
import { formatUsd, getAsset, relativeTime, shortAddress } from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { explorerTx } from '@/config/chains';
import { cn } from '@/lib/utils';
import type { ActivityItem } from '@/store/app';

export function activityTitle(a: ActivityItem): string {
  const asset = a.assetId ? getAsset(a.assetId) : undefined;
  switch (a.kind) {
    case 'buy':
      return `Bought ${a.tokens ?? ''} ${asset?.symbol ?? 'tokens'}`.replace(/\s+/g, ' ');
    case 'sell':
      return `${a.mode === 'onchain' ? 'Redeemed' : 'Sold'} ${a.tokens ?? ''} ${asset?.symbol ?? 'tokens'}`.replace(/\s+/g, ' ');
    case 'claim':
      return 'Claimed vUSD demo credits';
    case 'kyc':
      return a.note?.startsWith('Officer') ? a.note : 'Verification recorded';
    case 'reset':
      return 'Demo reset';
  }
}

export function activityAmount(a: ActivityItem): string {
  if (a.amount === undefined) return '';
  return a.mode === 'onchain' ? `${a.amount.toLocaleString('en-US')} vUSD` : formatUsd(a.amount);
}

const ICON = { buy: ArrowDownLeft, sell: ArrowUpRight, claim: Gift, kyc: ShieldCheck, reset: Gift } as const;

export function ModeBadge({ mode }: { mode: ActivityItem['mode'] }) {
  return mode === 'onchain' ? <Badge variant="blue">Testnet</Badge> : <Badge variant="outline" className="border-dashed">Simulated</Badge>;
}

export function StatusText({ status }: { status: ActivityItem['status'] }) {
  return (
    <span className={cn('text-xs', status === 'confirmed' && 'text-success', status === 'pending' && 'text-warning', status === 'failed' && 'text-danger')}>
      {status === 'confirmed' ? 'Confirmed' : status === 'pending' ? 'Pending' : 'Failed'}
    </span>
  );
}

export function ActivityList({ items, compact = false, empty, onSelect }: { items: ActivityItem[]; compact?: boolean; empty: string; onSelect?: (a: ActivityItem) => void }) {
  if (items.length === 0) return <p className="py-4 text-[13px] text-muted-foreground">{empty}</p>;
  return (
    <ul className="divide-y divide-border">
      {items.map((a) => {
        const Icon = ICON[a.kind];
        const link = a.hash ? explorerTx(a.hash, a.chainId) : null;
        const inner = (
          <>
            <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
              <Icon className="size-4" aria-hidden />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm text-foreground">{activityTitle(a)}</span>
              <span className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
                <ModeBadge mode={a.mode} />
                {relativeTime(a.createdAt)}
                {!compact && <span className="font-mono">{a.hash ? shortAddress(a.hash, 6) : a.id}</span>}
              </span>
            </span>
            <span className="flex flex-col items-end gap-0.5">
              <span className="text-sm tabular text-foreground">{activityAmount(a)}</span>
              <StatusText status={a.status} />
            </span>
          </>
        );
        return (
          <li key={a.id}>
            {onSelect ? (
              <button type="button" onClick={() => onSelect(a)} className="flex w-full items-center gap-3 rounded-md px-2 py-3 text-left transition-colors hover:bg-muted/60">
                {inner}
              </button>
            ) : (
              <div className="flex w-full items-center gap-3 py-3">
                {inner}
                {link && (
                  <a href={link} target="_blank" rel="noreferrer" className="rounded p-1 text-muted-foreground hover:text-foreground" aria-label="View on block explorer">
                    <ExternalLink className="size-3.5" />
                  </a>
                )}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
