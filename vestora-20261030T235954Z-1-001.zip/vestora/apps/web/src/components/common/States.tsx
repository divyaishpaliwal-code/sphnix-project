import type { ReactNode } from 'react';
import { AlertTriangle, Info, ShieldAlert, type LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

export function EmptyState({ icon: Icon = Info, title, description, action, className }: { icon?: LucideIcon; title: string; description?: ReactNode; action?: ReactNode; className?: string }) {
  return (
    <div className={cn('flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border px-6 py-10 text-center', className)}>
      <span className="flex size-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
        <Icon className="size-5" aria-hidden />
      </span>
      <div className="max-w-sm space-y-1">
        <p className="text-sm font-medium text-foreground">{title}</p>
        {description && <p className="text-[13px] leading-relaxed text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function ErrorState({ title = 'Something went wrong', description, action, className }: { title?: string; description?: ReactNode; action?: ReactNode; className?: string }) {
  return (
    <div role="alert" className={cn('flex items-start gap-3 rounded-lg border border-danger/30 bg-danger-soft px-4 py-3', className)}>
      <AlertTriangle className="mt-0.5 size-4 shrink-0 text-danger" aria-hidden />
      <div className="min-w-0 flex-1 space-y-1">
        <p className="text-sm font-medium text-foreground">{title}</p>
        {description && <p className="text-[13px] text-muted-foreground">{description}</p>}
        {action && <div className="pt-1">{action}</div>}
      </div>
    </div>
  );
}

/** Calm, always-visible disclaimer used where the brief requires one. */
export function Disclaimer({ children, className, tone = 'info', icon }: { children: ReactNode; className?: string; tone?: 'info' | 'gold' | 'warning'; icon?: LucideIcon }) {
  const Icon = icon ?? (tone === 'warning' ? ShieldAlert : Info);
  return (
    <div
      className={cn(
        'flex items-start gap-2.5 rounded-lg border px-3.5 py-3 text-[13px] leading-relaxed',
        tone === 'info' && 'border-border bg-muted text-muted-foreground',
        tone === 'gold' && 'border-gold/25 bg-gold-soft text-foreground/90',
        tone === 'warning' && 'border-warning/30 bg-warning-soft text-foreground/90',
        className,
      )}
    >
      <Icon className={cn('mt-0.5 size-4 shrink-0', tone === 'gold' ? 'text-gold' : tone === 'warning' ? 'text-warning' : 'text-muted-foreground')} aria-hidden />
      <div className="min-w-0">{children}</div>
    </div>
  );
}

export function PageHeader({ title, description, actions, className }: { title: string; description?: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <div className={cn('flex flex-col gap-4 md:flex-row md:items-end md:justify-between', className)}>
      <div className="min-w-0 space-y-1.5">
        <h1 className="font-display text-[26px] font-bold leading-tight tracking-[-0.025em] text-foreground md:text-[30px]">{title}</h1>
        {description && <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function SectionTitle({ title, description, actions, className, as: As = 'h2' }: { title: string; description?: ReactNode; actions?: ReactNode; className?: string; as?: 'h2' | 'h3' }) {
  return (
    <div className={cn('flex flex-wrap items-end justify-between gap-3', className)}>
      <div className="min-w-0 space-y-1">
        <As className="font-display text-base font-semibold tracking-[-0.015em] text-foreground">{title}</As>
        {description && <p className="text-[13px] text-muted-foreground">{description}</p>}
      </div>
      {actions}
    </div>
  );
}

export function StatTile({
  label,
  value,
  sub,
  delta,
  className,
  loading,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  delta?: ReactNode;
  className?: string;
  loading?: boolean;
}) {
  return (
    <div className={cn('flex min-w-0 flex-col gap-1.5 rounded-xl border border-border bg-card px-5 py-4', className)}>
      <span className="text-[13px] text-muted-foreground">{label}</span>
      {loading ? (
        <span className="skeleton h-7 w-32" />
      ) : (
        <span className="truncate font-display text-[26px] font-semibold leading-tight tracking-[-0.02em] text-foreground">{value}</span>
      )}
      {(delta || sub) && (
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
          {delta}
          {sub}
        </div>
      )}
    </div>
  );
}
