import { cn } from '@/lib/utils';

/** The VESTORA mark: a whole divided into fractions, with one fraction held. */
export function LogoMark({ className }: { className?: string }) {
  const cells = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  return (
    <svg viewBox="0 0 18 18" className={cn('size-6', className)} aria-hidden>
      {cells.map((i) => {
        const x = (i % 3) * 6.3;
        const y = Math.floor(i / 3) * 6.3;
        return <rect key={i} x={x} y={y} width="5.4" height="5.4" rx="1.3" fill={i === 4 ? 'var(--gold)' : 'currentColor'} opacity={i === 4 ? 1 : 0.28} />;
      })}
    </svg>
  );
}

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5 text-foreground', className)}>
      <LogoMark />
      {!compact && <span className="font-display text-[17px] font-extrabold tracking-[0.18em]">VESTORA</span>}
    </span>
  );
}
