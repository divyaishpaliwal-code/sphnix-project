import { useEffect, useState } from 'react';
import { BadgeCheck, Clock, Fingerprint, ScanFace, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { KYC_DISCLAIMER } from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Checkbox, Progress } from '@/components/ui/primitives';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Disclaimer } from '@/components/common/States';
import { cn, simulationId, uid } from '@/lib/utils';
import { useAppStore, type KycStatus } from '@/store/app';

const COUNTRIES = [
  'Australia', 'Brazil', 'Canada', 'France', 'Germany', 'India', 'Indonesia', 'Ireland', 'Italy', 'Japan', 'Kenya', 'Malaysia', 'Mexico', 'Netherlands',
  'New Zealand', 'Nigeria', 'Philippines', 'Singapore', 'South Africa', 'South Korea', 'Spain', 'Sweden', 'Switzerland', 'United Arab Emirates', 'United Kingdom',
  'United States', 'Other',
];

const STEPS = ['Your details', 'Country', 'Identity check', 'Risk acknowledgement', 'Result'] as const;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const NAME_RE = /^[\p{L}][\p{L}\s.'-]{1,79}$/u;

type Outcome = 'approve' | 'reject' | 'pending';

const CHECKS = ['Checking document format (simulated)', 'Comparing selfie to document (simulated)', 'Screening against watchlists (simulated)'];

export function KycWizard({ onFinished, compact = false }: { onFinished?: (status: KycStatus) => void; compact?: boolean }) {
  const kyc = useAppStore((s) => s.kyc);
  const setKyc = useAppStore((s) => s.setKyc);
  const resetKyc = useAppStore((s) => s.resetKyc);
  const recordActivity = useAppStore((s) => s.recordActivity);
  const notify = useAppStore((s) => s.notify);
  const done = kyc.status === 'verified' || kyc.status === 'rejected' || kyc.status === 'pending';
  const [step, setStep] = useState(done ? 4 : 0);
  const [name, setName] = useState(kyc.fullName);
  const [email, setEmail] = useState(kyc.email);
  const [country, setCountry] = useState(kyc.country);
  const [touched, setTouched] = useState(false);
  const [outcome, setOutcome] = useState<Outcome>('approve');
  const [checking, setChecking] = useState(false);
  const [progress, setProgress] = useState(0);
  const [checked, setChecked] = useState(false);
  const [acks, setAcks] = useState([false, false, false, false]);

  const nameOk = NAME_RE.test(name.trim());
  const emailOk = EMAIL_RE.test(email.trim());

  useEffect(() => {
    if (!checking) return;
    const t = window.setInterval(() => setProgress((p) => Math.min(100, p + 4)), 70);
    return () => window.clearInterval(t);
  }, [checking]);
  useEffect(() => {
    if (checking && progress >= 100) {
      setChecking(false);
      setChecked(true);
    }
  }, [checking, progress]);

  const finish = (status: KycStatus, reason: string | null) => {
    const now = new Date().toISOString();
    setKyc({
      status,
      fullName: name.trim(),
      email: email.trim(),
      country,
      caseId: kyc.caseId ?? uid('case_'),
      submittedAt: kyc.submittedAt ?? now,
      decidedAt: status === 'pending' ? null : now,
      reason,
    });
    recordActivity({ id: simulationId(), kind: 'kyc', mode: 'simulated', status: 'confirmed', createdAt: now, note: `Simulated KYC: ${status}` });
    notify({
      title: status === 'verified' ? 'Verification approved (simulated)' : status === 'rejected' ? 'Verification rejected (simulated)' : 'Verification pending (simulated)',
      body: reason ?? undefined,
      tone: status === 'verified' ? 'success' : status === 'rejected' ? 'error' : 'warning',
      href: '/verify',
    });
    setStep(4);
    onFinished?.(status);
  };

  const submit = () => {
    if (outcome === 'approve') finish('verified', null);
    else if (outcome === 'reject') finish('rejected', 'Simulated rejection: the reviewer could not match the details provided. You can try again.');
    else finish('pending', 'Your simulated application is waiting for a reviewer.');
    toast(outcome === 'approve' ? 'Simulated KYC approved' : outcome === 'reject' ? 'Simulated KYC rejected' : 'Simulated KYC pending');
  };

  const canNext = [nameOk && emailOk, Boolean(country), checked, acks.every(Boolean)][step] ?? false;

  return (
    <div className={cn('space-y-6', compact && 'space-y-5')}>
      <Disclaimer tone="warning" icon={Fingerprint}>
        <span className="font-medium text-foreground">{KYC_DISCLAIMER}</span> Do not enter real identity numbers. Nothing you type leaves this browser.
      </Disclaimer>

      <ol className="grid grid-cols-5 gap-1.5" aria-label="Verification steps">
        {STEPS.map((s, i) => (
          <li key={s} className="space-y-1.5">
            <div className={cn('h-1 rounded-full', i <= step ? 'bg-gold' : 'bg-muted')} />
            <span className={cn('hidden text-[11px] sm:block', i === step ? 'text-foreground' : 'text-muted-foreground')}>{s}</span>
          </li>
        ))}
      </ol>

      {step === 0 && (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="kyc-name">Full name</Label>
            <Input id="kyc-name" value={name} onChange={(e) => setName(e.target.value)} onBlur={() => setTouched(true)} autoComplete="name" placeholder="Alex Morgan" aria-invalid={(touched && !nameOk) || undefined} />
            {touched && !nameOk && <FieldHint error>Enter your name using letters (2–80 characters).</FieldHint>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="kyc-email">Email</Label>
            <Input id="kyc-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} onBlur={() => setTouched(true)} autoComplete="email" placeholder="alex@example.com" aria-invalid={(touched && !emailOk) || undefined} />
            {touched && !emailOk ? <FieldHint error>Enter a valid email address.</FieldHint> : <FieldHint>Used only to label your simulated profile. Any address works.</FieldHint>}
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="space-y-2">
          <Label htmlFor="kyc-country">Country of residence</Label>
          <Select value={country} onValueChange={setCountry}>
            <SelectTrigger id="kyc-country" aria-label="Country of residence">
              <SelectValue placeholder="Select a country" />
            </SelectTrigger>
            <SelectContent>
              {COUNTRIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FieldHint>Real platforms check eligibility by jurisdiction. Here the choice has no effect on the outcome.</FieldHint>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <div className="flex items-start gap-3 rounded-lg border border-border p-4">
            <ScanFace className="mt-0.5 size-5 shrink-0 text-gold" aria-hidden />
            <p className="text-sm leading-relaxed text-muted-foreground">
              A regulated platform would now ask a licensed provider to check an identity document and a selfie. VESTORA collects nothing — this step only shows what
              happens.
            </p>
          </div>
          {checking || checked ? (
            <div className="space-y-3" aria-live="polite">
              <Progress value={progress} />
              <ul className="space-y-1.5 text-[13px]">
                {CHECKS.map((c, i) => {
                  const ok = progress >= ((i + 1) / CHECKS.length) * 100 - 1;
                  return (
                    <li key={c} className={cn('flex items-center gap-2', ok ? 'text-foreground' : 'text-muted-foreground')}>
                      {ok ? <BadgeCheck className="size-4 text-success" aria-hidden /> : <Clock className="size-4" aria-hidden />} {c}
                    </li>
                  );
                })}
              </ul>
            </div>
          ) : (
            <Button variant="blue" onClick={() => (setProgress(0), setChecking(true))}>
              Run simulated check
            </Button>
          )}
          <div className="space-y-2 rounded-lg bg-muted px-4 py-3">
            <Label htmlFor="kyc-outcome" className="text-xs text-muted-foreground">
              Prototype control: simulated outcome
            </Label>
            <Select value={outcome} onValueChange={(v: string) => setOutcome(v as Outcome)}>
              <SelectTrigger id="kyc-outcome" className="bg-card">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="approve">Approve (Verified)</SelectItem>
                <SelectItem value="pending">Leave pending for review</SelectItem>
                <SelectItem value="reject">Reject</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {step === 3 && (
        <fieldset className="space-y-3">
          <legend className="mb-2 text-sm font-medium">Please confirm you understand:</legend>
          {[
            'I am 18 or older.',
            'VESTORA is an educational prototype: balances are simulated or testnet tokens with no monetary value.',
            'Sample tokens do not represent legal ownership of, or any claim on, a real commodity, property or bond.',
            'Prices can fall as well as rise, and past performance does not predict future results.',
          ].map((t, i) => (
            <label key={t} className="flex cursor-pointer items-start gap-3 rounded-lg border border-border p-3 text-[13px] leading-relaxed hover:border-border-strong">
              <Checkbox checked={acks[i]} onCheckedChange={(v: boolean | 'indeterminate') => setAcks((a) => a.map((x, j) => (j === i ? v === true : x)))} className="mt-0.5" />
              {t}
            </label>
          ))}
        </fieldset>
      )}

      {step === 4 && (
        <div className="space-y-4" aria-live="polite">
          {kyc.status === 'verified' && (
            <div className="flex items-start gap-3 rounded-lg border border-success/30 bg-success-soft p-4">
              <BadgeCheck className="mt-0.5 size-5 shrink-0 text-success" aria-hidden />
              <div>
                <p className="font-medium">Verified (simulated)</p>
                <p className="text-[13px] text-muted-foreground">You can now make simulated investments. To use the testnet contracts, record verification on-chain from the Wallet page.</p>
              </div>
            </div>
          )}
          {kyc.status === 'pending' && (
            <div className="space-y-3 rounded-lg border border-warning/30 bg-warning-soft p-4">
              <div className="flex items-start gap-3">
                <Clock className="mt-0.5 size-5 shrink-0 text-warning" aria-hidden />
                <div>
                  <p className="font-medium">Pending (simulated)</p>
                  <p className="text-[13px] text-muted-foreground">{kyc.reason}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" onClick={() => finish('verified', null)}>
                  Simulate reviewer approval
                </Button>
                <Button size="sm" variant="outline" onClick={() => finish('rejected', 'Simulated rejection by the reviewer.')}>
                  Simulate rejection
                </Button>
              </div>
            </div>
          )}
          {kyc.status === 'rejected' && (
            <div className="flex items-start gap-3 rounded-lg border border-danger/30 bg-danger-soft p-4">
              <XCircle className="mt-0.5 size-5 shrink-0 text-danger" aria-hidden />
              <div>
                <p className="font-medium">Rejected (simulated)</p>
                <p className="text-[13px] text-muted-foreground">{kyc.reason}</p>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              resetKyc();
              setStep(0);
              setChecked(false);
              setProgress(0);
              setAcks([false, false, false, false]);
            }}
          >
            Start over
          </Button>
        </div>
      )}

      {step < 4 && (
        <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
          <Button variant="ghost" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
          {step < 3 ? (
            <Button
              disabled={!canNext}
              onClick={() => {
                setTouched(true);
                if (canNext) setStep((s) => s + 1);
              }}
            >
              Continue
            </Button>
          ) : (
            <Button disabled={!canNext} onClick={submit}>
              Submit simulated verification
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
