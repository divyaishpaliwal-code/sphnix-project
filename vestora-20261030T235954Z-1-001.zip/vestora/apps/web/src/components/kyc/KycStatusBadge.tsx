import { BadgeCheck, CircleDashed, Clock, XCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { KycStatus } from '@/store/app';

const MAP: Record<KycStatus, { label: string; variant: 'neutral' | 'warning' | 'success' | 'danger'; icon: typeof Clock }> = {
  not_started: { label: 'Not started', variant: 'neutral', icon: CircleDashed },
  pending: { label: 'Pending', variant: 'warning', icon: Clock },
  verified: { label: 'Verified (simulated)', variant: 'success', icon: BadgeCheck },
  rejected: { label: 'Rejected (simulated)', variant: 'danger', icon: XCircle },
};

export function kycLabel(status: KycStatus): string {
  return MAP[status].label;
}

export function KycStatusBadge({ status, className }: { status: KycStatus; className?: string }) {
  const m = MAP[status];
  const Icon = m.icon;
  return (
    <Badge variant={m.variant} className={className}>
      <Icon aria-hidden /> KYC: {m.label}
    </Badge>
  );
}
