import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router';
import {
  CALCULATOR_DISCLAIMER,
  bondPrice,
  calculateOwnership,
  formatNumber,
  formatPct,
  formatUsd,
  yearsBetween,
  type AssetValuation,
  type TokenisedAsset,
} from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Disclaimer } from '@/components/common/States';
import { cn } from '@/lib/utils';

const PRESETS = [10, 50, 100, 500, 1000];

export function OwnershipCalculator({
  asset,
  valuation,
  available,
  amount,
  onAmountChange,
}: {
  asset: TokenisedAsset;
  valuation: AssetValuation;
  available: number;
  amount: string;
  onAmountChange: (v: string) => void;
}) {
  const navigate = useNavigate();
  const n = Number(amount);
  const calc = useMemo(
    () => calculateOwnership({ amount: n, tokenPrice: valuation.tokenPrice ?? NaN, totalSupply: asset.totalSupply, available, minInvestment: asset.minInvestment }),
    [n, valuation.tokenPrice, asset, available],
  );
  const invalid = amount !== '' && !calc.valid;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ownership calculator</CardTitle>
        <CardDescription>
          {valuation.sampleValue !== null && valuation.tokenPrice !== null
            ? `Sample asset value ${formatUsd(valuation.sampleValue, 0)} ÷ ${asset.totalSupply.toLocaleString('en-US')} tokens = ${formatUsd(valuation.tokenPrice)} per token (illustrative).`
            : 'The token price is unavailable right now.'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor={`calc-${asset.id}`}>Simulated investment (USD)</Label>
          <div className="relative">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-subtle">$</span>
            <Input
              id={`calc-${asset.id}`}
              inputMode="decimal"
              type="number"
              min={0}
              step="any"
              value={amount}
              onChange={(e) => onAmountChange(e.target.value)}
              className="pl-7 tabular"
              aria-invalid={invalid || undefined}
              aria-describedby={`calc-hint-${asset.id}`}
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => onAmountChange(String(p))}
                className={cn('rounded-md border border-border px-2.5 py-1 text-xs tabular text-muted-foreground transition-colors hover:text-foreground', Number(amount) === p && 'border-gold/40 bg-gold-soft text-foreground')}
              >
                ${p.toLocaleString('en-US')}
              </button>
            ))}
          </div>
          <FieldHint id={`calc-hint-${asset.id}`} error={invalid}>
            {invalid ? calc.error : `Minimum ${formatUsd(Math.max(asset.minInvestment, valuation.tokenPrice ?? 0))}. Whole tokens only; any remainder stays as cash.`}
          </FieldHint>
        </div>

        <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-border bg-border text-sm">
          {[
            ['Tokens', calc.valid ? calc.tokens.toLocaleString('en-US') : '—'],
            ['Cost', calc.valid ? formatUsd(calc.cost) : '—'],
            ['Share of supply', calc.valid ? `${formatNumber(calc.ownershipPct, calc.ownershipPct < 0.01 ? 4 : 3)}%` : '—'],
            ['Unspent cash', calc.valid ? formatUsd(calc.leftover) : '—'],
          ].map(([k, v]) => (
            <div key={k} className="bg-card px-3.5 py-3">
              <dt className="text-xs text-muted-foreground">{k}</dt>
              <dd className="mt-0.5 font-medium tabular">{v}</dd>
            </div>
          ))}
        </dl>
        <Disclaimer className="text-xs">{CALCULATOR_DISCLAIMER}</Disclaimer>
        <Button className="w-full" disabled={!calc.valid} onClick={() => navigate(`/invest/${asset.id}?amount=${encodeURIComponent(String(n))}`)}>
          Simulate this investment
        </Button>
      </CardContent>
    </Card>
  );
}

/** "What if" scenario: how an illustrative holding responds to a move in its input. */
export function ScenarioSimulator({ asset, valuation, tokens }: { asset: TokenisedAsset; valuation: AssetValuation; tokens: number }) {
  const isBond = asset.pricing.kind === 'bond';
  const [move, setMove] = useState(isBond ? 100 : -15);
  const min = isBond ? -200 : -50;
  const max = isBond ? 200 : 50;
  const step = isBond ? 25 : 5;

  const result = useMemo(() => {
    const p = valuation.tokenPrice;
    if (p === null || tokens <= 0) return null;
    let next: number;
    if (asset.pricing.kind === 'bond' && valuation.bond) {
      const b = asset.pricing;
      const years = Math.max(0, yearsBetween(new Date(), new Date(b.maturity)));
      const y0 = (valuation.bond.yieldPct + b.spreadBps / 100) / 100;
      const price = bondPrice(b.couponRate, y0 + move / 10_000, years, b.paymentsPerYear);
      next = (b.faceValue * price) / 100 / asset.totalSupply;
    } else {
      next = p * (1 + move / 100);
    }
    const before = tokens * p;
    const after = tokens * next;
    return { next, before, after, diff: after - before, pct: ((after - before) / before) * 100 };
  }, [valuation, tokens, move, asset]);

  const label = isBond ? `Yields ${move >= 0 ? 'rise' : 'fall'} by ${Math.abs(move)} bp` : asset.pricing.kind === 'fixed' ? `Valuation ${move >= 0 ? 'rises' : 'falls'} ${Math.abs(move)}%` : `Reference price ${move >= 0 ? 'rises' : 'falls'} ${Math.abs(move)}%`;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Scenario simulator</CardTitle>
        <CardDescription>
          {isBond ? 'See how the sample note’s price reacts when yields move — the price–yield relationship in action.' : 'Stress-test the holding from the calculator. Scenarios are not forecasts.'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <label htmlFor={`scn-${asset.id}`} className="text-foreground">
              {label}
            </label>
          </div>
          <input
            id={`scn-${asset.id}`}
            type="range"
            min={min}
            max={max}
            step={step}
            value={move}
            onChange={(e) => setMove(Number(e.target.value))}
            className="w-full accent-[var(--gold)]"
            aria-valuetext={label}
          />
          <div className="flex justify-between text-[11px] tabular text-subtle">
            <span>{isBond ? `${min} bp` : `${min}%`}</span>
            <span>0</span>
            <span>{isBond ? `+${max} bp` : `+${max}%`}</span>
          </div>
        </div>
        {result ? (
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Holding ({tokens.toLocaleString('en-US')} tokens) today</dt>
              <dd className="tabular">{formatUsd(result.before)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Token price in scenario</dt>
              <dd className="tabular">{formatUsd(result.next, result.next < 1 ? 4 : 2)}</dd>
            </div>
            <div className="flex justify-between border-t border-border pt-2 font-medium">
              <dt>Illustrative change</dt>
              <dd className={cn('tabular', result.diff >= 0 ? 'text-success' : 'text-danger')}>
                {result.diff >= 0 ? '+' : '−'}
                {formatUsd(Math.abs(result.diff))} ({formatPct(result.pct)})
              </dd>
            </div>
          </dl>
        ) : (
          <p className="text-[13px] text-muted-foreground">Enter an amount in the calculator to run a scenario.</p>
        )}
        {isBond && valuation.bond && (
          <p className="text-xs leading-relaxed text-muted-foreground">
            Modified duration ≈ {valuation.bond.modifiedDuration.toFixed(1)}: a 1 percentage-point (100 bp) rise in yields moves the price by roughly −
            {valuation.bond.modifiedDuration.toFixed(1)}%.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
