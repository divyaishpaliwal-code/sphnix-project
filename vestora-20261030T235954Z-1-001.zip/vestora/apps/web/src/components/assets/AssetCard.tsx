import { Link, useNavigate } from 'react-router';
import { Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { CATEGORY_LABELS, formatQuote, formatUsd, getInstrument, unitLabel, type TokenisedAsset } from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/primitives';
import { DataStatusBadge, IllustrativeBadge } from '@/components/market/DataStatus';
import { PriceChange } from '@/components/market/PriceChange';
import { Sparkline } from '@/components/market/Sparkline';
import { plainLanguage, useAssetInsights } from '@/hooks/useAsset';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/store/app';
import { AssetIcon, RiskBadge, SupplyBar, WatchButton } from './AssetBits';

export function useSampleSupply(asset: TokenisedAsset) {
  const held = useAppStore((s) => s.demo.holdings[asset.id]?.tokens ?? 0);
  const issued = Math.min(asset.totalSupply, asset.sampleIssued + held);
  return { issued, available: asset.totalSupply - issued, held };
}

export function AssetCard({ asset, className }: { asset: TokenisedAsset; className?: string }) {
  const navigate = useNavigate();
  const { valuation, quote, tokenSeries, risk, historyLoading } = useAssetInsights(asset);
  const supply = useSampleSupply(asset);
  const comparing = useAppStore((s) => s.compare.includes(asset.id));
  const toggleCompare = useAppStore((s) => s.toggleCompare);
  const ref = valuation.referenceInstrumentId ? getInstrument(valuation.referenceInstrumentId) : undefined;
  const isBond = asset.pricing.kind === 'bond';

  return (
    <article className={cn('group relative flex flex-col rounded-xl border border-border bg-card transition-colors hover:border-border-strong', className)}>
      <header className="flex items-start gap-3 px-5 pt-5">
        <AssetIcon asset={asset} />
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-display text-[15px] font-semibold tracking-[-0.01em]">
            <Link to={`/assets/${asset.id}`} className="hover:underline focus-visible:outline-2 focus-visible:outline-ring">
              {asset.name}
            </Link>
          </h3>
          <p className="text-xs text-muted-foreground">
            {asset.symbol} · {CATEGORY_LABELS[asset.category]}
            {asset.kind === 'simulated' && ' · Simulated asset'}
          </p>
        </div>
        <WatchButton id={asset.id} label={asset.name} className="-mr-2 -mt-1" />
      </header>

      <div className="flex items-end justify-between gap-3 px-5 pt-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-display text-2xl font-semibold tracking-[-0.02em] tabular">{formatUsd(valuation.tokenPrice)}</span>
            <IllustrativeBadge />
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground">Token price · 1 token of {asset.totalSupply.toLocaleString('en-US')}</p>
        </div>
        <Sparkline points={tokenSeries} width={104} height={34} label={`${asset.name} one-year illustrative token price trend`} className={historyLoading ? 'opacity-40' : undefined} />
      </div>

      {/* Market reference — kept visually separate from the illustrative token price. */}
      <div className="mx-5 mt-4 rounded-lg bg-muted/70 px-3 py-2.5">
        {asset.pricing.kind === 'fixed' ? (
          <div className="flex items-center justify-between gap-2 text-xs">
            <span className="text-muted-foreground">Valuation</span>
            <span className="text-foreground">Fixed — simulated asset</span>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="truncate text-muted-foreground">{isBond ? `Reference yield · ${ref?.shortName ?? ''}` : `Market reference · ${ref?.symbol ?? ''}`}</span>
              {quote && <DataStatusBadge status={valuation.inputStatus === 'fixed' ? 'historical' : valuation.inputStatus} frequency={quote.frequency} />}
            </div>
            <div className="mt-1 flex items-baseline justify-between gap-2">
              <span className="text-sm font-medium tabular text-foreground">
                {ref ? formatQuote(valuation.referencePrice, ref.denomination, ref.decimals) : '—'}
                {ref && ref.denomination !== 'percent' && <span className="ml-1 text-xs font-normal text-subtle">{unitLabel(ref)}</span>}
              </span>
              <span className="flex items-center gap-2">
                {quote?.change !== null && quote?.change !== undefined && ref && ref.denomination !== 'percent' && (
                  <span className="text-xs tabular text-muted-foreground">
                    {quote.change > 0 ? '+' : quote.change < 0 ? '−' : ''}
                    {formatQuote(Math.abs(quote.change), ref.denomination, ref.decimals)}
                  </span>
                )}
                <PriceChange pct={quote?.changePct} basis={quote?.changeBasis} showBasis />
              </span>
            </div>
          </>
        )}
      </div>

      <dl className="grid grid-cols-2 gap-x-4 gap-y-3 px-5 pt-4 text-xs">
        <div>
          <dt className="text-muted-foreground">Minimum (simulated)</dt>
          <dd className="mt-0.5 font-medium tabular text-foreground">{formatUsd(Math.max(asset.minInvestment, valuation.tokenPrice ?? 0))}</dd>
        </div>
        <div>
          <dt className="text-muted-foreground">Risk</dt>
          <dd className="mt-0.5">
            <RiskBadge risk={risk} />
          </dd>
        </div>
      </dl>
      <SupplyBar issued={supply.issued} total={asset.totalSupply} className="px-5 pt-3" label="Sample supply" />

      <p className="mx-5 mt-4 flex gap-2 border-t border-border pt-3 text-[13px] leading-relaxed text-muted-foreground">
        <Sparkles className="mt-0.5 size-3.5 shrink-0 text-gold" aria-hidden />
        <span className="line-clamp-3">{plainLanguage(asset)}</span>
      </p>

      <footer className="mt-auto flex flex-wrap items-center gap-2 px-5 pb-5 pt-4">
        <label className="mr-auto flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
          <Checkbox
            checked={comparing}
            onCheckedChange={() => {
              const r = toggleCompare(asset.id);
              if (r.full) toast('You can compare up to three assets at a time.');
            }}
            aria-label={`Compare ${asset.name}`}
          />
          Compare
        </label>
        <Button variant="outline" size="sm" asChild>
          <Link to={`/assets/${asset.id}`}>View details</Link>
        </Button>
        <Button size="sm" className="max-sm:flex-1" onClick={() => navigate(`/invest/${asset.id}`)}>
          Simulate investment
        </Button>
      </footer>
    </article>
  );
}
