import { useMemo } from 'react';
import { Link } from 'react-router';
import { useQueries } from '@tanstack/react-query';
import { GitCompareArrows, X } from 'lucide-react';
import {
  CATEGORY_LABELS,
  assessRisk,
  assetReferenceInstrument,
  formatPct,
  formatQuote,
  formatUsd,
  getAsset,
  getInstrument,
  seriesStats,
  tokenPriceSeries,
  valueAsset,
  type TokenisedAsset,
} from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ComparisonChart } from '@/components/charts/ComparisonChart';
import { DataStatusBadge } from '@/components/market/DataStatus';
import { useAllQuotes } from '@/hooks/useMarket';
import { COMPARE_SLOTS, slotColor } from '@/lib/chart-colors';
import { fetchHistory } from '@/services/market';
import { useAppStore } from '@/store/app';
import { useUi } from '@/store/ui';
import { AssetIcon, RiskBadge } from './AssetBits';

export function CompareTray() {
  const compare = useAppStore((s) => s.compare);
  const toggle = useAppStore((s) => s.toggleCompare);
  const clear = useAppStore((s) => s.clearCompare);
  const setOpen = useUi((s) => s.setCompareOpen);
  if (compare.length === 0) return null;
  const assets = compare.map((id) => getAsset(id)).filter((a): a is TokenisedAsset => Boolean(a));
  return (
    <div className="glass fixed inset-x-3 bottom-[76px] z-30 mx-auto flex max-w-2xl flex-wrap items-center gap-2 rounded-xl border border-border-strong px-3 py-2.5 shadow-float lg:bottom-6 lg:left-[272px]">
      <GitCompareArrows className="size-4 text-muted-foreground" aria-hidden />
      <ul className="flex min-w-0 flex-1 flex-wrap gap-1.5" aria-label="Assets selected for comparison">
        {assets.map((a) => (
          <li key={a.id} className="flex items-center gap-1 rounded-md bg-muted py-1 pl-2 pr-1 text-xs">
            {a.symbol}
            <button onClick={() => toggle(a.id)} className="rounded p-0.5 text-muted-foreground hover:text-foreground" aria-label={`Remove ${a.name} from comparison`}>
              <X className="size-3" />
            </button>
          </li>
        ))}
      </ul>
      <Button variant="ghost" size="sm" onClick={clear}>
        Clear
      </Button>
      <Button size="sm" disabled={assets.length < 2} onClick={() => setOpen(true)}>
        Compare {assets.length}
      </Button>
    </div>
  );
}

export function CompareDialog() {
  const open = useUi((s) => s.compareOpen);
  const setOpen = useUi((s) => s.setCompareOpen);
  const compare = useAppStore((s) => s.compare);
  const { quotes } = useAllQuotes();
  const assets = useMemo(() => compare.map((id) => getAsset(id)).filter((a): a is TokenisedAsset => Boolean(a)), [compare]);
  const histories = useQueries({
    queries: assets.map((a) => {
      const ref = assetReferenceInstrument(a);
      return { queryKey: ['history', ref, '1Y'], queryFn: () => fetchHistory(ref as string, '1Y'), enabled: open && Boolean(ref), staleTime: 10 * 60_000 };
    }),
  });

  const rows = assets.map((a, i) => {
    const v = valueAsset(a, quotes);
    const hist = histories[i]?.data;
    const series = hist ? tokenPriceSeries(a, hist.points) : [];
    const stats = series.length >= 2 ? seriesStats(series) : null;
    const risk = assessRisk(a.risk, stats ? { volatility: stats.volatility, maxDrawdown: stats.maxDrawdown, observations: stats.observations, window: 'the past year' } : {});
    const ref = v.referenceInstrumentId ? getInstrument(v.referenceInstrumentId) : undefined;
    return { a, v, series, stats, risk, ref, color: slotColor(COMPARE_SLOTS[i]) };
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Compare sample assets</DialogTitle>
          <DialogDescription>Side-by-side figures use the same methodology for every asset. Token prices are illustrative; reference prices come from the named data sources.</DialogDescription>
        </DialogHeader>
        <div className="scrollbar-thin overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="w-40 py-2 text-left text-xs font-medium text-muted-foreground">Attribute</th>
                {rows.map((r) => (
                  <th key={r.a.id} className="py-2 pl-4 text-left">
                    <Link to={`/assets/${r.a.id}`} onClick={() => setOpen(false)} className="flex items-center gap-2 font-medium hover:underline">
                      <span className="h-0.5 w-3 rounded-full" style={{ background: r.color }} aria-hidden />
                      <AssetIcon asset={r.a} size="sm" />
                      {r.a.symbol}
                    </Link>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="[&_td]:py-2.5 [&_td]:pl-4 [&_td:first-child]:pl-0 [&_tr]:border-b [&_tr]:border-border">
              <tr>
                <td className="text-muted-foreground">Category</td>
                {rows.map((r) => (
                  <td key={r.a.id}>{CATEGORY_LABELS[r.a.category]}</td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Token price</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {formatUsd(r.v.tokenPrice)} <span className="text-xs text-subtle">illustrative</span>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Reference</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {r.ref ? (
                      <span className="flex flex-wrap items-center gap-1.5">
                        {formatQuote(r.v.referencePrice, r.ref.denomination, r.ref.decimals)}
                        {r.v.inputStatus !== 'fixed' && <DataStatusBadge status={r.v.inputStatus} withTooltip={false} />}
                      </span>
                    ) : (
                      'Fixed valuation'
                    )}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Latest change</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {r.v.changePct === null ? '—' : formatPct(r.v.changePct)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">1Y token change</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {r.stats?.changePct == null ? '—' : formatPct(r.stats.changePct)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Volatility (1Y)</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {r.risk.factors[0].basis === 'measured' && r.stats?.volatility != null ? `${(r.stats.volatility * 100).toFixed(1)}% measured` : `~${(r.a.risk.typicalVolatility * 100).toFixed(0)}% curated`}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Risk</td>
                {rows.map((r) => (
                  <td key={r.a.id}>
                    <RiskBadge risk={r.risk} />
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Minimum</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {formatUsd(Math.max(r.a.minInvestment, r.v.tokenPrice ?? 0))}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="text-muted-foreground">Token supply</td>
                {rows.map((r) => (
                  <td key={r.a.id} className="tabular">
                    {r.a.totalSupply.toLocaleString('en-US')}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
        <div className="space-y-2">
          <p className="text-sm font-medium">Illustrative token price, indexed to 100 one year ago</p>
          <ComparisonChart
            range="1Y"
            height={240}
            loading={histories.some((h) => h.isLoading)}
            series={rows.map((r) => ({ key: r.a.id, label: r.a.symbol, color: r.color, points: r.series }))}
          />
          <p className="text-xs text-muted-foreground">Fixed-valuation (simulated) assets have no market history and are excluded from the chart rather than drawn as invented lines.</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
