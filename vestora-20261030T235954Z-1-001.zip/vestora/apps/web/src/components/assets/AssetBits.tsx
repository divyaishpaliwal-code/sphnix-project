import {
  Bitcoin,
  Briefcase,
  Cable,
  Coffee,
  Diamond,
  Droplet,
  Factory,
  Flame,
  Gem,
  Hexagon,
  Home,
  Landmark,
  Star,
  Warehouse,
  Wheat,
  type LucideIcon,
} from 'lucide-react';
import { toast } from 'sonner';
import { RISK_FACTORS, type RiskAssessment, type RiskLevel, type TokenisedAsset } from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Tooltip } from '@/components/ui/primitives';
import { categoryColor, RISK_COLOR } from '@/lib/chart-colors';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/store/app';

const ICONS: Record<TokenisedAsset['icon'], LucideIcon> = {
  gold: Gem,
  silver: Gem,
  platinum: Hexagon,
  oil: Droplet,
  flame: Flame,
  copper: Cable,
  factory: Factory,
  coffee: Coffee,
  wheat: Wheat,
  landmark: Landmark,
  briefcase: Briefcase,
  home: Home,
  warehouse: Warehouse,
  bitcoin: Bitcoin,
  ethereum: Diamond,
};

export function AssetIcon({ asset, size = 'md', className }: { asset: TokenisedAsset; size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const Icon = ICONS[asset.icon];
  const c = categoryColor(asset.category);
  return (
    <span
      className={cn('flex shrink-0 items-center justify-center rounded-lg', size === 'sm' && 'size-8', size === 'md' && 'size-10', size === 'lg' && 'size-12', className)}
      style={{ background: `color-mix(in oklab, ${c} 16%, transparent)`, color: c }}
      aria-hidden
    >
      <Icon className={size === 'lg' ? 'size-6' : size === 'md' ? 'size-5' : 'size-4'} />
    </span>
  );
}

const LEVEL_INDEX: Record<RiskLevel, number> = { Low: 1, Moderate: 2, Elevated: 3, High: 4, 'Very high': 5 };
const RAMP = ['var(--risk-1)', 'var(--risk-2)', 'var(--risk-3)', 'var(--risk-4)', 'var(--risk-5)'];

export function RiskMeter({ level, className }: { level: RiskLevel; className?: string }) {
  const n = LEVEL_INDEX[level];
  return (
    <span className={cn('inline-flex items-end gap-[3px]', className)} aria-hidden>
      {RAMP.map((color, i) => (
        <span key={i} className="w-[5px] rounded-[2px]" style={{ height: 6 + i * 2, background: i < n ? color : 'var(--border-strong)' }} />
      ))}
    </span>
  );
}

export function RiskBadge({ risk, className, showScore = true }: { risk: RiskAssessment; className?: string; showScore?: boolean }) {
  return (
    <Tooltip content={`Educational risk score ${risk.score.toFixed(1)}/10. ${risk.methodology.split('. ')[0]}.`}>
      <span tabIndex={0} className={cn('inline-flex items-center gap-2 rounded-md text-xs text-foreground', className)} aria-label={`Risk: ${risk.level}, ${risk.score.toFixed(1)} out of 10`}>
        <RiskMeter level={risk.level} />
        <span className="font-medium">{risk.level}</span>
        {showScore && <span className="tabular text-muted-foreground">{risk.score.toFixed(1)}</span>}
      </span>
    </Tooltip>
  );
}

/** Factor-by-factor breakdown — the methodology made visible. */
export function RiskBreakdown({ risk }: { risk: RiskAssessment }) {
  return (
    <div className="space-y-3.5">
      {risk.factors.map((f) => {
        const def = RISK_FACTORS.find((x) => x.key === f.key);
        return (
          <div key={f.key} className="space-y-1.5">
            <div className="flex items-baseline justify-between gap-3 text-[13px]">
              <span className="text-foreground">
                {f.label} <span className="text-subtle">· {Math.round(f.weight * 100)}%</span>
              </span>
              <span className="tabular text-muted-foreground">
                {f.score.toFixed(1)}/10 <span className="text-subtle">({f.basis})</span>
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-muted" role="meter" aria-valuemin={1} aria-valuemax={10} aria-valuenow={f.score} aria-label={f.label}>
              <div className="h-full rounded-full" style={{ width: `${(f.score / 10) * 100}%`, background: RISK_COLOR[levelFor(f.score)] }} />
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">{f.note}</p>
            {def && <p className="sr-only">{def.description}</p>}
          </div>
        );
      })}
    </div>
  );
}

function levelFor(score: number): RiskLevel {
  if (score < 3) return 'Low';
  if (score < 4.5) return 'Moderate';
  if (score < 6) return 'Elevated';
  if (score < 7.5) return 'High';
  return 'Very high';
}

export function WatchButton({ id, label, className }: { id: string; label: string; className?: string }) {
  const watched = useAppStore((s) => s.watchlist.includes(id));
  const toggle = useAppStore((s) => s.toggleWatch);
  return (
    <Button
      variant="ghost"
      size="icon-sm"
      className={cn(watched && 'text-gold hover:text-gold', className)}
      aria-pressed={watched}
      aria-label={watched ? `Remove ${label} from watchlist` : `Add ${label} to watchlist`}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        const added = toggle(id);
        toast(added ? `${label} added to your watchlist` : `${label} removed from your watchlist`);
      }}
    >
      <Star className={cn(watched && 'fill-current')} />
    </Button>
  );
}

export function SupplyBar({ issued, total, className, label = 'Sample supply issued' }: { issued: number; total: number; className?: string; label?: string }) {
  const pct = total > 0 ? Math.min(100, (issued / total) * 100) : 0;
  return (
    <div className={cn('space-y-1.5', className)}>
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{label}</span>
        <span className="tabular">
          {(total - issued).toLocaleString('en-US')} of {total.toLocaleString('en-US')} available
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(pct)} aria-label={label}>
        <div className="h-full rounded-full bg-gold/80" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
