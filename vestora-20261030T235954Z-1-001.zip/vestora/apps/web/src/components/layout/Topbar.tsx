import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Bell, BellRing, CheckCheck, Copy, ExternalLink, LogOut, Menu, Monitor, Moon, RotateCcw, Search, Settings, ShieldCheck, Sun, Trash2, UserRound, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { nyseSession, relativeTime, shortAddress } from '@vestora/shared';
import { Logo } from '@/components/common/Logo';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  Popover,
  PopoverContent,
  PopoverTrigger,
  Segmented,
} from '@/components/ui/primitives';
import { Sheet, SheetContent } from '@/components/ui/dialog';
import { KycStatusBadge } from '@/components/kyc/KycStatusBadge';
import { TARGET_CHAIN, chainName, explorerAddress } from '@/config/chains';
import { useHealth } from '@/hooks/useMarket';
import { copyText, cn } from '@/lib/utils';
import { useAppStore, type ThemePref } from '@/store/app';
import { useUi } from '@/store/ui';
import { useWallet } from '@/wallet/WalletProvider';
import { EnvironmentCard, NavList } from './Sidebar';

function MarketStatusPill() {
  const session = useMemo(() => nyseSession(), []);
  const apiOnline = useUi((s) => s.apiOnline);
  const { data: health } = useHealth();
  const live = health?.providers.filter((p) => p.configured).length ?? 0;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="hidden items-center gap-2 rounded-md border border-border px-2.5 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring md:inline-flex">
          <span className={cn('size-1.5 rounded-full', session.state === 'open' ? 'bg-success' : 'bg-subtle')} aria-hidden />
          NYSE {session.label}
          <span className="text-subtle">|</span>
          Crypto 24/7
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 space-y-3 text-sm">
        <div>
          <p className="font-medium">Market status</p>
          <p className="text-xs text-muted-foreground">Approximate sessions; holidays and early closes are included for 2026–27.</p>
        </div>
        <dl className="space-y-2 text-[13px]">
          <div className="flex justify-between gap-3">
            <dt className="text-muted-foreground">US equities (NYSE)</dt>
            <dd>
              {session.label} · {session.localTime}
            </dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-muted-foreground">Crypto-assets</dt>
            <dd>Open 24/7</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-muted-foreground">Data connection</dt>
            <dd>{apiOnline === false ? 'Browser fallback' : health ? `API · ${live} provider${live === 1 ? '' : 's'}` : 'Checking…'}</dd>
          </div>
        </dl>
        <p className="text-xs text-muted-foreground">{session.detail}</p>
      </PopoverContent>
    </Popover>
  );
}

function NotificationsBell() {
  const notifications = useAppStore((s) => s.notifications);
  const markAllRead = useAppStore((s) => s.markAllRead);
  const clear = useAppStore((s) => s.clearNotifications);
  const unread = notifications.filter((n) => !n.read).length;
  return (
    <Popover onOpenChange={(open: boolean) => { if (!open && unread) markAllRead(); }}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" aria-label={unread ? `Notifications, ${unread} unread` : 'Notifications'} className="relative">
          {unread ? <BellRing /> : <Bell />}
          {unread > 0 && <span className="absolute right-2 top-2 size-2 rounded-full bg-gold ring-2 ring-background" aria-hidden />}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[min(92vw,380px)] p-0">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="text-sm font-medium">Notifications</p>
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" onClick={markAllRead} disabled={!unread}>
              <CheckCheck /> Mark read
            </Button>
            <Button variant="ghost" size="icon-sm" onClick={clear} aria-label="Clear notifications" disabled={!notifications.length}>
              <Trash2 />
            </Button>
          </div>
        </div>
        {notifications.length === 0 ? (
          <p className="px-4 py-8 text-center text-[13px] text-muted-foreground">No notifications yet. Price alerts, verification updates and transactions appear here.</p>
        ) : (
          <ul className="scrollbar-thin max-h-96 divide-y divide-border overflow-y-auto">
            {notifications.map((n) => (
              <li key={n.id} className="flex gap-3 px-4 py-3">
                <span
                  className={cn(
                    'mt-1.5 size-1.5 shrink-0 rounded-full',
                    n.tone === 'success' && 'bg-success',
                    n.tone === 'warning' && 'bg-warning',
                    n.tone === 'error' && 'bg-danger',
                    n.tone === 'info' && 'bg-blue',
                  )}
                  aria-hidden
                />
                <div className="min-w-0 flex-1">
                  <p className={cn('text-[13px]', n.read ? 'text-muted-foreground' : 'font-medium text-foreground')}>
                    {n.href ? (
                      <Link to={n.href} className="hover:underline">
                        {n.title}
                      </Link>
                    ) : (
                      n.title
                    )}
                  </p>
                  {n.body && <p className="text-xs text-muted-foreground">{n.body}</p>}
                  <p className="mt-0.5 text-[11px] text-subtle">{relativeTime(n.createdAt)}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </PopoverContent>
    </Popover>
  );
}

export function WalletButton({ className }: { className?: string }) {
  const w = useWallet();
  const navigate = useNavigate();
  if (w.status !== 'connected' || !w.address) {
    return (
      <Button
        variant="outline"
        size="sm"
        className={className}
        loading={w.status === 'connecting'}
        onClick={() => (w.status === 'unavailable' ? navigate('/wallet') : w.connect())}
      >
        <Wallet /> <span className="hidden sm:inline">{w.status === 'unavailable' ? 'Wallet & demo' : 'Connect wallet'}</span>
      </Button>
    );
  }
  const link = explorerAddress(w.address);
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className={cn('gap-2 font-mono text-xs', className)}>
          <span className={cn('size-1.5 rounded-full', w.isCorrectChain ? 'bg-success' : 'bg-warning')} aria-hidden />
          {shortAddress(w.address)}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64">
        <DropdownMenuLabel>
          {w.walletName ?? 'Wallet'} on {chainName(w.chainId)}
          {!w.isCorrectChain && <span className="mt-1 block text-warning">VESTORA uses {TARGET_CHAIN.name}</span>}
        </DropdownMenuLabel>
        {!w.isCorrectChain && (
          <DropdownMenuItem onSelect={() => void w.switchToTarget()}>
            <RotateCcw /> Switch to {TARGET_CHAIN.name}
          </DropdownMenuItem>
        )}
        <DropdownMenuItem
          onSelect={async () => {
            toast((await copyText(w.address!)) ? 'Address copied' : 'Could not copy the address');
          }}
        >
          <Copy /> Copy address
        </DropdownMenuItem>
        {link && (
          <DropdownMenuItem asChild>
            <a href={link} target="_blank" rel="noreferrer">
              <ExternalLink /> View on explorer
            </a>
          </DropdownMenuItem>
        )}
        <DropdownMenuItem onSelect={() => navigate('/wallet')}>
          <Wallet /> Open wallet
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={() => void w.disconnect()}>
          <LogOut /> Disconnect
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function ProfileMenu() {
  const navigate = useNavigate();
  const profile = useAppStore((s) => s.profile);
  const kyc = useAppStore((s) => s.kyc);
  const theme = useAppStore((s) => s.settings.theme);
  const setSettings = useAppStore((s) => s.setSettings);
  const resetDemo = useAppStore((s) => s.resetDemo);
  const [confirmReset, setConfirmReset] = useState(false);
  const name = profile.displayName || kyc.fullName || 'Guest investor';
  const initials = name
    .split(/\s+/)
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex size-9 items-center justify-center rounded-full bg-gold-soft text-xs font-semibold text-gold focus-visible:outline-2 focus-visible:outline-ring" aria-label="Profile menu">
            {initials || <UserRound className="size-4" />}
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-64">
          <DropdownMenuLabel className="space-y-1.5">
            <span className="block text-sm font-medium text-foreground">{name}</span>
            <KycStatusBadge status={kyc.status} />
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <div className="px-2.5 py-2">
            <p className="mb-1.5 text-xs text-muted-foreground">Theme</p>
            <Segmented<ThemePref>
              label="Theme"
              value={theme}
              onChange={(v) => setSettings({ theme: v })}
              options={[
                { value: 'dark', label: <Moon className="size-3.5" aria-label="Dark" /> },
                { value: 'light', label: <Sun className="size-3.5" aria-label="Light" /> },
                { value: 'system', label: <Monitor className="size-3.5" aria-label="System" /> },
              ]}
            />
          </div>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={() => navigate('/verify')}>
            <ShieldCheck /> Verification (simulated KYC)
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => navigate('/settings')}>
            <Settings /> Profile & settings
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => setConfirmReset(true)}>
            <RotateCcw /> Reset demo data
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <ResetDemoDialog open={confirmReset} onOpenChange={setConfirmReset} onConfirm={() => resetDemo()} />
    </>
  );
}

export function ResetDemoDialog({ open, onOpenChange, onConfirm }: { open: boolean; onOpenChange: (v: boolean) => void; onConfirm: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reset demo data?</DialogTitle>
          <DialogDescription>
            This clears your simulated holdings, simulated activity, alerts, notifications and simulated KYC, and restores $10,000 of simulated cash. Testnet records on the
            blockchain are not affected.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Keep data
          </Button>
          <Button
            variant="destructive"
            onClick={() => {
              onConfirm();
              onOpenChange(false);
              toast.success('Demo data reset');
            }}
          >
            Reset demo data
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function Topbar() {
  const setPaletteOpen = useUi((s) => s.setPaletteOpen);
  const mobileNavOpen = useUi((s) => s.mobileNavOpen);
  const setMobileNavOpen = useUi((s) => s.setMobileNavOpen);
  const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);
  return (
    <header className="glass sticky top-0 z-20 border-b border-border">
      <div className="mx-auto flex h-16 max-w-[1360px] items-center gap-2 px-4 sm:px-6 lg:px-8">
        <Button variant="ghost" size="icon" className="-ml-2 lg:hidden" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation">
          <Menu />
        </Button>
        <Link to="/" className="mr-2 lg:hidden" aria-label="VESTORA home">
          <Logo compact />
        </Link>
        <button
          onClick={() => setPaletteOpen(true)}
          className="flex h-9 min-w-0 flex-1 items-center gap-2 rounded-md border border-border bg-surface/60 px-3 text-left text-[13px] text-subtle transition-colors hover:border-border-strong focus-visible:outline-2 focus-visible:outline-ring sm:max-w-sm"
          aria-label="Search assets, markets and pages"
        >
          <Search className="size-4 shrink-0" aria-hidden />
          <span className="truncate">Search assets, markets, pages</span>
          <kbd className="ml-auto hidden rounded border border-border px-1.5 py-0.5 font-sans text-[11px] text-muted-foreground sm:inline">{isMac ? '⌘' : 'Ctrl'} K</kbd>
        </button>
        <div className="ml-auto flex items-center gap-1.5">
          <MarketStatusPill />
          <NotificationsBell />
          <WalletButton />
          <ProfileMenu />
        </div>
      </div>
      <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
        <SheetContent side="left" className="w-[84vw] max-w-xs" aria-describedby={undefined}>
          <DialogTitle className="sr-only">Main navigation</DialogTitle>
          <div className="flex h-16 items-center px-5">
            <Logo />
          </div>
          <div className="scrollbar-thin flex-1 overflow-y-auto px-3">
            <NavList onNavigate={() => setMobileNavOpen(false)} />
          </div>
          <div className="p-3">
            <EnvironmentCard />
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}
