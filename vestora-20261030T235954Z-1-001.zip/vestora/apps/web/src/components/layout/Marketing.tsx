import { Link, NavLink } from 'react-router';
import { Menu } from 'lucide-react';
import { useState } from 'react';
import { PLATFORM_DISCLAIMER } from '@vestora/shared';
import { Logo } from '@/components/common/Logo';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

const LINKS = [
  { to: '/marketplace', label: 'Marketplace' },
  { to: '/markets', label: 'Markets' },
  { to: '/intelligence', label: 'Intelligence' },
  { to: '/learn', label: 'Learn' },
];

export function MarketingHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="glass sticky top-0 z-30 border-b border-border">
      <div className="mx-auto flex h-16 max-w-[1240px] items-center gap-6 px-4 sm:px-6">
        <Link to="/" aria-label="VESTORA home" className="rounded-md focus-visible:outline-2 focus-visible:outline-ring">
          <Logo />
        </Link>
        <nav aria-label="Site" className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) => cn('rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground', isActive && 'text-foreground')}>
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild className="hidden sm:inline-flex">
            <Link to="/verify">Get verified</Link>
          </Button>
          <Button size="sm" asChild>
            <Link to="/overview">Launch app</Link>
          </Button>
          <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu" onClick={() => setOpen(true)}>
            <Menu />
          </Button>
        </div>
      </div>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="max-w-xs p-6" aria-describedby={undefined}>
          <DialogTitle className="sr-only">Menu</DialogTitle>
          <nav aria-label="Site" className="mt-8 flex flex-col gap-1">
            {[...LINKS, { to: '/overview', label: 'Launch app' }].map((l) => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="rounded-md px-3 py-2.5 text-[15px] text-foreground hover:bg-muted">
                {l.label}
              </Link>
            ))}
          </nav>
        </SheetContent>
      </Sheet>
    </header>
  );
}

export function SiteFooter() {
  const cols = [
    {
      title: 'Product',
      links: [
        { to: '/marketplace', label: 'Marketplace' },
        { to: '/markets', label: 'Markets' },
        { to: '/portfolio', label: 'Portfolio' },
        { to: '/wallet', label: 'Wallet' },
        { to: '/intelligence', label: 'VESTORA Intelligence' },
      ],
    },
    {
      title: 'Learn',
      links: [
        { to: '/learn/fractional-ownership', label: 'Fractional ownership' },
        { to: '/learn/risk-score', label: 'Risk methodology' },
        { to: '/learn/data-sources', label: 'Data sources and labels' },
        { to: '/learn/tokenised-real-estate', label: 'Tokenised real estate' },
      ],
    },
    {
      title: 'Prototype',
      links: [
        { to: '/verify', label: 'Simulated KYC' },
        { to: '/transactions', label: 'Transaction explorer' },
        { to: '/settings', label: 'Settings and data' },
      ],
    },
  ];
  return (
    <footer className="border-t border-border bg-surface/40">
      <div className="mx-auto grid max-w-[1240px] gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_repeat(3,1fr)]">
        <div className="space-y-4">
          <Logo />
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">Own a fraction. Build a fortune. A prototype for learning how tokenised, fractional investing works — with simulated money.</p>
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <h2 className="mb-3 text-sm font-semibold text-foreground">{c.title}</h2>
            <ul className="space-y-2">
              {c.links.map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-border">
        <div className="mx-auto max-w-[1240px] space-y-2 px-4 py-6 text-xs leading-relaxed text-subtle sm:px-6">
          <p>{PLATFORM_DISCLAIMER}</p>
          <p>
            Market data: CoinGecko, FRED (Federal Reserve Bank of St. Louis), and optional providers configured by the operator (GoldAPI, Metals.Dev, Twelve Data, Alpha
            Vantage, Trading Economics). Each figure shows its source, status and timestamp.
          </p>
          <p>© {new Date().getFullYear()} VESTORA — educational prototype. Not a licensed financial service.</p>
        </div>
      </div>
    </footer>
  );
}
