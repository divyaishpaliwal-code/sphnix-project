import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Monitor, Moon, RotateCcw, ShieldCheck, Sparkles, Sun, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { INSTRUMENTS, TOKENISED_ASSETS, CATEGORY_LABELS, INSTRUMENT_CLASS_LABELS } from '@vestora/shared';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { AssetIcon } from '@/components/assets/AssetBits';
import { useAppStore } from '@/store/app';
import { useUi } from '@/store/ui';
import { useWallet } from '@/wallet/WalletProvider';
import { NAV_ITEMS } from './nav';

export function CommandPalette() {
  const open = useUi((s) => s.paletteOpen);
  const setOpen = useUi((s) => s.setPaletteOpen);
  const navigate = useNavigate();
  const setSettings = useAppStore((s) => s.setSettings);
  const wallet = useWallet();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen(!useUi.getState().paletteOpen);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setOpen]);

  const go = (to: string) => {
    setOpen(false);
    navigate(to);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-xl gap-0 overflow-hidden p-0" hideClose aria-describedby={undefined}>
        <DialogTitle className="sr-only">Search VESTORA</DialogTitle>
        <Command loop>
          <CommandInput placeholder="Search assets, markets, pages or actions…" autoFocus />
          <CommandList>
            <CommandEmpty>No results. Try “gold”, “bonds” or “wallet”.</CommandEmpty>
            <CommandGroup heading="Sample assets">
              {TOKENISED_ASSETS.map((a) => (
                <CommandItem key={a.id} value={`${a.name} ${a.symbol} ${CATEGORY_LABELS[a.category]}`} onSelect={() => go(`/assets/${a.id}`)}>
                  <AssetIcon asset={a} size="sm" />
                  <span className="flex-1">{a.name}</span>
                  <span className="text-xs text-muted-foreground">{a.symbol}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandGroup heading="Markets">
              {INSTRUMENTS.map((i) => (
                <CommandItem key={i.id} value={`${i.name} ${i.symbol} ${i.keywords.join(' ')} market`} onSelect={() => go(`/markets?focus=${i.id}`)}>
                  <span className="flex-1">{i.name}</span>
                  <span className="text-xs text-muted-foreground">{INSTRUMENT_CLASS_LABELS[i.class]}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandGroup heading="Pages">
              {NAV_ITEMS.map((n) => (
                <CommandItem key={n.to} value={`${n.label} ${n.description}`} onSelect={() => go(n.to)}>
                  <n.icon />
                  <span className="flex-1">{n.label}</span>
                  <span className="hidden text-xs text-muted-foreground sm:inline">{n.description}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandGroup heading="Actions">
              <CommandItem value="simulate invest buy" onSelect={() => go('/invest')}>
                <Sparkles /> Start a simulated investment
              </CommandItem>
              <CommandItem value="kyc verification identity" onSelect={() => go('/verify')}>
                <ShieldCheck /> Complete simulated KYC
              </CommandItem>
              <CommandItem
                value="connect wallet metamask"
                onSelect={() => {
                  setOpen(false);
                  if (wallet.status === 'unavailable') navigate('/wallet');
                  else void wallet.connect();
                }}
              >
                <Wallet /> Connect MetaMask
              </CommandItem>
              <CommandItem value="ask ai intelligence question" onSelect={() => go('/intelligence')}>
                <Sparkles /> Ask VESTORA Intelligence
              </CommandItem>
              <CommandItem value="theme dark" onSelect={() => (setSettings({ theme: 'dark' }), setOpen(false))}>
                <Moon /> Dark theme
              </CommandItem>
              <CommandItem value="theme light" onSelect={() => (setSettings({ theme: 'light' }), setOpen(false))}>
                <Sun /> Light theme
              </CommandItem>
              <CommandItem value="theme system" onSelect={() => (setSettings({ theme: 'system' }), setOpen(false))}>
                <Monitor /> Match system theme
              </CommandItem>
              <CommandItem
                value="reset demo data"
                onSelect={() => {
                  setOpen(false);
                  navigate('/settings#data');
                  toast('Reset demo data from Settings → Data & privacy.');
                }}
              >
                <RotateCcw /> Reset demo data
              </CommandItem>
            </CommandGroup>
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
