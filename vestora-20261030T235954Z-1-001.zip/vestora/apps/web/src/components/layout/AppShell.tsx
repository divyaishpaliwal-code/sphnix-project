import { Suspense, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router';
import { Skeleton } from '@/components/ui/primitives';
import { CompareDialog, CompareTray } from '@/components/assets/Compare';
import { CommandPalette } from './CommandPalette';
import { MobileTabBar } from './MobileTabBar';
import { Sidebar } from './Sidebar';
import { Topbar } from './Topbar';
import { AlertsWatcher, ApiStatusWatcher, SyncManager } from './Watchers';

export function PageSkeleton() {
  return (
    <div className="space-y-6" role="status" aria-label="Loading page">
      <Skeleton className="h-8 w-64" />
      <Skeleton className="h-4 w-96 max-w-full" />
      <div className="grid gap-4 md:grid-cols-3">
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
      </div>
      <Skeleton className="h-72" />
    </div>
  );
}

export function AppShell() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);
  return (
    <div className="min-h-dvh bg-background">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-card focus:px-3 focus:py-2">
        Skip to content
      </a>
      <Sidebar className="hidden lg:flex" />
      <div className="lg:pl-[248px]">
        <Topbar />
        <main id="main" className="mx-auto w-full max-w-[1360px] px-4 pb-32 pt-6 sm:px-6 lg:px-8 lg:pb-16 lg:pt-8">
          <Suspense fallback={<PageSkeleton />}>
            <Outlet />
          </Suspense>
        </main>
      </div>
      <MobileTabBar />
      <CompareTray />
      <CompareDialog />
      <CommandPalette />
      <ApiStatusWatcher />
      <AlertsWatcher />
      <SyncManager />
    </div>
  );
}
