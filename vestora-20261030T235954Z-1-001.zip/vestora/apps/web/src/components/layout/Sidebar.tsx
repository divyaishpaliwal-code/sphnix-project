import { Link, NavLink } from 'react-router';
import { formatUsd } from '@vestora/shared';
import { Logo } from '@/components/common/Logo';
import { TARGET_CHAIN } from '@/config/chains';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/store/app';
import { useUi } from '@/store/ui';
import { NAV_ITEMS } from './nav';

export function NavList({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav aria-label="Main" className="flex flex-col gap-0.5">
      {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn(
              'group relative flex items-center gap-3 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring',
              isActive && 'bg-muted text-foreground',
            )
          }
        >
          {({ isActive }) => (
            <>
              <span className={cn('absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-full bg-gold transition-opacity', isActive ? 'opacity-100' : 'opacity-0')} aria-hidden />
              <Icon className={cn('size-[18px]', isActive ? 'text-gold' : 'text-subtle group-hover:text-muted-foreground')} aria-hidden />
              {label}
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
}

export function EnvironmentCard() {
  const cash = useAppStore((s) => s.demo.cash);
  const hide = useAppStore((s) => s.settings.hideBalances);
  const apiOnline = useUi((s) => s.apiOnline);
  return (
    <div className="space-y-2.5 rounded-lg border border-border bg-surface px-3.5 py-3 text-xs">
      <div className="flex items-center justify-between">
        <span className="text-muted-foreground">Mode</span>
        <span className="font-medium text-foreground">Testnet prototype</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-muted-foreground">Network</span>
        <span className="text-foreground">{TARGET_CHAIN.name}</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-muted-foreground">Market data</span>
        <span className="flex items-center gap-1.5 text-foreground">
          <span className={cn('size-1.5 rounded-full', apiOnline === false ? 'bg-warning' : apiOnline ? 'bg-success' : 'bg-subtle')} aria-hidden />
          {apiOnline === false ? 'Browser fallback' : apiOnline ? 'API connected' : 'Checking…'}
        </span>
      </div>
      <div className="flex items-center justify-between border-t border-border pt-2.5">
        <span className="text-muted-foreground">Simulated cash</span>
        <span className="font-medium tabular text-foreground">{hide ? '•••••' : formatUsd(cash)}</span>
      </div>
    </div>
  );
}

export function Sidebar({ className }: { className?: string }) {
  return (
    <aside className={cn('fixed inset-y-0 left-0 z-30 w-[248px] flex-col border-r border-border bg-surface/60', className)}>
      <div className="flex h-16 items-center px-5">
        <Link to="/" className="rounded-md focus-visible:outline-2 focus-visible:outline-ring" aria-label="VESTORA home">
          <Logo />
        </Link>
      </div>
      <div className="scrollbar-thin flex flex-1 flex-col gap-6 overflow-y-auto px-3 pb-4 pt-2">
        <NavList />
      </div>
      <div className="p-3">
        <EnvironmentCard />
      </div>
    </aside>
  );
}
