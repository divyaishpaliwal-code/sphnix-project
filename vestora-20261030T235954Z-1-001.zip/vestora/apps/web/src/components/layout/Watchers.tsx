import { useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { getAsset, getInstrument, formatQuote, formatUsd } from '@vestora/shared';
import { useAllQuotes, useValuations } from '@/hooks/useMarket';
import { onApiStatus } from '@/services/api';
import { pullProfile, pushProfile } from '@/services/sync';
import { useAppStore } from '@/store/app';
import { useUi } from '@/store/ui';

/** Keeps the "API connected / browser fallback" indicator current. */
export function ApiStatusWatcher() {
  const setApiOnline = useUi((s) => s.setApiOnline);
  const { mode } = useAllQuotes();
  useEffect(() => onApiStatus(setApiOnline), [setApiOnline]);
  useEffect(() => {
    if (mode) setApiOnline(mode === 'server');
  }, [mode, setApiOnline]);
  return null;
}

/**
 * Demo price alerts. They only trigger on live, delayed or historical data —
 * never on static demo values.
 */
export function AlertsWatcher() {
  const { quotes, valuations } = useValuations();
  const alerts = useAppStore((s) => s.alerts);
  const triggerAlert = useAppStore((s) => s.triggerAlert);
  const notify = useAppStore((s) => s.notify);
  useEffect(() => {
    for (const a of alerts) {
      if (!a.active) continue;
      let price: number | null = null;
      let label = '';
      let text = '';
      if (a.target.kind === 'instrument') {
        const q = quotes[a.target.id];
        const inst = getInstrument(a.target.id);
        if (!q || !inst || q.price === null || q.status === 'demo' || q.status === 'unavailable') continue;
        price = q.price;
        label = inst.name;
        text = formatQuote(price, inst.denomination, inst.decimals);
      } else {
        const v = valuations[a.target.id];
        const asset = getAsset(a.target.id);
        if (!v || !asset || v.tokenPrice === null || v.inputStatus === 'demo' || v.inputStatus === 'unavailable') continue;
        price = v.tokenPrice;
        label = `${asset.symbol} token`;
        text = formatUsd(price);
      }
      const hit = a.direction === 'above' ? price >= a.price : price <= a.price;
      if (hit) {
        triggerAlert(a.id, price);
        const title = `${label} is ${a.direction} your alert`;
        notify({ title, body: `Now ${text} (alert ${a.direction} ${a.target.kind === 'asset' ? formatUsd(a.price) : a.price.toLocaleString('en-US')}). Demo alert.`, tone: 'info', href: '/settings#alerts' });
        toast(title, { description: `Now ${text}` });
      }
    }
  }, [alerts, quotes, valuations, triggerAlert, notify]);
  return null;
}

/** Optional server sync of preferences, watchlist and simulated portfolio (Settings → Data & privacy). */
export function SyncManager() {
  const enabled = useAppStore((s) => s.settings.syncEnabled);
  const apiOnline = useUi((s) => s.apiOnline);
  const applyRemote = useAppStore((s) => s.applyRemote);
  const setLastSynced = useAppStore((s) => s.setLastSynced);
  const pulled = useRef(false);

  useEffect(() => {
    if (!enabled || !apiOnline || pulled.current) return;
    pulled.current = true;
    pullProfile()
      .then((remote) => {
        const last = useAppStore.getState().lastSyncedAt;
        if (remote && (!last || remote.updatedAt > last)) {
          applyRemote(remote);
          setLastSynced(remote.updatedAt);
          toast('Synced your VESTORA profile from the server');
        }
      })
      .catch(() => undefined);
  }, [enabled, apiOnline, applyRemote, setLastSynced]);

  useEffect(() => {
    if (!enabled || !apiOnline) return;
    let timer: number | undefined;
    const unsub = useAppStore.subscribe((s, prev) => {
      if (s.demo === prev.demo && s.watchlist === prev.watchlist && s.activity === prev.activity && s.alerts === prev.alerts && s.settings === prev.settings) return;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        pushProfile()
          .then((r) => setLastSynced(r.updatedAt))
          .catch(() => undefined);
      }, 2000);
    });
    return () => {
      unsub();
      window.clearTimeout(timer);
    };
  }, [enabled, apiOnline, setLastSynced]);
  return null;
}
