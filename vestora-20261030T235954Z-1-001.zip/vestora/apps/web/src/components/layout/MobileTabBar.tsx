import { NavLink } from 'react-router';
import { cn } from '@/lib/utils';
import { MOBILE_TABS, NAV_ITEMS } from './nav';

const SHORT: Record<string, string> = {
  '/overview': 'Overview',
  '/marketplace': 'Assets',
  '/markets': 'Markets',
  '/portfolio': 'Portfolio',
  '/intelligence': 'AI',
};

export function MobileTabBar() {
  const items = NAV_ITEMS.filter((n) => MOBILE_TABS.includes(n.to));
  return (
    <nav aria-label="Primary" className="glass fixed inset-x-0 bottom-0 z-30 border-t border-border pb-[env(safe-area-inset-bottom)] lg:hidden">
      <ul className="mx-auto grid max-w-lg grid-cols-5">
        {items.map(({ to, icon: Icon }) => (
          <li key={to}>
            <NavLink
              to={to}
              className={({ isActive }) =>
                cn('flex flex-col items-center gap-1 py-2.5 text-[11px] text-muted-foreground focus-visible:outline-2 focus-visible:outline-ring', isActive && 'text-foreground')
              }
            >
              {({ isActive }) => (
                <>
                  <Icon className={cn('size-5', isActive && 'text-gold')} aria-hidden />
                  {SHORT[to]}
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
