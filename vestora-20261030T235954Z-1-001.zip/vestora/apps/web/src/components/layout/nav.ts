import { BookOpen, CandlestickChart, LayoutDashboard, PieChart, Receipt, Settings, Sparkles, Store, Wallet, type LucideIcon } from 'lucide-react';

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  description: string;
}

export const NAV_ITEMS: NavItem[] = [
  { to: '/overview', label: 'Overview', icon: LayoutDashboard, description: 'Your markets and portfolio at a glance' },
  { to: '/marketplace', label: 'Marketplace', icon: Store, description: 'Browse tokenised sample assets' },
  { to: '/markets', label: 'Markets', icon: CandlestickChart, description: 'Live commodity, crypto and rates data' },
  { to: '/portfolio', label: 'My Portfolio', icon: PieChart, description: 'Holdings, allocation and performance' },
  { to: '/wallet', label: 'Wallet', icon: Wallet, description: 'MetaMask, testnet balances and demo mode' },
  { to: '/intelligence', label: 'AI Intelligence', icon: Sparkles, description: 'Plain-language explanations of risk' },
  { to: '/transactions', label: 'Transactions', icon: Receipt, description: 'Simulated and testnet activity' },
  { to: '/learn', label: 'Learn', icon: BookOpen, description: 'Guides on tokenisation and risk' },
  { to: '/settings', label: 'Settings', icon: Settings, description: 'Profile, theme, data sources and alerts' },
];

export const MOBILE_TABS = ['/overview', '/marketplace', '/markets', '/portfolio', '/intelligence'];
