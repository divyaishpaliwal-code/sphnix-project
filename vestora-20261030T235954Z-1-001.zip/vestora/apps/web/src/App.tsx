import { lazy, Suspense } from 'react';
import { BrowserRouter, HashRouter, Navigate, Route, Routes } from 'react-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TooltipProvider } from '@/components/ui/primitives';
import { Toaster } from '@/components/ui/toaster';
import { AppShell, PageSkeleton } from '@/components/layout/AppShell';
import { env } from '@/config/env';
import { useThemeSync } from '@/hooks/useTheme';
import { WalletProvider } from '@/wallet/WalletProvider';
import Landing from '@/pages/Landing';

const Overview = lazy(() => import('@/pages/Overview'));
const Marketplace = lazy(() => import('@/pages/Marketplace'));
const AssetDetail = lazy(() => import('@/pages/AssetDetail'));
const Markets = lazy(() => import('@/pages/Markets'));
const Portfolio = lazy(() => import('@/pages/Portfolio'));
const WalletPage = lazy(() => import('@/pages/Wallet'));
const Invest = lazy(() => import('@/pages/Invest'));
const Verify = lazy(() => import('@/pages/Verify'));
const Intelligence = lazy(() => import('@/pages/Intelligence'));
const Transactions = lazy(() => import('@/pages/Transactions'));
const Learn = lazy(() => import('@/pages/Learn'));
const Settings = lazy(() => import('@/pages/Settings'));
const NotFound = lazy(() => import('@/pages/NotFound'));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { refetchOnWindowFocus: false, retry: 1 },
  },
});

function ThemeSync() {
  useThemeSync();
  return null;
}

export default function App() {
  const Router = env.routerMode === 'hash' ? HashRouter : BrowserRouter;
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider delayDuration={200}>
        <WalletProvider>
          <ThemeSync />
          <Router>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route element={<AppShell />}>
                <Route path="/overview" element={<Overview />} />
                <Route path="/marketplace" element={<Marketplace />} />
                <Route path="/assets/:assetId" element={<AssetDetail />} />
                <Route path="/markets" element={<Markets />} />
                <Route path="/portfolio" element={<Portfolio />} />
                <Route path="/wallet" element={<WalletPage />} />
                <Route path="/invest" element={<Invest />} />
                <Route path="/invest/:assetId" element={<Invest />} />
                <Route path="/verify" element={<Verify />} />
                <Route path="/intelligence" element={<Intelligence />} />
                <Route path="/transactions" element={<Transactions />} />
                <Route path="/learn" element={<Learn />} />
                <Route path="/learn/:slug" element={<Learn />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/app" element={<Navigate to="/overview" replace />} />
                <Route
                  path="*"
                  element={
                    <Suspense fallback={<PageSkeleton />}>
                      <NotFound />
                    </Suspense>
                  }
                />
              </Route>
            </Routes>
          </Router>
          <Toaster />
        </WalletProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
