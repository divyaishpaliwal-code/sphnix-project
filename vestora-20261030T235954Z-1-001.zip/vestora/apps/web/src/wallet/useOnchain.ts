import { useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { JsonRpcProvider, formatEther, id as keccakText, type ContractTransactionResponse, type EventLog, type JsonRpcSigner, type Log, type Provider } from 'ethers';
import { toast } from 'sonner';
import { TOKENISED_ASSETS, getAssetByTokenId, shortAddress } from '@vestora/shared';
import { env } from '@/config/env';
import { TARGET_CHAIN, explorerTx } from '@/config/chains';
import { ONCHAIN_KYC_STATUS, type OnchainKycStatus } from '@/services/web3/abi';
import { assetTokenContract, complianceContract, contractConfig, describeTxError } from '@/services/web3/contracts';
import { useAppStore, type ActivityKind } from '@/store/app';
import { useWallet } from './WalletProvider';

export interface OnchainAssetInfo {
  tokenId: number;
  price: number;
  maxSupply: number;
  available: number;
  active: boolean;
}

export interface OnchainSnapshot {
  credits: number;
  claimed: boolean;
  kycStatus: OnchainKycStatus;
  verified: boolean;
  frozen: boolean;
  paused: boolean;
  isOfficer: boolean;
  native: string;
  balances: Record<number, number>;
  assets: Record<number, OnchainAssetInfo>;
  selfService: boolean;
}

export interface OnchainEvent {
  kind: 'buy' | 'sell' | 'claim' | 'kyc';
  hash: string;
  blockNumber: number;
  account: string;
  assetId?: string;
  tokens?: number;
  credits?: number;
  note?: string;
}

export interface TxResult {
  hash: string;
  ok: boolean;
  blockNumber: number | null;
}

/** Read-only provider for public data (event explorer) when no wallet is connected. */
export function readProvider(fallback?: Provider | null): Provider {
  return fallback ?? new JsonRpcProvider(env.rpcUrl ?? TARGET_CHAIN.rpcUrls[0], TARGET_CHAIN.id, { staticNetwork: true });
}

/** Query contract events in bounded block windows (public RPCs cap log ranges). */
export async function queryRecentEvents(provider: Provider, account?: string, maxWindows = 6): Promise<OnchainEvent[]> {
  const token = assetTokenContract(provider);
  const comp = complianceContract(provider);
  if (!token || !comp) return [];
  const latest = await provider.getBlockNumber();
  const cfg = contractConfig();
  const floor = Math.max(cfg.deployBlock ?? 0, latest - 9_000 * maxWindows);
  const filters = [
    { c: token, f: token.filters.AssetPurchased(account ?? null), kind: 'buy' as const },
    { c: token, f: token.filters.AssetRedeemed(account ?? null), kind: 'sell' as const },
    { c: token, f: token.filters.DemoCreditsClaimed(account ?? null), kind: 'claim' as const },
    { c: comp, f: comp.filters.StatusChanged(account ?? null), kind: 'kyc' as const },
  ];
  const out: OnchainEvent[] = [];
  for (let to = latest; to >= floor; to -= 9_000) {
    const from = Math.max(floor, to - 8_999);
    const batches = await Promise.all(filters.map((x) => x.c.queryFilter(x.f, from, to).then((logs: Array<EventLog | Log>) => ({ logs, kind: x.kind }))));
    for (const { logs, kind } of batches) {
      for (const log of logs as EventLog[]) {
        const a = log.args;
        if (!a) continue;
        if (kind === 'buy') out.push({ kind, hash: log.transactionHash, blockNumber: log.blockNumber, account: a[0], assetId: getAssetByTokenId(Number(a[1]))?.id, tokens: Number(a[2]), credits: Number(a[3]) });
        if (kind === 'sell') out.push({ kind, hash: log.transactionHash, blockNumber: log.blockNumber, account: a[0], assetId: getAssetByTokenId(Number(a[1]))?.id, tokens: Number(a[2]), credits: Number(a[3]) });
        if (kind === 'claim') out.push({ kind, hash: log.transactionHash, blockNumber: log.blockNumber, account: a[0], credits: Number(a[1]) });
        if (kind === 'kyc') out.push({ kind, hash: log.transactionHash, blockNumber: log.blockNumber, account: a[0], note: ONCHAIN_KYC_STATUS[Number(a[1])] ?? 'Updated' });
      }
    }
    if (from === floor) break;
  }
  return out.sort((x, y) => y.blockNumber - x.blockNumber);
}

export function useOnchain() {
  const wallet = useWallet();
  const qc = useQueryClient();
  const cfg = contractConfig();
  const recordActivity = useAppStore((s) => s.recordActivity);
  const updateActivity = useAppStore((s) => s.updateActivity);
  const notify = useAppStore((s) => s.notify);
  const ready = wallet.status === 'connected' && wallet.isCorrectChain && cfg.configured && Boolean(wallet.address);

  const snapshot = useQuery<OnchainSnapshot>({
    queryKey: ['onchain', wallet.address, wallet.chainId, cfg.assetToken],
    enabled: ready,
    refetchInterval: 30_000,
    queryFn: async () => {
      const provider = wallet.getBrowserProvider();
      if (!provider || !wallet.address) throw new Error('Wallet not connected');
      const token = assetTokenContract(provider)!;
      const comp = complianceContract(provider)!;
      const addr = wallet.address;
      const ids = TOKENISED_ASSETS.map((a) => BigInt(a.tokenId));
      const [credits, claimed, statusN, verified, frozen, paused, balances, native, officerRole, selfService] = await Promise.all([
        token.creditsOf(addr),
        token.hasClaimedCredits(addr),
        comp.statusOf(addr),
        comp.isVerified(addr),
        comp.frozen(addr),
        token.paused(),
        token.balanceOfBatch(
          ids.map(() => addr),
          ids,
        ),
        provider.getBalance(addr),
        comp.COMPLIANCE_OFFICER_ROLE(),
        comp.selfServiceApproval(),
      ]);
      const isOfficer = (await comp.hasRole(officerRole, addr)) as boolean;
      const assets: Record<number, OnchainAssetInfo> = {};
      await Promise.all(
        ids.map(async (tid) => {
          try {
            const [a, available] = await Promise.all([token.getAsset(tid), token.availableSupply(tid)]);
            assets[Number(tid)] = { tokenId: Number(tid), price: Number(a.price), maxSupply: Number(a.maxSupply), available: Number(available), active: Boolean(a.active) };
          } catch {
            /* asset not created on this deployment */
          }
        }),
      );
      const bal: Record<number, number> = {};
      ids.forEach((tid, i) => (bal[Number(tid)] = Number((balances as bigint[])[i])));
      return {
        credits: Number(credits),
        claimed: Boolean(claimed),
        kycStatus: ONCHAIN_KYC_STATUS[Number(statusN)] ?? 'None',
        verified: Boolean(verified),
        frozen: Boolean(frozen),
        paused: Boolean(paused),
        isOfficer,
        native: formatEther(native as bigint),
        balances: bal,
        assets,
        selfService: Boolean(selfService),
      };
    },
  });

  const history = useQuery<OnchainEvent[]>({
    queryKey: ['onchain-history', wallet.address, wallet.chainId, cfg.assetToken],
    enabled: ready,
    staleTime: 60_000,
    queryFn: async () => {
      const provider = wallet.getBrowserProvider();
      if (!provider || !wallet.address) return [];
      return queryRecentEvents(provider, wallet.address);
    },
  });

  /** Send a transaction, track it in activity + toasts, and wait for confirmation. */
  const send = useCallback(
    async (
      label: string,
      kind: ActivityKind,
      build: (signer: JsonRpcSigner) => Promise<ContractTransactionResponse>,
      extra: { assetId?: string; tokens?: number; amount?: number; unitPrice?: number; note?: string } = {},
      onSubmitted?: (hash: string) => void,
    ): Promise<TxResult> => {
      const provider = wallet.getBrowserProvider();
      if (!provider) throw new Error('Connect a wallet first.');
      if (!wallet.isCorrectChain) throw new Error(`Switch your wallet to ${TARGET_CHAIN.name} first.`);
      const toastId = toast.loading(`${label}: confirm in your wallet`);
      try {
        const signer = await provider.getSigner();
        const tx = await build(signer);
        onSubmitted?.(tx.hash);
        recordActivity({ id: tx.hash, hash: tx.hash, kind, mode: 'onchain', status: 'pending', chainId: TARGET_CHAIN.id, createdAt: new Date().toISOString(), ...extra });
        toast.loading(`${label}: waiting for confirmation`, { id: toastId, description: shortAddress(tx.hash, 6) });
        const receipt = await tx.wait();
        const ok = receipt?.status === 1;
        updateActivity(tx.hash, { status: ok ? 'confirmed' : 'failed' });
        const link = explorerTx(tx.hash);
        if (ok) {
          toast.success(`${label}: confirmed on ${TARGET_CHAIN.name}`, {
            id: toastId,
            description: link ? 'View it on the block explorer from Transactions.' : undefined,
          });
          notify({ title: `${label} confirmed`, body: `Testnet transaction ${shortAddress(tx.hash, 6)} on ${TARGET_CHAIN.name}.`, tone: 'success', href: '/transactions' });
        } else {
          toast.error(`${label}: transaction failed`, { id: toastId });
        }
        await Promise.all([qc.invalidateQueries({ queryKey: ['onchain'] }), qc.invalidateQueries({ queryKey: ['onchain-history'] })]);
        return { hash: tx.hash, ok, blockNumber: receipt?.blockNumber ?? null };
      } catch (err) {
        toast.error(describeTxError(err), { id: toastId });
        throw err;
      }
    },
    [wallet, recordActivity, updateActivity, notify, qc],
  );

  const claimCredits = useCallback(
    (onSubmitted?: (h: string) => void) =>
      send('Claim demo credits', 'claim', async (signer) => assetTokenContract(signer)!.claimDemoCredits(), { amount: 10_000, note: 'vUSD demo credits' }, onSubmitted),
    [send],
  );

  const requestVerification = useCallback(
    (caseId: string, onSubmitted?: (h: string) => void) =>
      send('Record verification on-chain', 'kyc', async (signer) => complianceContract(signer)!.requestVerification(keccakText(caseId)), { note: 'ComplianceManager.requestVerification' }, onSubmitted),
    [send],
  );

  const buy = useCallback(
    (tokenId: number, tokens: number, unitPrice: number, onSubmitted?: (h: string) => void) => {
      const asset = getAssetByTokenId(tokenId);
      return send(
        `Buy ${tokens} ${asset?.symbol ?? 'tokens'}`,
        'buy',
        async (signer) => assetTokenContract(signer)!.buy(BigInt(tokenId), BigInt(tokens)),
        { assetId: asset?.id, tokens, unitPrice, amount: tokens * unitPrice },
        onSubmitted,
      );
    },
    [send],
  );

  const redeem = useCallback(
    (tokenId: number, tokens: number, unitPrice: number) => {
      const asset = getAssetByTokenId(tokenId);
      return send(`Redeem ${tokens} ${asset?.symbol ?? 'tokens'}`, 'sell', async (signer) => assetTokenContract(signer)!.redeem(BigInt(tokenId), BigInt(tokens)), {
        assetId: asset?.id,
        tokens,
        unitPrice,
        amount: tokens * unitPrice,
      });
    },
    [send],
  );

  const officerAction = useCallback(
    (action: 'approve' | 'reject' | 'revoke', account: string) =>
      send(`KYC ${action} ${shortAddress(account)}`, 'kyc', async (signer) => complianceContract(signer)![action](account), { note: `Officer ${action}: ${account}` }),
    [send],
  );

  return { ready, config: cfg, snapshot, history, claimCredits, requestVerification, buy, redeem, officerAction };
}
