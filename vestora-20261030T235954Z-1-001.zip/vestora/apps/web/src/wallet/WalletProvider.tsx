import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { BrowserProvider, type Eip1193Provider } from 'ethers';
import { TARGET_CHAIN } from '@/config/chains';
import { readFlag, writeFlag } from '@/lib/storage';

type Listener = (...args: unknown[]) => void;

export interface InjectedProvider extends Eip1193Provider {
  on?: (event: string, cb: Listener) => void;
  removeListener?: (event: string, cb: Listener) => void;
  isMetaMask?: boolean;
}

export interface WalletInfo {
  uuid: string;
  name: string;
  icon: string;
  rdns: string;
}

interface ProviderDetail {
  info: WalletInfo;
  provider: InjectedProvider;
}

export type WalletStatus = 'detecting' | 'unavailable' | 'disconnected' | 'connecting' | 'connected';

interface WalletContextValue {
  status: WalletStatus;
  address: string | null;
  chainId: number | null;
  walletName: string | null;
  wallets: WalletInfo[];
  isCorrectChain: boolean;
  error: string | null;
  connect: (rdns?: string) => Promise<void>;
  disconnect: () => Promise<void>;
  switchToTarget: () => Promise<boolean>;
  getBrowserProvider: () => BrowserProvider | null;
}

const WalletContext = createContext<WalletContextValue | null>(null);
const FLAG = 'vestora-wallet';

function errorCode(err: unknown): number | undefined {
  const e = err as { code?: number; data?: { originalError?: { code?: number } } };
  return e?.code ?? e?.data?.originalError?.code;
}

export function WalletProvider({ children }: { children: ReactNode }) {
  const [details, setDetails] = useState<ProviderDetail[]>([]);
  const [status, setStatus] = useState<WalletStatus>('detecting');
  const [address, setAddress] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);
  const [active, setActive] = useState<ProviderDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const browserProvider = useRef<BrowserProvider | null>(null);

  // EIP-6963 multi-wallet discovery, with a legacy window.ethereum fallback.
  useEffect(() => {
    const seen = new Map<string, ProviderDetail>();
    const onAnnounce = (event: Event) => {
      const detail = (event as CustomEvent<ProviderDetail>).detail;
      if (!detail?.info?.uuid || seen.has(detail.info.uuid)) return;
      seen.set(detail.info.uuid, detail);
      setDetails([...seen.values()]);
    };
    window.addEventListener('eip6963:announceProvider', onAnnounce as EventListener);
    window.dispatchEvent(new Event('eip6963:requestProvider'));
    const timer = window.setTimeout(() => {
      const legacy = (window as unknown as { ethereum?: InjectedProvider }).ethereum;
      if (seen.size === 0 && legacy) {
        const d: ProviderDetail = { info: { uuid: 'legacy', name: legacy.isMetaMask ? 'MetaMask' : 'Browser wallet', icon: '', rdns: 'legacy.injected' }, provider: legacy };
        seen.set('legacy', d);
        setDetails([d]);
      }
      if (seen.size === 0) setStatus((s) => (s === 'detecting' ? 'unavailable' : s));
      else setStatus((s) => (s === 'detecting' ? 'disconnected' : s));
    }, 700);
    return () => {
      window.removeEventListener('eip6963:announceProvider', onAnnounce as EventListener);
      window.clearTimeout(timer);
    };
  }, []);

  // Wallet events for the active provider.
  useEffect(() => {
    if (!active) return;
    const p = active.provider;
    const onAccounts: Listener = (accounts) => {
      const list = accounts as string[];
      if (!list || list.length === 0) {
        setAddress(null);
        setStatus('disconnected');
        writeFlag(FLAG, 'disconnected');
      } else {
        setAddress(list[0]);
        setStatus('connected');
      }
    };
    const onChain: Listener = (hex) => {
      setChainId(parseInt(String(hex), 16));
      browserProvider.current = new BrowserProvider(p, 'any');
    };
    p.on?.('accountsChanged', onAccounts);
    p.on?.('chainChanged', onChain);
    return () => {
      p.removeListener?.('accountsChanged', onAccounts);
      p.removeListener?.('chainChanged', onChain);
    };
  }, [active]);

  const pick = useCallback(
    (rdns?: string): ProviderDetail | null => {
      if (details.length === 0) return null;
      return (
        (rdns ? details.find((d) => d.info.rdns === rdns) : undefined) ??
        details.find((d) => d.info.rdns === 'io.metamask') ??
        details.find((d) => d.provider.isMetaMask) ??
        details[0]
      );
    },
    [details],
  );

  const attach = useCallback(async (d: ProviderDetail, accounts: string[]) => {
    const hex = (await d.provider.request({ method: 'eth_chainId' })) as string;
    browserProvider.current = new BrowserProvider(d.provider, 'any');
    setActive(d);
    setAddress(accounts[0]);
    setChainId(parseInt(hex, 16));
    setStatus('connected');
    setError(null);
    writeFlag(FLAG, d.info.rdns);
  }, []);

  // Silent reconnect (no prompt) if the user connected before and did not disconnect.
  useEffect(() => {
    if (details.length === 0 || status === 'connected' || status === 'connecting') return;
    const flag = readFlag(FLAG);
    if (!flag || flag === 'disconnected') return;
    const d = pick(flag);
    if (!d) return;
    d.provider
      .request({ method: 'eth_accounts' })
      .then((accounts: unknown) => {
        const list = accounts as string[];
        if (list?.length) return attach(d, list);
      })
      .catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [details]);

  const connect = useCallback(
    async (rdns?: string) => {
      const d = pick(rdns);
      if (!d) {
        setError('No browser wallet found. Install MetaMask, or continue in demo mode.');
        setStatus('unavailable');
        return;
      }
      setStatus('connecting');
      setError(null);
      try {
        const accounts = (await d.provider.request({ method: 'eth_requestAccounts' })) as string[];
        if (!accounts?.length) throw new Error('No account was shared by the wallet.');
        await attach(d, accounts);
      } catch (err) {
        setStatus('disconnected');
        setError(errorCode(err) === 4001 ? 'Connection request was rejected in the wallet.' : (err as Error)?.message ?? 'Could not connect the wallet.');
      }
    },
    [attach, pick],
  );

  const disconnect = useCallback(async () => {
    const d = active;
    writeFlag(FLAG, 'disconnected');
    setAddress(null);
    setChainId(null);
    setActive(null);
    browserProvider.current = null;
    setStatus(details.length ? 'disconnected' : 'unavailable');
    // Best effort: also revoke the site permission where the wallet supports it.
    try {
      await d?.provider.request({ method: 'wallet_revokePermissions', params: [{ eth_accounts: {} }] });
    } catch {
      /* not supported by every wallet */
    }
  }, [active, details.length]);

  const switchToTarget = useCallback(async (): Promise<boolean> => {
    const p = active?.provider;
    if (!p) return false;
    try {
      await p.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: TARGET_CHAIN.hex }] });
      return true;
    } catch (err) {
      if (errorCode(err) === 4902) {
        try {
          await p.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: TARGET_CHAIN.hex,
                chainName: TARGET_CHAIN.name,
                nativeCurrency: TARGET_CHAIN.currency,
                rpcUrls: TARGET_CHAIN.rpcUrls,
                blockExplorerUrls: TARGET_CHAIN.explorer ? [TARGET_CHAIN.explorer] : undefined,
              },
            ],
          });
          return true;
        } catch (addErr) {
          setError((addErr as Error)?.message ?? 'Could not add the network.');
          return false;
        }
      }
      setError(errorCode(err) === 4001 ? 'Network switch was rejected in the wallet.' : (err as Error)?.message ?? 'Could not switch network.');
      return false;
    }
  }, [active]);

  const value = useMemo<WalletContextValue>(
    () => ({
      status,
      address,
      chainId,
      walletName: active?.info.name ?? null,
      wallets: details.map((d) => d.info),
      isCorrectChain: chainId === TARGET_CHAIN.id,
      error,
      connect,
      disconnect,
      switchToTarget,
      getBrowserProvider: () => browserProvider.current,
    }),
    [status, address, chainId, active, details, error, connect, disconnect, switchToTarget],
  );

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}

export function useWallet(): WalletContextValue {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error('useWallet must be used inside <WalletProvider>');
  return ctx;
}
