/**
 * Human-readable ABIs for the VESTORA contracts (kept in sync with contracts/contracts/*.sol).
 * Full JSON ABIs are exported to src/contracts/abi by the deploy script for other tools.
 */
export const ASSET_TOKEN_ABI = [
  'function CREDITS_ID() view returns (uint256)',
  'function DEMO_CREDIT_GRANT() view returns (uint256)',
  'function hasClaimedCredits(address account) view returns (bool)',
  'function creditsOf(address account) view returns (uint256)',
  'function balanceOf(address account, uint256 id) view returns (uint256)',
  'function balanceOfBatch(address[] accounts, uint256[] ids) view returns (uint256[])',
  'function totalSupply(uint256 id) view returns (uint256)',
  'function availableSupply(uint256 assetId) view returns (uint256)',
  'function assetIds() view returns (uint256[])',
  'function getAsset(uint256 assetId) view returns (tuple(string symbol, string name, string category, uint256 maxSupply, uint256 price, bool active, bool exists))',
  'function paused() view returns (bool)',
  'function uri(uint256 id) view returns (string)',
  'function claimDemoCredits()',
  'function buy(uint256 assetId, uint256 amount)',
  'function redeem(uint256 assetId, uint256 amount)',
  'event DemoCreditsClaimed(address indexed account, uint256 amount)',
  'event AssetPurchased(address indexed buyer, uint256 indexed assetId, uint256 amount, uint256 cost)',
  'event AssetRedeemed(address indexed holder, uint256 indexed assetId, uint256 amount, uint256 credits)',
  'event AssetIssued(address indexed to, uint256 indexed assetId, uint256 amount)',
  'error UnknownAsset(uint256 assetId)',
  'error AssetInactive(uint256 assetId)',
  'error InvalidAmount()',
  'error NotVerified(address account)',
  'error ExceedsMaxSupply(uint256 assetId, uint256 requested, uint256 available)',
  'error InsufficientCredits(uint256 balance, uint256 needed)',
  'error CreditsAlreadyClaimed(address account)',
  'error CreditsNonTransferable()',
  'error TransferNotCompliant(address from, address to)',
  'error EnforcedPause()',
  'error ERC1155InsufficientBalance(address sender, uint256 balance, uint256 needed, uint256 tokenId)',
  'error AccessControlUnauthorizedAccount(address account, bytes32 neededRole)',
] as const;

export const COMPLIANCE_ABI = [
  'function COMPLIANCE_OFFICER_ROLE() view returns (bytes32)',
  'function hasRole(bytes32 role, address account) view returns (bool)',
  'function statusOf(address account) view returns (uint8)',
  'function isVerified(address account) view returns (bool)',
  'function frozen(address account) view returns (bool)',
  'function selfServiceApproval() view returns (bool)',
  'function requestVerification(bytes32 caseRef)',
  'function approve(address account)',
  'function reject(address account)',
  'function revoke(address account)',
  'event VerificationRequested(address indexed account, bytes32 caseRef)',
  'event StatusChanged(address indexed account, uint8 status, address indexed operator)',
  'error AlreadyVerified(address account)',
  'error ZeroAddress()',
  'error AccessControlUnauthorizedAccount(address account, bytes32 neededRole)',
] as const;

/** ComplianceManager.Status enum order. */
export const ONCHAIN_KYC_STATUS = ['None', 'Pending', 'Verified', 'Rejected'] as const;
export type OnchainKycStatus = (typeof ONCHAIN_KYC_STATUS)[number];
