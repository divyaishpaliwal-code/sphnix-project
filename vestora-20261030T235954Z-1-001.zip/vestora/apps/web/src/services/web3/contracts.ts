import { Contract, type ContractRunner } from 'ethers';
import { env } from '@/config/env';
import { TARGET_CHAIN } from '@/config/chains';
import { ASSET_TOKEN_ABI, COMPLIANCE_ABI } from './abi';

export interface DeploymentRecord {
  chainId: number;
  network: string;
  deployedAt: string;
  deployer: string;
  startBlock: number;
  selfServiceKyc: boolean;
  explorer: string | null;
  contracts: { AssetToken: string; ComplianceManager: string };
}

// Deployment records written by contracts/scripts/deploy.js.
const files = import.meta.glob<DeploymentRecord>('../../contracts/deployments/*.json', { eager: true, import: 'default' });
const DEPLOYMENTS: Record<number, DeploymentRecord> = {};
for (const record of Object.values(files)) {
  if (record && typeof record.chainId === 'number' && record.contracts) DEPLOYMENTS[record.chainId] = record;
}

const ZERO = /^0x0{40}$/i;
const isAddr = (a?: string) => Boolean(a && /^0x[a-fA-F0-9]{40}$/.test(a) && !ZERO.test(a));

export interface ContractConfig {
  chainId: number;
  assetToken: string | null;
  compliance: string | null;
  deployBlock: number | undefined;
  selfServiceKyc: boolean | null;
  source: 'env' | 'deployment' | 'none';
  configured: boolean;
}

export function contractConfig(): ContractConfig {
  const d = DEPLOYMENTS[TARGET_CHAIN.id];
  const assetToken = env.assetToken ?? d?.contracts.AssetToken;
  const compliance = env.compliance ?? d?.contracts.ComplianceManager;
  const configured = isAddr(assetToken) && isAddr(compliance);
  return {
    chainId: TARGET_CHAIN.id,
    assetToken: configured ? (assetToken as string) : null,
    compliance: configured ? (compliance as string) : null,
    deployBlock: env.deployBlock ?? d?.startBlock,
    selfServiceKyc: d ? d.selfServiceKyc : null,
    source: env.assetToken ? 'env' : d ? 'deployment' : 'none',
    configured,
  };
}

export function assetTokenContract(runner: ContractRunner): Contract | null {
  const c = contractConfig();
  return c.assetToken ? new Contract(c.assetToken, ASSET_TOKEN_ABI, runner) : null;
}

export function complianceContract(runner: ContractRunner): Contract | null {
  const c = contractConfig();
  return c.compliance ? new Contract(c.compliance, COMPLIANCE_ABI, runner) : null;
}

const FRIENDLY: Record<string, string> = {
  NotVerified: 'This wallet is not verified in the ComplianceManager yet. Complete the simulated KYC and record it on-chain first.',
  InsufficientCredits: 'Not enough vUSD demo credits. Claim your free testnet credits first.',
  CreditsAlreadyClaimed: 'This wallet has already claimed its demo credits.',
  ExceedsMaxSupply: 'That is more than the remaining sample token supply.',
  AssetInactive: 'This sample asset is paused for new purchases.',
  UnknownAsset: 'This asset has not been created on the contract.',
  InvalidAmount: 'Enter at least one whole token.',
  EnforcedPause: 'The contract is paused by its administrator.',
  TransferNotCompliant: 'Both wallets must be verified (and not frozen) to transfer asset tokens.',
  CreditsNonTransferable: 'Demo credits cannot be transferred.',
  AlreadyVerified: 'This wallet is already verified on-chain.',
  ERC1155InsufficientBalance: 'You do not hold enough tokens for that.',
  AccessControlUnauthorizedAccount: 'This wallet does not have permission for that action.',
};

/** Turn wallet / RPC / contract errors into a clear sentence. */
export function describeTxError(err: unknown): string {
  const e = err as {
    code?: string | number;
    shortMessage?: string;
    message?: string;
    reason?: string;
    revert?: { name?: string };
    info?: { error?: { code?: number; message?: string } };
    error?: { code?: number; message?: string };
  };
  const nested = e?.info?.error?.code ?? e?.error?.code;
  if (e?.code === 'ACTION_REJECTED' || e?.code === 4001 || nested === 4001) return 'You rejected the request in your wallet.';
  if (e?.revert?.name && FRIENDLY[e.revert.name]) return FRIENDLY[e.revert.name];
  const text = `${e?.shortMessage ?? ''} ${e?.reason ?? ''} ${e?.message ?? ''}`;
  for (const [name, msg] of Object.entries(FRIENDLY)) if (text.includes(name)) return msg;
  if (/insufficient funds/i.test(text)) return `Not enough ${TARGET_CHAIN.currency.symbol} on ${TARGET_CHAIN.name} to pay for gas. Get free test funds from a faucet.`;
  if (/network changed|underlying network changed/i.test(text)) return 'Your wallet switched networks. Please try again.';
  if (e?.code === 'NETWORK_ERROR' || /failed to fetch|network error/i.test(text)) return 'Could not reach the network RPC. Check your connection and try again.';
  return (e?.shortMessage ?? e?.message ?? 'The transaction failed.').slice(0, 220);
}
