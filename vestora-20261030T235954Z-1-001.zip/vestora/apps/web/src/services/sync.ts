import { api } from './api';
import { useAppStore } from '@/store/app';

export interface RemoteProfile {
  id: string;
  updatedAt: string;
  preferences: Record<string, unknown>;
  watchlist: string[];
  portfolio: unknown;
  activity: unknown[];
  alerts: unknown[];
}

/** Payload sent to the API. Personal KYC details never leave the browser. */
export function buildPayload() {
  const s = useAppStore.getState();
  return {
    preferences: { theme: s.settings.theme, refreshSeconds: s.settings.refreshSeconds, kycStatus: undefined },
    watchlist: s.watchlist,
    portfolio: s.demo,
    activity: s.activity.slice(0, 300),
    alerts: s.alerts,
  };
}

export async function pullProfile(): Promise<RemoteProfile | null> {
  const { profileId, profileSecret } = useAppStore.getState().profile;
  try {
    return await api<RemoteProfile>(`/profile/${profileId}`, { headers: { 'x-profile-key': profileSecret } });
  } catch (err) {
    if ((err as { status?: number }).status === 404) return null;
    throw err;
  }
}

export async function pushProfile(): Promise<RemoteProfile> {
  const { profileId, profileSecret } = useAppStore.getState().profile;
  return api<RemoteProfile>(`/profile/${profileId}`, {
    method: 'PUT',
    headers: { 'x-profile-key': profileSecret },
    body: JSON.stringify(buildPayload()),
  });
}
