import { env } from '@/config/env';

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export class ApiUnavailableError extends Error {
  constructor(message = 'The VESTORA API server is not reachable.') {
    super(message);
    this.name = 'ApiUnavailableError';
  }
}

/**
 * Tracks whether the API server is reachable so the UI can switch to its
 * browser-only fallbacks without waiting for a timeout on every request.
 */
let downUntil = 0;
const listeners = new Set<(online: boolean) => void>();

export function apiOnline(): boolean {
  return !env.disableApi && Date.now() >= downUntil;
}

function markDown() {
  const wasOnline = Date.now() >= downUntil;
  downUntil = Date.now() + 60_000;
  if (wasOnline) listeners.forEach((l) => l(false));
}

function markUp() {
  const wasDown = Date.now() < downUntil;
  downUntil = 0;
  if (wasDown) listeners.forEach((l) => l(true));
}

export function onApiStatus(cb: (online: boolean) => void): () => void {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export async function api<T>(path: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<T> {
  if (env.disableApi) throw new ApiUnavailableError('API calls are disabled in this build (VITE_DISABLE_API=true).');
  if (Date.now() < downUntil) throw new ApiUnavailableError();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), init.timeoutMs ?? 15_000);
  let res: Response;
  try {
    res = await fetch(`${env.apiBase}/api${path}`, {
      ...init,
      headers: { 'content-type': 'application/json', ...(init.headers ?? {}) },
      signal: controller.signal,
    });
  } catch {
    markDown();
    throw new ApiUnavailableError();
  } finally {
    clearTimeout(timer);
  }
  // A static host returning index.html (or a gateway error) means there is no API here.
  const type = res.headers.get('content-type') ?? '';
  if (res.status === 502 || res.status === 503 || res.status === 504 || (!type.includes('application/json') && res.status !== 204)) {
    markDown();
    throw new ApiUnavailableError();
  }
  markUp();
  const body = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new ApiError(body?.error ?? `Request failed (${res.status})`, res.status);
  return body;
}
