import type { NewsCategory, NewsResponse } from '@vestora/shared';
import { api, ApiUnavailableError } from './api';

export async function fetchNews(category?: NewsCategory): Promise<NewsResponse> {
  try {
    return await api<NewsResponse>(`/news${category ? `?category=${category}` : ''}`);
  } catch (err) {
    if (err instanceof ApiUnavailableError) {
      return { items: [], generatedAt: new Date().toISOString(), status: 'unavailable', message: 'Market news is fetched by the VESTORA API server, which is offline.' };
    }
    throw err;
  }
}
