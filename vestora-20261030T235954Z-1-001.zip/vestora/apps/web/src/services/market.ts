import { INSTRUMENTS, INSTRUMENT_MAP, type HistoryRange, type Instrument, type Quote, type Series } from '@vestora/shared';
import { env } from '@/config/env';
import { api, ApiUnavailableError } from './api';

export type DataMode = 'server' | 'browser';

export interface QuotesResult {
  quotes: Quote[];
  generatedAt: string;
  mode: DataMode;
}

const ALL_IDS = INSTRUMENTS.map((i) => i.id);
const CG = 'https://api.coingecko.com/api/v3';

function demoQuote(inst: Instrument, message: string): Quote {
  const now = new Date().toISOString();
  if (inst.demo === null) {
    return {
      instrumentId: inst.id,
      price: null,
      previous: null,
      change: null,
      changePct: null,
      changeBasis: null,
      denomination: inst.denomination,
      unit: inst.unit,
      status: 'unavailable',
      frequency: 'daily',
      source: { id: 'none', name: 'Unavailable' },
      asOf: null,
      fetchedAt: now,
      message,
    };
  }
  return {
    instrumentId: inst.id,
    price: inst.demo,
    previous: null,
    change: null,
    changePct: null,
    changeBasis: null,
    denomination: inst.denomination,
    unit: inst.unit,
    status: 'demo',
    frequency: 'daily',
    source: { id: 'demo', name: 'Static demo value', note: 'A fixed illustration, not a market quote.' },
    asOf: null,
    fetchedAt: now,
    message,
  };
}

/**
 * Browser-only fallback when the API server is offline: CoinGecko's public API
 * (CORS-enabled) for crypto and the PAXG gold proxy; everything else is labelled demo.
 */
async function browserQuotes(ids: string[]): Promise<Quote[]> {
  const insts = ids.map((id) => INSTRUMENT_MAP[id]).filter((i): i is Instrument => Boolean(i));
  const cgItems = env.directCoinGecko ? insts.filter((i) => i.providers.coingecko) : [];
  const out = new Map<string, Quote>();
  if (cgItems.length) {
    try {
      const cgIds = [...new Set(cgItems.map((i) => i.providers.coingecko!.symbol))];
      const res = await fetch(`${CG}/simple/price?ids=${cgIds.join(',')}&vs_currencies=usd&include_24hr_change=true&include_last_updated_at=true`);
      if (res.ok) {
        const data = (await res.json()) as Record<string, { usd?: number; usd_24h_change?: number; last_updated_at?: number }>;
        for (const inst of cgItems) {
          const map = inst.providers.coingecko!;
          const row = data[map.symbol];
          if (!row || typeof row.usd !== 'number') continue;
          const pct = typeof row.usd_24h_change === 'number' ? row.usd_24h_change : null;
          const previous = pct !== null ? row.usd / (1 + pct / 100) : null;
          out.set(inst.id, {
            instrumentId: inst.id,
            price: row.usd,
            previous,
            change: previous !== null ? row.usd - previous : null,
            changePct: pct,
            changeBasis: pct !== null ? '24h' : null,
            denomination: inst.denomination,
            unit: inst.unit,
            status: 'realtime',
            frequency: 'realtime',
            source: { id: 'coingecko', name: 'CoinGecko (direct)', url: 'https://www.coingecko.com', note: map.proxy?.note },
            proxy: map.proxy,
            asOf: row.last_updated_at ? new Date(row.last_updated_at * 1000).toISOString() : null,
            fetchedAt: new Date().toISOString(),
          });
        }
      }
    } catch {
      // fall through to demo values
    }
  }
  const reason = env.disableApi
    ? 'This build runs without the VESTORA API, so only crypto prices are fetched live.'
    : 'The VESTORA API server is offline, so only crypto prices are fetched live.';
  return insts.map((i) => out.get(i.id) ?? demoQuote(i, reason));
}

export async function fetchQuotes(ids: string[] = ALL_IDS): Promise<QuotesResult> {
  try {
    const r = await api<{ quotes: Quote[]; generatedAt: string }>(`/market/quotes?ids=${encodeURIComponent(ids.join(','))}`);
    return { ...r, mode: 'server' };
  } catch (err) {
    if (!(err instanceof ApiUnavailableError)) throw err;
    return { quotes: await browserQuotes(ids), generatedAt: new Date().toISOString(), mode: 'browser' };
  }
}

const CG_DAYS: Record<HistoryRange, number> = { '1D': 1, '1W': 7, '1M': 30, '3M': 90, '1Y': 365, ALL: 365 };

export async function fetchHistory(id: string, range: HistoryRange): Promise<Series> {
  const inst = INSTRUMENT_MAP[id];
  try {
    return await api<Series>(`/market/history?id=${encodeURIComponent(id)}&range=${range}`);
  } catch (err) {
    if (!(err instanceof ApiUnavailableError) || !inst) throw err;
  }
  const base: Series = {
    instrumentId: id,
    range,
    points: [],
    status: 'unavailable',
    frequency: 'daily',
    denomination: inst.denomination,
    unit: inst.unit,
    source: { id: 'none', name: 'Unavailable' },
    fetchedAt: new Date().toISOString(),
    message: 'Historical data for this instrument needs the VESTORA API server. VESTORA never invents price history.',
  };
  const map = inst.providers.coingecko;
  if (!map || !env.directCoinGecko) return base;
  try {
    const res = await fetch(`${CG}/coins/${map.symbol}/market_chart?vs_currency=usd&days=${CG_DAYS[range]}`);
    if (!res.ok) return { ...base, message: 'CoinGecko is rate-limiting requests right now — try again in a minute.' };
    const data = (await res.json()) as { prices?: [number, number][] };
    const points = (data.prices ?? []).map(([t, v]) => ({ t, v })).filter((p) => Number.isFinite(p.v));
    return {
      ...base,
      points,
      status: range === '1D' ? 'realtime' : 'historical',
      frequency: range === '1Y' || range === 'ALL' ? 'daily' : 'intraday',
      source: { id: 'coingecko', name: 'CoinGecko (direct)', url: 'https://www.coingecko.com', note: map.proxy?.note },
      proxy: map.proxy,
      message: range === 'ALL' ? 'The free CoinGecko API provides up to 365 days of history.' : undefined,
    };
  } catch {
    return base;
  }
}
