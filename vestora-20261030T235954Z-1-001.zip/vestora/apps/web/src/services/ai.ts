import { answerQuestion, type AskRequest, type AssistantResponse, type MarketStats } from '@vestora/shared';
import { api, ApiUnavailableError } from './api';

/**
 * Ask VESTORA Intelligence. The API server holds any AI keys; when it is
 * unreachable the built-in educational assistant answers locally (labelled demo).
 */
type StatsMap = Record<string, MarketStats | undefined>;

export async function askAssistant(req: AskRequest, localStats?: StatsMap | (() => Promise<StatsMap>)): Promise<AssistantResponse> {
  try {
    return await api<AssistantResponse>('/ai/ask', { method: 'POST', body: JSON.stringify(req), timeoutMs: 45_000 });
  } catch (err) {
    if (!(err instanceof ApiUnavailableError)) throw err;
    let stats: StatsMap | undefined;
    try {
      stats = typeof localStats === 'function' ? await localStats() : localStats;
    } catch {
      stats = undefined;
    }
    return answerQuestion(req, { stats, mode: 'demo' });
  }
}

export async function aiStatus(): Promise<{ mode: 'live' | 'demo'; provider: string | null; model: string | null; reachable: boolean }> {
  try {
    const s = await api<{ mode: 'live' | 'demo'; provider: string | null; model: string | null }>('/ai/status');
    return { ...s, reachable: true };
  } catch {
    return { mode: 'demo', provider: null, model: null, reachable: false };
  }
}
