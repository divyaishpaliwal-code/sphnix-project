import { env } from './env';

export interface ChainConfig {
  id: number;
  hex: string;
  name: string;
  currency: { name: string; symbol: string; decimals: number };
  rpcUrls: string[];
  explorer: string | null;
  faucet: string | null;
}

const hex = (id: number) => `0x${id.toString(16)}`;

/** Supported testnets only. VESTORA never targets a mainnet. */
export const CHAINS: Record<number, ChainConfig> = {
  11155111: {
    id: 11155111,
    hex: hex(11155111),
    name: 'Sepolia',
    currency: { name: 'Sepolia Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: ['https://ethereum-sepolia-rpc.publicnode.com', 'https://rpc.sepolia.org'],
    explorer: 'https://sepolia.etherscan.io',
    faucet: 'https://www.alchemy.com/faucets/ethereum-sepolia',
  },
  84532: {
    id: 84532,
    hex: hex(84532),
    name: 'Base Sepolia',
    currency: { name: 'Sepolia Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: ['https://sepolia.base.org'],
    explorer: 'https://sepolia.basescan.org',
    faucet: 'https://docs.base.org/chain/network-faucets',
  },
  80002: {
    id: 80002,
    hex: hex(80002),
    name: 'Polygon Amoy',
    currency: { name: 'POL', symbol: 'POL', decimals: 18 },
    rpcUrls: ['https://rpc-amoy.polygon.technology'],
    explorer: 'https://amoy.polygonscan.com',
    faucet: 'https://faucet.polygon.technology',
  },
  31337: {
    id: 31337,
    hex: hex(31337),
    name: 'Hardhat Local',
    currency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: ['http://127.0.0.1:8545'],
    explorer: null,
    faucet: null,
  },
};

export const TARGET_CHAIN: ChainConfig = CHAINS[env.chainId] ?? CHAINS[11155111];

export function chainName(id: number | null | undefined): string {
  if (!id) return 'Unknown network';
  return CHAINS[id]?.name ?? (id === 1 ? 'Ethereum Mainnet (not supported)' : `Chain ${id}`);
}

export function explorerTx(hash: string, chainId: number = TARGET_CHAIN.id): string | null {
  const base = CHAINS[chainId]?.explorer;
  return base ? `${base}/tx/${hash}` : null;
}

export function explorerAddress(address: string, chainId: number = TARGET_CHAIN.id): string | null {
  const base = CHAINS[chainId]?.explorer;
  return base ? `${base}/address/${address}` : null;
}
