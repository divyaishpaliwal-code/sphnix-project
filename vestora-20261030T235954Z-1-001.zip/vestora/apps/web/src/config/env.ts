/** Typed access to VITE_* environment variables (never secrets). */
const e = import.meta.env;

function optionalAddress(v: string | undefined): string | undefined {
  return v && /^0x[a-fA-F0-9]{40}$/.test(v.trim()) ? v.trim() : undefined;
}

export const env = {
  apiBase: String(e.VITE_API_BASE_URL ?? '').replace(/\/$/, ''),
  disableApi: e.VITE_DISABLE_API === 'true',
  directCoinGecko: e.VITE_DIRECT_COINGECKO !== 'false',
  chainId: Number(e.VITE_CHAIN_ID ?? 11155111) || 11155111,
  assetToken: optionalAddress(e.VITE_ASSET_TOKEN_ADDRESS),
  compliance: optionalAddress(e.VITE_COMPLIANCE_ADDRESS),
  deployBlock: e.VITE_DEPLOY_BLOCK ? Number(e.VITE_DEPLOY_BLOCK) : undefined,
  rpcUrl: e.VITE_RPC_URL ? String(e.VITE_RPC_URL) : undefined,
  routerMode: e.VITE_ROUTER_MODE === 'hash' ? ('hash' as const) : ('browser' as const),
};
