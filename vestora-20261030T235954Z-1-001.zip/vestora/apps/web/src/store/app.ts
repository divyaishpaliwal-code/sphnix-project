import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { jsonStorage } from '@/lib/storage';
import { simulationId, uid } from '@/lib/utils';

export type ThemePref = 'dark' | 'light' | 'system';
export type KycStatus = 'not_started' | 'pending' | 'verified' | 'rejected';

export interface KycRecord {
  status: KycStatus;
  fullName: string;
  email: string;
  country: string;
  caseId: string | null;
  submittedAt: string | null;
  decidedAt: string | null;
  reason: string | null;
}

export interface DemoHolding {
  assetId: string;
  tokens: number;
  costBasis: number;
  firstBoughtAt: string;
}

export type ActivityKind = 'buy' | 'sell' | 'claim' | 'kyc' | 'reset';

export interface ActivityItem {
  /** SIM-XXXXXX for simulations, the transaction hash for on-chain activity. */
  id: string;
  kind: ActivityKind;
  mode: 'simulated' | 'onchain';
  assetId?: string;
  tokens?: number;
  /** USD for simulations, vUSD credits for on-chain activity. */
  amount?: number;
  unitPrice?: number;
  status: 'confirmed' | 'pending' | 'failed';
  hash?: string;
  chainId?: number;
  createdAt: string;
  note?: string;
}

export interface PriceAlert {
  id: string;
  target: { kind: 'instrument' | 'asset'; id: string };
  direction: 'above' | 'below';
  price: number;
  createdAt: string;
  triggeredAt: string | null;
  triggeredPrice?: number;
  active: boolean;
}

export interface AppNotification {
  id: string;
  title: string;
  body?: string;
  tone: 'success' | 'info' | 'warning' | 'error';
  createdAt: string;
  read: boolean;
  href?: string;
}

export type PortfolioView = 'auto' | 'sample' | 'simulated' | 'onchain';

export const DEMO_STARTING_CASH = 10_000;
const MAX_COMPARE = 3;

const emptyKyc: KycRecord = {
  status: 'not_started',
  fullName: '',
  email: '',
  country: '',
  caseId: null,
  submittedAt: null,
  decidedAt: null,
  reason: null,
};

const round2 = (n: number) => Math.round(n * 100) / 100;

/* ---- Validation for data restored from sync or an import file ---- */

const isStr = (v: unknown): v is string => typeof v === 'string';
const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const optNum = (v: unknown) => v === undefined || isNum(v);
const optStr = (v: unknown) => v === undefined || isStr(v);

function isActivityItem(x: unknown): x is ActivityItem {
  const a = x as Record<string, unknown> | null;
  return Boolean(
    a &&
      isStr(a.id) &&
      ['buy', 'sell', 'claim', 'kyc', 'reset'].includes(a.kind as string) &&
      (a.mode === 'simulated' || a.mode === 'onchain') &&
      ['confirmed', 'pending', 'failed'].includes(a.status as string) &&
      isStr(a.createdAt) &&
      !Number.isNaN(Date.parse(a.createdAt)) &&
      optStr(a.assetId) &&
      optNum(a.tokens) &&
      optNum(a.amount) &&
      optNum(a.unitPrice) &&
      optStr(a.hash) &&
      optNum(a.chainId) &&
      optStr(a.note),
  );
}

function isPriceAlert(x: unknown): x is PriceAlert {
  const a = x as Record<string, unknown> | null;
  const t = a?.target as Record<string, unknown> | undefined;
  return Boolean(
    a &&
      isStr(a.id) &&
      t &&
      (t.kind === 'instrument' || t.kind === 'asset') &&
      isStr(t.id) &&
      (a.direction === 'above' || a.direction === 'below') &&
      isNum(a.price) &&
      a.price > 0 &&
      isStr(a.createdAt) &&
      (a.triggeredAt === null || isStr(a.triggeredAt)) &&
      typeof a.active === 'boolean',
  );
}

function sanitizeDemo(x: unknown): { cash: number; holdings: Record<string, DemoHolding>; startedAt: string } | null {
  const p = x as Record<string, unknown> | null | undefined;
  if (!p || !isNum(p.cash) || p.cash < 0 || typeof p.holdings !== 'object' || p.holdings === null) return null;
  const holdings: Record<string, DemoHolding> = {};
  for (const [id, h] of Object.entries(p.holdings as Record<string, unknown>)) {
    const v = h as Record<string, unknown> | null;
    if (v && isStr(v.assetId) && v.assetId === id && isNum(v.tokens) && Number.isInteger(v.tokens) && v.tokens > 0 && isNum(v.costBasis) && v.costBasis >= 0 && isStr(v.firstBoughtAt)) {
      holdings[id] = { assetId: id, tokens: v.tokens, costBasis: v.costBasis, firstBoughtAt: v.firstBoughtAt };
    }
  }
  return { cash: round2(p.cash), holdings, startedAt: isStr(p.startedAt) ? p.startedAt : new Date().toISOString() };
}

interface Settings {
  theme: ThemePref;
  refreshSeconds: number;
  syncEnabled: boolean;
  hideBalances: boolean;
}

interface AppState {
  settings: Settings;
  profile: { displayName: string; profileId: string; profileSecret: string };
  kyc: KycRecord;
  demo: { cash: number; holdings: Record<string, DemoHolding>; startedAt: string };
  activity: ActivityItem[];
  watchlist: string[];
  compare: string[];
  alerts: PriceAlert[];
  notifications: AppNotification[];
  portfolioView: PortfolioView;
  lastSyncedAt: string | null;

  setSettings: (s: Partial<Settings>) => void;
  setProfile: (p: Partial<AppState['profile']>) => void;
  setKyc: (k: Partial<KycRecord>) => void;
  resetKyc: () => void;
  toggleWatch: (id: string) => boolean;
  toggleCompare: (assetId: string) => { added: boolean; full: boolean };
  clearCompare: () => void;
  simulateBuy: (p: { assetId: string; tokens: number; unitPrice: number }) => { ok: true; item: ActivityItem } | { ok: false; error: string };
  simulateSell: (p: { assetId: string; tokens: number; unitPrice: number }) => { ok: true; item: ActivityItem } | { ok: false; error: string };
  recordActivity: (item: ActivityItem) => void;
  updateActivity: (id: string, patch: Partial<ActivityItem>) => void;
  addAlert: (a: Omit<PriceAlert, 'id' | 'createdAt' | 'triggeredAt' | 'active'>) => void;
  removeAlert: (id: string) => void;
  triggerAlert: (id: string, price: number) => void;
  notify: (n: Omit<AppNotification, 'id' | 'createdAt' | 'read'>) => void;
  markAllRead: () => void;
  clearNotifications: () => void;
  setPortfolioView: (v: PortfolioView) => void;
  resetDemo: () => void;
  applyRemote: (r: { preferences?: Record<string, unknown>; watchlist?: string[]; portfolio?: unknown; activity?: unknown[]; alerts?: unknown[] }) => void;
  setLastSynced: (iso: string) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      settings: { theme: 'dark', refreshSeconds: 60, syncEnabled: false, hideBalances: false },
      profile: { displayName: '', profileId: `p_${uid()}`, profileSecret: uid() },
      kyc: emptyKyc,
      demo: { cash: DEMO_STARTING_CASH, holdings: {}, startedAt: new Date().toISOString() },
      activity: [],
      watchlist: ['vgld', 'vbtc', 'i:XAU', 'i:WTI'],
      compare: [],
      alerts: [],
      notifications: [],
      portfolioView: 'auto',
      lastSyncedAt: null,

      setSettings: (s) => set((st) => ({ settings: { ...st.settings, ...s } })),
      setProfile: (p) => set((st) => ({ profile: { ...st.profile, ...p } })),
      setKyc: (k) => set((st) => ({ kyc: { ...st.kyc, ...k } })),
      resetKyc: () => set({ kyc: emptyKyc }),

      toggleWatch: (id) => {
        const has = get().watchlist.includes(id);
        set((st) => ({ watchlist: has ? st.watchlist.filter((x) => x !== id) : [...st.watchlist, id] }));
        return !has;
      },

      toggleCompare: (assetId) => {
        const list = get().compare;
        if (list.includes(assetId)) {
          set({ compare: list.filter((x) => x !== assetId) });
          return { added: false, full: false };
        }
        if (list.length >= MAX_COMPARE) return { added: false, full: true };
        set({ compare: [...list, assetId] });
        return { added: true, full: false };
      },
      clearCompare: () => set({ compare: [] }),

      simulateBuy: ({ assetId, tokens, unitPrice }) => {
        if (!Number.isInteger(tokens) || tokens < 1) return { ok: false, error: 'Buy at least one whole token.' };
        if (!(unitPrice > 0)) return { ok: false, error: 'Token price is unavailable right now.' };
        const cost = round2(tokens * unitPrice);
        const { demo } = get();
        if (cost > demo.cash + 1e-9) return { ok: false, error: `Not enough simulated cash — you have $${demo.cash.toFixed(2)}.` };
        const now = new Date().toISOString();
        const prev = demo.holdings[assetId];
        const holding: DemoHolding = prev
          ? { ...prev, tokens: prev.tokens + tokens, costBasis: round2(prev.costBasis + cost) }
          : { assetId, tokens, costBasis: cost, firstBoughtAt: now };
        const item: ActivityItem = { id: simulationId(), kind: 'buy', mode: 'simulated', assetId, tokens, amount: cost, unitPrice, status: 'confirmed', createdAt: now };
        set((st) => ({
          demo: { ...st.demo, cash: round2(st.demo.cash - cost), holdings: { ...st.demo.holdings, [assetId]: holding } },
          activity: [item, ...st.activity].slice(0, 300),
        }));
        return { ok: true, item };
      },

      simulateSell: ({ assetId, tokens, unitPrice }) => {
        const prev = get().demo.holdings[assetId];
        if (!prev || prev.tokens < 1) return { ok: false, error: 'You do not hold this asset in your simulated portfolio.' };
        if (!Number.isInteger(tokens) || tokens < 1 || tokens > prev.tokens) return { ok: false, error: `Sell between 1 and ${prev.tokens} tokens.` };
        if (!(unitPrice > 0)) return { ok: false, error: 'Token price is unavailable right now.' };
        const proceeds = round2(tokens * unitPrice);
        const remaining = prev.tokens - tokens;
        const holdings = { ...get().demo.holdings };
        if (remaining === 0) delete holdings[assetId];
        else holdings[assetId] = { ...prev, tokens: remaining, costBasis: round2(prev.costBasis * (remaining / prev.tokens)) };
        const item: ActivityItem = { id: simulationId(), kind: 'sell', mode: 'simulated', assetId, tokens, amount: proceeds, unitPrice, status: 'confirmed', createdAt: new Date().toISOString() };
        set((st) => ({ demo: { ...st.demo, cash: round2(st.demo.cash + proceeds), holdings }, activity: [item, ...st.activity].slice(0, 300) }));
        return { ok: true, item };
      },

      recordActivity: (item) => set((st) => ({ activity: [item, ...st.activity.filter((a) => a.id !== item.id)].slice(0, 300) })),
      updateActivity: (id, patch) => set((st) => ({ activity: st.activity.map((a) => (a.id === id ? { ...a, ...patch } : a)) })),

      addAlert: (a) =>
        set((st) => ({ alerts: [{ ...a, id: uid('al_'), createdAt: new Date().toISOString(), triggeredAt: null, active: true }, ...st.alerts].slice(0, 50) })),
      removeAlert: (id) => set((st) => ({ alerts: st.alerts.filter((a) => a.id !== id) })),
      triggerAlert: (id, price) =>
        set((st) => ({ alerts: st.alerts.map((a) => (a.id === id ? { ...a, active: false, triggeredAt: new Date().toISOString(), triggeredPrice: price } : a)) })),

      notify: (n) =>
        set((st) => ({ notifications: [{ ...n, id: uid('n_'), createdAt: new Date().toISOString(), read: false }, ...st.notifications].slice(0, 60) })),
      markAllRead: () => set((st) => ({ notifications: st.notifications.map((n) => ({ ...n, read: true })) })),
      clearNotifications: () => set({ notifications: [] }),

      setPortfolioView: (v) => set({ portfolioView: v }),

      resetDemo: () =>
        set((st) => ({
          demo: { cash: DEMO_STARTING_CASH, holdings: {}, startedAt: new Date().toISOString() },
          activity: st.activity.filter((a) => a.mode === 'onchain'),
          compare: [],
          alerts: [],
          notifications: [],
          kyc: emptyKyc,
          portfolioView: 'auto',
        })),

      applyRemote: (r) =>
        set((st) => {
          const prefs = (r.preferences ?? {}) as Partial<Settings>;
          const theme = prefs.theme === 'dark' || prefs.theme === 'light' || prefs.theme === 'system' ? prefs.theme : null;
          const refresh = typeof prefs.refreshSeconds === 'number' && prefs.refreshSeconds >= 15 && prefs.refreshSeconds <= 3600 ? prefs.refreshSeconds : null;
          const demo = sanitizeDemo(r.portfolio);
          return {
            settings: { ...st.settings, ...(theme ? { theme } : {}), ...(refresh ? { refreshSeconds: refresh } : {}) },
            watchlist: Array.isArray(r.watchlist) ? r.watchlist.filter((w): w is string => typeof w === 'string' && w.length <= 64).slice(0, 100) : st.watchlist,
            demo: demo ?? st.demo,
            activity: Array.isArray(r.activity) ? r.activity.filter(isActivityItem).slice(0, 300) : st.activity,
            alerts: Array.isArray(r.alerts) ? r.alerts.filter(isPriceAlert).slice(0, 50) : st.alerts,
          };
        }),
      setLastSynced: (iso) => set({ lastSyncedAt: iso }),
    }),
    {
      name: 'vestora-store',
      storage: jsonStorage,
      version: 1,
      partialize: (s) => ({
        settings: s.settings,
        profile: s.profile,
        kyc: s.kyc,
        demo: s.demo,
        activity: s.activity,
        watchlist: s.watchlist,
        compare: s.compare,
        alerts: s.alerts,
        notifications: s.notifications,
        portfolioView: s.portfolioView,
        lastSyncedAt: s.lastSyncedAt,
      }),
    },
  ),
);

export const isKycVerified = (k: KycRecord) => k.status === 'verified';
