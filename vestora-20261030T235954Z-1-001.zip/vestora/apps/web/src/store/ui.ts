import { create } from 'zustand';

/** Ephemeral UI state (not persisted). */
interface UiState {
  paletteOpen: boolean;
  mobileNavOpen: boolean;
  compareOpen: boolean;
  apiOnline: boolean | null;
  setPaletteOpen: (v: boolean) => void;
  setMobileNavOpen: (v: boolean) => void;
  setCompareOpen: (v: boolean) => void;
  setApiOnline: (v: boolean) => void;
}

export const useUi = create<UiState>((set) => ({
  paletteOpen: false,
  mobileNavOpen: false,
  compareOpen: false,
  apiOnline: null,
  setPaletteOpen: (v) => set({ paletteOpen: v }),
  setMobileNavOpen: (v) => set({ mobileNavOpen: v }),
  setCompareOpen: (v) => set({ compareOpen: v }),
  setApiOnline: (v) => set({ apiOnline: v }),
}));
