import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router';
import { useQuery } from '@tanstack/react-query';
import { ChevronRight, GitCompareArrows, Send, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import {
  CATEGORY_LABELS,
  HISTORY_RANGES,
  calculateOwnership,
  contextualQuestions,
  formatNumber,
  formatPct,
  formatQuote,
  formatUsd,
  getAsset,
  getInstrument,
  seriesStats,
  unitLabel,
  type AskRequest,
  type HistoryRange,
} from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Segmented, Tabs, TabsList, TabsTrigger } from '@/components/ui/primitives';
import { EmptyState, ErrorState } from '@/components/common/States';
import { AssetIcon, RiskBadge, RiskBreakdown, SupplyBar, WatchButton } from '@/components/assets/AssetBits';
import { useSampleSupply } from '@/components/assets/AssetCard';
import { OwnershipCalculator, ScenarioSimulator } from '@/components/assets/Calculators';
import { AnswerCard } from '@/components/ai/AnswerCard';
import { PriceChart } from '@/components/charts/PriceChart';
import { DataStatusBadge, IllustrativeBadge, SourceLine } from '@/components/market/DataStatus';
import { BASIS_LABEL, PriceChange } from '@/components/market/PriceChange';
import { useAssetInsights } from '@/hooks/useAsset';
import { useHistory, useMarketStats } from '@/hooks/useMarket';
import { categoryColor } from '@/lib/chart-colors';
import { askAssistant } from '@/services/ai';
import { useAppStore } from '@/store/app';
import { useOnchain } from '@/wallet/useOnchain';

export default function AssetDetail() {
  const { assetId } = useParams<{ assetId: string }>();
  const asset = getAsset(assetId ?? '');
  if (!asset) {
    return (
      <EmptyState
        title="Asset not found"
        description="This sample asset does not exist. Browse the marketplace to see all available samples."
        action={
          <Button asChild>
            <Link to="/marketplace">Open marketplace</Link>
          </Button>
        }
      />
    );
  }
  return <AssetDetailView key={asset.id} assetId={asset.id} />;
}

function AssetDetailView({ assetId }: { assetId: string }) {
  const asset = getAsset(assetId)!;
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [range, setRange] = useState<HistoryRange>('3M');
  const [view, setView] = useState<'token' | 'reference'>('token');
  const [amount, setAmount] = useState(params.get('amount') ?? '100');
  const [question, setQuestion] = useState('');
  const [asked, setAsked] = useState<AskRequest>({ question: `Explain the ${asset.name} (${asset.symbol}) and its risks.`, assetId: asset.id });

  const ranged = useAssetInsights(asset, range);
  const yearly = useAssetInsights(asset, '1Y');
  const ref = ranged.valuation.referenceInstrumentId ? getInstrument(ranged.valuation.referenceInstrumentId) : undefined;
  const refHistory = useHistory(ref?.id, range, view === 'reference');
  const supply = useSampleSupply(asset);
  const comparing = useAppStore((s) => s.compare.includes(asset.id));
  const toggleCompare = useAppStore((s) => s.toggleCompare);
  const onchain = useOnchain();
  const chainAsset = onchain.snapshot.data?.assets[asset.tokenId];
  const stats = useMarketStats(ref?.id ?? null);

  const ai = useQuery({
    queryKey: ['ai', asked.question, asked.assetId],
    queryFn: () => askAssistant(asked, stats ? { [stats.instrumentId]: stats } : undefined),
    staleTime: 30 * 60_000,
  });

  const fixed = asset.pricing.kind === 'fixed';
  const showReference = view === 'reference' && !fixed;
  const series = showReference ? refHistory.data?.points : ranged.tokenSeries;
  const seriesStatsNow = useMemo(() => (series && series.length >= 2 ? seriesStats(series) : null), [series]);
  const sourceData = showReference ? refHistory.data : null;
  const calc = calculateOwnership({ amount: Number(amount), tokenPrice: ranged.valuation.tokenPrice ?? NaN, totalSupply: asset.totalSupply, available: supply.available });
  const scenarioTokens = calc.valid ? calc.tokens : 0;
  const quote = ranged.quote;
  const color = categoryColor(asset.category);

  const statRows: [string, string][] = seriesStatsNow
    ? [
        ['Period high', showReference && ref ? formatQuote(seriesStatsNow.high, ref.denomination, ref.decimals) : formatUsd(seriesStatsNow.high, 4)],
        ['Period low', showReference && ref ? formatQuote(seriesStatsNow.low, ref.denomination, ref.decimals) : formatUsd(seriesStatsNow.low, 4)],
        ['Change over period', formatPct(seriesStatsNow.changePct)],
        ['Annualised volatility', seriesStatsNow.volatility === null ? 'Needs 20+ observations' : `${formatNumber(seriesStatsNow.volatility * 100, 1)}%`],
        ['Largest decline', seriesStatsNow.maxDrawdown === null ? '—' : `${formatNumber(seriesStatsNow.maxDrawdown * 100, 1)}%`],
        ['Observations', seriesStatsNow.observations.toLocaleString('en-US')],
      ]
    : [];

  const ask = (q: string) => {
    const text = q.trim();
    if (text.length < 2) return;
    setAsked({ question: text, assetId: asset.id });
    setQuestion('');
  };

  return (
    <div className="space-y-6">
      <nav aria-label="Breadcrumb" className="flex items-center gap-1 text-[13px] text-muted-foreground">
        <Link to="/marketplace" className="hover:text-foreground">
          Marketplace
        </Link>
        <ChevronRight className="size-3.5" aria-hidden />
        <Link to={`/marketplace?category=${asset.category}`} className="hover:text-foreground">
          {CATEGORY_LABELS[asset.category]}
        </Link>
        <ChevronRight className="size-3.5" aria-hidden />
        <span className="text-foreground">{asset.name}</span>
      </nav>

      <header className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-4">
          <AssetIcon asset={asset} size="lg" />
          <div className="space-y-1">
            <h1 className="font-display text-[26px] font-bold leading-tight tracking-[-0.025em] md:text-[30px]">{asset.name}</h1>
            <div className="flex flex-wrap items-center gap-2 text-[13px] text-muted-foreground">
              <span>{asset.symbol}</span>
              <span aria-hidden>·</span>
              <span>{CATEGORY_LABELS[asset.category]}</span>
              <Badge variant={asset.kind === 'simulated' ? 'demo' : 'blue'}>{asset.kind === 'simulated' ? 'Simulated asset' : 'Market-referenced sample'}</Badge>
              <RiskBadge risk={yearly.risk} />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <WatchButton id={asset.id} label={asset.name} />
          <Button
            variant="outline"
            onClick={() => {
              const r = toggleCompare(asset.id);
              if (r.full) toast('You can compare up to three assets at a time.');
            }}
            aria-pressed={comparing}
          >
            <GitCompareArrows /> {comparing ? 'In comparison' : 'Compare'}
          </Button>
          <Button onClick={() => navigate(`/invest/${asset.id}${calc.valid ? `?amount=${encodeURIComponent(amount)}` : ''}`)}>Simulate investment</Button>
        </div>
      </header>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">
        <div className="min-w-0 space-y-6">
          <Card>
            <CardHeader className="gap-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                {fixed ? (
                  <CardTitle>Valuation history</CardTitle>
                ) : (
                  <Tabs value={view} onValueChange={(v: string) => setView(v as 'token' | 'reference')}>
                    <TabsList>
                      <TabsTrigger value="token">Illustrative token price</TabsTrigger>
                      <TabsTrigger value="reference">{asset.pricing.kind === 'bond' ? 'Reference yield' : 'Market reference'}</TabsTrigger>
                    </TabsList>
                  </Tabs>
                )}
                <Segmented<HistoryRange> label="Chart range" value={range} onChange={setRange} options={HISTORY_RANGES.map((r) => ({ value: r, label: r }))} />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {fixed ? (
                <EmptyState title="No market history" description="This is a fully simulated asset with a fixed illustrative valuation, so there is no price history to chart. VESTORA does not invent one." />
              ) : (
                <PriceChart
                  points={series}
                  range={range}
                  denomination={showReference && ref ? ref.denomination : 'USD-token'}
                  decimals={ref?.decimals ?? 2}
                  color={color}
                  loading={showReference ? refHistory.isLoading : ranged.historyLoading}
                  seriesLabel={showReference ? ref?.name ?? 'Reference' : `${asset.symbol} token (illustrative)`}
                  emptyTitle="No history for this range"
                  emptyMessage={(showReference ? refHistory.data?.message : undefined) ?? 'This instrument’s data source has no observations in this range. Try a longer range.'}
                />
              )}
              {!fixed && sourceData && <SourceLine data={sourceData} />}
              {!fixed && !showReference && ranged.tokenSeries.length > 0 && ranged.historySource && (
                <p className="text-xs text-muted-foreground">Token price series = sample formula applied to real reference history from {ranged.historySource}.</p>
              )}
            </CardContent>
          </Card>

          {statRows.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Market statistics</CardTitle>
                <CardDescription>
                  Computed from the {showReference ? 'reference' : 'illustrative token'} series shown above ({range}). Past movements do not predict future ones.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-3">
                  {statRows.map(([k, v]) => (
                    <div key={k} className="bg-card px-4 py-3">
                      <dt className="text-xs text-muted-foreground">{k}</dt>
                      <dd className="mt-0.5 text-sm font-medium tabular">{v}</dd>
                    </div>
                  ))}
                </dl>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>About this sample</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm leading-relaxed text-muted-foreground">
                <p>{asset.description}</p>
                <ul className="space-y-1.5">
                  {asset.highlights.map((h) => (
                    <li key={h} className="flex gap-2 text-foreground/90">
                      <span className="mt-2 size-1 shrink-0 rounded-full bg-gold" aria-hidden /> {h}
                    </li>
                  ))}
                </ul>
                {asset.assumptions && (
                  <div className="rounded-lg bg-muted px-3.5 py-3">
                    <p className="mb-1.5 text-xs font-medium text-foreground">Illustrative assumptions</p>
                    <ul className="space-y-1 text-xs">
                      {asset.assumptions.map((a) => (
                        <li key={a}>{a}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Tokenisation methodology</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm leading-relaxed text-muted-foreground">
                <p>{asset.methodology}</p>
                <div className="rounded-lg border border-border px-3.5 py-3 font-mono text-xs leading-relaxed text-foreground/90">{ranged.valuation.formula}</div>
                <p className="text-xs">
                  On the testnet this sample is ERC-1155 token id <span className="font-mono text-foreground">#{asset.tokenId}</span> in the AssetToken contract, issued at{' '}
                  {chainAsset ? chainAsset.price : asset.onchainPrice} vUSD demo credits per token.
                </p>
              </CardContent>
            </Card>
          </div>

          <section aria-labelledby="ai-heading" className="space-y-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 id="ai-heading" className="flex items-center gap-2 font-display text-lg font-semibold tracking-[-0.015em]">
                  <Sparkles className="size-4 text-gold" aria-hidden /> AI risk explanation
                </h2>
                <p className="text-[13px] text-muted-foreground">VESTORA Intelligence — understand before you invest.</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {contextualQuestions(asset).map((q) => (
                <button key={q} onClick={() => ask(q)} className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-border-strong hover:text-foreground">
                  {q}
                </button>
              ))}
            </div>
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                ask(question);
              }}
            >
              <Input value={question} onChange={(e) => setQuestion(e.target.value.slice(0, 600))} placeholder={`Ask about the ${asset.name.toLowerCase()}…`} aria-label="Ask VESTORA Intelligence" />
              <Button type="submit" variant="blue" disabled={question.trim().length < 2} aria-label="Ask">
                <Send />
              </Button>
            </form>
            {ai.isLoading ? (
              <div className="space-y-3 rounded-xl border border-border bg-card p-5">
                <span className="skeleton block h-5 w-2/3" />
                <span className="skeleton block h-4 w-full" />
                <span className="skeleton block h-4 w-5/6" />
                <span className="skeleton block h-24 w-full" />
              </div>
            ) : ai.error ? (
              <ErrorState title="The assistant could not answer" description={(ai.error as Error).message} action={<Button size="sm" variant="outline" onClick={() => ai.refetch()}>Try again</Button>} />
            ) : ai.data ? (
              <AnswerCard answer={ai.data} onFollowUp={ask} />
            ) : null}
          </section>
        </div>

        <aside className="space-y-6">
          <Card>
            <CardHeader className="gap-2">
              <div className="flex items-center justify-between gap-2">
                <CardTitle>{fixed ? 'Valuation' : asset.pricing.kind === 'bond' ? 'Reference yield' : 'Live market price'}</CardTitle>
                {quote && !fixed && <DataStatusBadge status={quote.status} frequency={quote.frequency} />}
              </div>
              {ref && <CardDescription>{ref.name}</CardDescription>}
            </CardHeader>
            <CardContent className="space-y-3">
              {fixed ? (
                <p className="text-sm text-muted-foreground">No market reference — this asset uses a fixed illustrative valuation of {formatUsd(ranged.valuation.sampleValue, 0)}.</p>
              ) : (
                <>
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-[28px] font-semibold tracking-[-0.02em] tabular">{ref ? formatQuote(ranged.valuation.referencePrice, ref.denomination, ref.decimals) : '—'}</span>
                    {ref && ref.denomination !== 'percent' && <span className="text-xs text-muted-foreground">{unitLabel(ref)}</span>}
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <PriceChange pct={quote?.changePct} basis={quote?.changeBasis} size="md" />
                    {quote?.changeBasis && <span className="text-xs text-muted-foreground">{BASIS_LABEL[quote.changeBasis]}</span>}
                  </div>
                  {quote && <SourceLine data={quote} />}
                  {quote?.message && <p className="text-xs text-muted-foreground">{quote.message}</p>}
                </>
              )}
            </CardContent>
          </Card>

          <Card className="border-gold/20">
            <CardHeader className="gap-2">
              <div className="flex items-center justify-between">
                <CardTitle>Token price</CardTitle>
                <IllustrativeBadge />
              </div>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="font-display text-[28px] font-semibold tracking-[-0.02em] tabular">{formatUsd(ranged.valuation.tokenPrice, (ranged.valuation.tokenPrice ?? 0) < 1 ? 4 : 2)}</div>
              <dl className="space-y-1.5 text-[13px]">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Sample asset value</dt>
                  <dd className="tabular">{formatUsd(ranged.valuation.sampleValue, 0)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Token supply</dt>
                  <dd className="tabular">{asset.totalSupply.toLocaleString('en-US')}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Input data</dt>
                  <dd>{ranged.valuation.inputStatus === 'fixed' ? 'Fixed valuation' : <DataStatusBadge status={ranged.valuation.inputStatus} withTooltip={false} />}</dd>
                </div>
              </dl>
              <p className="text-xs text-muted-foreground">Not a market price. A token is not a claim on any commodity, property or bond.</p>
            </CardContent>
          </Card>

          <OwnershipCalculator asset={asset} valuation={ranged.valuation} available={supply.available} amount={amount} onAmountChange={setAmount} />
          <ScenarioSimulator asset={asset} valuation={ranged.valuation} tokens={scenarioTokens} />

          <Card>
            <CardHeader>
              <CardTitle>Sample token supply</CardTitle>
              <CardDescription>Demo mode shows simulated issuance; the testnet figure comes from the contract when your wallet is connected.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <SupplyBar issued={supply.issued} total={asset.totalSupply} label="Simulated issuance" />
              {chainAsset ? (
                <SupplyBar issued={chainAsset.maxSupply - chainAsset.available} total={chainAsset.maxSupply} label="On-chain (testnet) minted" />
              ) : (
                <p className="text-xs text-muted-foreground">Connect a wallet on the supported testnet to read on-chain supply.</p>
              )}
              {supply.held > 0 && <p className="text-xs text-muted-foreground">You hold {supply.held.toLocaleString('en-US')} simulated tokens.</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Risk indicators</CardTitle>
              <CardDescription>
                {yearly.risk.level} · {yearly.risk.score.toFixed(1)}/10.{' '}
                <Link to="/learn/risk-score" className="text-blue hover:underline">
                  Methodology
                </Link>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RiskBreakdown risk={yearly.risk} />
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}
