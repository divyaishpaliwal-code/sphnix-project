import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import { useQueries } from '@tanstack/react-query';
import { BellPlus, Search } from 'lucide-react';
import { toast } from 'sonner';
import {
  DATA_DISCLAIMER,
  HISTORY_RANGES,
  INSTRUMENTS,
  INSTRUMENT_CLASS_LABELS,
  formatNumber,
  formatPct,
  formatQuote,
  getInstrument,
  relativeTime,
  seriesStats,
  unitLabel,
  type HistoryRange,
  type InstrumentClass,
} from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Segmented } from '@/components/ui/primitives';
import { Table, TBody, TD, TH, THead, TR } from '@/components/ui/table';
import { Disclaimer, PageHeader } from '@/components/common/States';
import { WatchButton } from '@/components/assets/AssetBits';
import { ComparisonChart } from '@/components/charts/ComparisonChart';
import { MoversChart, type Mover } from '@/components/charts/MoversChart';
import { PriceChart } from '@/components/charts/PriceChart';
import { DataStatusBadge, SourceLine } from '@/components/market/DataStatus';
import { BASIS_LABEL, PriceChange } from '@/components/market/PriceChange';
import { Sparkline } from '@/components/market/Sparkline';
import { useAllQuotes, useHistory } from '@/hooks/useMarket';
import { classColor, COMPARE_SLOTS, slotColor } from '@/lib/chart-colors';
import { cn } from '@/lib/utils';
import { fetchHistory } from '@/services/market';
import { useAppStore } from '@/store/app';

type ClassFilter = 'all' | InstrumentClass;
const CLASS_ORDER: InstrumentClass[] = ['precious-metals', 'energy', 'industrial-metals', 'agriculture', 'digital-assets', 'rates', 'indices'];

function AlertDialog({ instrumentId, open, onOpenChange }: { instrumentId: string; open: boolean; onOpenChange: (v: boolean) => void }) {
  const inst = getInstrument(instrumentId)!;
  const { quotes } = useAllQuotes();
  const addAlert = useAppStore((s) => s.addAlert);
  const current = quotes[instrumentId]?.price ?? null;
  const [direction, setDirection] = useState<'above' | 'below'>('above');
  const [price, setPrice] = useState(current ? String(Number((current * 1.02).toPrecision(5))) : '');
  const n = Number(price);
  const valid = price !== '' && Number.isFinite(n) && n > 0;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Price alert for {inst.name}</DialogTitle>
          <DialogDescription>Demo alert: you’ll get an in-app notification while VESTORA is open. Alerts only trigger on live, delayed or historical data — never on demo values.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Segmented label="Direction" value={direction} onChange={setDirection} options={[{ value: 'above', label: 'Rises above' }, { value: 'below', label: 'Falls below' }]} />
          <div className="space-y-2">
            <Label htmlFor="alert-price">Target ({unitLabel(inst)})</Label>
            <Input id="alert-price" type="number" step="any" min={0} value={price} onChange={(e) => setPrice(e.target.value)} aria-invalid={(price !== '' && !valid) || undefined} />
            <FieldHint error={price !== '' && !valid}>{price !== '' && !valid ? 'Enter a positive number.' : current ? `Now ${formatQuote(current, inst.denomination, inst.decimals)}` : 'Current price unavailable.'}</FieldHint>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            disabled={!valid}
            onClick={() => {
              addAlert({ target: { kind: 'instrument', id: instrumentId }, direction, price: n });
              toast.success(`Alert set: ${inst.shortName} ${direction} ${formatQuote(n, inst.denomination, inst.decimals)}`);
              onOpenChange(false);
            }}
          >
            Set alert
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Markets() {
  const [params, setParams] = useSearchParams();
  const focus = getInstrument(params.get('focus') ?? '') ? (params.get('focus') as string) : 'XAU';
  const [range, setRange] = useState<HistoryRange>('3M');
  const [classFilter, setClassFilter] = useState<ClassFilter>('all');
  const [search, setSearch] = useState('');
  const [alertOpen, setAlertOpen] = useState(false);
  const [metalsRange, setMetalsRange] = useState<HistoryRange>('1Y');
  const [compareIds, setCompareIds] = useState<string[]>(['XAU', 'WTI', 'COPPER', 'BTC']);
  const [compareRange, setCompareRange] = useState<HistoryRange>('1Y');
  const topRef = useRef<HTMLDivElement>(null);
  const { quotes, isLoading, generatedAt, mode, refetch, isFetching } = useAllQuotes();

  const inst = getInstrument(focus)!;
  const q = quotes[focus];
  const hist = useHistory(focus, range);
  const st = useMemo(() => (hist.data && hist.data.points.length >= 2 ? seriesStats(hist.data.points) : null), [hist.data]);

  useEffect(() => {
    if (params.get('focus')) topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [params]);

  const metals = useQueries({ queries: ['XAU', 'XAG'].map((id) => ({ queryKey: ['history', id, metalsRange], queryFn: () => fetchHistory(id, metalsRange), staleTime: 10 * 60_000 })) });
  const compare = useQueries({ queries: compareIds.map((id) => ({ queryKey: ['history', id, compareRange], queryFn: () => fetchHistory(id, compareRange), staleTime: 10 * 60_000 })) });

  const movers: Mover[] = useMemo(
    () =>
      INSTRUMENTS.map((i) => quotes[i.id])
        .filter((x) => x && x.changePct !== null && (x.status === 'realtime' || x.status === 'delayed') && x.frequency !== 'monthly')
        .map((x) => ({ key: x.instrumentId, label: getInstrument(x.instrumentId)!.shortName, pct: x.changePct as number, basis: x.changeBasis ? BASIS_LABEL[x.changeBasis] : 'Latest change' }))
        .sort((a, b) => b.pct - a.pct),
    [quotes],
  );
  const shownMovers = movers.length > 12 ? [...movers.slice(0, 6), ...movers.slice(-6)] : movers;

  const rows = INSTRUMENTS.filter((i) => (classFilter === 'all' || i.class === classFilter) && (!search || `${i.name} ${i.symbol} ${i.keywords.join(' ')}`.toLowerCase().includes(search.toLowerCase())));

  const select = (id: string) => {
    const next = new URLSearchParams(params);
    next.set('focus', id);
    setParams(next, { replace: true });
  };

  const toggleCompare = (id: string) =>
    setCompareIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : ids.length >= 4 ? (toast('Compare up to four instruments at once.'), ids) : [...ids, id]));

  return (
    <div className="space-y-6" ref={topRef}>
      <PageHeader
        title="Market overview"
        description="Commodities, digital assets, Treasury yields and indices from public data providers. Every figure carries its source, status and observation time."
        actions={
          <Button variant="outline" size="sm" onClick={() => refetch()} loading={isFetching}>
            Refresh
          </Button>
        }
      />
      <Disclaimer>
        {DATA_DISCLAIMER} {mode === 'browser' ? 'The API server is offline, so only crypto prices are live right now.' : ''} {generatedAt ? `Last refreshed ${relativeTime(generatedAt)}.` : ''}
      </Disclaimer>

      <Card>
        <CardHeader className="gap-4">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle className="text-lg">{inst.name}</CardTitle>
                {q && <DataStatusBadge status={q.status} frequency={q.frequency} />}
              </div>
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <span className="font-display text-[28px] font-semibold tracking-[-0.02em] tabular">{q ? formatQuote(q.price, inst.denomination, inst.decimals) : '—'}</span>
                <span className="text-xs text-muted-foreground">{unitLabel(inst)}</span>
                <PriceChange pct={q?.changePct} basis={q?.changeBasis} showBasis size="md" />
              </div>
              <CardDescription>{inst.description}</CardDescription>
            </div>
            <div className="flex items-center gap-1">
              <WatchButton id={`i:${focus}`} label={inst.name} />
              <Button variant="outline" size="sm" onClick={() => setAlertOpen(true)}>
                <BellPlus /> Price alert
              </Button>
            </div>
          </div>
          <Segmented<HistoryRange> label="Chart range" value={range} onChange={setRange} options={HISTORY_RANGES.map((r) => ({ value: r, label: r }))} />
        </CardHeader>
        <CardContent className="space-y-4">
          <PriceChart
            points={hist.data?.points}
            range={range}
            denomination={inst.denomination}
            decimals={inst.decimals}
            color={classColor(inst.class)}
            loading={hist.isLoading}
            height={300}
            seriesLabel={inst.shortName}
            emptyTitle={hist.data?.status === 'unavailable' ? 'Historical data unavailable' : 'No observations in this range'}
            emptyMessage={hist.data?.message}
          />
          {hist.data && hist.data.points.length > 0 && <SourceLine data={hist.data} />}
          {st && (
            <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-border bg-border text-sm sm:grid-cols-5">
              {[
                ['High', formatQuote(st.high, inst.denomination, inst.decimals)],
                ['Low', formatQuote(st.low, inst.denomination, inst.decimals)],
                ['Change', formatPct(st.changePct)],
                ['Volatility (ann.)', st.volatility === null ? 'n/a' : `${formatNumber(st.volatility * 100, 1)}%`],
                ['Observations', st.observations.toLocaleString('en-US')],
              ].map(([k, v]) => (
                <div key={k} className="bg-card px-3.5 py-2.5">
                  <dt className="text-xs text-muted-foreground">{k}</dt>
                  <dd className="tabular">{v}</dd>
                </div>
              ))}
            </dl>
          )}
          {inst.class === 'rates' && st?.volatility !== null && <p className="text-xs text-muted-foreground">For yields, volatility describes how much the yield level moves — not the price of a bond.</p>}
        </CardContent>
      </Card>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader className="flex-row flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Gold and silver price history</CardTitle>
              <CardDescription>Indexed to 100 at the start of the range, so both fit one honest axis.</CardDescription>
            </div>
            <Segmented<HistoryRange> label="Gold and silver range" value={metalsRange} onChange={setMetalsRange} options={(['1M', '3M', '1Y', 'ALL'] as HistoryRange[]).map((r) => ({ value: r, label: r }))} />
          </CardHeader>
          <CardContent>
            <ComparisonChart
              range={metalsRange}
              height={260}
              loading={metals.some((m) => m.isLoading)}
              series={[
                { key: 'XAU', label: `Gold${metals[0]?.data?.proxy ? ' (PAXG proxy)' : ''}`, color: slotColor(4), points: metals[0]?.data?.points ?? [] },
                { key: 'XAG', label: 'Silver', color: slotColor(1), points: metals[1]?.data?.points ?? [] },
              ]}
            />
            {metals.some((m) => m.data?.status === 'unavailable') && (
              <p className="mt-3 text-xs text-muted-foreground">Silver history needs a metals data key (Twelve Data) on the API server; it is left out rather than estimated.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Market gainers and losers</CardTitle>
            <CardDescription>Latest change on live or delayed data (24h or previous close). Monthly and demo figures are excluded.</CardDescription>
          </CardHeader>
          <CardContent>
            {shownMovers.length ? (
              <MoversChart movers={shownMovers} />
            ) : (
              <p className="py-10 text-center text-[13px] text-muted-foreground">{isLoading ? 'Loading prices…' : 'No live or delayed changes available right now.'}</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="gap-3">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Commodity performance comparison</CardTitle>
              <CardDescription>Pick up to four instruments. Each line is indexed to 100 at the start of the range.</CardDescription>
            </div>
            <Segmented<HistoryRange> label="Comparison range" value={compareRange} onChange={setCompareRange} options={(['1M', '3M', '1Y', 'ALL'] as HistoryRange[]).map((r) => ({ value: r, label: r }))} />
          </div>
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="Instruments to compare">
            {INSTRUMENTS.filter((i) => i.class !== 'rates').map((i) => {
              const on = compareIds.includes(i.id);
              return (
                <button
                  key={i.id}
                  aria-pressed={on}
                  onClick={() => toggleCompare(i.id)}
                  className={cn('rounded-full border px-2.5 py-1 text-xs transition-colors', on ? 'border-blue/40 bg-blue-soft text-foreground' : 'border-border text-muted-foreground hover:text-foreground')}
                >
                  {i.shortName}
                </button>
              );
            })}
          </div>
        </CardHeader>
        <CardContent>
          <ComparisonChart
            range={compareRange}
            loading={compare.some((c) => c.isLoading)}
            series={compareIds.map((id, idx) => ({ key: id, label: getInstrument(id)!.shortName, color: slotColor(COMPARE_SLOTS[idx]), points: compare[idx]?.data?.points ?? [] }))}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="gap-3">
          <CardTitle>All instruments</CardTitle>
          <div className="flex flex-col gap-3 md:flex-row md:items-center">
            <div className="relative md:w-72">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search instruments" className="pl-9" aria-label="Search instruments" />
            </div>
            <div className="no-scrollbar -mx-1 flex gap-1 overflow-x-auto px-1">
              {(['all', ...CLASS_ORDER] as ClassFilter[]).map((c) => (
                <button
                  key={c}
                  onClick={() => setClassFilter(c)}
                  aria-pressed={classFilter === c}
                  className={cn('shrink-0 rounded-md px-2.5 py-1.5 text-xs transition-colors', classFilter === c ? 'bg-muted text-foreground' : 'text-muted-foreground hover:text-foreground')}
                >
                  {c === 'all' ? 'All' : INSTRUMENT_CLASS_LABELS[c]}
                </button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-0 pb-2">
          <Table>
            <THead>
              <TR>
                <TH>Instrument</TH>
                <TH className="text-right">Price</TH>
                <TH className="text-right">Change</TH>
                <TH>Basis</TH>
                <TH>Status</TH>
                <TH className="hidden md:table-cell">Source</TH>
                <TH className="hidden lg:table-cell">Observation</TH>
                <TH className="hidden sm:table-cell">1M</TH>
                <TH>
                  <span className="sr-only">Watch</span>
                </TH>
              </TR>
            </THead>
            <TBody>
              {rows.map((i) => (
                <InstrumentRow key={i.id} id={i.id} selected={i.id === focus} onSelect={() => select(i.id)} />
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
      <AlertDialog key={focus} instrumentId={focus} open={alertOpen} onOpenChange={setAlertOpen} />
    </div>
  );
}

function InstrumentRow({ id, selected, onSelect }: { id: string; selected: boolean; onSelect: () => void }) {
  const inst = getInstrument(id)!;
  const { quotes, isLoading } = useAllQuotes();
  const q = quotes[id];
  const { data } = useHistory(id, '1M');
  return (
    <TR className={cn('cursor-pointer hover:bg-muted/50', selected && 'bg-muted/60')} onClick={onSelect}>
      <TD>
        <button className="text-left focus-visible:outline-2 focus-visible:outline-ring" onClick={onSelect}>
          <span className="block font-medium text-foreground">{inst.name}</span>
          <span className="block text-xs text-muted-foreground">
            {inst.symbol} · {unitLabel(inst)}
          </span>
        </button>
      </TD>
      <TD className="text-right tabular">{isLoading ? <span className="skeleton ml-auto inline-block h-4 w-16" /> : q ? formatQuote(q.price, inst.denomination, inst.decimals) : '—'}</TD>
      <TD className="text-right">
        <PriceChange pct={q?.changePct} />
      </TD>
      <TD className="text-xs text-muted-foreground">{q?.changeBasis ? BASIS_LABEL[q.changeBasis] : '—'}</TD>
      <TD>{q && <DataStatusBadge status={q.status} frequency={q.frequency} />}</TD>
      <TD className="hidden max-w-48 truncate text-xs text-muted-foreground md:table-cell">
        {q?.source.name}
        {q?.proxy ? ` (${q.proxy.symbol} proxy)` : ''}
      </TD>
      <TD className="hidden text-xs text-muted-foreground lg:table-cell">{q?.asOf ? relativeTime(q.asOf) : '—'}</TD>
      <TD className="hidden sm:table-cell">
        <Sparkline points={data?.points} width={88} height={26} label={`${inst.name} one-month trend`} />
      </TD>
      <TD onClick={(e) => e.stopPropagation()}>
        <WatchButton id={`i:${id}`} label={inst.name} />
      </TD>
    </TR>
  );
}
