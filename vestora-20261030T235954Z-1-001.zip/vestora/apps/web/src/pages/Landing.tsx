import { useMemo, type ReactNode } from 'react';
import { Link } from 'react-router';
import { motion } from 'framer-motion';
import { Blocks, FlaskConical, KeyRound, ScanFace, ShieldCheck, Sparkles, Tag } from 'lucide-react';
import {
  KYC_DISCLAIMER,
  TICKER_INSTRUMENTS,
  answerQuestion,
  formatQuote,
  formatUsd,
  getAsset,
  getInstrument,
  shortAddress,
  type TokenisedAsset,
} from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { AssetCard } from '@/components/assets/AssetCard';
import { AnswerCard } from '@/components/ai/AnswerCard';
import { HeroVisual } from '@/components/landing/HeroVisual';
import { MarketingHeader, SiteFooter } from '@/components/layout/Marketing';
import { DataStatusBadge } from '@/components/market/DataStatus';
import { MarketTicker } from '@/components/market/MarketTicker';
import { PriceChange } from '@/components/market/PriceChange';
import { Sparkline } from '@/components/market/Sparkline';
import { TARGET_CHAIN, explorerAddress } from '@/config/chains';
import { useAllQuotes, useHistory, useValuations } from '@/hooks/useMarket';
import { useReducedMotion } from '@/hooks/useTheme';
import { contractConfig } from '@/services/web3/contracts';

function Section({ id, title, intro, children, className }: { id?: string; title: string; intro?: string; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={`mx-auto max-w-[1240px] px-4 py-20 sm:px-6 md:py-24 ${className ?? ''}`}>
      <div className="mb-10 max-w-2xl space-y-3">
        <h2 className="font-display text-[28px] font-bold leading-tight tracking-[-0.03em] md:text-[36px]">{title}</h2>
        {intro && <p className="text-[15px] leading-relaxed text-muted-foreground">{intro}</p>}
      </div>
      {children}
    </section>
  );
}

function MarketTile({ id }: { id: string }) {
  const inst = getInstrument(id)!;
  const { quotes, isLoading } = useAllQuotes();
  const q = quotes[id];
  const { data } = useHistory(id, '1M');
  return (
    <Link to={`/markets?focus=${id}`} className="group flex flex-col gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-border-strong focus-visible:outline-2 focus-visible:outline-ring">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-sm font-medium text-foreground">{inst.shortName}</p>
          <p className="text-xs text-muted-foreground">{inst.symbol}</p>
        </div>
        {q && <DataStatusBadge status={q.status} frequency={q.frequency} withTooltip={false} />}
      </div>
      {isLoading ? (
        <span className="skeleton h-6 w-28" />
      ) : (
        <div className="flex items-baseline justify-between gap-2">
          <span className="font-display text-lg font-semibold tabular">{q ? formatQuote(q.price, inst.denomination, inst.decimals) : '—'}</span>
          <PriceChange pct={q?.changePct} basis={q?.changeBasis} />
        </div>
      )}
      <Sparkline points={data?.points} width={220} height={38} className="w-full" label={`${inst.name} one-month trend`} />
      <p className="truncate text-[11px] text-subtle">{q ? `${q.source.name}${q.proxy ? ` (${q.proxy.symbol} proxy)` : ''}` : 'Loading source…'}</p>
    </Link>
  );
}

const STEPS = [
  { title: 'Choose a sample asset', body: 'Each asset is a fictional pool with a published formula — for example, 50 troy oz of gold divided into 20,000 tokens.' },
  { title: 'Verify, in simulation', body: 'A mock KYC flow shows how regulated platforms check identity. No documents are collected and nothing is sent anywhere.' },
  { title: 'Buy a fraction', body: 'Use simulated cash in demo mode, or sign a real Sepolia testnet transaction with MetaMask and free demo credits.' },
  { title: 'Track and understand', body: 'Follow live reference prices, allocation and risk — with plain-language explanations from VESTORA Intelligence.' },
];

function AccessibilityComparison() {
  const { quotes, valuations } = useValuations();
  const rows = useMemo(() => {
    const xau = quotes.XAU;
    const wti = quotes.WTI;
    const v = (id: string) => valuations[id]?.tokenPrice ?? null;
    return [
      {
        asset: 'Gold',
        traditional: 'One 1 kg bar (32.15 troy oz)',
        cost: xau?.price ? 32.1507 * xau.price : null,
        status: xau?.status,
        fractional: v('vgld'),
        sample: getAsset('vgld')!,
      },
      {
        asset: 'Crude oil',
        traditional: 'One WTI futures contract (1,000 barrels, notional)',
        cost: wti?.price ? 1000 * wti.price : null,
        status: wti?.status,
        fractional: v('vwti'),
        sample: getAsset('vwti')!,
      },
      {
        asset: 'US Treasuries',
        traditional: 'Minimum purchase via TreasuryDirect',
        cost: 100,
        status: undefined,
        fractional: v('vust10'),
        sample: getAsset('vust10')!,
      },
      {
        asset: 'Real estate',
        traditional: 'A whole property, usually with a large deposit and a mortgage',
        cost: null,
        status: undefined,
        fractional: v('vres'),
        sample: getAsset('vres')!,
      },
    ] as { asset: string; traditional: string; cost: number | null; status?: string; fractional: number | null; sample: TokenisedAsset }[];
  }, [quotes, valuations]);

  return (
    <div className="overflow-hidden rounded-xl border border-border">
      <div className="hidden grid-cols-[1fr_1.6fr_1fr] gap-4 border-b border-border bg-surface/60 px-5 py-3 text-xs text-muted-foreground md:grid">
        <span>Asset</span>
        <span>Traditional starting point</span>
        <span>Fractional sample on VESTORA</span>
      </div>
      <ul className="divide-y divide-border">
        {rows.map((r) => (
          <li key={r.asset} className="grid gap-2 px-5 py-4 md:grid-cols-[1fr_1.6fr_1fr] md:items-center md:gap-4">
            <span className="font-medium text-foreground">{r.asset}</span>
            <span className="text-sm text-muted-foreground">
              {r.traditional}
              {r.cost !== null && (
                <span className="ml-2 font-medium tabular text-foreground">
                  ≈ {formatUsd(r.cost, 0)}
                  {r.status === 'demo' && <span className="ml-1 text-xs font-normal text-demo">(demo value)</span>}
                </span>
              )}
            </span>
            <span className="text-sm">
              <span className="font-display text-base font-semibold tabular text-gold">{formatUsd(r.fractional)}</span>
              <span className="ml-1.5 text-xs text-muted-foreground">for 1 {r.sample.symbol} token</span>
            </span>
          </li>
        ))}
      </ul>
      <p className="border-t border-border bg-surface/40 px-5 py-3 text-xs text-muted-foreground">
        Illustrative. Traditional figures are computed from the current reference prices shown on this page; token prices are illustrative and carry no ownership claim.
        Smaller tickets do not make an asset less risky.
      </p>
    </div>
  );
}

function TransparencyPanel() {
  const cfg = contractConfig();
  const rows: { label: string; value: ReactNode }[] = [
    { label: 'Network', value: `${TARGET_CHAIN.name} testnet (chain ${TARGET_CHAIN.id})` },
    {
      label: 'AssetToken (ERC-1155)',
      value: cfg.assetToken ? (
        <a className="font-mono text-xs text-blue hover:underline" href={explorerAddress(cfg.assetToken) ?? '#'} target="_blank" rel="noreferrer">
          {shortAddress(cfg.assetToken, 6)}
        </a>
      ) : (
        <span className="text-muted-foreground">Not deployed in this build</span>
      ),
    },
    {
      label: 'ComplianceManager',
      value: cfg.compliance ? (
        <a className="font-mono text-xs text-blue hover:underline" href={explorerAddress(cfg.compliance) ?? '#'} target="_blank" rel="noreferrer">
          {shortAddress(cfg.compliance, 6)}
        </a>
      ) : (
        <span className="text-muted-foreground">Not deployed in this build</span>
      ),
    },
    { label: 'Token ids', value: 'id 0 = vUSD demo credits · ids 1–15 = sample assets' },
  ];
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="rounded-xl border border-border bg-card">
        <dl className="divide-y divide-border">
          {rows.map((r) => (
            <div key={r.label} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3.5 text-sm">
              <dt className="text-muted-foreground">{r.label}</dt>
              <dd className="text-right text-foreground">{r.value}</dd>
            </div>
          ))}
        </dl>
        {!cfg.configured && (
          <p className="border-t border-border px-5 py-3 text-xs text-muted-foreground">
            Deploy with <code className="rounded bg-muted px-1 py-0.5">npm run contracts:deploy:sepolia</code> and the addresses appear here automatically.
          </p>
        )}
      </div>
      <ol className="space-y-3">
        {[
          ['buy(assetId = 1, amount = 5)', 'You sign a testnet transaction in MetaMask.'],
          ['ComplianceManager.isVerified(you)', 'The contract — not just the website — checks your (mock) verification.'],
          ['burn 50 vUSD → mint 5 vGLD', 'Demo credits are burned and sample tokens minted within the supply cap.'],
          ['emit AssetPurchased(...)', 'An event anyone can read on the block explorer — VESTORA shows it in Transactions.'],
        ].map(([code, text], i) => (
          <li key={code} className="flex gap-4 rounded-xl border border-border bg-card px-4 py-3.5">
            <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-muted text-xs tabular text-muted-foreground">{i + 1}</span>
            <div className="min-w-0 space-y-1">
              <code className="block truncate font-mono text-[13px] text-foreground">{code}</code>
              <p className="text-[13px] text-muted-foreground">{text}</p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

export default function Landing() {
  const reduced = useReducedMotion();
  const preview = useMemo(() => answerQuestion({ question: 'Is gold a risky investment?' }), []);
  const featured = ['vgld', 'vust10', 'vres'].map((id) => getAsset(id)!);
  const enter = reduced ? {} : { initial: { opacity: 0, y: 14 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const } };

  return (
    <div className="min-h-dvh bg-background">
      <MarketingHeader />
      <main id="main">
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="mx-auto grid max-w-[1240px] items-center gap-12 px-4 pb-16 pt-14 sm:px-6 md:pt-20 lg:grid-cols-[1.05fr_1fr] lg:pb-24">
            <motion.div {...enter} className="max-w-xl space-y-7">
              <h1 className="font-display text-[44px] font-extrabold leading-[1.02] tracking-[-0.045em] text-foreground sm:text-[60px] lg:text-[72px]">Invest Beyond Limits.</h1>
              <p className="max-w-lg text-[17px] leading-relaxed text-muted-foreground">
                From gold to global assets, access fractional ownership and explore the future of investing — starting small.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button size="lg" asChild>
                  <Link to="/marketplace">Explore Marketplace</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link to="/portfolio">Launch Your Portfolio</Link>
                </Button>
              </div>
              <ul className="grid gap-3 pt-2 text-[13px] text-muted-foreground sm:grid-cols-3">
                <li className="flex items-start gap-2">
                  <FlaskConical className="mt-0.5 size-4 shrink-0 text-gold" aria-hidden /> Testnet only — no real money moves
                </li>
                <li className="flex items-start gap-2">
                  <Tag className="mt-0.5 size-4 shrink-0 text-gold" aria-hidden /> Every price shows its source and status
                </li>
                <li className="flex items-start gap-2">
                  <Sparkles className="mt-0.5 size-4 shrink-0 text-gold" aria-hidden /> AI explanations, never advice
                </li>
              </ul>
            </motion.div>
            <HeroVisual />
          </div>
        </section>

        <MarketTicker />

        <Section title="Markets right now" intro="Reference prices from public data providers. Live, delayed, monthly and demo figures are labelled — VESTORA never fills gaps with made-up numbers.">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {TICKER_INSTRUMENTS.map((id) => (
              <MarketTile key={id} id={id} />
            ))}
          </div>
          <div className="mt-6">
            <Button variant="outline" asChild>
              <Link to="/markets">Open all markets</Link>
            </Button>
          </div>
        </Section>

        <Section title="How tokenised investing works" intro="Four steps, each one explained as you go. Nothing here involves real money or real ownership.">
          <ol className="grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
            {STEPS.map((s, i) => (
              <li key={s.title} className="space-y-3 bg-card p-6">
                <span className="font-display text-sm font-semibold tabular text-gold">Step {i + 1}</span>
                <h3 className="font-display text-[17px] font-semibold tracking-[-0.015em]">{s.title}</h3>
                <p className="text-[13px] leading-relaxed text-muted-foreground">{s.body}</p>
              </li>
            ))}
          </ol>
        </Section>

        <Section title="Featured sample assets" intro="A commodity pool priced from live gold, a tokenised-bond sample priced from the live 10-year Treasury yield, and a fully simulated property.">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {featured.map((a) => (
              <AssetCard key={a.id} asset={a} />
            ))}
          </div>
        </Section>

        <Section title="What it takes to start" intro="Traditional routes into these markets often need thousands of dollars. Fractions change the entry point — not the risk.">
          <AccessibilityComparison />
        </Section>

        <section className="border-y border-border bg-surface/40">
          <div className="mx-auto grid max-w-[1240px] items-start gap-12 px-4 py-20 sm:px-6 md:py-24 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="space-y-6 lg:sticky lg:top-24">
              <p className="flex items-center gap-2 text-sm font-medium text-gold">
                <Sparkles className="size-4" aria-hidden /> VESTORA Intelligence
              </p>
              <h2 className="font-display text-[32px] font-bold leading-tight tracking-[-0.03em] md:text-[40px]">Understand before you invest.</h2>
              <p className="text-[15px] leading-relaxed text-muted-foreground">
                Ask about any asset or concept and get a structured, plain-language answer: what it is, what moves its price, what could go wrong, and how volatile it has been
                — measured from real data where available.
              </p>
              <ul className="space-y-3 text-sm text-foreground/90">
                {[
                  'A deterministic risk score with a published methodology',
                  'Bull and bear scenarios — never predictions or targets',
                  'Grounded in curated facts; live AI only through a secure server',
                  'Refuses personal buy or sell advice, every time',
                ].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <ShieldCheck className="mt-0.5 size-4 shrink-0 text-gold" aria-hidden /> {t}
                  </li>
                ))}
              </ul>
              <Button asChild>
                <Link to="/intelligence">Ask VESTORA Intelligence</Link>
              </Button>
            </div>
            <AnswerCard answer={preview} compact />
          </div>
        </section>

        <Section title="Blockchain transparency" intro="Sample tokens live in an ERC-1155 contract on a public testnet. Anyone can inspect the rules and every purchase event.">
          <TransparencyPanel />
        </Section>

        <Section title="Security and compliance, in plain terms" className="pt-0 md:pt-0">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: FlaskConical, title: 'Testnet only', body: 'Balances are simulated or use testnet tokens with no monetary value. Nothing can be converted into real money.' },
              { icon: ScanFace, title: 'Simulated KYC', body: KYC_DISCLAIMER },
              { icon: KeyRound, title: 'Keys stay server-side', body: 'AI and data-provider keys live only on the API server. Private keys and seed phrases are never requested.' },
              { icon: Blocks, title: 'Unaudited contracts', body: 'The contracts are teaching examples built on OpenZeppelin libraries — not audited, and not for real assets.' },
            ].map((c) => (
              <div key={c.title} className="space-y-3 rounded-xl border border-border bg-card p-5">
                <c.icon className="size-5 text-gold" aria-hidden />
                <h3 className="font-display text-[15px] font-semibold">{c.title}</h3>
                <p className="text-[13px] leading-relaxed text-muted-foreground">{c.body}</p>
              </div>
            ))}
          </div>
        </Section>

        <section className="mx-auto max-w-[1240px] px-4 pb-24 sm:px-6">
          <div className="relative overflow-hidden rounded-2xl border border-gold/25 bg-card px-6 py-14 text-center md:px-16">
            <div className="absolute inset-x-0 -top-24 mx-auto h-48 w-2/3 rounded-full blur-3xl" style={{ background: 'var(--hero-glow)' }} aria-hidden />
            <h2 className="relative mx-auto max-w-2xl font-display text-[30px] font-bold leading-tight tracking-[-0.03em] md:text-[40px]">
              Investing shouldn’t depend on how much you start with.
            </h2>
            <p className="relative mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
              Explore fractional ownership with simulated money first, and understand the risks before anything else.
            </p>
            <div className="relative mt-8 flex flex-wrap justify-center gap-3">
              <Button size="lg" asChild>
                <Link to="/marketplace">Explore Marketplace</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/portfolio">Launch Your Portfolio</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
