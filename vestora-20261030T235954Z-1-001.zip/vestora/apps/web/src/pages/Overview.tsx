import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router';
import { ArrowUpRight, Newspaper, ShieldCheck, Sparkles } from 'lucide-react';
import {
  SUGGESTED_QUESTIONS,
  TICKER_INSTRUMENTS,
  TOKENISED_ASSETS,
  formatPct,
  formatQuote,
  formatUsd,
  getInstrument,
  relativeTime,
} from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Disclaimer, EmptyState, PageHeader, StatTile } from '@/components/common/States';
import { AssetIcon } from '@/components/assets/AssetBits';
import { DataStatusBadge } from '@/components/market/DataStatus';
import { PriceChange } from '@/components/market/PriceChange';
import { ActivityList } from '@/components/portfolio/ActivityList';
import { useAllQuotes, useNews, useValuations } from '@/hooks/useMarket';
import { usePortfolio } from '@/hooks/usePortfolio';
import { useAppStore } from '@/store/app';

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}

export default function Overview() {
  const navigate = useNavigate();
  const kyc = useAppStore((s) => s.kyc);
  const name = useAppStore((s) => s.profile.displayName || s.kyc.fullName);
  const hide = useAppStore((s) => s.settings.hideBalances);
  const activity = useAppStore((s) => s.activity);
  const portfolio = usePortfolio();
  const { quotes, isLoading } = useAllQuotes();
  const { valuations } = useValuations();
  const news = useNews();

  const trending = useMemo(
    () =>
      TOKENISED_ASSETS.map((a) => ({ a, v: valuations[a.id] }))
        // Only live or delayed daily data counts as "today" — simulated (fixed) assets and monthly series never qualify.
        .filter((x) => x.v?.changePct !== null && x.v?.changePct !== undefined && (x.v.inputStatus === 'realtime' || x.v.inputStatus === 'delayed'))
        .sort((x, y) => Math.abs(y.v.changePct!) - Math.abs(x.v.changePct!))
        .slice(0, 4),
    [valuations],
  );
  const question = SUGGESTED_QUESTIONS[new Date().getDate() % SUGGESTED_QUESTIONS.length];
  const money = (n: number | null) => (hide ? '•••••' : formatUsd(n));

  return (
    <div className="space-y-8">
      <PageHeader
        title={`${greeting()}${name ? `, ${name.split(' ')[0]}` : ''}`}
        description="Markets, your portfolio and what to explore next. Everything here is simulated or on a testnet."
        actions={
          <>
            <Button variant="outline" onClick={() => navigate('/intelligence')}>
              <Sparkles /> Ask Intelligence
            </Button>
            <Button onClick={() => navigate('/invest')}>Simulate an investment</Button>
          </>
        }
      />

      {kyc.status !== 'verified' && (
        <Disclaimer tone="gold" icon={ShieldCheck}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span>
              <span className="font-medium text-foreground">Complete simulated KYC to unlock investing.</span> It takes a minute, collects no documents and only exists in your
              browser.
            </span>
            <Button size="sm" onClick={() => navigate('/verify')}>
              {kyc.status === 'pending' ? 'Check verification' : 'Start verification'}
            </Button>
          </div>
        </Disclaimer>
      )}

      <section aria-label="Portfolio summary" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label={`${portfolio.title} value`} value={money(portfolio.totals.value)} loading={portfolio.loading} sub={<Link to="/portfolio" className="text-blue hover:underline">Open portfolio</Link>} />
        <StatTile
          label="Simulated profit / loss"
          value={portfolio.totals.pnl === null ? '—' : money(portfolio.totals.pnl)}
          delta={portfolio.totals.pnlPct !== null ? <span className={portfolio.totals.pnlPct >= 0 ? 'text-success' : 'text-danger'}>{formatPct(portfolio.totals.pnlPct)}</span> : undefined}
          sub={portfolio.totals.pnl === null ? 'Sample holdings have no cost basis' : 'vs. cost basis'}
        />
        <StatTile label="Sample token holdings" value={portfolio.totals.tokens.toLocaleString('en-US')} sub={`${portfolio.positions.length} assets`} />
        <StatTile label={portfolio.totals.cashLabel} value={portfolio.totals.cash === null ? '—' : portfolio.source === 'onchain' ? `${portfolio.totals.cash.toLocaleString('en-US')} vUSD` : money(portfolio.totals.cash)} sub={portfolio.source === 'sample' ? 'Start investing to use it' : 'Available to invest'} />
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <Card>
            <CardHeader className="flex-row flex-wrap items-center justify-between gap-3">
              <div>
                <CardTitle>Market snapshot</CardTitle>
                <CardDescription>Reference prices with their data status.</CardDescription>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/markets">
                  All markets <ArrowUpRight />
                </Link>
              </Button>
            </CardHeader>
            <CardContent className="px-0 pb-2">
              <ul className="divide-y divide-border">
                {TICKER_INSTRUMENTS.map((id) => {
                  const inst = getInstrument(id)!;
                  const q = quotes[id];
                  return (
                    <li key={id}>
                      <Link to={`/markets?focus=${id}`} className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-muted/60">
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium">{inst.name}</span>
                          <span className="block truncate text-xs text-muted-foreground">{q ? `${q.source.name}${q.asOf ? ` · ${relativeTime(q.asOf)}` : ''}` : 'Loading…'}</span>
                          {q && (
                            <span className="mt-1 block sm:hidden">
                              <DataStatusBadge status={q.status} frequency={q.frequency} withTooltip={false} />
                            </span>
                          )}
                        </span>
                        {q && <DataStatusBadge status={q.status} frequency={q.frequency} withTooltip={false} className="max-sm:hidden" />}
                        <span className="flex shrink-0 flex-col items-end gap-0.5 sm:flex-row sm:items-center sm:gap-3">
                          <span className="text-right text-sm tabular sm:w-28">
                            {isLoading ? <span className="skeleton ml-auto inline-block h-4 w-20" /> : q ? formatQuote(q.price, inst.denomination, inst.decimals) : '—'}
                          </span>
                          <span className="text-right sm:w-20">
                            <PriceChange pct={q?.changePct} basis={q?.changeBasis} />
                          </span>
                        </span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Moving today</CardTitle>
              <CardDescription>Sample assets whose reference prices moved the most on live or delayed data.</CardDescription>
            </CardHeader>
            <CardContent>
              {trending.length === 0 ? (
                <EmptyState title="No live movers yet" description="Movers appear once live or delayed prices load. Demo values never count as movement." />
              ) : (
                <ul className="grid gap-3 sm:grid-cols-2">
                  {trending.map(({ a, v }) => (
                    <li key={a.id}>
                      <Link to={`/assets/${a.id}`} className="flex items-center gap-3 rounded-lg border border-border p-3 transition-colors hover:border-border-strong">
                        <AssetIcon asset={a} size="sm" />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium">{a.name}</span>
                          <span className="block text-xs text-muted-foreground">{formatUsd(v.tokenPrice)} per token</span>
                        </span>
                        <PriceChange pct={v.changePct} />
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-gold/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="size-4 text-gold" aria-hidden /> Question of the day
              </CardTitle>
              <CardDescription>{question}</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" size="sm" onClick={() => navigate(`/intelligence?q=${encodeURIComponent(question)}`)}>
                Get a plain-language answer
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle>Recent activity</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/transactions">View all</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <ActivityList items={activity.slice(0, 5)} compact empty="No activity yet. Your simulated and testnet transactions will appear here." />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="size-4 text-muted-foreground" aria-hidden /> Market news
              </CardTitle>
              <CardDescription>Headlines from public RSS feeds, with sources.</CardDescription>
            </CardHeader>
            <CardContent>
              {news.isLoading ? (
                <div className="space-y-3">
                  <span className="skeleton block h-4 w-full" />
                  <span className="skeleton block h-4 w-4/5" />
                  <span className="skeleton block h-4 w-3/5" />
                </div>
              ) : news.data?.status === 'live' ? (
                <ul className="space-y-3.5">
                  {news.data.items.slice(0, 5).map((n) => (
                    <li key={n.id}>
                      <a href={n.url} target="_blank" rel="noreferrer" className="text-sm leading-snug text-foreground hover:underline">
                        {n.title}
                      </a>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {n.source}
                        {n.publishedAt ? ` · ${relativeTime(n.publishedAt)}` : ''}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState icon={Newspaper} title="News unavailable" description={news.data?.message ?? 'News feeds could not be loaded.'} />
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
