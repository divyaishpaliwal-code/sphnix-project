import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router';
import { useQueries } from '@tanstack/react-query';
import { Flame, Search, Star } from 'lucide-react';
import {
  CATEGORY_DESCRIPTIONS,
  CATEGORY_LABELS,
  TOKEN_PRICE_DISCLAIMER,
  TOKENISED_ASSETS,
  assessRisk,
  assetReferenceInstrument,
  seriesStats,
  tokenPriceSeries,
  type AssetCategory,
  type TokenisedAsset,
} from '@vestora/shared';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Disclaimer, EmptyState, PageHeader } from '@/components/common/States';
import { AssetCard } from '@/components/assets/AssetCard';
import { AssetIcon } from '@/components/assets/AssetBits';
import { DataStatusBadge } from '@/components/market/DataStatus';
import { PriceChange } from '@/components/market/PriceChange';
import { useValuations } from '@/hooks/useMarket';
import { cn } from '@/lib/utils';
import { fetchHistory } from '@/services/market';
import { useAppStore } from '@/store/app';

type Filter = 'all' | 'watchlist' | AssetCategory;
type Sort = 'featured' | 'price-asc' | 'price-desc' | 'perf-desc' | 'perf-asc' | 'risk-asc' | 'risk-desc' | 'min-asc';

const CATEGORY_ORDER: AssetCategory[] = ['precious-metals', 'energy', 'industrial-metals', 'agriculture', 'bonds', 'real-estate', 'digital-assets'];

export default function Marketplace() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get('q') ?? '');
  const filter = (params.get('category') as Filter) ?? 'all';
  const sort = (params.get('sort') as Sort) ?? 'featured';
  const watchlist = useAppStore((s) => s.watchlist);
  const { valuations, isLoading } = useValuations();

  // One-year histories are shared with the cards through the query cache (no duplicate requests).
  const histories = useQueries({
    queries: TOKENISED_ASSETS.map((a) => {
      const ref = assetReferenceInstrument(a);
      return { queryKey: ['history', ref, '1Y'], queryFn: () => fetchHistory(ref as string, '1Y'), enabled: Boolean(ref), staleTime: 10 * 60_000 };
    }),
  });
  const risks = useMemo(() => {
    const out: Record<string, number> = {};
    TOKENISED_ASSETS.forEach((a, i) => {
      const pts = histories[i]?.data?.points;
      const series = pts ? tokenPriceSeries(a, pts) : [];
      const st = series.length >= 2 ? seriesStats(series) : null;
      out[a.id] = assessRisk(a.risk, st ? { volatility: st.volatility, maxDrawdown: st.maxDrawdown, observations: st.observations } : {}).score;
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [histories.map((h) => h.dataUpdatedAt).join()]);

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(params);
    if (value === null || value === 'all' || value === 'featured') next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  };

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = TOKENISED_ASSETS.filter((a) => {
      if (filter === 'watchlist' && !watchlist.includes(a.id)) return false;
      if (filter !== 'all' && filter !== 'watchlist' && a.category !== filter) return false;
      if (!q) return true;
      return [a.name, a.symbol, CATEGORY_LABELS[a.category], a.tagline].some((t) => t.toLowerCase().includes(q));
    });
    const price = (a: TokenisedAsset) => valuations[a.id]?.tokenPrice ?? Number.POSITIVE_INFINITY;
    const perf = (a: TokenisedAsset) => valuations[a.id]?.changePct ?? Number.NEGATIVE_INFINITY;
    const cmp: Record<Sort, (x: TokenisedAsset, y: TokenisedAsset) => number> = {
      featured: () => 0,
      'price-asc': (x, y) => price(x) - price(y),
      'price-desc': (x, y) => price(y) - price(x),
      'perf-desc': (x, y) => perf(y) - perf(x),
      'perf-asc': (x, y) => perf(x) - perf(y),
      'risk-asc': (x, y) => risks[x.id] - risks[y.id],
      'risk-desc': (x, y) => risks[y.id] - risks[x.id],
      'min-asc': (x, y) => Math.max(x.minInvestment, price(x)) - Math.max(y.minInvestment, price(y)),
    };
    list = [...list].sort(cmp[sort]);
    return list;
  }, [query, filter, sort, watchlist, valuations, risks]);

  const trending = useMemo(
    () =>
      TOKENISED_ASSETS.map((a) => ({ a, v: valuations[a.id] }))
        .filter((x) => x.v && x.v.changePct !== null && (x.v.inputStatus === 'realtime' || x.v.inputStatus === 'delayed'))
        .sort((x, y) => Math.abs(y.v.changePct!) - Math.abs(x.v.changePct!))
        .slice(0, 3),
    [valuations],
  );

  const filters: { value: Filter; label: string }[] = [
    { value: 'all', label: 'All assets' },
    { value: 'watchlist', label: 'Watchlist' },
    ...CATEGORY_ORDER.map((c) => ({ value: c as Filter, label: CATEGORY_LABELS[c] })),
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Investment marketplace"
        description="Tokenised sample assets across seven categories. Market reference prices come from real data providers; token prices are illustrative and derived from each sample's published formula."
      />

      <Disclaimer>
        {TOKEN_PRICE_DISCLAIMER} Status labels show whether a reference price is <span className="text-success">live</span>, <span className="text-warning">delayed</span>,{' '}
        <span className="text-blue">historical</span> or <span className="text-demo">demo data</span>.
      </Disclaimer>

      {trending.length > 0 && (
        <section aria-label="Trending" className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1.5 text-[13px] text-muted-foreground">
            <Flame className="size-4 text-gold" aria-hidden /> Trending now
          </span>
          {trending.map(({ a, v }) => (
            <Link key={a.id} to={`/assets/${a.id}`} className="flex items-center gap-2 rounded-full border border-border bg-card py-1 pl-1 pr-3 text-[13px] transition-colors hover:border-border-strong">
              <AssetIcon asset={a} size="sm" className="size-6 rounded-full [&_svg]:size-3.5" />
              {a.symbol}
              <PriceChange pct={v.changePct} size="xs" />
              {v.inputStatus !== 'fixed' && <DataStatusBadge status={v.inputStatus} withTooltip={false} className="hidden sm:inline-flex" />}
            </Link>
          ))}
        </section>
      )}

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="relative lg:w-80">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setParam('q', e.target.value || null);
            }}
            placeholder="Search by name, symbol or category"
            className="pl-9"
            aria-label="Search sample assets"
          />
        </div>
        <div className="flex items-center gap-2 lg:ml-auto">
          <span className="text-[13px] text-muted-foreground">Sort</span>
          <Select value={sort} onValueChange={(v: string) => setParam('sort', v)}>
            <SelectTrigger className="w-56" aria-label="Sort assets">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="perf-desc">Best performance (latest)</SelectItem>
              <SelectItem value="perf-asc">Worst performance (latest)</SelectItem>
              <SelectItem value="price-asc">Token price: low to high</SelectItem>
              <SelectItem value="price-desc">Token price: high to low</SelectItem>
              <SelectItem value="risk-asc">Risk: low to high</SelectItem>
              <SelectItem value="risk-desc">Risk: high to low</SelectItem>
              <SelectItem value="min-asc">Lowest minimum</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div role="tablist" aria-label="Asset categories" className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 sm:mx-0 sm:flex-wrap sm:px-0">
        {filters.map((f) => (
          <button
            key={f.value}
            role="tab"
            aria-selected={filter === f.value}
            onClick={() => setParam('category', f.value)}
            className={cn(
              'flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[13px] transition-colors focus-visible:outline-2 focus-visible:outline-ring',
              filter === f.value ? 'border-gold/40 bg-gold-soft text-foreground' : 'border-border text-muted-foreground hover:text-foreground',
            )}
          >
            {f.value === 'watchlist' && <Star className="size-3.5" aria-hidden />}
            {f.label}
          </button>
        ))}
      </div>
      {filter !== 'all' && filter !== 'watchlist' && <p className="-mt-2 text-[13px] text-muted-foreground">{CATEGORY_DESCRIPTIONS[filter]}</p>}

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-[460px] rounded-xl" />
          ))}
        </div>
      ) : visible.length === 0 ? (
        <EmptyState
          icon={filter === 'watchlist' ? Star : Search}
          title={filter === 'watchlist' ? 'Your watchlist is empty' : 'No assets match your search'}
          description={filter === 'watchlist' ? 'Tap the star on any asset to follow it here and on your dashboard.' : 'Try a different name, symbol or category.'}
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((a) => (
            <AssetCard key={a.id} asset={a} />
          ))}
        </div>
      )}
    </div>
  );
}
