import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router';
import { ArrowLeft, BookOpen, Search, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { EmptyState, PageHeader } from '@/components/common/States';
import { GLOSSARY, GUIDES, GUIDE_MAP, GUIDE_TOPICS, readingMinutes, type Guide } from '@/data/learn';

export default function Learn() {
  const { slug } = useParams<{ slug?: string }>();
  if (slug) {
    const guide = GUIDE_MAP[slug];
    return guide ? (
      <GuideView guide={guide} />
    ) : (
      <EmptyState
        icon={BookOpen}
        title="We couldn’t find that guide"
        description="It may have been renamed. Browse all guides instead."
        action={
          <Button asChild size="sm">
            <Link to="/learn">All guides</Link>
          </Button>
        }
      />
    );
  }
  return <LearnIndex />;
}

function LearnIndex() {
  const [term, setTerm] = useState('');
  const terms = useMemo(() => {
    const q = term.trim().toLowerCase();
    return q ? GLOSSARY.filter((g) => `${g.term} ${g.definition}`.toLowerCase().includes(q)) : GLOSSARY;
  }, [term]);

  return (
    <div className="space-y-10">
      <PageHeader title="Learn" description="Short, plain-language guides to fractional ownership, tokenisation and risk — written for beginners, with no jargon left unexplained." />

      {GUIDE_TOPICS.map(({ topic, description }) => {
        const guides = GUIDES.filter((g) => g.topic === topic);
        return (
          <section key={topic} aria-labelledby={`topic-${topic}`} className="space-y-4">
            <div>
              <h2 id={`topic-${topic}`} className="font-display text-lg font-semibold tracking-[-0.015em]">
                {topic}
              </h2>
              <p className="text-[13px] text-muted-foreground">{description}</p>
            </div>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {guides.map((g) => (
                <Link
                  key={g.slug}
                  to={`/learn/${g.slug}`}
                  className="group flex flex-col gap-2 rounded-xl border border-border bg-card p-5 transition-colors hover:border-border-strong focus-visible:outline-2 focus-visible:outline-ring"
                >
                  <span className="font-display text-[15px] font-semibold leading-snug text-foreground group-hover:text-gold">{g.title}</span>
                  <span className="flex-1 text-[13px] leading-relaxed text-muted-foreground">{g.summary}</span>
                  <span className="text-xs text-subtle">{readingMinutes(g)} min read</span>
                </Link>
              ))}
            </div>
          </section>
        );
      })}

      <section aria-labelledby="glossary" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 id="glossary" className="font-display text-lg font-semibold tracking-[-0.015em]">
              Glossary
            </h2>
            <p className="text-[13px] text-muted-foreground">{GLOSSARY.length} terms used across VESTORA.</p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
            <Input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Find a term" className="pl-9" aria-label="Find a glossary term" />
          </div>
        </div>
        {terms.length === 0 ? (
          <EmptyState
            icon={Search}
            title={`No term matches “${term}”`}
            description="Try VESTORA Intelligence for anything not covered here."
            action={
              <Button asChild size="sm" variant="outline">
                <Link to={`/intelligence?q=${encodeURIComponent(`What is ${term}?`)}`}>Ask about “{term}”</Link>
              </Button>
            }
          />
        ) : (
          <dl className="grid gap-x-8 gap-y-0 rounded-xl border border-border bg-card px-5 md:grid-cols-2">
            {terms.map((g) => (
              <div key={g.term} className="border-b border-border py-3.5 last:border-b-0 md:[&:nth-last-child(2):nth-child(odd)]:border-b-0">
                <dt className="text-sm font-medium text-foreground">{g.term}</dt>
                <dd className="mt-0.5 text-[13px] leading-relaxed text-muted-foreground">
                  {g.definition}{' '}
                  {g.guide && GUIDE_MAP[g.guide] && (
                    <Link to={`/learn/${g.guide}`} className="whitespace-nowrap text-blue hover:underline">
                      Read the guide
                    </Link>
                  )}
                </dd>
              </div>
            ))}
          </dl>
        )}
      </section>
    </div>
  );
}

function GuideView({ guide }: { guide: Guide }) {
  const related = guide.related.map((s) => GUIDE_MAP[s]).filter((g): g is Guide => Boolean(g));
  return (
    <div className="space-y-6">
      <Link to="/learn" className="inline-flex items-center gap-1.5 text-[13px] text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-3.5" aria-hidden /> All guides
      </Link>

      <div className="grid gap-10 xl:grid-cols-[minmax(0,1fr)_300px]">
        <article className="min-w-0 max-w-[720px] space-y-8">
          <header className="space-y-3">
            <p className="text-[13px] text-gold">
              {guide.topic} · {readingMinutes(guide)} min read
            </p>
            <h1 className="font-display text-[28px] font-bold leading-tight tracking-[-0.025em] md:text-[34px]">{guide.title}</h1>
            <p className="text-[15px] leading-relaxed text-muted-foreground">{guide.summary}</p>
          </header>

          {guide.sections.map((s) => (
            <section key={s.id} id={s.id} aria-labelledby={`h-${s.id}`} className="scroll-mt-24 space-y-3">
              <h2 id={`h-${s.id}`} className="font-display text-lg font-semibold tracking-[-0.015em]">
                {s.heading}
              </h2>
              {s.body.map((p) => (
                <p key={p.slice(0, 40)} className="text-[15px] leading-[1.7] text-foreground/90">
                  {p}
                </p>
              ))}
              {s.bullets && (
                <ul className="space-y-2 pl-1">
                  {s.bullets.map((b) => (
                    <li key={b} className="flex gap-3 text-[15px] leading-[1.6] text-foreground/90">
                      <span className="mt-[11px] size-1.5 shrink-0 rounded-full bg-gold" aria-hidden />
                      {b}
                    </li>
                  ))}
                </ul>
              )}
              {s.table && (
                <div className="overflow-x-auto rounded-lg border border-border">
                  <table className="w-full text-left text-[13px]">
                    <caption className="sr-only">{s.table.caption}</caption>
                    <thead className="bg-muted text-muted-foreground">
                      <tr>
                        {s.table.head.map((h, i) => (
                          <th key={`${i}-${h}`} scope="col" className="px-3.5 py-2.5 font-medium">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {s.table.rows.map((r) => (
                        <tr key={r.join('|')}>
                          {r.map((c, i) => (
                            <td key={i} className={i === 0 ? 'px-3.5 py-2.5 font-medium text-foreground' : 'px-3.5 py-2.5 text-muted-foreground'}>
                              {c}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          ))}

          <p className="border-t border-border pt-5 text-xs leading-relaxed text-subtle">
            General education only, not financial advice. VESTORA is a testnet prototype: tokens and balances have no monetary value and do not represent ownership of any real asset.
          </p>
        </article>

        <aside className="space-y-6 xl:sticky xl:top-24 xl:self-start">
          <nav aria-label="On this page" className="hidden space-y-2 xl:block">
            <p className="text-[13px] font-medium text-foreground">On this page</p>
            <ul className="space-y-1.5 border-l border-border">
              {guide.sections.map((s) => (
                <li key={s.id}>
                  <a
                    href={`#${s.id}`}
                    onClick={(e) => {
                      // In-page jump without touching the URL hash (the static build routes with it).
                      e.preventDefault();
                      document.getElementById(s.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }}
                    className="-ml-px block border-l border-transparent pl-3 text-[13px] text-muted-foreground hover:border-gold hover:text-foreground"
                  >
                    {s.heading}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <Card className="border-gold/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="size-4 text-gold" aria-hidden /> Still curious?
              </CardTitle>
              <CardDescription>Ask VESTORA Intelligence for a structured explanation.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-start gap-2">
              {guide.questions.map((q) => (
                <Link key={q} to={`/intelligence?q=${encodeURIComponent(q)}`} className="text-left text-[13px] text-blue hover:underline">
                  {q}
                </Link>
              ))}
            </CardContent>
          </Card>

          {related.length > 0 && (
            <div className="space-y-2">
              <p className="text-[13px] font-medium text-foreground">Related guides</p>
              <ul className="space-y-1">
                {related.map((g) => (
                  <li key={g.slug}>
                    <Link to={`/learn/${g.slug}`} className="block rounded-md px-2 py-1.5 text-[13px] text-muted-foreground hover:bg-muted hover:text-foreground">
                      {g.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
