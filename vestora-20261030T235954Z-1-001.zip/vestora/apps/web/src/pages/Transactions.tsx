import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router';
import { useQuery } from '@tanstack/react-query';
import { Copy, Download, ExternalLink, FileSearch, RefreshCw, Search } from 'lucide-react';
import { toast } from 'sonner';
import { SIMULATION_LABEL, formatUsd, getAsset, relativeTime, shortAddress } from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { DialogDescription, DialogTitle, Sheet, SheetContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Segmented, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/primitives';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TBody, TD, TH, THead, TR, Table } from '@/components/ui/table';
import { EmptyState, ErrorState, PageHeader } from '@/components/common/States';
import { ModeBadge, StatusText, activityAmount, activityTitle } from '@/components/portfolio/ActivityList';
import { TARGET_CHAIN, chainName, explorerAddress, explorerTx } from '@/config/chains';
import { copyText } from '@/lib/utils';
import { useAppStore, type ActivityItem, type ActivityKind } from '@/store/app';
import { queryRecentEvents, readProvider, useOnchain, type OnchainEvent } from '@/wallet/useOnchain';
import { useWallet } from '@/wallet/WalletProvider';

type ModeFilter = 'all' | 'simulated' | 'onchain';
type KindFilter = 'all' | ActivityKind;

const KIND_LABEL: Record<ActivityKind, string> = { buy: 'Buy', sell: 'Sell / redeem', claim: 'Credits claim', kyc: 'Verification', reset: 'Demo reset' };

function fullDate(iso: string): string {
  return new Date(iso).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });
}

function dayLabel(iso: string): string {
  const d = new Date(iso);
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
}

function toCsv(items: ActivityItem[]): string {
  const head = ['date', 'reference', 'mode', 'type', 'asset', 'tokens', 'unit_price', 'amount', 'currency', 'status', 'network'];
  const esc = (v: unknown) => {
    const s = v === undefined || v === null ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows = items.map((a) => [
    a.createdAt,
    a.hash ?? a.id,
    a.mode === 'onchain' ? 'testnet' : 'simulated',
    a.kind,
    a.assetId ? getAsset(a.assetId)?.symbol ?? a.assetId : '',
    a.tokens ?? '',
    a.unitPrice ?? '',
    a.amount ?? '',
    a.amount === undefined ? '' : a.mode === 'onchain' ? 'vUSD (testnet credits)' : 'USD (simulated)',
    a.status,
    a.mode === 'onchain' ? chainName(a.chainId) : 'none',
  ]);
  return [head, ...rows].map((r) => r.map(esc).join(',')).join('\n');
}

function download(name: string, text: string, type = 'text/csv') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Re-check testnet transactions left "pending" (e.g. the page was closed before confirmation). */
function useReconcilePending(items: ActivityItem[]) {
  const updateActivity = useAppStore((s) => s.updateActivity);
  const pending = items.filter((a) => a.mode === 'onchain' && a.status === 'pending' && a.hash && (a.chainId ?? TARGET_CHAIN.id) === TARGET_CHAIN.id);
  const key = pending.map((a) => a.hash).join(',');
  useEffect(() => {
    if (!key) return;
    let cancelled = false;
    const provider = readProvider();
    void Promise.all(
      key.split(',').map(async (hash) => {
        try {
          const receipt = await provider.getTransactionReceipt(hash);
          if (!cancelled && receipt) updateActivity(hash, { status: receipt.status === 1 ? 'confirmed' : 'failed' });
        } catch {
          /* RPC unavailable: leave as pending */
        }
      }),
    );
    return () => {
      cancelled = true;
    };
  }, [key, updateActivity]);
}

export default function Transactions() {
  const activity = useAppStore((s) => s.activity);
  const [mode, setMode] = useState<ModeFilter>('all');
  const [kind, setKind] = useState<KindFilter>('all');
  const [query, setQuery] = useState('');
  const [view, setView] = useState<'table' | 'timeline'>('table');
  const [selected, setSelected] = useState<ActivityItem | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const openDetail = (a: ActivityItem) => {
    setSelected(a);
    setDetailOpen(true);
  };
  useReconcilePending(activity);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return activity.filter((a) => {
      if (mode !== 'all' && a.mode !== mode) return false;
      if (kind !== 'all' && a.kind !== kind) return false;
      if (!q) return true;
      const asset = a.assetId ? getAsset(a.assetId) : undefined;
      return [a.id, a.hash, asset?.name, asset?.symbol, activityTitle(a), a.note].some((v) => v?.toLowerCase().includes(q));
    });
  }, [activity, mode, kind, query]);

  const counts = useMemo(
    () => ({ simulated: activity.filter((a) => a.mode === 'simulated').length, onchain: activity.filter((a) => a.mode === 'onchain').length, pending: activity.filter((a) => a.status === 'pending').length }),
    [activity],
  );

  const groups = useMemo(() => {
    const out: { label: string; items: ActivityItem[] }[] = [];
    for (const a of filtered) {
      const label = dayLabel(a.createdAt);
      const last = out[out.length - 1];
      if (last && last.label === label) last.items.push(a);
      else out.push({ label, items: [a] });
    }
    return out;
  }, [filtered]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Transactions"
        description="Every simulated and testnet action in one place. Simulated entries never touch a blockchain; testnet entries link to the public block explorer."
        actions={
          <Button variant="outline" size="sm" disabled={filtered.length === 0} onClick={() => download(`vestora-activity-${new Date().toISOString().slice(0, 10)}.csv`, toCsv(filtered))}>
            <Download /> Export CSV
          </Button>
        }
      />

      <Tabs defaultValue="activity" className="space-y-5">
        <TabsList>
          <TabsTrigger value="activity">Your activity</TabsTrigger>
          <TabsTrigger value="explorer">Contract explorer</TabsTrigger>
        </TabsList>

        <TabsContent value="activity" className="space-y-5">
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              ['Simulated', counts.simulated, 'Stored in this browser only'],
              ['Testnet', counts.onchain, `Recorded on ${TARGET_CHAIN.name}`],
              ['Pending', counts.pending, 'Waiting for confirmation'],
            ].map(([label, n, sub]) => (
              <div key={label as string} className="rounded-xl border border-border bg-card px-4 py-3">
                <p className="text-[13px] text-muted-foreground">{label}</p>
                <p className="font-display text-2xl font-semibold tabular">{n}</p>
                <p className="text-xs text-subtle">{sub}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[200px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by asset, reference or hash" className="pl-9" aria-label="Search activity" />
            </div>
            <Segmented
              label="Mode"
              value={mode}
              onChange={setMode}
              options={[
                { value: 'all', label: 'All' },
                { value: 'simulated', label: 'Simulated' },
                { value: 'onchain', label: 'Testnet' },
              ]}
            />
            <Select value={kind} onValueChange={(v: string) => setKind(v as KindFilter)}>
              <SelectTrigger className="w-[160px]" aria-label="Activity type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                {(Object.keys(KIND_LABEL) as ActivityKind[]).map((k) => (
                  <SelectItem key={k} value={k}>
                    {KIND_LABEL[k]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Segmented
              label="View"
              value={view}
              onChange={setView}
              options={[
                { value: 'table', label: 'Table' },
                { value: 'timeline', label: 'Timeline' },
              ]}
            />
          </div>

          {activity.length === 0 ? (
            <EmptyState
              icon={FileSearch}
              title="No activity yet"
              description="Simulated purchases, testnet transactions and verification steps will appear here."
              action={
                <Button asChild size="sm">
                  <Link to="/invest">Simulate an investment</Link>
                </Button>
              }
            />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={Search}
              title="Nothing matches these filters"
              action={
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setMode('all');
                    setKind('all');
                    setQuery('');
                  }}
                >
                  Clear filters
                </Button>
              }
            />
          ) : view === 'table' ? (
            <Card className="overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <THead>
                    <TR>
                      <TH>Date</TH>
                      <TH>Activity</TH>
                      <TH className="text-right">Amount</TH>
                      <TH>Mode</TH>
                      <TH>Status</TH>
                      <TH>Reference</TH>
                    </TR>
                  </THead>
                  <TBody>
                    {filtered.map((a) => (
                      <TR key={a.id} className="cursor-pointer" onClick={() => openDetail(a)}>
                        <TD className="whitespace-nowrap text-muted-foreground">{fullDate(a.createdAt)}</TD>
                        <TD>
                          <button type="button" onClick={(e) => { e.stopPropagation(); openDetail(a); }} className="text-left font-medium text-foreground hover:underline focus-visible:outline-2 focus-visible:outline-ring">
                            {activityTitle(a)}
                          </button>
                        </TD>
                        <TD className="whitespace-nowrap text-right tabular">{activityAmount(a) || '—'}</TD>
                        <TD>
                          <ModeBadge mode={a.mode} />
                        </TD>
                        <TD>
                          <StatusText status={a.status} />
                        </TD>
                        <TD className="whitespace-nowrap font-mono text-xs text-muted-foreground">{a.hash ? shortAddress(a.hash, 6) : a.id}</TD>
                      </TR>
                    ))}
                  </TBody>
                </Table>
              </div>
            </Card>
          ) : (
            <div className="space-y-6">
              {groups.map((g) => (
                <section key={g.label} aria-label={g.label}>
                  <h2 className="mb-2 text-[13px] font-medium text-muted-foreground">{g.label}</h2>
                  <ol className="relative space-y-1 border-l border-border pl-5">
                    {g.items.map((a) => (
                      <li key={a.id} className="relative">
                        <span
                          className={`absolute -left-[25px] top-4 size-2.5 rounded-full ring-4 ring-background ${a.status === 'failed' ? 'bg-danger' : a.status === 'pending' ? 'bg-warning' : a.mode === 'onchain' ? 'bg-blue' : 'bg-gold'}`}
                          aria-hidden
                        />
                        <button type="button" onClick={() => openDetail(a)} className="flex w-full flex-wrap items-center gap-x-3 gap-y-1 rounded-md px-3 py-2.5 text-left transition-colors hover:bg-muted/60">
                          <span className="min-w-0 flex-1 text-sm">{activityTitle(a)}</span>
                          <span className="text-sm tabular">{activityAmount(a)}</span>
                          <span className="flex w-full items-center gap-2 text-xs text-muted-foreground">
                            <ModeBadge mode={a.mode} /> {new Date(a.createdAt).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} <StatusText status={a.status} />
                          </span>
                        </button>
                      </li>
                    ))}
                  </ol>
                </section>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="explorer">
          <ContractExplorer />
        </TabsContent>
      </Tabs>

      <Sheet open={detailOpen && Boolean(selected)} onOpenChange={setDetailOpen}>
        <SheetContent>{selected && <ActivityDetail item={activity.find((a) => a.id === selected.id) ?? selected} />}</SheetContent>
      </Sheet>
    </div>
  );
}

function ActivityDetail({ item }: { item: ActivityItem }) {
  const asset = item.assetId ? getAsset(item.assetId) : undefined;
  const link = item.hash ? explorerTx(item.hash, item.chainId) : null;
  const rows: [string, string][] = [
    ['When', `${fullDate(item.createdAt)} (${relativeTime(item.createdAt)})`],
    ['Type', KIND_LABEL[item.kind]],
    ...(asset ? ([['Asset', `${asset.name} (${asset.symbol})`]] as [string, string][]) : []),
    ...(item.tokens !== undefined ? ([['Tokens', item.tokens.toLocaleString('en-US')]] as [string, string][]) : []),
    ...(item.unitPrice !== undefined
      ? ([['Price per token', item.mode === 'onchain' ? `${item.unitPrice.toLocaleString('en-US')} vUSD` : `${formatUsd(item.unitPrice, 4)} (illustrative)`]] as [string, string][])
      : []),
    ...(item.amount !== undefined ? ([['Total', activityAmount(item)]] as [string, string][]) : []),
    ['Status', item.status === 'confirmed' ? 'Confirmed' : item.status === 'pending' ? 'Pending' : 'Failed'],
    ['Network', item.mode === 'onchain' ? chainName(item.chainId) : 'None — simulated in this browser'],
  ];
  return (
    <div className="flex h-full flex-col overflow-y-auto">
      <div className="space-y-2 border-b border-border px-6 pb-5 pt-6">
        <ModeBadge mode={item.mode} />
        <DialogTitle className="font-display text-lg font-semibold">{activityTitle(item)}</DialogTitle>
        <DialogDescription className="text-[13px] text-muted-foreground">
          {item.mode === 'onchain' ? `A transaction on the ${chainName(item.chainId)} test network. Testnet tokens have no monetary value.` : SIMULATION_LABEL}
        </DialogDescription>
      </div>
      <dl className="divide-y divide-border px-6">
        {rows.map(([k, v]) => (
          <div key={k} className="flex justify-between gap-4 py-3 text-sm">
            <dt className="text-muted-foreground">{k}</dt>
            <dd className="text-right">{v}</dd>
          </div>
        ))}
      </dl>
      <div className="space-y-3 px-6 py-5">
        <p className="text-[13px] text-muted-foreground">{item.mode === 'onchain' ? 'Transaction hash' : 'Simulation reference'}</p>
        <div className="flex items-start gap-2 rounded-lg bg-muted px-3 py-2.5">
          <code className="min-w-0 flex-1 break-all font-mono text-xs">{item.hash ?? item.id}</code>
          <button
            type="button"
            aria-label="Copy reference"
            className="rounded p-1 text-muted-foreground hover:text-foreground"
            onClick={async () => ((await copyText(item.hash ?? item.id)) ? toast.success('Copied') : toast.error('Copy failed'))}
          >
            <Copy className="size-3.5" />
          </button>
        </div>
        {link && (
          <Button variant="outline" size="sm" asChild>
            <a href={link} target="_blank" rel="noreferrer">
              <ExternalLink /> View on block explorer
            </a>
          </Button>
        )}
        {item.note && <p className="text-xs text-subtle">{item.note}</p>}
        {asset && (
          <Button variant="ghost" size="sm" asChild>
            <Link to={`/assets/${asset.id}`}>Open {asset.symbol} details</Link>
          </Button>
        )}
      </div>
    </div>
  );
}

const EVENT_LABEL: Record<OnchainEvent['kind'], string> = { buy: 'AssetPurchased', sell: 'AssetRedeemed', claim: 'DemoCreditsClaimed', kyc: 'StatusChanged' };

function ContractExplorer() {
  const wallet = useWallet();
  const onchain = useOnchain();
  const cfg = onchain.config;
  const [scope, setScope] = useState<'all' | 'mine'>('all');
  const mineAvailable = wallet.status === 'connected' && Boolean(wallet.address);
  const account = scope === 'mine' && mineAvailable ? wallet.address! : undefined;

  const events = useQuery({
    queryKey: ['contract-events', cfg.assetToken, account ?? 'all'],
    enabled: cfg.configured,
    staleTime: 60_000,
    retry: 1,
    queryFn: () => queryRecentEvents(readProvider(wallet.isCorrectChain ? wallet.getBrowserProvider() : null), account),
  });

  if (!cfg.configured) {
    return (
      <EmptyState
        icon={FileSearch}
        title="Contracts are not deployed in this build"
        description={
          <>
            Deploy AssetToken and ComplianceManager to {TARGET_CHAIN.name} with <code className="font-mono text-xs">npm run contracts:deploy:sepolia</code>, then set the contract
            addresses in the web app’s environment. The steps are in docs/DEPLOYMENT.md.
          </>
        }
      />
    );
  }

  return (
    <div className="space-y-5">
      <Card>
        <CardHeader>
          <CardTitle>Deployed contracts</CardTitle>
          <CardDescription>Public, verifiable testnet contracts. Anyone can read their rules and events.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          {[
            ['AssetToken (ERC-1155)', cfg.assetToken!],
            ['ComplianceManager', cfg.compliance!],
          ].map(([label, addr]) => {
            const link = explorerAddress(addr);
            return (
              <div key={label} className="rounded-lg border border-border px-4 py-3">
                <p className="text-[13px] text-muted-foreground">{label}</p>
                <div className="mt-1 flex items-center gap-2">
                  <code className="min-w-0 flex-1 truncate font-mono text-xs">{addr}</code>
                  {link && (
                    <a href={link} target="_blank" rel="noreferrer" aria-label={`Open ${label} on the block explorer`} className="text-muted-foreground hover:text-foreground">
                      <ExternalLink className="size-3.5" />
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Segmented
          label="Accounts"
          value={scope}
          onChange={setScope}
          options={[
            { value: 'all', label: 'All wallets' },
            { value: 'mine', label: 'My wallet', disabled: !mineAvailable },
          ]}
        />
        <Button variant="ghost" size="sm" onClick={() => void events.refetch()} loading={events.isFetching}>
          <RefreshCw /> Refresh
        </Button>
      </div>

      {events.isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }, (_, i) => (
            <span key={i} className="skeleton block h-11 w-full" />
          ))}
        </div>
      ) : events.isError ? (
        <ErrorState title="Could not read contract events" description={`The ${TARGET_CHAIN.name} RPC endpoint did not respond. Try again, or set VITE_RPC_URL to another public endpoint.`} />
      ) : (events.data ?? []).length === 0 ? (
        <EmptyState icon={FileSearch} title="No recent events" description="No purchases, redemptions, credit claims or verification changes in the recent block range." />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <THead>
                <TR>
                  <TH>Block</TH>
                  <TH>Event</TH>
                  <TH>Wallet</TH>
                  <TH>Details</TH>
                  <TH>Transaction</TH>
                </TR>
              </THead>
              <TBody>
                {events.data!.map((e) => {
                  const asset = e.assetId ? getAsset(e.assetId) : undefined;
                  const link = explorerTx(e.hash);
                  return (
                    <TR key={`${e.hash}-${e.kind}-${e.account}`}>
                      <TD className="tabular text-muted-foreground">{e.blockNumber.toLocaleString('en-US')}</TD>
                      <TD>
                        <Badge variant="outline" className="font-mono">
                          {EVENT_LABEL[e.kind]}
                        </Badge>
                      </TD>
                      <TD className="font-mono text-xs">
                        {shortAddress(e.account)}
                        {wallet.address && e.account.toLowerCase() === wallet.address.toLowerCase() && <span className="ml-1.5 text-gold">(you)</span>}
                      </TD>
                      <TD className="text-[13px]">
                        {e.kind === 'buy' || e.kind === 'sell'
                          ? `${e.tokens?.toLocaleString('en-US')} ${asset?.symbol ?? 'tokens'} for ${e.credits?.toLocaleString('en-US')} vUSD`
                          : e.kind === 'claim'
                            ? `${e.credits?.toLocaleString('en-US')} vUSD demo credits`
                            : `Verification: ${e.note}`}
                      </TD>
                      <TD className="font-mono text-xs">
                        {link ? (
                          <a href={link} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-blue hover:underline">
                            {shortAddress(e.hash, 6)} <ExternalLink className="size-3" aria-hidden />
                          </a>
                        ) : (
                          shortAddress(e.hash, 6)
                        )}
                      </TD>
                    </TR>
                  );
                })}
              </TBody>
            </Table>
          </div>
        </Card>
      )}
      <p className="text-xs text-subtle">Shows events from roughly the last 54,000 blocks, read directly from the public RPC. Testnet tokens and vUSD credits have no monetary value.</p>
    </div>
  );
}
