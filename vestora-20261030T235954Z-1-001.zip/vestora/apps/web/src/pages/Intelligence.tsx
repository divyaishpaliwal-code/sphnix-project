import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router';
import { useQuery } from '@tanstack/react-query';
import { create } from 'zustand';
import { ArrowUp, BookOpen, Lock, MessageSquareText, RotateCcw, ShieldCheck, Sparkles, Trash2 } from 'lucide-react';
import {
  AI_DISCLAIMER,
  RISK_FACTORS,
  SUGGESTED_QUESTIONS,
  TOKENISED_ASSETS,
  answerQuestion,
  assetReferenceInstrument,
  getAsset,
  resolveSubject,
  type AskRequest,
  type AssistantResponse,
} from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ErrorState, PageHeader } from '@/components/common/States';
import { AnswerCard } from '@/components/ai/AnswerCard';
import { useStatsLoader } from '@/hooks/useMarket';
import { ApiError } from '@/services/api';
import { aiStatus, askAssistant } from '@/services/ai';
import { uid } from '@/lib/utils';

const MAX_QUESTION = 600;

interface Turn {
  id: string;
  req: AskRequest;
  status: 'loading' | 'done' | 'error';
  answer?: AssistantResponse;
  error?: string;
}

/** Session-only conversation (kept across page navigation, cleared on reload). */
const useThread = create<{ turns: Turn[]; push: (t: Turn) => void; patch: (id: string, p: Partial<Turn>) => void; clear: () => void }>()((set) => ({
  turns: [],
  push: (t) => set((s) => ({ turns: [t, ...s.turns].slice(0, 30) })),
  patch: (id, p) => set((s) => ({ turns: s.turns.map((t) => (t.id === id ? { ...t, ...p } : t)) })),
  clear: () => set({ turns: [] }),
}));

function instrumentIdsFor(req: AskRequest): string[] {
  const { all } = resolveSubject(req);
  return all.flatMap((s) => (s.kind === 'asset' ? [assetReferenceInstrument(s.asset)].filter((x): x is string => Boolean(x)) : s.kind === 'instrument' ? [s.instrument.id] : []));
}

function friendlyError(err: unknown): string {
  if (err instanceof ApiError && err.status === 429) return 'Too many questions in a short time. Wait a minute, or use the built-in assistant below.';
  if (err instanceof ApiError && err.status === 400) return 'That question could not be processed. Try rephrasing it in plain words.';
  return (err as Error)?.message || 'The assistant could not answer right now.';
}

export default function Intelligence() {
  const [params, setParams] = useSearchParams();
  const { turns, push, patch, clear } = useThread();
  const [draft, setDraft] = useState('');
  const [explainId, setExplainId] = useState<string>('');
  const loadStats = useStatsLoader();
  const status = useQuery({ queryKey: ['ai-status'], queryFn: aiStatus, staleTime: 5 * 60_000 });
  const busy = turns.some((t) => t.status === 'loading');

  const run = async (req: AskRequest) => {
    const question = req.question.trim().slice(0, MAX_QUESTION);
    if (question.length < 2) return;
    const id = uid('t_');
    const full = { ...req, question };
    push({ id, req: full, status: 'loading' });
    try {
      const answer = await askAssistant(full, () => loadStats(instrumentIdsFor(full)));
      patch(id, { status: 'done', answer });
    } catch (err) {
      patch(id, { status: 'error', error: friendlyError(err) });
    }
  };

  const answerLocally = async (turn: Turn) => {
    const stats = await loadStats(instrumentIdsFor(turn.req)).catch(() => undefined);
    patch(turn.id, { status: 'done', error: undefined, answer: answerQuestion(turn.req, { stats, mode: 'demo' }) });
  };

  // Questions linked from elsewhere (?q=…&asset=…) are asked once on arrival.
  const handled = useRef<string | null>(null);
  useEffect(() => {
    const q = params.get('q');
    const asset = params.get('asset');
    const key = `${q ?? ''}|${asset ?? ''}`;
    if ((!q && !asset) || handled.current === key) return;
    handled.current = key;
    const a = asset ? getAsset(asset) : undefined;
    void run({ question: q ?? (a ? `Explain the ${a.name} (${a.symbol}) and its risks.` : ''), assetId: a?.id });
    setParams({}, { replace: true });
  }, [params]);

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    if (!draft.trim() || busy) return;
    void run({ question: draft });
    setDraft('');
  };

  const live = status.data?.mode === 'live';

  return (
    <div className="space-y-6">
      <PageHeader
        title="VESTORA Intelligence"
        description="Understand before you invest. Ask about an asset, a market or a concept and get a structured, plain-language explanation of what drives it and what could go wrong."
        actions={
          status.isLoading ? (
            <span className="skeleton h-6 w-40" />
          ) : live ? (
            <Badge variant="blue">
              <Sparkles aria-hidden /> Live AI · {status.data?.model ?? status.data?.provider}
            </Badge>
          ) : (
            <Badge variant="demo">Educational demo assistant</Badge>
          )
        }
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="min-w-0 space-y-6">
          <Card>
            <CardContent className="space-y-4 pt-5">
              <form onSubmit={submit} className="space-y-3">
                <label htmlFor="ai-question" className="sr-only">
                  Your question
                </label>
                <div className="relative">
                  <Textarea
                    id="ai-question"
                    value={draft}
                    maxLength={MAX_QUESTION}
                    onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        submit();
                      }
                    }}
                    rows={3}
                    placeholder="Ask about an asset or a concept — for example, why is silver more volatile than gold?"
                    className="min-h-[96px] resize-none pr-14 text-[15px]"
                  />
                  <Button type="submit" size="icon" aria-label="Ask" disabled={!draft.trim() || busy} className="absolute bottom-3 right-3">
                    <ArrowUp />
                  </Button>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-subtle">
                  <span>Enter to ask · Shift+Enter for a new line</span>
                  <span className="tabular">
                    {draft.length}/{MAX_QUESTION}
                  </span>
                </div>
              </form>
              <div className="flex flex-wrap gap-2">
                {SUGGESTED_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    type="button"
                    disabled={busy}
                    onClick={() => void run({ question: q })}
                    className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-border-strong hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {turns.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border px-6 py-12 text-center">
              <MessageSquareText className="mx-auto size-8 text-subtle" aria-hidden />
              <p className="mt-3 font-medium">Ask your first question</p>
              <p className="mx-auto mt-1 max-w-md text-[13px] leading-relaxed text-muted-foreground">
                Answers about an asset follow the same seven sections: what it is, how it derives value, what moves its price, its major risks, its historical volatility, what
                beginners should know, and what could make it fall.
              </p>
            </div>
          ) : (
            <section aria-label="Conversation" aria-live="polite" className="space-y-6">
              <div className="flex items-center justify-between">
                <p className="text-[13px] text-muted-foreground">
                  {turns.length} question{turns.length === 1 ? '' : 's'} this session · newest first
                </p>
                <Button variant="ghost" size="sm" onClick={clear} disabled={busy}>
                  <Trash2 /> Clear
                </Button>
              </div>
              {turns.map((t) => (
                <div key={t.id} className="space-y-3">
                  <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-muted px-4 py-2.5 text-sm text-foreground">{t.req.question}</div>
                  {t.status === 'loading' && (
                    <div className="space-y-3 rounded-xl border border-border bg-card p-5" aria-busy="true" aria-label="Preparing an answer">
                      <span className="skeleton block h-5 w-40" />
                      <span className="skeleton block h-6 w-2/3" />
                      <span className="skeleton block h-4 w-full" />
                      <span className="skeleton block h-4 w-5/6" />
                      <span className="skeleton block h-24 w-full" />
                    </div>
                  )}
                  {t.status === 'error' && (
                    <ErrorState
                      title="No answer this time"
                      description={t.error}
                      action={
                        <div className="flex flex-wrap gap-2">
                          <Button size="sm" variant="outline" onClick={() => void answerLocally(t)}>
                            Use the built-in assistant
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              patch(t.id, { status: 'loading', error: undefined });
                              askAssistant(t.req, () => loadStats(instrumentIdsFor(t.req)))
                                .then((answer) => patch(t.id, { status: 'done', answer }))
                                .catch((err) => patch(t.id, { status: 'error', error: friendlyError(err) }));
                            }}
                          >
                            <RotateCcw /> Try again
                          </Button>
                        </div>
                      }
                    />
                  )}
                  {t.status === 'done' && t.answer && (
                    <AnswerCard
                      answer={t.answer}
                      onFollowUp={(q) => {
                        if (!busy) void run({ question: q, assetId: t.answer?.subject?.kind === 'asset' ? t.answer.subject.id : undefined });
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                    />
                  )}
                </div>
              ))}
            </section>
          )}
        </div>

        <aside className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Explain a sample asset</CardTitle>
              <CardDescription>Get the seven-part explainer, a risk score and bull and bear scenarios.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Select value={explainId} onValueChange={setExplainId}>
                <SelectTrigger aria-label="Sample asset">
                  <SelectValue placeholder="Choose an asset" />
                </SelectTrigger>
                <SelectContent>
                  {TOKENISED_ASSETS.map((a) => (
                    <SelectItem key={a.id} value={a.id}>
                      {a.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                className="w-full"
                disabled={!explainId || busy}
                onClick={() => {
                  const a = getAsset(explainId);
                  if (a) void run({ question: `Explain the ${a.name} (${a.symbol}) and its risks.`, assetId: a.id });
                }}
              >
                Explain this asset
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>How the risk score works</CardTitle>
              <CardDescription>Five weighted factors, each scored 1–10. Volatility and drawdown are measured from a year of real prices when at least 20 observations exist.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <ul className="space-y-2.5">
                {RISK_FACTORS.map((f) => (
                  <li key={f.key} className="space-y-1 text-[13px]">
                    <span className="flex justify-between gap-3">
                      <span className="text-foreground/90">{f.label}</span>
                      <span className="tabular text-muted-foreground">{Math.round(f.weight * 100)}% of score</span>
                    </span>
                    <span className="block h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden>
                      <span className="block h-full rounded-full bg-blue" style={{ width: `${f.weight * 100}%` }} />
                    </span>
                  </li>
                ))}
              </ul>
              <Link to="/learn/risk-score" className="inline-flex items-center gap-1.5 text-[13px] text-blue hover:underline">
                <BookOpen className="size-3.5" aria-hidden /> Read the full methodology
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="size-4 text-gold" aria-hidden /> What it will not do
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-[13px] leading-relaxed text-muted-foreground">
                <li>Tell you to buy, sell or hold anything, or how much to invest.</li>
                <li>Predict prices, set targets or promise returns.</li>
                <li>Act as a licensed financial adviser.</li>
                <li>Follow instructions hidden inside a question — your text is treated as a question, nothing more.</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="size-4 text-muted-foreground" aria-hidden /> Where answers come from
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-[13px] leading-relaxed text-muted-foreground">
              {live ? (
                <p>
                  Answers are written by {status.data?.provider === 'openai' ? 'an OpenAI' : 'a Claude'} model through the VESTORA server, grounded in a curated knowledge base
                  and real market statistics, and checked against guardrails. If the model is unavailable, a curated answer is shown and labelled.
                </p>
              ) : (
                <p>
                  No AI provider is configured{status.data?.reachable === false ? ' and the API server is not reachable' : ''}, so answers come from VESTORA’s built-in educational
                  assistant: curated explanations plus statistics measured from real market history where available. Add an API key on the server to enable live AI.
                </p>
              )}
              <p>AI keys stay on the server — never in this page.</p>
            </CardContent>
          </Card>
        </aside>
      </div>

      <p className="text-xs leading-relaxed text-subtle">{AI_DISCLAIMER}</p>
    </div>
  );
}
