import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Eye, EyeOff, Star } from 'lucide-react';
import { toast } from 'sonner';
import {
  formatPct,
  formatQuote,
  formatUsd,
  getAsset,
  getInstrument,
  type HistoryRange,
} from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Segmented } from '@/components/ui/primitives';
import { Table, TBody, TD, TH, THead, TR } from '@/components/ui/table';
import { Disclaimer, EmptyState, PageHeader, StatTile } from '@/components/common/States';
import { AssetIcon, RiskBadge } from '@/components/assets/AssetBits';
import { AllocationChart } from '@/components/charts/AllocationChart';
import { PriceChart } from '@/components/charts/PriceChart';
import { RiskDistribution } from '@/components/charts/RiskDistribution';
import { DataStatusBadge } from '@/components/market/DataStatus';
import { PriceChange } from '@/components/market/PriceChange';
import { ActivityList } from '@/components/portfolio/ActivityList';
import { useAllQuotes, useValuations } from '@/hooks/useMarket';
import { usePerformance, usePortfolio, type PortfolioSource, type Position } from '@/hooks/usePortfolio';
import { CATEGORY_CHART_ORDER, categoryColor } from '@/lib/chart-colors';
import { useAppStore } from '@/store/app';
import { useOnchain } from '@/wallet/useOnchain';
import { useWallet } from '@/wallet/WalletProvider';

const SOURCE_LABEL: Record<PortfolioSource, string> = { sample: 'Sample', simulated: 'Simulated', onchain: 'On-chain' };

function SellDialog({ position, mode, onClose }: { position: Position | null; mode: PortfolioSource; onClose: () => void }) {
  const [tokens, setTokens] = useState('1');
  const sell = useAppStore((s) => s.simulateSell);
  const onchain = useOnchain();
  const [busy, setBusy] = useState(false);
  if (!position) return null;
  const n = Number(tokens);
  const valid = Number.isInteger(n) && n >= 1 && n <= position.tokens;
  const chainPrice = onchain.snapshot.data?.assets[position.asset.tokenId]?.price ?? position.asset.onchainPrice;
  const price = mode === 'onchain' ? chainPrice : position.valuation.tokenPrice ?? 0;
  return (
    <Dialog open onOpenChange={(o: boolean) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'onchain' ? 'Redeem testnet tokens' : 'Sell simulated tokens'}</DialogTitle>
          <DialogDescription>
            {mode === 'onchain'
              ? `Burns your ${position.asset.symbol} tokens and returns vUSD demo credits at the on-chain issuance price (${chainPrice} vUSD per token).`
              : `Sells at today’s illustrative token price (${formatUsd(price)}). This is a simulation — no real market or counterparty exists.`}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="sell-tokens">Tokens to {mode === 'onchain' ? 'redeem' : 'sell'} (max {position.tokens.toLocaleString('en-US')})</Label>
          <Input id="sell-tokens" type="number" min={1} max={position.tokens} step={1} value={tokens} onChange={(e) => setTokens(e.target.value)} aria-invalid={!valid || undefined} />
          <FieldHint error={!valid}>{valid ? `You receive ${mode === 'onchain' ? `${(n * chainPrice).toLocaleString('en-US')} vUSD` : formatUsd(n * price)}.` : `Enter a whole number between 1 and ${position.tokens}.`}</FieldHint>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            disabled={!valid || busy}
            loading={busy}
            onClick={async () => {
              if (mode === 'onchain') {
                setBusy(true);
                try {
                  await onchain.redeem(position.asset.tokenId, n, chainPrice);
                  onClose();
                } catch {
                  /* toast already shown */
                } finally {
                  setBusy(false);
                }
                return;
              }
              const r = sell({ assetId: position.asset.id, tokens: n, unitPrice: price });
              if (r.ok) {
                toast.success(`Sold ${n} ${position.asset.symbol} (simulated)`, { description: r.item.id });
                onClose();
              } else toast.error(r.error);
            }}
          >
            {mode === 'onchain' ? 'Confirm in wallet' : 'Confirm simulated sale'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Portfolio() {
  const navigate = useNavigate();
  const portfolio = usePortfolio();
  const [range, setRange] = useState<HistoryRange>('3M');
  const perf = usePerformance(portfolio, range);
  const setView = useAppStore((s) => s.setPortfolioView);
  const hide = useAppStore((s) => s.settings.hideBalances);
  const setSettings = useAppStore((s) => s.setSettings);
  const watchlist = useAppStore((s) => s.watchlist);
  const activity = useAppStore((s) => s.activity);
  const wallet = useWallet();
  const { quotes } = useAllQuotes();
  const { valuations } = useValuations();
  const [selling, setSelling] = useState<Position | null>(null);

  const money = (n: number | null, d = 2) => (hide ? '•••••' : formatUsd(n, d));
  const slices = useMemo(
    () =>
      CATEGORY_CHART_ORDER.map((c) => portfolio.byCategory.find((b) => b.category === c))
        .filter((x): x is NonNullable<typeof x> => Boolean(x))
        .map((b) => ({ key: b.category, label: b.label, value: b.value, color: categoryColor(b.category) })),
    [portfolio.byCategory],
  );
  // Only holdings priced from market data (not simulated fixed valuations or static demo values) can "perform".
  const top = [...portfolio.positions]
    .filter((p) => p.valuation.changePct !== null && p.valuation.inputStatus !== 'fixed' && p.valuation.inputStatus !== 'demo' && p.valuation.inputStatus !== 'unavailable')
    .sort((a, b) => (b.valuation.changePct ?? 0) - (a.valuation.changePct ?? 0)).slice(0, 3);
  const watchedAssets = watchlist.map((id) => getAsset(id)).filter((a): a is NonNullable<typeof a> => Boolean(a));
  const watchedInstruments = watchlist.filter((w) => w.startsWith('i:')).map((w) => getInstrument(w.slice(2))).filter((i): i is NonNullable<typeof i> => Boolean(i));

  return (
    <div className="space-y-6">
      <PageHeader
        title="My portfolio"
        description={portfolio.description}
        actions={
          <>
            <Button variant="ghost" size="sm" onClick={() => setSettings({ hideBalances: !hide })} aria-pressed={hide}>
              {hide ? <Eye /> : <EyeOff />} {hide ? 'Show values' : 'Hide values'}
            </Button>
            <Segmented<PortfolioSource>
              label="Portfolio source"
              value={portfolio.source}
              onChange={(v) => setView(v)}
              options={(['sample', 'simulated', 'onchain'] as PortfolioSource[]).map((s) => ({ value: s, label: SOURCE_LABEL[s], disabled: !portfolio.available.includes(s) }))}
            />
          </>
        }
      />

      {portfolio.source === 'sample' && (
        <Disclaimer tone="gold">
          You’re viewing a <span className="font-medium text-foreground">sample portfolio</span>. Make a simulated investment or connect a testnet wallet to see your own holdings.{' '}
          <button className="text-blue hover:underline" onClick={() => navigate('/invest')}>
            Simulate an investment
          </button>
          {wallet.status !== 'connected' && (
            <>
              {' '}
              or{' '}
              <button className="text-blue hover:underline" onClick={() => navigate('/wallet')}>
                connect a wallet
              </button>
            </>
          )}
          .
        </Disclaimer>
      )}
      {portfolio.source === 'onchain' && wallet.address && (
        <Disclaimer>
          Showing testnet balances for <span className="font-mono text-foreground">{wallet.address}</span>. Values use illustrative token prices.
        </Disclaimer>
      )}

      <section aria-label="Portfolio totals" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Total portfolio value" value={money(portfolio.totals.value)} loading={portfolio.loading} sub={<Badge variant="outline">{SOURCE_LABEL[portfolio.source]}</Badge>} />
        <StatTile
          label={portfolio.totals.pnl !== null ? 'Simulated profit / loss' : `Change over ${range}`}
          value={portfolio.totals.pnl !== null ? money(portfolio.totals.pnl) : perf.change === null ? '—' : money(perf.change)}
          delta={
            (portfolio.totals.pnl !== null ? portfolio.totals.pnlPct : perf.changePct) !== null ? (
              <span className={((portfolio.totals.pnl !== null ? portfolio.totals.pnlPct : perf.changePct) ?? 0) >= 0 ? 'text-success' : 'text-danger'}>
                {formatPct(portfolio.totals.pnl !== null ? portfolio.totals.pnlPct : perf.changePct)}
              </span>
            ) : undefined
          }
          sub={portfolio.totals.pnl !== null ? 'vs cost basis' : 'from real reference prices'}
        />
        <StatTile label="Sample token holdings" value={portfolio.totals.tokens.toLocaleString('en-US')} sub={`${portfolio.positions.length} assets`} />
        <StatTile
          label={portfolio.totals.cashLabel}
          value={portfolio.totals.cash === null ? '—' : portfolio.source === 'onchain' ? `${portfolio.totals.cash.toLocaleString('en-US')} vUSD` : money(portfolio.totals.cash)}
          sub={portfolio.source === 'sample' ? 'Not used by the sample' : 'Available to invest'}
        />
      </section>

      {portfolio.positions.length === 0 ? (
        <EmptyState
          title="No holdings yet"
          description={portfolio.source === 'onchain' ? 'This wallet holds no sample tokens yet. Claim demo credits and buy a fraction from the marketplace.' : 'Start with a simulated investment from the marketplace.'}
          action={
            <Button asChild>
              <Link to="/marketplace">Browse the marketplace</Link>
            </Button>
          }
        />
      ) : (
        <>
          <div className="grid gap-6 xl:grid-cols-[1.5fr_1fr]">
            <Card>
              <CardHeader className="flex-row flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Portfolio performance</CardTitle>
                  <CardDescription>Value of current holdings over time, using real reference histories.</CardDescription>
                </div>
                <Segmented<HistoryRange> label="Performance range" value={range} onChange={setRange} options={(['1M', '3M', '1Y'] as HistoryRange[]).map((r) => ({ value: r, label: r }))} />
              </CardHeader>
              <CardContent className="space-y-3">
                <PriceChart
                  points={perf.points}
                  range={range}
                  denomination="USD"
                  color="var(--gold)"
                  height={280}
                  loading={perf.loading}
                  seriesLabel="Portfolio value"
                  emptyTitle={portfolio.source === 'simulated' ? 'Your simulated portfolio is new' : 'Not enough history yet'}
                  emptyMessage={
                    portfolio.source === 'simulated'
                      ? 'Performance builds up as reference prices update after your first purchase. Switch to the sample portfolio to see a longer history.'
                      : 'Reference histories are unavailable for this range.'
                  }
                />
                {perf.flatAssets.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    Held at today’s illustrative value (no history in range): {perf.flatAssets.join(', ')}.
                  </p>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Asset allocation</CardTitle>
                <CardDescription>By category, at illustrative token prices.</CardDescription>
              </CardHeader>
              <CardContent>
                <AllocationChart slices={slices} hideValues={hide} centerLabel="Portfolio" />
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 xl:grid-cols-[1fr_1.5fr]">
            <Card>
              <CardHeader>
                <CardTitle>Portfolio risk distribution</CardTitle>
                <CardDescription>
                  Share of value by educational risk level.{' '}
                  <Link to="/learn/risk-score" className="text-blue hover:underline">
                    How levels are set
                  </Link>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <RiskDistribution values={portfolio.byRisk} hideValues={hide} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Top performing holdings</CardTitle>
                <CardDescription>Latest change in each holding’s reference price.</CardDescription>
              </CardHeader>
              <CardContent>
                {top.length === 0 ? (
                  <p className="text-[13px] text-muted-foreground">No live changes yet.</p>
                ) : (
                  <ul className="space-y-2.5">
                    {top.map((p) => (
                      <li key={p.asset.id} className="flex items-center gap-3">
                        <AssetIcon asset={p.asset} size="sm" />
                        <Link to={`/assets/${p.asset.id}`} className="min-w-0 flex-1 truncate text-sm hover:underline">
                          {p.asset.name}
                        </Link>
                        {p.valuation.inputStatus !== 'fixed' && <DataStatusBadge status={p.valuation.inputStatus} withTooltip={false} />}
                        <PriceChange pct={p.valuation.changePct} />
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Token ownership breakdown</CardTitle>
              <CardDescription>Your share of each sample’s token supply. Illustrative only — tokens carry no legal ownership.</CardDescription>
            </CardHeader>
            <CardContent className="px-0 pb-2">
              <Table>
                <THead>
                  <TR>
                    <TH>Asset</TH>
                    <TH className="text-right">Tokens</TH>
                    <TH className="text-right">Share of supply</TH>
                    <TH className="text-right">Token price</TH>
                    <TH className="text-right">Value</TH>
                    <TH className="text-right">P/L</TH>
                    <TH>Risk</TH>
                    <TH>
                      <span className="sr-only">Actions</span>
                    </TH>
                  </TR>
                </THead>
                <TBody>
                  {portfolio.positions.map((p) => (
                    <TR key={p.asset.id}>
                      <TD>
                        <Link to={`/assets/${p.asset.id}`} className="flex items-center gap-3 hover:underline">
                          <AssetIcon asset={p.asset} size="sm" />
                          <span>
                            <span className="block font-medium">{p.asset.symbol}</span>
                            <span className="block text-xs text-muted-foreground">{p.asset.name}</span>
                          </span>
                        </Link>
                      </TD>
                      <TD className="text-right tabular">{p.tokens.toLocaleString('en-US')}</TD>
                      <TD className="text-right tabular">{p.supplyShare < 0.01 ? p.supplyShare.toFixed(4) : p.supplyShare.toFixed(3)}%</TD>
                      <TD className="text-right tabular">{formatUsd(p.valuation.tokenPrice, (p.valuation.tokenPrice ?? 0) < 1 ? 4 : 2)}</TD>
                      <TD className="text-right tabular">{money(p.value)}</TD>
                      <TD className="text-right tabular">
                        {p.pnl === null ? (
                          <span className="text-subtle">—</span>
                        ) : (
                          <span className={p.pnl >= 0 ? 'text-success' : 'text-danger'}>
                            {hide ? '•••' : `${p.pnl >= 0 ? '+' : '−'}${formatUsd(Math.abs(p.pnl))}`} <span className="text-xs">({formatPct(p.pnlPct)})</span>
                          </span>
                        )}
                      </TD>
                      <TD>
                        <RiskBadge risk={p.risk} showScore={false} />
                      </TD>
                      <TD className="text-right">
                        {portfolio.source === 'sample' ? (
                          <Button size="sm" variant="ghost" onClick={() => navigate(`/invest/${p.asset.id}`)}>
                            Invest
                          </Button>
                        ) : (
                          <Button size="sm" variant="outline" onClick={() => setSelling(p)}>
                            {portfolio.source === 'onchain' ? 'Redeem' : 'Sell'}
                          </Button>
                        )}
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>Recent transactions</CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/transactions">All transactions</Link>
            </Button>
          </CardHeader>
          <CardContent>
            <ActivityList items={activity.slice(0, 6)} empty="No transactions yet." />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="size-4 text-gold" aria-hidden /> Watchlist
            </CardTitle>
            <CardDescription>Assets and markets you follow.</CardDescription>
          </CardHeader>
          <CardContent>
            {watchedAssets.length + watchedInstruments.length === 0 ? (
              <p className="text-[13px] text-muted-foreground">Star assets or markets to follow them here.</p>
            ) : (
              <ul className="divide-y divide-border">
                {watchedAssets.map((a) => (
                  <li key={a.id} className="flex items-center gap-3 py-2.5">
                    <AssetIcon asset={a} size="sm" />
                    <Link to={`/assets/${a.id}`} className="min-w-0 flex-1 truncate text-sm hover:underline">
                      {a.name}
                    </Link>
                    <span className="text-sm tabular">{formatUsd(valuations[a.id]?.tokenPrice)}</span>
                    <PriceChange pct={valuations[a.id]?.changePct} />
                  </li>
                ))}
                {watchedInstruments.map((i) => (
                  <li key={i.id} className="flex items-center gap-3 py-2.5">
                    <span className="flex size-8 items-center justify-center rounded-lg bg-muted text-[11px] font-semibold text-muted-foreground">{i.symbol.slice(0, 3)}</span>
                    <Link to={`/markets?focus=${i.id}`} className="min-w-0 flex-1 truncate text-sm hover:underline">
                      {i.name}
                    </Link>
                    <span className="text-sm tabular">{formatQuote(quotes[i.id]?.price, i.denomination, i.decimals)}</span>
                    <PriceChange pct={quotes[i.id]?.changePct} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
      <SellDialog position={selling} mode={portfolio.source} onClose={() => setSelling(null)} />
    </div>
  );
}
