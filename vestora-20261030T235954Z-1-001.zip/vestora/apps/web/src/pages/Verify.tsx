import { Link } from 'react-router';
import { ShieldCheck } from 'lucide-react';
import { relativeTime } from '@vestora/shared';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/common/States';
import { KycStatusBadge } from '@/components/kyc/KycStatusBadge';
import { KycWizard } from '@/components/kyc/KycWizard';
import { TARGET_CHAIN } from '@/config/chains';
import { useAppStore } from '@/store/app';
import { useOnchain } from '@/wallet/useOnchain';
import { useWallet } from '@/wallet/WalletProvider';

export default function Verify() {
  const kyc = useAppStore((s) => s.kyc);
  const wallet = useWallet();
  const onchain = useOnchain();
  const snap = onchain.snapshot.data;
  return (
    <div className="space-y-6">
      <PageHeader title="Verification" description="A simulated know-your-customer (KYC) flow that shows how regulated platforms onboard investors — without collecting any real identity data." />
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <Card>
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-3">
            <CardTitle>Simulated KYC</CardTitle>
            <KycStatusBadge status={kyc.status} />
          </CardHeader>
          <CardContent>
            <KycWizard />
          </CardContent>
        </Card>
        <aside className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Status</CardTitle>
              <CardDescription>Statuses used by VESTORA: Not started, Pending, Verified (simulated) and Rejected (simulated).</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Browser status</span>
                <KycStatusBadge status={kyc.status} />
              </div>
              {kyc.submittedAt && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Submitted</span>
                  <span>{relativeTime(kyc.submittedAt)}</span>
                </div>
              )}
              {kyc.caseId && (
                <div className="flex justify-between gap-3">
                  <span className="text-muted-foreground">Case reference</span>
                  <span className="truncate font-mono text-xs">{kyc.caseId.slice(0, 14)}…</span>
                </div>
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="size-4 text-blue" aria-hidden /> On-chain gate
              </CardTitle>
              <CardDescription>
                On {TARGET_CHAIN.name}, the ComplianceManager contract records only a status and a hashed case reference — never your name or email. AssetToken refuses
                purchases from unverified wallets.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              {wallet.status !== 'connected' ? (
                <p className="text-muted-foreground">Connect a wallet to record your simulated verification on the testnet.</p>
              ) : !onchain.ready ? (
                <p className="text-muted-foreground">Switch to {TARGET_CHAIN.name} with the contracts deployed to use the on-chain gate.</p>
              ) : (
                <p>
                  On-chain status: <span className="font-medium">{snap ? (snap.verified ? 'Verified' : snap.kycStatus) : 'Loading…'}</span>
                </p>
              )}
              <Button variant="outline" size="sm" asChild>
                <Link to="/wallet">Open wallet</Link>
              </Button>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}
