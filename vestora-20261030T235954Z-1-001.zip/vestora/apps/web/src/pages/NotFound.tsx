import { Link, useLocation } from 'react-router';
import { Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { EmptyState } from '@/components/common/States';

export default function NotFound() {
  const { pathname } = useLocation();
  return (
    <div className="mx-auto max-w-lg py-16">
      <EmptyState
        icon={Compass}
        title="This page doesn’t exist"
        description={
          <>
            Nothing lives at <code className="font-mono text-xs">{pathname}</code>. Check the address, or head back to an area of VESTORA below.
          </>
        }
        action={
          <div className="flex flex-wrap justify-center gap-2">
            <Button asChild size="sm">
              <Link to="/overview">Go to overview</Link>
            </Button>
            <Button asChild size="sm" variant="outline">
              <Link to="/marketplace">Browse the marketplace</Link>
            </Button>
          </div>
        }
      />
    </div>
  );
}
