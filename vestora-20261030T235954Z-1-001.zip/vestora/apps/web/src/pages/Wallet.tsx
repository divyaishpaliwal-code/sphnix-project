import { useState } from 'react';
import { Link } from 'react-router';
import { Copy, ExternalLink, Gift, LogOut, RefreshCw, ShieldCheck, Wallet as WalletIcon } from 'lucide-react';
import { toast } from 'sonner';
import { isAddress } from 'ethers';
import { formatUsd, getAsset, getAssetByTokenId, shortAddress } from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Table, TBody, TD, TH, THead, TR } from '@/components/ui/table';
import { Disclaimer, EmptyState, ErrorState, PageHeader } from '@/components/common/States';
import { AssetIcon } from '@/components/assets/AssetBits';
import { TARGET_CHAIN, chainName, explorerAddress, explorerTx } from '@/config/chains';
import { copyText, uid } from '@/lib/utils';
import { useAppStore } from '@/store/app';
import { useOnchain } from '@/wallet/useOnchain';
import { useWallet } from '@/wallet/WalletProvider';

function ConnectionCard() {
  const w = useWallet();
  if (w.status === 'connected' && w.address) {
    const link = explorerAddress(w.address);
    return (
      <Card>
        <CardHeader className="flex-row flex-wrap items-start justify-between gap-3">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-success" aria-hidden /> Connected{w.walletName ? ` with ${w.walletName}` : ''}
            </CardTitle>
            <CardDescription className="font-mono text-foreground/90">{shortAddress(w.address, 6)}</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={async () => toast((await copyText(w.address!)) ? 'Address copied' : 'Could not copy the address')}>
              <Copy /> Copy address
            </Button>
            {link && (
              <Button variant="outline" size="sm" asChild>
                <a href={link} target="_blank" rel="noreferrer">
                  <ExternalLink /> Explorer
                </a>
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => void w.disconnect()}>
              <LogOut /> Disconnect
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4 text-sm">
          <span className="flex items-center gap-2">
            Active network
            <Badge variant={w.isCorrectChain ? 'success' : 'warning'}>{chainName(w.chainId)}</Badge>
          </span>
          {!w.isCorrectChain && (
            <Button size="sm" onClick={() => void w.switchToTarget()}>
              Switch to {TARGET_CHAIN.name}
            </Button>
          )}
        </CardContent>
        {w.error && <ErrorState className="mx-5 mb-5" title="Wallet message" description={w.error} />}
      </Card>
    );
  }
  return (
    <Card>
      <CardHeader>
        <CardTitle>Connect MetaMask</CardTitle>
        <CardDescription>
          Connect a browser wallet to sign real transactions on the {TARGET_CHAIN.name} testnet. VESTORA never asks for private keys or seed phrases.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {w.status === 'detecting' ? (
          <span className="skeleton block h-10 w-48" />
        ) : w.status === 'unavailable' ? (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">No browser wallet was detected in this browser.</p>
            <Button asChild>
              <a href="https://metamask.io/download/" target="_blank" rel="noreferrer">
                Install MetaMask
              </a>
            </Button>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {w.wallets.map((info) => (
              <Button key={info.uuid} onClick={() => void w.connect(info.rdns)} loading={w.status === 'connecting'} variant={info.rdns === 'io.metamask' ? 'default' : 'outline'}>
                {info.icon ? <img src={info.icon} alt="" className="size-4" /> : <WalletIcon />}
                Connect {info.name}
              </Button>
            ))}
          </div>
        )}
        {w.error && <ErrorState title="Wallet message" description={w.error} />}
      </CardContent>
    </Card>
  );
}

function DemoWalletCard() {
  const demo = useAppStore((s) => s.demo);
  const holdings = Object.values(demo.holdings);
  return (
    <Card className="border-dashed">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Demo mode <Badge variant="outline" className="border-dashed">Simulated</Badge>
        </CardTitle>
        <CardDescription>No wallet needed. Simulated balances live only in this browser and never touch a blockchain.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Simulated cash</span>
          <span className="font-medium tabular">{formatUsd(demo.cash)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Simulated holdings</span>
          <span className="tabular">
            {holdings.length} assets · {holdings.reduce((s, h) => s + h.tokens, 0).toLocaleString('en-US')} tokens
          </span>
        </div>
        <div className="flex gap-2 pt-1">
          <Button size="sm" asChild>
            <Link to="/invest">Simulate an investment</Link>
          </Button>
          <Button size="sm" variant="outline" asChild>
            <Link to="/portfolio">View portfolio</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function OfficerConsole() {
  const { officerAction } = useOnchain();
  const [addr, setAddr] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const valid = isAddress(addr);
  const run = async (action: 'approve' | 'reject' | 'revoke') => {
    setBusy(action);
    try {
      await officerAction(action, addr);
    } catch {
      /* toast shown */
    } finally {
      setBusy(null);
    }
  };
  return (
    <Card className="border-blue/25">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="size-4 text-blue" aria-hidden /> Compliance officer console
        </CardTitle>
        <CardDescription>This wallet holds the COMPLIANCE_OFFICER_ROLE. Approve, reject or revoke simulated verification for any testnet address.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-2">
          <Label htmlFor="officer-addr">Wallet address</Label>
          <Input id="officer-addr" value={addr} onChange={(e) => setAddr(e.target.value.trim())} placeholder="0x…" className="font-mono" aria-invalid={(addr !== '' && !valid) || undefined} />
          {addr !== '' && !valid && <FieldHint error>Enter a valid 0x address.</FieldHint>}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" disabled={!valid || Boolean(busy)} loading={busy === 'approve'} onClick={() => run('approve')}>
            Approve
          </Button>
          <Button size="sm" variant="outline" disabled={!valid || Boolean(busy)} loading={busy === 'reject'} onClick={() => run('reject')}>
            Reject
          </Button>
          <Button size="sm" variant="ghost" disabled={!valid || Boolean(busy)} loading={busy === 'revoke'} onClick={() => run('revoke')}>
            Revoke
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function WalletPage() {
  const w = useWallet();
  const onchain = useOnchain();
  const kyc = useAppStore((s) => s.kyc);
  const snap = onchain.snapshot.data;
  const [busy, setBusy] = useState<string | null>(null);

  const act = async (key: string, fn: () => Promise<unknown>) => {
    setBusy(key);
    try {
      await fn();
    } catch {
      /* toast already shown */
    } finally {
      setBusy(null);
    }
  };

  const holdings = snap ? Object.entries(snap.balances).filter(([, b]) => b > 0) : [];

  return (
    <div className="space-y-6">
      <PageHeader title="Wallet" description="Connect MetaMask to use the testnet contracts, or keep exploring in demo mode." />

      {!onchain.config.configured && (
        <Disclaimer tone="warning">
          Testnet contracts are not configured for {TARGET_CHAIN.name} in this build, so on-chain actions are unavailable. Deploy them with{' '}
          <code className="rounded bg-muted px-1">npm run contracts:deploy:sepolia</code> (see docs/DEPLOYMENT.md). Demo mode works without them.
        </Disclaimer>
      )}

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <ConnectionCard />
        <DemoWalletCard />
      </div>

      {w.status === 'connected' && w.isCorrectChain && onchain.config.configured && (
        <>
          {onchain.snapshot.isLoading ? (
            <div className="grid gap-4 md:grid-cols-3">
              <span className="skeleton h-32" />
              <span className="skeleton h-32" />
              <span className="skeleton h-32" />
            </div>
          ) : onchain.snapshot.error ? (
            <ErrorState
              title="Could not read the contracts"
              description={(onchain.snapshot.error as Error).message}
              action={
                <Button size="sm" variant="outline" onClick={() => onchain.snapshot.refetch()}>
                  <RefreshCw /> Retry
                </Button>
              }
            />
          ) : snap ? (
            <>
              <section aria-label="Testnet balances" className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardDescription>Test {TARGET_CHAIN.currency.symbol} (pays gas)</CardDescription>
                    <CardTitle className="text-2xl tabular">{Number(snap.native).toFixed(4)}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground">
                    {TARGET_CHAIN.faucet ? (
                      <a href={TARGET_CHAIN.faucet} target="_blank" rel="noreferrer" className="text-blue hover:underline">
                        Get free test {TARGET_CHAIN.currency.symbol} from a faucet
                      </a>
                    ) : (
                      'Local chain accounts are pre-funded.'
                    )}
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardDescription>vUSD demo credits (token id 0)</CardDescription>
                    <CardTitle className="text-2xl tabular">{snap.credits.toLocaleString('en-US')}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {snap.claimed ? (
                      <p className="text-xs text-muted-foreground">Claimed. Credits are non-transferable and have no value.</p>
                    ) : (
                      <Button size="sm" loading={busy === 'claim'} onClick={() => act('claim', () => onchain.claimCredits())}>
                        <Gift /> Claim 10,000 vUSD
                      </Button>
                    )}
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardDescription>On-chain verification</CardDescription>
                    <CardTitle className="flex items-center gap-2 text-2xl">
                      {snap.verified ? 'Verified' : snap.kycStatus}
                      {snap.frozen && <Badge variant="danger">Frozen</Badge>}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {!snap.verified && snap.kycStatus !== 'Pending' && (
                      <Button
                        size="sm"
                        variant="blue"
                        loading={busy === 'kyc'}
                        disabled={kyc.status !== 'verified'}
                        onClick={() => act('kyc', () => onchain.requestVerification(kyc.caseId ?? uid('case_')))}
                      >
                        <ShieldCheck /> Record verification
                      </Button>
                    )}
                    <p className="text-xs text-muted-foreground">
                      {kyc.status !== 'verified' && !snap.verified ? (
                        <>
                          Complete the{' '}
                          <Link to="/verify" className="text-blue hover:underline">
                            simulated KYC
                          </Link>{' '}
                          first.{' '}
                        </>
                      ) : null}
                      {snap.selfService ? 'Self-service mode: requests are approved instantly.' : 'Requests wait for a compliance officer to approve them.'}
                    </p>
                  </CardContent>
                </Card>
              </section>

              {snap.isOfficer && <OfficerConsole />}

              <Card>
                <CardHeader>
                  <CardTitle>Sample token holdings</CardTitle>
                  <CardDescription>ERC-1155 balances read from the AssetToken contract.</CardDescription>
                </CardHeader>
                <CardContent className="px-0 pb-2">
                  {holdings.length === 0 ? (
                    <div className="px-5 pb-3">
                      <EmptyState title="No sample tokens yet" description="Buy a fraction from the marketplace — the purchase is recorded on the testnet." action={<Button asChild size="sm"><Link to="/invest">Start an investment</Link></Button>} />
                    </div>
                  ) : (
                    <Table>
                      <THead>
                        <TR>
                          <TH>Asset</TH>
                          <TH>Token id</TH>
                          <TH className="text-right">Balance</TH>
                          <TH className="text-right">Issuance price</TH>
                        </TR>
                      </THead>
                      <TBody>
                        {holdings.map(([tid, bal]) => {
                          const a = getAssetByTokenId(Number(tid));
                          return (
                            <TR key={tid}>
                              <TD>
                                {a ? (
                                  <Link to={`/assets/${a.id}`} className="flex items-center gap-2.5 hover:underline">
                                    <AssetIcon asset={a} size="sm" /> {a.name}
                                  </Link>
                                ) : (
                                  `Token ${tid}`
                                )}
                              </TD>
                              <TD className="font-mono text-xs">#{tid}</TD>
                              <TD className="text-right tabular">{bal.toLocaleString('en-US')}</TD>
                              <TD className="text-right tabular">{snap.assets[Number(tid)]?.price ?? '—'} vUSD</TD>
                            </TR>
                          );
                        })}
                      </TBody>
                    </Table>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex-row items-center justify-between">
                  <div>
                    <CardTitle>Transaction history</CardTitle>
                    <CardDescription>Contract events for this wallet from recent blocks.</CardDescription>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => onchain.history.refetch()}>
                    <RefreshCw /> Refresh
                  </Button>
                </CardHeader>
                <CardContent>
                  {onchain.history.isLoading ? (
                    <span className="skeleton block h-24" />
                  ) : (onchain.history.data ?? []).length === 0 ? (
                    <p className="text-[13px] text-muted-foreground">No contract events found for this wallet in recent blocks.</p>
                  ) : (
                    <ul className="divide-y divide-border">
                      {(onchain.history.data ?? []).map((e) => {
                        const link = explorerTx(e.hash);
                        const asset = e.assetId ? getAsset(e.assetId) : undefined;
                        return (
                          <li key={`${e.hash}-${e.kind}`} className="flex flex-wrap items-center gap-3 py-3 text-sm">
                            <Badge variant="blue">{e.kind === 'buy' ? 'Purchase' : e.kind === 'sell' ? 'Redeem' : e.kind === 'claim' ? 'Credits' : 'KYC'}</Badge>
                            <span className="min-w-0 flex-1">
                              {e.kind === 'buy' || e.kind === 'sell'
                                ? `${e.tokens} ${asset?.symbol ?? ''} for ${e.credits} vUSD`
                                : e.kind === 'claim'
                                  ? `${e.credits?.toLocaleString('en-US')} vUSD claimed`
                                  : `Status: ${e.note}`}
                            </span>
                            <span className="text-xs text-muted-foreground">Block {e.blockNumber.toLocaleString('en-US')}</span>
                            {link && (
                              <a href={link} target="_blank" rel="noreferrer" className="flex items-center gap-1 font-mono text-xs text-blue hover:underline">
                                {shortAddress(e.hash, 6)} <ExternalLink className="size-3" />
                              </a>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </CardContent>
              </Card>
            </>
          ) : null}
        </>
      )}

      {w.status === 'connected' && !w.isCorrectChain && (
        <Disclaimer tone="warning">
          Your wallet is on {chainName(w.chainId)}. VESTORA only works on the {TARGET_CHAIN.name} testnet — switch networks to see balances.
        </Disclaimer>
      )}
    </div>
  );
}
