import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router';
import { BadgeCheck, CheckCircle2, Circle, ExternalLink, FlaskConical, Loader2, Search, Wallet as WalletIcon, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import {
  CALCULATOR_DISCLAIMER,
  CATEGORY_LABELS,
  SIMULATION_LABEL,
  TOKENISED_ASSETS,
  assetReferenceInstrument,
  calculateOwnership,
  formatNumber,
  formatUsd,
  getAsset,
  getInstrument,
  profileForSubject,
  shortAddress,
  type AssetValuation,
  type TokenisedAsset,
} from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/primitives';
import { Disclaimer, PageHeader } from '@/components/common/States';
import { AssetIcon, RiskBadge } from '@/components/assets/AssetBits';
import { useSampleSupply } from '@/components/assets/AssetCard';
import { KycWizard } from '@/components/kyc/KycWizard';
import { IllustrativeBadge } from '@/components/market/DataStatus';
import { TARGET_CHAIN, explorerTx } from '@/config/chains';
import { useAssetInsights } from '@/hooks/useAsset';
import { useValuations } from '@/hooks/useMarket';
import { cn, uid } from '@/lib/utils';
import { useAppStore, type ActivityItem } from '@/store/app';
import { useOnchain } from '@/wallet/useOnchain';
import { useWallet } from '@/wallet/WalletProvider';

const STEPS = ['Select asset', 'Amount', 'Calculation', 'Risk disclosure', 'Verification', 'Wallet or demo', 'Confirm', 'Result'];

type Mode = 'demo' | 'chain';
type Result =
  | { kind: 'demo'; item: ActivityItem }
  | { kind: 'chain'; hash: string | null; status: 'signing' | 'pending' | 'confirmed' | 'failed'; blockNumber: number | null; tokens: number; error?: string };

export default function Invest() {
  const { assetId } = useParams<{ assetId?: string }>();
  const [params] = useSearchParams();
  // A new deep link (/invest/:assetId?amount=…) starts a fresh flow.
  return <InvestFlow key={`${assetId ?? ''}|${params.get('amount') ?? ''}`} routeAsset={assetId} initialAmount={params.get('amount')} />;
}

function InvestFlow({ routeAsset, initialAmount }: { routeAsset?: string; initialAmount: string | null }) {
  const navigate = useNavigate();
  const initialAsset = routeAsset && getAsset(routeAsset) ? routeAsset : null;
  const [step, setStep] = useState(initialAsset ? 1 : 0);
  const [assetId, setAssetId] = useState<string | null>(initialAsset);
  const [amount, setAmount] = useState(initialAmount ?? '100');
  const [search, setSearch] = useState('');
  const [ack, setAck] = useState(false);
  const [mode, setMode] = useState<Mode | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const { valuations } = useValuations();
  const kyc = useAppStore((s) => s.kyc);
  const cash = useAppStore((s) => s.demo.cash);
  const simulateBuy = useAppStore((s) => s.simulateBuy);
  const notify = useAppStore((s) => s.notify);
  const wallet = useWallet();
  const onchain = useOnchain();
  const snap = onchain.snapshot.data;

  const asset = assetId ? getAsset(assetId) : undefined;
  const valuation = asset ? valuations[asset.id] : undefined;
  const supply = useSampleSupply(asset ?? TOKENISED_ASSETS[0]);
  const n = Number(amount);
  const calc = useMemo(
    () =>
      asset && valuation
        ? calculateOwnership({ amount: n, tokenPrice: valuation.tokenPrice ?? NaN, totalSupply: asset.totalSupply, available: supply.available, minInvestment: asset.minInvestment })
        : null,
    [asset, valuation, n, supply.available],
  );
  // Same measured risk score as the marketplace card and detail page (shared query cache).
  const insights = useAssetInsights(asset ?? TOKENISED_ASSETS[0]);
  const risk = asset ? insights.risk : null;
  const profile = useMemo(() => {
    if (!asset) return null;
    const ref = assetReferenceInstrument(asset);
    return profileForSubject({ kind: 'asset', asset, instrument: ref ? getInstrument(ref) ?? null : null });
  }, [asset]);

  // On-chain purchase is in whole tokens at the contract's integer issuance price (vUSD credits).
  const chainPrice = asset ? snap?.assets[asset.tokenId]?.price ?? asset.onchainPrice : 0;
  const chainTokens = asset && chainPrice > 0 ? Math.floor(n / chainPrice) : 0;
  const chainAvailable = asset ? snap?.assets[asset.tokenId]?.available ?? asset.totalSupply : 0;
  const chainChecks = {
    network: wallet.status === 'connected' && wallet.isCorrectChain,
    configured: onchain.config.configured,
    credits: Boolean(snap?.claimed) && (snap?.credits ?? 0) >= chainTokens * chainPrice,
    verified: Boolean(snap?.verified),
    supply: chainTokens >= 1 && chainTokens <= chainAvailable,
  };
  const chainReady = Object.values(chainChecks).every(Boolean);

  const canContinue = [
    Boolean(asset),
    Boolean(calc?.valid),
    Boolean(calc?.valid),
    ack,
    kyc.status === 'verified',
    mode === 'demo' || (mode === 'chain' && onchain.config.configured),
  ][step];

  const go = (s: number) => setStep(Math.max(0, Math.min(STEPS.length - 1, s)));

  const confirmDemo = () => {
    if (!asset || !calc?.valid || !valuation?.tokenPrice) return;
    const r = simulateBuy({ assetId: asset.id, tokens: calc.tokens, unitPrice: valuation.tokenPrice });
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    notify({ title: `Bought ${calc.tokens} ${asset.symbol} (simulated)`, body: `${r.item.id} · ${formatUsd(calc.cost)}`, tone: 'success', href: '/portfolio' });
    setResult({ kind: 'demo', item: r.item });
    go(7);
  };

  const confirmChain = async () => {
    if (!asset || !chainReady) return;
    setResult({ kind: 'chain', hash: null, status: 'signing', blockNumber: null, tokens: chainTokens });
    go(7);
    try {
      const r = await onchain.buy(asset.tokenId, chainTokens, chainPrice, (hash) => setResult({ kind: 'chain', hash, status: 'pending', blockNumber: null, tokens: chainTokens }));
      setResult({ kind: 'chain', hash: r.hash, status: r.ok ? 'confirmed' : 'failed', blockNumber: r.blockNumber, tokens: chainTokens });
    } catch (err) {
      setResult({ kind: 'chain', hash: null, status: 'failed', blockNumber: null, tokens: chainTokens, error: (err as Error)?.message });
    }
  };

  const run = async (key: string, fn: () => Promise<unknown>) => {
    setBusy(key);
    try {
      await fn();
    } catch {
      /* toast shown by the hook */
    } finally {
      setBusy(null);
    }
  };

  const filtered = TOKENISED_ASSETS.filter((a) => !search || `${a.name} ${a.symbol} ${CATEGORY_LABELS[a.category]}`.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <PageHeader title="Simulate an investment" description="Eight steps from choosing a sample asset to a confirmed result — in demo mode, or as a real transaction on the testnet." />

      <div className="grid gap-6 lg:grid-cols-[240px_minmax(0,1fr)]">
        <nav aria-label="Investment steps" className="min-w-0 lg:sticky lg:top-24 lg:self-start">
          <ol className="no-scrollbar flex gap-2 overflow-x-auto lg:flex-col lg:gap-0.5">
            {STEPS.map((s, i) => {
              const state = i < step ? 'done' : i === step ? 'current' : 'todo';
              return (
                <li key={s} className="shrink-0">
                  <button
                    disabled={i > step || step === 7}
                    onClick={() => go(i)}
                    aria-current={state === 'current' ? 'step' : undefined}
                    className={cn(
                      'flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-[13px] transition-colors disabled:cursor-default',
                      state === 'current' ? 'bg-muted text-foreground' : state === 'done' ? 'text-foreground/80 hover:bg-muted/60' : 'text-subtle',
                    )}
                  >
                    {state === 'done' ? <CheckCircle2 className="size-4 text-gold" aria-hidden /> : <Circle className={cn('size-4', state === 'current' && 'text-gold')} aria-hidden />}
                    <span className="whitespace-nowrap">
                      <span className="tabular">{i + 1}.</span> {s}
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </nav>

        <Card className="min-w-0">
          <CardHeader>
            <CardTitle className="text-lg">
              Step {step + 1}: {STEPS[step]}
            </CardTitle>
            {asset && step > 0 && (
              <CardDescription className="flex items-center gap-2">
                <AssetIcon asset={asset} size="sm" className="size-6 [&_svg]:size-3.5" /> {asset.name} · {formatUsd(valuation?.tokenPrice)} per token (illustrative)
              </CardDescription>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            {step === 0 && (
              <div className="space-y-4">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" aria-hidden />
                  <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search sample assets" className="pl-9" aria-label="Search sample assets" />
                </div>
                <div role="radiogroup" aria-label="Sample assets" className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {filtered.map((a) => (
                    <AssetOption
                      key={a.id}
                      asset={a}
                      valuation={valuations[a.id]}
                      selected={assetId === a.id}
                      onSelect={() => {
                        setAssetId(a.id);
                        setAck(false);
                        go(1);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {step === 1 && asset && (
              <div className="max-w-md space-y-3">
                <Label htmlFor="invest-amount">Simulated amount (USD)</Label>
                <div className="relative">
                  <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-subtle">$</span>
                  <Input
                    id="invest-amount"
                    type="number"
                    min={0}
                    step="any"
                    inputMode="decimal"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="h-12 pl-7 text-lg tabular"
                    aria-invalid={(amount !== '' && !calc?.valid) || undefined}
                    aria-describedby="invest-amount-hint"
                  />
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[10, 25, 50, 100, 250, 1000].map((p) => (
                    <button key={p} type="button" onClick={() => setAmount(String(p))} className={cn('rounded-md border border-border px-2.5 py-1 text-xs tabular', Number(amount) === p ? 'border-gold/40 bg-gold-soft' : 'text-muted-foreground hover:text-foreground')}>
                      ${p.toLocaleString('en-US')}
                    </button>
                  ))}
                </div>
                <FieldHint id="invest-amount-hint" error={amount !== '' && !calc?.valid}>
                  {amount !== '' && !calc?.valid ? calc?.error : `Minimum ${formatUsd(Math.max(asset.minInvestment, valuation?.tokenPrice ?? 0))}. Simulated cash available: ${formatUsd(cash)}.`}
                </FieldHint>
              </div>
            )}

            {step === 2 && asset && calc?.valid && valuation && (
              <div className="space-y-4">
                <dl className="grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-3">
                  {[
                    ['Tokens', calc.tokens.toLocaleString('en-US')],
                    ['Cost', formatUsd(calc.cost)],
                    ['Unspent cash', formatUsd(calc.leftover)],
                    ['Token price', formatUsd(valuation.tokenPrice, (valuation.tokenPrice ?? 0) < 1 ? 4 : 2)],
                    ['Share of sample supply', `${formatNumber(calc.ownershipPct, 4)}%`],
                    ['Illustrative value', formatUsd(calc.illustrativeValue)],
                  ].map(([k, v]) => (
                    <div key={k} className="bg-card px-4 py-3">
                      <dt className="text-xs text-muted-foreground">{k}</dt>
                      <dd className="mt-0.5 font-display text-lg font-semibold tabular">{v}</dd>
                    </div>
                  ))}
                </dl>
                <div className="rounded-lg border border-border px-4 py-3 font-mono text-xs leading-relaxed text-foreground/90">
                  {calc.tokens} tokens × {formatUsd(valuation.tokenPrice, 4)} = {formatUsd(calc.cost)} · token price = {valuation.formula}
                </div>
                <Disclaimer>{CALCULATOR_DISCLAIMER}</Disclaimer>
              </div>
            )}

            {step === 3 && asset && risk && profile && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-3">
                  <RiskBadge risk={risk} />
                  <IllustrativeBadge />
                  {asset.kind === 'simulated' && <Badge variant="demo">Simulated asset</Badge>}
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Main risks</p>
                    <ul className="space-y-1.5 text-[13px] text-muted-foreground">
                      {profile.risks.map((r) => (
                        <li key={r} className="flex gap-2">
                          <span className="mt-2 size-1 shrink-0 rounded-full bg-danger" aria-hidden /> {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">What could make it fall</p>
                    <ul className="space-y-1.5 text-[13px] text-muted-foreground">
                      {profile.downside.map((r) => (
                        <li key={r} className="flex gap-2">
                          <span className="mt-2 size-1 shrink-0 rounded-full bg-warning" aria-hidden /> {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <Disclaimer tone="warning">
                  This sample token is a testnet demonstration. It does not represent ownership of, or a claim on, any real asset, and it is not a security. Fractional size
                  does not reduce the percentage risk of the underlying.
                </Disclaimer>
                <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-border p-3 text-sm">
                  <Checkbox checked={ack} onCheckedChange={(v: boolean | 'indeterminate') => setAck(v === true)} className="mt-0.5" />I have read the risk disclosure and
                  understand this is an educational simulation.
                </label>
                <p className="text-xs text-muted-foreground">
                  Want a plain-language explanation first?{' '}
                  <Link to={`/assets/${asset.id}`} className="text-blue hover:underline">
                    Read the AI risk explanation
                  </Link>
                  .
                </p>
              </div>
            )}

            {step === 4 &&
              (kyc.status === 'verified' ? (
                <div className="flex items-start gap-3 rounded-lg border border-success/30 bg-success-soft p-4">
                  <BadgeCheck className="mt-0.5 size-5 text-success" aria-hidden />
                  <div>
                    <p className="font-medium">Verified (simulated)</p>
                    <p className="text-[13px] text-muted-foreground">Your simulated KYC is complete{kyc.fullName ? ` for ${kyc.fullName}` : ''}. Continue to choose how to transact.</p>
                  </div>
                </div>
              ) : (
                // The wizard has its own navigation; finishing as verified moves the flow on.
                <KycWizard compact onFinished={(s) => s === 'verified' && go(5)} />
              ))}

            {step === 5 && (
              <div className="grid gap-3 md:grid-cols-2" role="radiogroup" aria-label="Transaction mode">
                <button
                  role="radio"
                  aria-checked={mode === 'chain'}
                  disabled={!onchain.config.configured}
                  onClick={() => setMode('chain')}
                  className={cn(
                    'flex flex-col gap-3 rounded-xl border p-4 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-60',
                    mode === 'chain' ? 'border-blue/50 bg-blue-soft' : 'border-border hover:border-border-strong',
                  )}
                >
                  <span className="flex items-center gap-2 font-medium">
                    <WalletIcon className="size-4 text-blue" aria-hidden /> Testnet transaction
                  </span>
                  <span className="text-[13px] leading-relaxed text-muted-foreground">
                    Sign a real {TARGET_CHAIN.name} transaction with MetaMask. Pays with free vUSD demo credits; gas uses test {TARGET_CHAIN.currency.symbol}.
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {!onchain.config.configured
                      ? 'Unavailable: contracts are not deployed in this build.'
                      : wallet.status === 'connected'
                        ? `Wallet ${shortAddress(wallet.address)} on ${wallet.isCorrectChain ? TARGET_CHAIN.name : 'another network'}`
                        : 'You will connect MetaMask in the next step.'}
                  </span>
                </button>
                <button
                  role="radio"
                  aria-checked={mode === 'demo'}
                  onClick={() => setMode('demo')}
                  className={cn('flex flex-col gap-3 rounded-xl border p-4 text-left transition-colors', mode === 'demo' ? 'border-gold/50 bg-gold-soft' : 'border-border hover:border-border-strong')}
                >
                  <span className="flex items-center gap-2 font-medium">
                    <FlaskConical className="size-4 text-gold" aria-hidden /> Demo mode
                  </span>
                  <span className="text-[13px] leading-relaxed text-muted-foreground">Simulated locally with your simulated cash. Clearly labelled as simulated — nothing is written to a blockchain.</span>
                  <span className="text-xs text-muted-foreground">Simulated cash: {formatUsd(cash)}</span>
                </button>
              </div>
            )}

            {step === 6 && asset && calc?.valid && valuation && mode === 'demo' && (
              <div className="space-y-4">
                <dl className="divide-y divide-border rounded-lg border border-border text-sm">
                  {[
                    ['Asset', `${asset.name} (${asset.symbol})`],
                    ['Tokens', calc.tokens.toLocaleString('en-US')],
                    ['Price per token (illustrative)', formatUsd(valuation.tokenPrice, 4)],
                    ['Total', formatUsd(calc.cost)],
                    ['Simulated cash after', formatUsd(cash - calc.cost)],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-3 px-4 py-2.5">
                      <dt className="text-muted-foreground">{k}</dt>
                      <dd className="text-right tabular">{v}</dd>
                    </div>
                  ))}
                </dl>
                {calc.cost > cash && <Disclaimer tone="warning">Not enough simulated cash. Lower the amount or reset demo data in Settings.</Disclaimer>}
                <Badge variant="outline" className="border-dashed">
                  {SIMULATION_LABEL}
                </Badge>
                <div className="flex justify-end">
                  <Button size="lg" disabled={calc.cost > cash} onClick={confirmDemo}>
                    Confirm simulated purchase
                  </Button>
                </div>
              </div>
            )}

            {step === 6 && asset && mode === 'chain' && (
              <div className="space-y-4">
                <ul className="space-y-2">
                  {[
                    {
                      ok: chainChecks.network,
                      label: wallet.status === 'connected' ? `Wallet on ${TARGET_CHAIN.name}` : 'Connect MetaMask',
                      action:
                        wallet.status !== 'connected' ? (
                          <Button size="sm" onClick={() => void wallet.connect()} loading={wallet.status === 'connecting'}>
                            Connect
                          </Button>
                        ) : !wallet.isCorrectChain ? (
                          <Button size="sm" onClick={() => void wallet.switchToTarget()}>
                            Switch network
                          </Button>
                        ) : null,
                    },
                    {
                      ok: chainChecks.verified,
                      label: snap ? `On-chain verification: ${snap.verified ? 'Verified' : snap.kycStatus}` : 'On-chain verification',
                      action:
                        chainChecks.network && snap && !snap.verified && snap.kycStatus !== 'Pending' ? (
                          <Button size="sm" variant="blue" loading={busy === 'kyc'} onClick={() => run('kyc', () => onchain.requestVerification(kyc.caseId ?? uid('case_')))}>
                            Record verification
                          </Button>
                        ) : snap?.kycStatus === 'Pending' ? (
                          <span className="text-xs text-warning">Waiting for a compliance officer</span>
                        ) : null,
                    },
                    {
                      ok: chainChecks.credits,
                      label: snap ? `vUSD credits: ${snap.credits.toLocaleString('en-US')} (need ${(chainTokens * chainPrice).toLocaleString('en-US')})` : 'vUSD demo credits',
                      action:
                        chainChecks.network && snap && !snap.claimed ? (
                          <Button size="sm" loading={busy === 'claim'} onClick={() => run('claim', () => onchain.claimCredits())}>
                            Claim 10,000 vUSD
                          </Button>
                        ) : null,
                    },
                    { ok: chainChecks.supply, label: `${chainTokens} token${chainTokens === 1 ? '' : 's'} at ${chainPrice} vUSD (on-chain issuance price); ${chainAvailable.toLocaleString('en-US')} available`, action: null },
                  ].map((c) => (
                    <li key={c.label} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border px-4 py-3 text-sm">
                      <span className="flex items-center gap-2">
                        {c.ok ? <CheckCircle2 className="size-4 text-success" aria-hidden /> : <Circle className="size-4 text-subtle" aria-hidden />}
                        {c.label}
                      </span>
                      {c.action}
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-muted-foreground">
                  The testnet contract prices tokens in whole vUSD credits, so the on-chain quantity can differ slightly from the illustrative calculation. Gas is paid in test{' '}
                  {TARGET_CHAIN.currency.symbol}.
                </p>
                <div className="flex justify-end">
                  <Button size="lg" variant="blue" disabled={!chainReady} onClick={() => void confirmChain()}>
                    Confirm testnet transaction
                  </Button>
                </div>
              </div>
            )}

            {step === 7 && result && asset && (
              <div className="space-y-5" aria-live="polite">
                {result.kind === 'demo' ? (
                  <>
                    <div className="flex items-start gap-3 rounded-lg border border-success/30 bg-success-soft p-4">
                      <CheckCircle2 className="mt-0.5 size-5 text-success" aria-hidden />
                      <div>
                        <p className="font-medium">Simulated purchase complete</p>
                        <p className="text-[13px] text-muted-foreground">
                          {result.item.tokens} {asset.symbol} for {formatUsd(result.item.amount)}. Reference <span className="font-mono">{result.item.id}</span>.
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className="border-dashed">
                      {SIMULATION_LABEL}
                    </Badge>
                  </>
                ) : (
                  <div className="space-y-3">
                    <div
                      className={cn(
                        'flex items-start gap-3 rounded-lg border p-4',
                        result.status === 'confirmed' && 'border-success/30 bg-success-soft',
                        result.status === 'failed' && 'border-danger/30 bg-danger-soft',
                        (result.status === 'pending' || result.status === 'signing') && 'border-blue/30 bg-blue-soft',
                      )}
                    >
                      {result.status === 'confirmed' ? (
                        <CheckCircle2 className="mt-0.5 size-5 text-success" aria-hidden />
                      ) : result.status === 'failed' ? (
                        <XCircle className="mt-0.5 size-5 text-danger" aria-hidden />
                      ) : (
                        <Loader2 className="mt-0.5 size-5 animate-spin text-blue" aria-hidden />
                      )}
                      <div className="min-w-0">
                        <p className="font-medium">
                          {result.status === 'signing'
                            ? 'Confirm the transaction in MetaMask'
                            : result.status === 'pending'
                              ? `Waiting for ${TARGET_CHAIN.name} to confirm`
                              : result.status === 'confirmed'
                                ? `Bought ${result.tokens} ${asset.symbol} on ${TARGET_CHAIN.name}`
                                : 'Transaction did not complete'}
                        </p>
                        {result.hash && (
                          <p className="mt-1 break-all font-mono text-xs text-muted-foreground">
                            {result.hash}
                            {result.blockNumber ? ` · block ${result.blockNumber.toLocaleString('en-US')}` : ''}
                          </p>
                        )}
                        {result.status === 'failed' && <p className="mt-1 text-[13px] text-muted-foreground">Nothing was purchased. Check the message in the notification and try again.</p>}
                      </div>
                    </div>
                    {result.hash && explorerTx(result.hash) && (
                      <Button variant="outline" size="sm" asChild>
                        <a href={explorerTx(result.hash)!} target="_blank" rel="noreferrer">
                          <ExternalLink /> View on block explorer
                        </a>
                      </Button>
                    )}
                    {result.status === 'confirmed' && snap && <p className="text-[13px] text-muted-foreground">Your {asset.symbol} balance: {(snap.balances[asset.tokenId] ?? 0).toLocaleString('en-US')} tokens.</p>}
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => navigate('/portfolio')}>View portfolio</Button>
                  <Button variant="outline" onClick={() => navigate('/transactions')}>
                    Transactions
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setResult(null);
                      setAck(false);
                      setMode(null);
                      setAssetId(null);
                      go(0);
                    }}
                  >
                    Invest in another asset
                  </Button>
                </div>
              </div>
            )}

            {step > 0 && step < 6 && !(step === 4 && kyc.status !== 'verified') && (
              <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
                <Button variant="ghost" onClick={() => go(step - 1)}>
                  Back
                </Button>
                <Button disabled={!canContinue} onClick={() => go(step + 1)}>
                  Continue
                </Button>
              </div>
            )}
            {step === 6 && (
              <div className="border-t border-border pt-4">
                <Button variant="ghost" onClick={() => go(5)}>
                  Back
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function AssetOption({ asset, valuation, selected, onSelect }: { asset: TokenisedAsset; valuation: AssetValuation | undefined; selected: boolean; onSelect: () => void }) {
  const { risk } = useAssetInsights(asset);
  return (
    <button
      role="radio"
      aria-checked={selected}
      onClick={onSelect}
      className={cn(
        'flex min-w-0 items-center gap-3 rounded-lg border p-3 text-left transition-colors focus-visible:outline-2 focus-visible:outline-ring',
        selected ? 'border-gold/50 bg-gold-soft' : 'border-border hover:border-border-strong',
      )}
    >
      <AssetIcon asset={asset} size="sm" />
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-medium">{asset.name}</span>
        <span className="block text-xs text-muted-foreground">
          {asset.symbol} · {CATEGORY_LABELS[asset.category]}
        </span>
      </span>
      <span className="flex flex-col items-end gap-1">
        <span className="text-sm tabular">{formatUsd(valuation?.tokenPrice, (valuation?.tokenPrice ?? 0) < 1 ? 4 : 2)}</span>
        <RiskBadge risk={risk} showScore={false} />
      </span>
    </button>
  );
}
