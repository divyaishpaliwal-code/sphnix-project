import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Link, useLocation } from 'react-router';
import { BellRing, CloudUpload, Download, ExternalLink, RefreshCw, Trash2, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { PLATFORM_DISCLAIMER, formatQuote, formatUsd, getAsset, getInstrument, relativeTime } from '@vestora/shared';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FieldHint, Input, Label } from '@/components/ui/input';
import { Segmented, Switch } from '@/components/ui/primitives';
import { EmptyState, PageHeader } from '@/components/common/States';
import { ResetDemoDialog } from '@/components/layout/Topbar';
import { TARGET_CHAIN, explorerAddress } from '@/config/chains';
import { env } from '@/config/env';
import { useHealth } from '@/hooks/useMarket';
import { buildPayload, pushProfile } from '@/services/sync';
import { contractConfig } from '@/services/web3/contracts';
import { useAppStore, type PriceAlert, type ThemePref } from '@/store/app';
import { useUi } from '@/store/ui';
import { useWallet } from '@/wallet/WalletProvider';

const REFRESH_OPTIONS = [15, 30, 60, 120, 300];

function Row({ label, hint, children }: { label: ReactNode; hint?: ReactNode; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-3 border-b border-border py-4 last:border-b-0 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0 space-y-0.5">
        <div className="text-sm font-medium text-foreground">{label}</div>
        {hint && <div className="text-[13px] leading-relaxed text-muted-foreground">{hint}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function alertTarget(a: PriceAlert): { name: string; price: string; href: string } {
  if (a.target.kind === 'asset') {
    const asset = getAsset(a.target.id);
    return { name: asset ? `${asset.symbol} token (illustrative)` : a.target.id, price: formatUsd(a.price), href: `/assets/${a.target.id}` };
  }
  const inst = getInstrument(a.target.id);
  return { name: inst?.name ?? a.target.id, price: inst ? formatQuote(a.price, inst.denomination, inst.decimals) : String(a.price), href: '/markets' };
}

function isImportShape(x: unknown): x is { watchlist?: string[]; portfolio?: { cash: number; holdings: Record<string, unknown> }; activity?: unknown[]; alerts?: unknown[] } {
  if (!x || typeof x !== 'object') return false;
  const o = x as Record<string, unknown>;
  if (o.watchlist !== undefined && !(Array.isArray(o.watchlist) && o.watchlist.every((w) => typeof w === 'string'))) return false;
  if (o.portfolio !== undefined) {
    const p = o.portfolio as Record<string, unknown> | null;
    if (!p || typeof p.cash !== 'number' || !Number.isFinite(p.cash) || p.cash < 0 || typeof p.holdings !== 'object' || p.holdings === null) return false;
  }
  if (o.activity !== undefined && !Array.isArray(o.activity)) return false;
  if (o.alerts !== undefined && !Array.isArray(o.alerts)) return false;
  return true;
}

export default function Settings() {
  const location = useLocation();
  const settings = useAppStore((s) => s.settings);
  const setSettings = useAppStore((s) => s.setSettings);
  const profile = useAppStore((s) => s.profile);
  const setProfile = useAppStore((s) => s.setProfile);
  const alerts = useAppStore((s) => s.alerts);
  const removeAlert = useAppStore((s) => s.removeAlert);
  const resetDemo = useAppStore((s) => s.resetDemo);
  const applyRemote = useAppStore((s) => s.applyRemote);
  const lastSyncedAt = useAppStore((s) => s.lastSyncedAt);
  const setLastSynced = useAppStore((s) => s.setLastSynced);
  const clearNotifications = useAppStore((s) => s.clearNotifications);
  const apiOnline = useUi((s) => s.apiOnline);
  const health = useHealth();
  const wallet = useWallet();
  const cfg = contractConfig();
  const [resetOpen, setResetOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // Deep links such as /settings#alerts and /settings#data.
  useEffect(() => {
    const id = location.hash.replace('#', '');
    if (!id) return;
    const t = setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
    return () => clearTimeout(t);
  }, [location.hash]);

  const syncNow = async () => {
    setSyncing(true);
    try {
      const r = await pushProfile();
      setLastSynced(r.updatedAt);
      toast.success('Profile synced to the VESTORA server');
    } catch (err) {
      toast.error((err as Error).message || 'Sync failed');
    } finally {
      setSyncing(false);
    }
  };

  const exportData = () => {
    const payload = { format: 'vestora-export', version: 1, exportedAt: new Date().toISOString(), ...buildPayload() };
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `vestora-data-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const importData = async (file: File) => {
    if (file.size > 1_000_000) return void toast.error('That file is larger than 1 MB — it is not a VESTORA export.');
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!isImportShape(parsed) || (parsed as { format?: string }).format !== 'vestora-export') throw new Error('shape');
      applyRemote(parsed as Parameters<typeof applyRemote>[0]);
      toast.success('Data imported', { description: 'Watchlist, simulated portfolio, activity and alerts were restored.' });
    } catch {
      toast.error('Could not import that file', { description: 'Choose a JSON file exported from VESTORA Settings.' });
    }
  };

  const providers = health.data?.providers ?? [];

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Your profile, display preferences, data sources, network details, alerts and local data." />

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
            <CardDescription>Stored in this browser. VESTORA has no accounts or passwords.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="display-name">Display name</Label>
              <Input id="display-name" value={profile.displayName} maxLength={40} onChange={(e) => setProfile({ displayName: e.target.value })} placeholder="Optional" />
              <FieldHint>Shown in the top bar. Not sent anywhere unless you turn on sync.</FieldHint>
            </div>
            <div className="space-y-1.5">
              <p className="text-sm font-medium">Profile ID</p>
              <code className="block truncate rounded-md bg-muted px-3 py-2 font-mono text-xs text-muted-foreground">{profile.profileId}</code>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Display</CardTitle>
          </CardHeader>
          <CardContent>
            <Row label="Theme" hint="Dark is the default. System follows your device.">
              <Segmented<ThemePref>
                label="Theme"
                value={settings.theme}
                onChange={(v) => setSettings({ theme: v })}
                options={[
                  { value: 'dark', label: 'Dark' },
                  { value: 'light', label: 'Light' },
                  { value: 'system', label: 'System' },
                ]}
              />
            </Row>
            <Row label="Hide balances" hint="Masks portfolio values for screen sharing.">
              <Switch checked={settings.hideBalances} onCheckedChange={(v: boolean) => setSettings({ hideBalances: v })} aria-label="Hide balances" />
            </Row>
            <Row label="Price refresh" hint="How often market prices are re-requested. Providers may update less often.">
              <Segmented<string>
                label="Price refresh interval"
                value={String(settings.refreshSeconds)}
                onChange={(v) => setSettings({ refreshSeconds: Number(v) })}
                options={REFRESH_OPTIONS.map((s) => ({ value: String(s), label: s < 60 ? `${s}s` : `${s / 60}m` }))}
              />
            </Row>
          </CardContent>
        </Card>
      </div>

      <Card id="sources" className="scroll-mt-24">
        <CardHeader className="flex-row flex-wrap items-start justify-between gap-3">
          <div className="space-y-1.5">
            <CardTitle>Market data sources</CardTitle>
            <CardDescription>
              Which providers the VESTORA server can use. Keys live only on the server.{' '}
              <Link to="/learn/data-sources" className="text-blue hover:underline">
                How sources and labels work
              </Link>
            </CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={() => void health.refetch()} loading={health.isFetching}>
            <RefreshCw /> Refresh
          </Button>
        </CardHeader>
        <CardContent>
          {health.isLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }, (_, i) => (
                <span key={i} className="skeleton block h-10 w-full" />
              ))}
            </div>
          ) : !health.data ? (
            <EmptyState
              title={env.disableApi ? 'This build runs without the API server' : 'The API server is not reachable'}
              description={`The app is running in browser-only mode: ${
                env.directCoinGecko ? 'crypto prices come straight from CoinGecko’s public API and other instruments show labelled demo values' : 'instruments show labelled demo values'
              }. ${env.disableApi ? 'Deploy the API server and rebuild without VITE_DISABLE_API to enable every provider.' : 'Start the server (npm run dev) to enable every provider.'}`}
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] text-left text-[13px]">
                <thead className="text-muted-foreground">
                  <tr className="border-b border-border">
                    <th scope="col" className="py-2 pr-3 font-medium">
                      Provider
                    </th>
                    <th scope="col" className="py-2 pr-3 font-medium">
                      Status
                    </th>
                    <th scope="col" className="py-2 pr-3 font-medium">
                      Last success
                    </th>
                    <th scope="col" className="py-2 font-medium">
                      Last issue
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {providers.map((p) => {
                    const cooling = p.coolingDownUntil && new Date(p.coolingDownUntil).getTime() > Date.now();
                    return (
                      <tr key={p.id}>
                        <td className="py-2.5 pr-3 font-medium text-foreground">{p.name}</td>
                        <td className="py-2.5 pr-3">
                          {!p.configured ? (
                            <Badge variant="outline">Not configured</Badge>
                          ) : cooling ? (
                            <Badge variant="warning">Cooling down</Badge>
                          ) : p.lastErrorAt && (!p.lastSuccessAt || p.lastErrorAt > p.lastSuccessAt) ? (
                            <Badge variant="danger">Errors</Badge>
                          ) : (
                            <Badge variant="success">{p.keyless ? 'Active (no key)' : 'Active'}</Badge>
                          )}
                        </td>
                        <td className="py-2.5 pr-3 text-muted-foreground">{p.lastSuccessAt ? relativeTime(p.lastSuccessAt) : '—'}</td>
                        <td className="max-w-[280px] truncate py-2.5 text-muted-foreground" title={p.lastError ?? undefined}>
                          {p.lastError ?? '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <p className="mt-3 text-xs text-subtle">
                Server {health.data.version} · AI {health.data.ai.mode === 'live' ? `live (${health.data.ai.model ?? health.data.ai.provider})` : 'demo assistant'} · storage{' '}
                {health.data.storage.mode} · demo fallback {health.data.demoFallback ? 'on' : 'off'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Network and contracts</CardTitle>
          <CardDescription>Testnet only. VESTORA refuses to deploy to Ethereum mainnet.</CardDescription>
        </CardHeader>
        <CardContent>
          <Row label="Target network" hint={`Chain ID ${TARGET_CHAIN.id}. Gas is paid in test ${TARGET_CHAIN.currency.symbol}.`}>
            <Badge variant="blue">{TARGET_CHAIN.name}</Badge>
          </Row>
          <Row label="Wallet" hint={wallet.status === 'connected' ? `${wallet.walletName ?? 'Wallet'} on ${wallet.isCorrectChain ? TARGET_CHAIN.name : 'another network'}` : 'Not connected'}>
            <Button variant="outline" size="sm" asChild>
              <Link to="/wallet">Open wallet</Link>
            </Button>
          </Row>
          {(
            [
              ['AssetToken (ERC-1155)', cfg.assetToken],
              ['ComplianceManager', cfg.compliance],
            ] as const
          ).map(([label, addr]) => (
            <Row key={label} label={label} hint={addr ? <code className="break-all font-mono text-xs">{addr}</code> : 'Not deployed in this build'}>
              {addr && explorerAddress(addr) ? (
                <Button variant="ghost" size="sm" asChild>
                  <a href={explorerAddress(addr)!} target="_blank" rel="noreferrer">
                    <ExternalLink /> Explorer
                  </a>
                </Button>
              ) : (
                <Badge variant="outline">{cfg.source === 'none' ? 'Unset' : cfg.source}</Badge>
              )}
            </Row>
          ))}
          <Row label="Configuration source" hint="Addresses come from VITE_ environment variables or a deployment file written by the deploy script.">
            <Badge variant="outline">{cfg.source === 'env' ? 'Environment' : cfg.source === 'deployment' ? 'Deployment file' : 'None'}</Badge>
          </Row>
          <Row label="API server" hint={env.disableApi ? 'Disabled in this build (static mode).' : apiOnline ? 'Connected' : 'Not reachable — using browser fallbacks'}>
            <Badge variant={apiOnline && !env.disableApi ? 'success' : 'outline'}>{apiOnline && !env.disableApi ? 'Online' : 'Offline'}</Badge>
          </Row>
        </CardContent>
      </Card>

      <Card id="alerts" className="scroll-mt-24">
        <CardHeader className="flex-row flex-wrap items-start justify-between gap-3">
          <div className="space-y-1.5">
            <CardTitle>Price alerts</CardTitle>
            <CardDescription>Demo alerts are checked in this browser while VESTORA is open, and only against live, delayed or historical prices — never demo values.</CardDescription>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link to="/markets">
              <BellRing /> Create in Markets
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          {alerts.length === 0 ? (
            <EmptyState icon={BellRing} title="No alerts yet" description="Use the bell next to any instrument in Markets to set one." />
          ) : (
            <ul className="divide-y divide-border">
              {alerts.map((a) => {
                const t = alertTarget(a);
                return (
                  <li key={a.id} className="flex flex-wrap items-center gap-3 py-3">
                    <div className="min-w-0 flex-1">
                      <Link to={t.href} className="text-sm font-medium hover:underline">
                        {t.name}
                      </Link>
                      <p className="text-xs text-muted-foreground">
                        {a.direction === 'above' ? 'Rises to or above' : 'Falls to or below'} {t.price} · set {relativeTime(a.createdAt)}
                      </p>
                    </div>
                    {a.active ? (
                      <Badge variant="blue">Watching</Badge>
                    ) : (
                      <Badge variant="success">Triggered {a.triggeredAt ? relativeTime(a.triggeredAt) : ''}</Badge>
                    )}
                    <Button variant="ghost" size="icon-sm" aria-label={`Delete alert for ${t.name}`} onClick={() => removeAlert(a.id)}>
                      <Trash2 />
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card id="data" className="scroll-mt-24">
        <CardHeader>
          <CardTitle>Data and privacy</CardTitle>
          <CardDescription>
            Everything is stored in this browser by default. Simulated KYC details (name, email, country) never leave it — not with sync, and not in exports.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Row
            label="Sync to the VESTORA server"
            hint={
              <>
                Saves preferences, watchlist, simulated portfolio, activity and alerts under your random profile ID and secret key.
                {lastSyncedAt ? ` Last synced ${relativeTime(lastSyncedAt)}.` : ''}
                {!apiOnline ? ' The API server is not reachable right now.' : ''}
              </>
            }
          >
            <div className="flex items-center gap-3">
              {settings.syncEnabled && (
                <Button variant="ghost" size="sm" onClick={() => void syncNow()} loading={syncing} disabled={!apiOnline}>
                  <CloudUpload /> Sync now
                </Button>
              )}
              <Switch checked={settings.syncEnabled} onCheckedChange={(v: boolean) => setSettings({ syncEnabled: v })} disabled={!apiOnline && !settings.syncEnabled} aria-label="Sync to server" />
            </div>
          </Row>
          <Row label="Export your data" hint="Download a JSON file of your watchlist, simulated portfolio, activity and alerts.">
            <Button variant="outline" size="sm" onClick={exportData}>
              <Download /> Export JSON
            </Button>
          </Row>
          <Row label="Import data" hint="Restore from a VESTORA export file. This replaces the matching data in this browser.">
            <>
              <input
                ref={fileRef}
                type="file"
                accept="application/json,.json"
                className="sr-only"
                tabIndex={-1}
                aria-hidden
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void importData(f);
                  e.target.value = '';
                }}
              />
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                <Upload /> Import JSON
              </Button>
            </>
          </Row>
          <Row label="Notifications" hint="Remove every notification from the bell menu.">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                clearNotifications();
                toast.success('Notifications cleared');
              }}
            >
              Clear notifications
            </Button>
          </Row>
          <Row label="Reset demo data" hint="Restores $10,000 of simulated cash and clears simulated holdings, activity, alerts and KYC. Testnet records are not affected.">
            <Button variant="destructive" size="sm" onClick={() => setResetOpen(true)}>
              Reset demo data
            </Button>
          </Row>
        </CardContent>
      </Card>

      <p className="text-xs leading-relaxed text-subtle">{PLATFORM_DISCLAIMER}</p>
      <ResetDemoDialog open={resetOpen} onOpenChange={setResetOpen} onConfirm={resetDemo} />
    </div>
  );
}
