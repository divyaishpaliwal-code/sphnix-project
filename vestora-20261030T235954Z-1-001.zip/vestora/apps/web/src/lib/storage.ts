import { createJSONStorage, type StateStorage } from 'zustand/middleware';

/**
 * localStorage can be unavailable (private windows, blocked site data, sandboxed
 * previews). Every access is wrapped so the app keeps working in memory.
 */
const memory = new Map<string, string>();

export const safeStorage: StateStorage = {
  getItem: (key) => {
    try {
      return window.localStorage.getItem(key);
    } catch {
      return memory.get(key) ?? null;
    }
  },
  setItem: (key, value) => {
    try {
      window.localStorage.setItem(key, value);
    } catch {
      memory.set(key, value);
    }
  },
  removeItem: (key) => {
    try {
      window.localStorage.removeItem(key);
    } catch {
      memory.delete(key);
    }
  },
};

export const jsonStorage = createJSONStorage(() => safeStorage);

export function readFlag(key: string): string | null {
  return safeStorage.getItem(key) as string | null;
}

export function writeFlag(key: string, value: string | null) {
  if (value === null) safeStorage.removeItem(key);
  else safeStorage.setItem(key, value);
}
