import type { AssetCategory, InstrumentClass, RiskLevel } from '@vestora/shared';

/**
 * Colour follows the entity, never its rank. Categories map to fixed chart
 * slots (validated palette in index.css), so filtering never repaints survivors.
 */
export const CATEGORY_SLOT: Record<AssetCategory, number> = {
  bonds: 1,
  energy: 2,
  'real-estate': 3,
  'precious-metals': 4,
  'digital-assets': 5,
  agriculture: 6,
  'industrial-metals': 7,
};

/** Chart legend order = slot order. */
export const CATEGORY_CHART_ORDER: AssetCategory[] = ['bonds', 'energy', 'real-estate', 'precious-metals', 'digital-assets', 'agriculture', 'industrial-metals'];

export const CLASS_SLOT: Record<InstrumentClass, number> = {
  rates: 1,
  energy: 2,
  'precious-metals': 4,
  'digital-assets': 5,
  agriculture: 6,
  'industrial-metals': 7,
  indices: 8,
};

export const slotColor = (slot: number) => `var(--chart-${slot})`;
export const categoryColor = (c: AssetCategory) => slotColor(CATEGORY_SLOT[c]);
export const classColor = (c: InstrumentClass) => slotColor(CLASS_SLOT[c]);

export const RISK_COLOR: Record<RiskLevel, string> = {
  Low: 'var(--risk-1)',
  Moderate: 'var(--risk-2)',
  Elevated: 'var(--risk-3)',
  High: 'var(--risk-4)',
  'Very high': 'var(--risk-5)',
};

/** Series colours for ad-hoc line comparisons, assigned by selection slot (adjacent pairs validated). */
export const COMPARE_SLOTS = [1, 2, 3, 4];
