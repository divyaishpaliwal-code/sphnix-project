Deployment records are written here by `contracts/scripts/deploy.js` as `<chainId>.json`.
The web app loads every JSON file in this folder automatically; `VITE_ASSET_TOKEN_ADDRESS`
and `VITE_COMPLIANCE_ADDRESS` override them when set.
