import { useCallback, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  INSTRUMENT_MAP,
  TOKENISED_ASSETS,
  seriesStats,
  valueAsset,
  type AssetValuation,
  type HealthResponse,
  type HistoryRange,
  type MarketStats,
  type NewsCategory,
  type Quote,
  type Series,
} from '@vestora/shared';
import { api } from '@/services/api';
import { fetchHistory, fetchQuotes, type DataMode } from '@/services/market';
import { fetchNews } from '@/services/news';
import { useAppStore } from '@/store/app';

/** One shared query for every instrument; components select what they need. */
export function useAllQuotes() {
  const refreshSeconds = useAppStore((s) => s.settings.refreshSeconds);
  const q = useQuery({
    queryKey: ['quotes'],
    queryFn: () => fetchQuotes(),
    refetchInterval: Math.max(15, refreshSeconds) * 1000,
    staleTime: 20_000,
    retry: 1,
  });
  const byId = useMemo(() => {
    const m: Record<string, Quote> = {};
    for (const quote of q.data?.quotes ?? []) m[quote.instrumentId] = quote;
    return m;
  }, [q.data]);
  return {
    quotes: byId,
    generatedAt: q.data?.generatedAt ?? null,
    mode: (q.data?.mode ?? null) as DataMode | null,
    isLoading: q.isLoading,
    isFetching: q.isFetching,
    error: q.error as Error | null,
    refetch: q.refetch,
  };
}

export function useQuote(id: string | null | undefined): { quote: Quote | undefined; isLoading: boolean } {
  const { quotes, isLoading } = useAllQuotes();
  return { quote: id ? quotes[id] : undefined, isLoading };
}

export function useHistory(id: string | null | undefined, range: HistoryRange, enabled = true) {
  return useQuery<Series>({
    queryKey: ['history', id, range],
    queryFn: () => fetchHistory(id as string, range),
    enabled: Boolean(id) && enabled,
    staleTime: range === '1D' ? 2 * 60_000 : 10 * 60_000,
    retry: 1,
  });
}

/** Illustrative valuations for every tokenised sample asset. */
export function useValuations(): { valuations: Record<string, AssetValuation>; isLoading: boolean; quotes: Record<string, Quote> } {
  const { quotes, isLoading } = useAllQuotes();
  const valuations = useMemo(() => {
    const out: Record<string, AssetValuation> = {};
    for (const a of TOKENISED_ASSETS) out[a.id] = valueAsset(a, quotes);
    return out;
  }, [quotes]);
  return { valuations, isLoading, quotes };
}

export function useHealth() {
  return useQuery<HealthResponse | null>({
    queryKey: ['health'],
    queryFn: async () => {
      try {
        return await api<HealthResponse>('/health', { timeoutMs: 6000 });
      } catch {
        return null;
      }
    },
    refetchInterval: 60_000,
    staleTime: 30_000,
  });
}

export function useNews(category?: NewsCategory) {
  return useQuery({
    queryKey: ['news', category ?? 'all'],
    queryFn: () => fetchNews(category),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
  });
}

/** Measured statistics from a real history series (yield series are not prices, so they are excluded). */
export function marketStatsFromSeries(instrumentId: string, data: Series | undefined): MarketStats | undefined {
  if (!data || data.points.length < 2 || INSTRUMENT_MAP[instrumentId]?.class === 'rates') return undefined;
  const s = seriesStats(data.points);
  return {
    instrumentId,
    volatility: s.volatility,
    maxDrawdown: s.maxDrawdown,
    changeOverWindow: s.changePct,
    observations: s.observations,
    window: 'the past year',
    source: data.proxy ? `${data.source.name}, ${data.proxy.symbol} proxy` : data.source.name,
    status: data.status,
  };
}

/** Measured one-year statistics for the assistant (real observations only). */
export function useMarketStats(instrumentId: string | null): MarketStats | undefined {
  const usable = instrumentId && INSTRUMENT_MAP[instrumentId]?.class !== 'rates' ? instrumentId : null;
  const { data } = useHistory(usable, '1Y');
  return useMemo(() => (usable ? marketStatsFromSeries(usable, data) : undefined), [usable, data]);
}

/** Loads one-year stats on demand through the shared history cache (used by the local assistant). */
export function useStatsLoader() {
  const qc = useQueryClient();
  return useCallback(
    async (ids: string[]): Promise<Record<string, MarketStats | undefined>> => {
      const out: Record<string, MarketStats | undefined> = {};
      const usable = [...new Set(ids)].filter((id) => INSTRUMENT_MAP[id] && INSTRUMENT_MAP[id].class !== 'rates');
      await Promise.all(
        usable.map(async (id) => {
          try {
            const data = await qc.fetchQuery({ queryKey: ['history', id, '1Y'], queryFn: () => fetchHistory(id, '1Y'), staleTime: 10 * 60_000 });
            out[id] = marketStatsFromSeries(id, data);
          } catch {
            /* history unavailable: the assistant answers without measured statistics */
          }
        }),
      );
      return out;
    },
    [qc],
  );
}
