import { useMemo } from 'react';
import { useQueries } from '@tanstack/react-query';
import {
  CATEGORY_LABELS,
  assessRisk,
  assetReferenceInstrument,
  getAsset,
  getAssetByTokenId,
  tokenPriceSeries,
  type AssetCategory,
  type AssetValuation,
  type HistoryRange,
  type RiskAssessment,
  type SeriesPoint,
  type TokenisedAsset,
} from '@vestora/shared';
import { fetchHistory } from '@/services/market';
import { useAppStore, type ActivityItem } from '@/store/app';
import { useOnchain } from '@/wallet/useOnchain';
import { useValuations } from './useMarket';

export type PortfolioSource = 'sample' | 'simulated' | 'onchain';

/** Illustrative sample portfolio shown before the user invests or connects a wallet. */
export const SAMPLE_HOLDINGS: { assetId: string; tokens: number }[] = [
  { assetId: 'vgld', tokens: 120 },
  { assetId: 'vust10', tokens: 150 },
  { assetId: 'vres', tokens: 100 },
  { assetId: 'vbtc', tokens: 35 },
  { assetId: 'vcpr', tokens: 60 },
  { assetId: 'vwti', tokens: 50 },
  { assetId: 'vcof', tokens: 40 },
];

export interface Position {
  asset: TokenisedAsset;
  tokens: number;
  valuation: AssetValuation;
  value: number | null;
  costBasis: number | null;
  pnl: number | null;
  pnlPct: number | null;
  supplyShare: number;
  risk: RiskAssessment;
}

export interface PortfolioModel {
  source: PortfolioSource;
  available: PortfolioSource[];
  positions: Position[];
  totals: { value: number; cost: number | null; pnl: number | null; pnlPct: number | null; tokens: number; cash: number | null; cashLabel: string };
  byCategory: { category: AssetCategory; label: string; value: number }[];
  byRisk: Partial<Record<RiskAssessment['level'], number>>;
  title: string;
  description: string;
  loading: boolean;
}

function positionFor(asset: TokenisedAsset, tokens: number, valuation: AssetValuation, costBasis: number | null): Position {
  const value = valuation.tokenPrice !== null ? tokens * valuation.tokenPrice : null;
  const pnl = value !== null && costBasis !== null ? value - costBasis : null;
  return {
    asset,
    tokens,
    valuation,
    value,
    costBasis,
    pnl,
    pnlPct: pnl !== null && costBasis ? (pnl / costBasis) * 100 : null,
    supplyShare: (tokens / asset.totalSupply) * 100,
    risk: assessRisk(asset.risk),
  };
}

export function usePortfolio(): PortfolioModel {
  const { valuations, isLoading } = useValuations();
  const view = useAppStore((s) => s.portfolioView);
  const demo = useAppStore((s) => s.demo);
  const onchain = useOnchain();
  const snap = onchain.snapshot.data;

  const hasSimulated = Object.keys(demo.holdings).length > 0;
  const hasOnchain = Boolean(onchain.ready && snap);
  const available: PortfolioSource[] = ['sample', ...(hasSimulated ? (['simulated'] as const) : []), ...(hasOnchain ? (['onchain'] as const) : [])];
  const auto: PortfolioSource = hasOnchain && snap && (snap.credits > 0 || Object.values(snap.balances).some((b) => b > 0)) ? 'onchain' : hasSimulated ? 'simulated' : 'sample';
  const source: PortfolioSource = view !== 'auto' && available.includes(view) ? view : auto;

  return useMemo(() => {
    let positions: Position[] = [];
    let cash: number | null = null;
    let cashLabel = 'Simulated cash';
    let title = 'Sample portfolio';
    let description = 'An illustrative portfolio shown before you invest or connect a wallet. Values move with real reference prices; holdings are fictional.';

    if (source === 'sample') {
      positions = SAMPLE_HOLDINGS.map((h) => {
        const a = getAsset(h.assetId)!;
        return positionFor(a, h.tokens, valuations[a.id], null);
      });
    } else if (source === 'simulated') {
      title = 'Simulated portfolio';
      description = 'Your demo-mode holdings, bought with simulated cash. Nothing here exists on a blockchain.';
      cash = demo.cash;
      positions = Object.values(demo.holdings).map((h) => {
        const a = getAsset(h.assetId)!;
        return positionFor(a, h.tokens, valuations[a.id], h.costBasis);
      });
    } else if (snap) {
      title = 'On-chain testnet portfolio';
      description = 'Token balances read from the AssetToken contract on the testnet, valued at today’s illustrative token prices. vUSD credits are counted at $1 for illustration.';
      cash = snap.credits;
      cashLabel = 'vUSD demo credits';
      const costs = new Map<string, number>();
      for (const e of onchain.history.data ?? []) {
        if (!e.assetId || e.credits === undefined) continue;
        costs.set(e.assetId, (costs.get(e.assetId) ?? 0) + (e.kind === 'buy' ? e.credits : e.kind === 'sell' ? -e.credits : 0));
      }
      positions = Object.entries(snap.balances)
        .filter(([, b]) => b > 0)
        .map(([tid, b]) => {
          const a = getAssetByTokenId(Number(tid));
          if (!a) return null;
          return positionFor(a, b, valuations[a.id], costs.has(a.id) ? Math.max(0, costs.get(a.id)!) : null);
        })
        .filter((p): p is Position => Boolean(p));
    }

    positions.sort((x, y) => (y.value ?? 0) - (x.value ?? 0));
    const value = positions.reduce((s, p) => s + (p.value ?? 0), 0);
    const costKnown = positions.every((p) => p.costBasis !== null);
    const cost = costKnown && positions.length ? positions.reduce((s, p) => s + (p.costBasis ?? 0), 0) : null;
    const pnl = cost !== null ? value - cost : null;
    const byCatMap = new Map<AssetCategory, number>();
    const byRisk: PortfolioModel['byRisk'] = {};
    for (const p of positions) {
      byCatMap.set(p.asset.category, (byCatMap.get(p.asset.category) ?? 0) + (p.value ?? 0));
      byRisk[p.risk.level] = (byRisk[p.risk.level] ?? 0) + (p.value ?? 0);
    }
    return {
      source,
      available,
      positions,
      totals: { value, cost, pnl, pnlPct: pnl !== null && cost ? (pnl / cost) * 100 : null, tokens: positions.reduce((s, p) => s + p.tokens, 0), cash, cashLabel },
      byCategory: [...byCatMap.entries()].map(([category, v]) => ({ category, label: CATEGORY_LABELS[category], value: v })),
      byRisk,
      title,
      description,
      loading: isLoading || (source === 'onchain' && onchain.snapshot.isLoading),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [source, valuations, demo, snap, onchain.history.data, isLoading, onchain.snapshot.isLoading, available.join()]);
}

/** Tokens held of an asset at time t, reconstructed from simulated activity. */
function tokensAt(activity: ActivityItem[], assetId: string, t: number): number {
  let n = 0;
  for (const a of activity) {
    if (a.mode !== 'simulated' || a.assetId !== assetId || a.status !== 'confirmed') continue;
    if (new Date(a.createdAt).getTime() > t) continue;
    if (a.kind === 'buy') n += a.tokens ?? 0;
    if (a.kind === 'sell') n -= a.tokens ?? 0;
  }
  return Math.max(0, n);
}

export interface PerformanceResult {
  points: SeriesPoint[];
  start: number | null;
  end: number | null;
  change: number | null;
  changePct: number | null;
  loading: boolean;
  flatAssets: string[];
}

/**
 * Portfolio value over time from real reference histories. Assets without
 * history (e.g. fixed-valuation samples) are held at their current
 * illustrative value; that is disclosed in the UI.
 */
export function usePerformance(model: PortfolioModel, range: HistoryRange): PerformanceResult {
  const activity = useAppStore((s) => s.activity);
  const queries = useQueries({
    queries: model.positions.map((p) => {
      const ref = assetReferenceInstrument(p.asset);
      return { queryKey: ['history', ref, range], queryFn: () => fetchHistory(ref as string, range), enabled: Boolean(ref), staleTime: 10 * 60_000 };
    }),
  });
  const loading = queries.some((q) => q.isLoading);
  const dataKey = queries.map((q) => q.dataUpdatedAt).join(',');

  return useMemo(() => {
    const series = model.positions.map((p, i) => (p.asset.pricing.kind === 'fixed' ? [] : tokenPriceSeries(p.asset, queries[i]?.data?.points ?? [])));
    const flatAssets = model.positions.filter((_, i) => series[i].length < 2).map((p) => p.asset.symbol);
    let times = [...new Set(series.flat().map((pt) => pt.t))].sort((a, b) => a - b);
    if (times.length > 300) {
      const step = Math.ceil(times.length / 300);
      times = times.filter((_, i) => i % step === 0 || i === times.length - 1);
    }
    const now = Date.now();
    if (times.length === 0 || times[times.length - 1] < now - 60_000) times.push(now);
    const firstSimulated =
      model.source === 'simulated'
        ? Math.min(...activity.filter((a) => a.mode === 'simulated' && a.kind === 'buy').map((a) => new Date(a.createdAt).getTime()), now)
        : -Infinity;
    const cursors = series.map(() => 0);
    const points: SeriesPoint[] = [];
    for (const t of times) {
      if (t < firstSimulated) continue;
      let total = 0;
      model.positions.forEach((p, i) => {
        const s = series[i];
        let price: number | null;
        if (t >= now - 60_000 || s.length < 2) price = p.valuation.tokenPrice;
        else {
          while (cursors[i] + 1 < s.length && s[cursors[i] + 1].t <= t) cursors[i]++;
          price = s[cursors[i]].v;
        }
        const tokens = model.source === 'simulated' ? tokensAt(activity, p.asset.id, t) : p.tokens;
        total += tokens * (price ?? 0);
      });
      points.push({ t, v: total });
    }
    // A change needs at least two observations and at least one holding with real history;
    // otherwise report "no data" rather than a misleading 0.00%.
    const measurable = points.length >= 2 && flatAssets.length < model.positions.length;
    const start = measurable ? points[0].v : null;
    const end = measurable ? points[points.length - 1].v : null;
    return {
      points,
      start,
      end,
      change: start !== null && end !== null ? end - start : null,
      changePct: start && end !== null ? ((end - start) / start) * 100 : null,
      loading,
      flatAssets,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [model.positions, model.source, dataKey, activity, loading]);
}
