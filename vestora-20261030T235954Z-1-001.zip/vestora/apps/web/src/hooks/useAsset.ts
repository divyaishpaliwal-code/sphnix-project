import { useMemo } from 'react';
import {
  assessRisk,
  assetReferenceInstrument,
  getInstrument,
  profileForSubject,
  seriesStats,
  tokenPriceSeries,
  valueAsset,
  type AssetValuation,
  type HistoryRange,
  type Quote,
  type RiskAssessment,
  type SeriesPoint,
  type SeriesStats,
  type TokenisedAsset,
} from '@vestora/shared';
import { useAllQuotes, useHistory } from './useMarket';

export interface AssetInsights {
  valuation: AssetValuation;
  quote: Quote | undefined;
  /** Illustrative token-price series derived from real reference history (empty for fixed assets). */
  tokenSeries: SeriesPoint[];
  stats: SeriesStats | null;
  risk: RiskAssessment;
  historyLoading: boolean;
  historySource: string | null;
}

/** Everything a card or detail page needs about one sample asset. */
export function useAssetInsights(asset: TokenisedAsset, range: HistoryRange = '1Y'): AssetInsights {
  const { quotes } = useAllQuotes();
  const ref = assetReferenceInstrument(asset);
  const hist = useHistory(ref, range);
  const valuation = useMemo(() => valueAsset(asset, quotes), [asset, quotes]);
  const tokenSeries = useMemo(() => (hist.data ? tokenPriceSeries(asset, hist.data.points) : []), [asset, hist.data]);
  const stats = useMemo(() => (tokenSeries.length >= 2 ? seriesStats(tokenSeries) : null), [tokenSeries]);
  const risk = useMemo(
    () =>
      assessRisk(
        asset.risk,
        stats && range === '1Y'
          ? { volatility: stats.volatility, maxDrawdown: stats.maxDrawdown, observations: stats.observations, window: 'the past year', source: hist.data?.source.name ?? null }
          : {},
      ),
    [asset, stats, range, hist.data],
  );
  return {
    valuation,
    quote: ref ? quotes[ref] : undefined,
    tokenSeries,
    stats,
    risk,
    historyLoading: hist.isLoading,
    historySource: hist.data?.source.name ?? null,
  };
}

function firstSentence(s: string): string {
  const m = s.match(/^.*?[.!?](\s|$)/);
  return (m ? m[0] : s).trim();
}

/** One-line plain-language explanation from the curated knowledge base. */
export function plainLanguage(asset: TokenisedAsset): string {
  const ref = assetReferenceInstrument(asset);
  const p = profileForSubject({ kind: 'asset', asset, instrument: ref ? getInstrument(ref) ?? null : null });
  const risk = p.risks[0]?.replace(/\.$/, '') ?? '';
  return `${firstSentence(p.valueSource)} Key risk: ${risk.charAt(0).toLowerCase()}${risk.slice(1)}.`;
}
