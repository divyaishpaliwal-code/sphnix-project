/**
 * Learn centre content. General education for beginners — not advice.
 * Figures about VESTORA describe how this prototype calculates things; any
 * market prices used in examples are hypothetical round numbers, not quotes.
 */

export type GuideTopic = 'Basics' | 'Risk' | 'Markets' | 'Platform';

export interface GuideSection {
  id: string;
  heading: string;
  body: string[];
  bullets?: string[];
  table?: { caption: string; head: string[]; rows: string[][] };
}

export interface Guide {
  slug: string;
  title: string;
  summary: string;
  topic: GuideTopic;
  sections: GuideSection[];
  /** Questions handed to VESTORA Intelligence. */
  questions: string[];
  related: string[];
}

export const GUIDE_TOPICS: { topic: GuideTopic; description: string }[] = [
  { topic: 'Basics', description: 'What fractions and tokens are — and what they are not.' },
  { topic: 'Risk', description: 'How to read volatility, drawdowns and the VESTORA risk score.' },
  { topic: 'Markets', description: 'Bonds, property and where the market data comes from.' },
  { topic: 'Platform', description: 'Wallets, testnets and the simulated verification flow.' },
];

export const GUIDES: Guide[] = [
  {
    slug: 'fractional-ownership',
    title: 'Fractional ownership, explained',
    summary: 'How splitting an asset into many small units lowers the entry ticket — and why it does not lower the risk.',
    topic: 'Basics',
    sections: [
      {
        id: 'idea',
        heading: 'The idea',
        body: [
          'Many assets come in large, expensive units: a 400-ounce gold bar, an office building, a $1,000 bond. Fractional ownership divides one of those units into many smaller pieces so that more people can take part with a small amount of money.',
          'Each piece is worth a proportional slice of the whole. If the whole goes up or down, every slice moves by the same percentage.',
        ],
      },
      {
        id: 'example',
        heading: 'A worked example',
        body: [
          'VESTORA’s Gold Reserve Pool is a sample of 50 troy ounces of gold divided into 20,000 tokens. If the reference gold price were $4,000 an ounce (a hypothetical round number), the pool would be valued at $200,000 and each token at $10.',
          'With $55 you could hold 5 tokens — $50 — and $5 would stay unspent, because tokens are bought whole. Five tokens out of 20,000 is 0.025% of the sample pool.',
        ],
        table: {
          caption: 'How the calculator works',
          head: ['Step', 'Formula'],
          rows: [
            ['Sample asset value', 'quantity × reference price (or a fixed simulated valuation)'],
            ['Token price', 'sample asset value ÷ token supply'],
            ['Tokens you get', 'whole tokens only: floor(amount ÷ token price)'],
            ['Your share', 'tokens ÷ token supply'],
          ],
        },
      },
      {
        id: 'unchanged',
        heading: 'What fractions do not change',
        body: [
          'A smaller ticket is not a safer investment. If gold falls 10%, a $10 fraction falls 10% too. Fractions also add layers that whole ownership does not have: someone has to hold the real asset, keep records and honour redemptions.',
        ],
        bullets: [
          'Price risk is identical, percentage for percentage.',
          'Liquidity can be worse: a small token may have few buyers even when the underlying market is deep.',
          'You depend on the issuer, custodian and legal structure being sound.',
        ],
      },
      {
        id: 'legal',
        heading: 'Ownership on paper versus in law',
        body: [
          'In real products, what you own is defined by legal documents — often shares in a company or trust that holds the asset — not by the token itself. If those documents are weak, or the issuer fails, a token can be worth far less than its slice of the asset.',
          'On VESTORA nothing is owned at all. Tokens are testnet records of an illustrative share of a sample pool. Illustrative calculations only. Not a representation of a legally enforceable ownership claim.',
        ],
      },
    ],
    questions: ['What is fractional ownership?', 'Does owning a token mean I legally own the asset?'],
    related: ['tokenisation', 'risk-score', 'tokenised-real-estate'],
  },
  {
    slug: 'tokenisation',
    title: 'What tokenisation means',
    summary: 'Tokens are digital records on a blockchain. They are only as good as the legal agreement and the custodian behind them.',
    topic: 'Basics',
    sections: [
      {
        id: 'record',
        heading: 'A token is a record',
        body: [
          'Tokenisation means representing a claim — on gold in a vault, a bond, a building — as a token on a blockchain. The blockchain keeps a shared, tamper-resistant record of who holds how many tokens, and transfers settle in minutes rather than days.',
          'The token does not contain the asset. Its value depends on an off-chain promise: a custodian holding the gold, an issuer paying the bond, a company owning the building.',
        ],
      },
      {
        id: 'smart-contracts',
        heading: 'Rules written in code',
        body: [
          'Smart contracts are programs on the blockchain that hold the token rules: who may receive tokens, the maximum supply, whether transfers are paused. Regulated tokens usually restrict transfers to verified wallets so that the issuer can meet know-your-customer rules.',
          'Code can have bugs, and administrators can usually change settings. Contract risk is one reason VESTORA’s risk score includes a tokenisation and custody factor.',
        ],
      },
      {
        id: 'vestora',
        heading: 'How VESTORA’s testnet contracts work',
        body: ['VESTORA deploys two contracts to a public test network. They are for demonstration only and hold nothing of value.'],
        bullets: [
          'AssetToken (ERC-1155): one contract holds every sample asset under its own token id (1–15). Token id 0 is vUSD, non-transferable demo credits used to pay.',
          'ComplianceManager: records each wallet’s simulated verification status. AssetToken refuses purchases from unverified wallets.',
          'Each token’s on-chain metadata states that it does not represent ownership of any real asset.',
          'Purchases and redemptions emit public events you can inspect in Transactions → Contract explorer.',
        ],
      },
      {
        id: 'questions',
        heading: 'Questions to ask about any real tokenised product',
        body: ['Before trusting a token, a careful investor would want clear answers to these:'],
        bullets: [
          'Who holds the underlying asset, and is it audited?',
          'What legal right does a token holder have, and in which jurisdiction?',
          'Can tokens be redeemed for the asset or cash — by whom, and how fast?',
          'Who can pause, freeze or upgrade the contract?',
          'Is the offering registered or exempt under securities law where you live?',
        ],
      },
    ],
    questions: ['What is tokenisation?', 'What is a smart contract?'],
    related: ['fractional-ownership', 'testnet-and-wallets', 'kyc-and-compliance'],
  },
  {
    slug: 'risk-score',
    title: 'How the VESTORA risk score works',
    summary: 'Five weighted factors, each scored from 1 to 10. Volatility and drawdown are measured from real prices whenever enough data exists.',
    topic: 'Risk',
    sections: [
      {
        id: 'formula',
        heading: 'The formula',
        body: [
          'Every sample asset gets a score from 1 (lower risk) to 10 (higher risk). The score is a weighted average of five factors. The AI assistant explains the score — it never sets it.',
        ],
        table: {
          caption: 'Risk factors and weights',
          head: ['Factor', 'Weight', 'What it captures'],
          rows: [
            ['Price volatility', '30%', 'Annualised standard deviation of returns — how widely prices swing.'],
            ['Drawdown history', '20%', 'Largest peak-to-trough decline — how deep losses have been.'],
            ['Liquidity', '15%', 'How easily the underlying (and a token on it) can be sold without a large discount.'],
            ['Tokenisation & custody structure', '20%', 'Custody, legal enforceability, issuer and smart-contract risk.'],
            ['Macro & event sensitivity', '15%', 'Exposure to interest rates, growth shocks, weather, geopolitics and policy.'],
          ],
        },
      },
      {
        id: 'measured',
        heading: 'Measured, not guessed',
        body: [
          'Volatility and drawdown come from one year of real market history for the asset’s reference instrument when at least 20 observations are available. Otherwise VESTORA uses a curated long-run estimate and says so. Every factor in the breakdown is labelled “measured” or “curated”.',
          'The scores below map those measurements to 1–10, interpolating between the points.',
        ],
        table: {
          caption: 'Scoring curves',
          head: ['Annualised volatility', 'Score', 'Largest decline', 'Score'],
          rows: [
            ['5%', '1', '5%', '1'],
            ['10%', '2.5', '15%', '3'],
            ['20%', '4.5', '30%', '5'],
            ['35%', '6.5', '50%', '7'],
            ['60%', '8.5', '70%', '9'],
            ['90% or more', '10', '85% or more', '10'],
          ],
        },
      },
      {
        id: 'bands',
        heading: 'Reading the bands',
        body: ['The weighted score falls into one of five bands. The bands are labels for comparison, not a rating or a recommendation.'],
        table: {
          caption: 'Risk bands',
          head: ['Score', 'Band'],
          rows: [
            ['Below 3', 'Low'],
            ['3 to 4.5', 'Moderate'],
            ['4.5 to 6', 'Elevated'],
            ['6 to 7.5', 'High'],
            ['7.5 and above', 'Very high'],
          ],
        },
      },
      {
        id: 'limits',
        heading: 'Limits of any score',
        body: ['A single number cannot capture everything that matters. Keep these limits in mind:'],
        bullets: [
          'The past year may be calmer or wilder than the future.',
          'Liquidity, structure and macro scores are judgements made by VESTORA’s curators, not measurements.',
          'Simulated assets (the property samples) have no price history, so their scores rely entirely on curated estimates.',
          'Bond samples are scored from their own illustrative price series, which moves with yields.',
        ],
      },
    ],
    questions: ['How is the risk score calculated?', 'Is gold a risky investment?'],
    related: ['volatility-and-drawdown', 'data-sources', 'fractional-ownership'],
  },
  {
    slug: 'volatility-and-drawdown',
    title: 'Volatility and drawdown',
    summary: 'Two numbers that describe how bumpy the ride has been — and why a 50% fall needs a 100% gain to recover.',
    topic: 'Risk',
    sections: [
      {
        id: 'volatility',
        heading: 'Volatility',
        body: [
          'Volatility measures how widely an asset’s returns have varied. VESTORA takes the standard deviation of daily log returns over the past year and annualises it by the number of observations per year.',
          'As a rough guide, an annualised volatility of 15% means that in a typical year, moves of 15% or so in either direction are unremarkable. Bitcoin has often shown volatility several times that of gold.',
        ],
      },
      {
        id: 'drawdown',
        heading: 'Drawdown',
        body: [
          'A drawdown is the fall from a peak to a later low. The maximum drawdown is the deepest such fall within a period. It answers a practical question: how much would someone who bought at the worst moment have been down?',
        ],
      },
      {
        id: 'recovery',
        heading: 'Losses are harder to recover than they look',
        body: ['Because a recovery starts from a lower base, the gain needed to get back to even is always larger than the loss.'],
        table: {
          caption: 'Gain needed to recover',
          head: ['Fall', 'Gain needed to break even'],
          rows: [
            ['10%', '11.1%'],
            ['15%', '17.6%'],
            ['25%', '33.3%'],
            ['50%', '100%'],
            ['75%', '300%'],
          ],
        },
      },
      {
        id: 'together',
        heading: 'Using them together',
        body: [
          'Volatility describes the everyday swings; drawdown describes the worst stretch. Two assets with similar volatility can have very different drawdowns if one suffered a long, steady slide. Neither number predicts the future.',
        ],
      },
    ],
    questions: ['What does a 15% drawdown mean?', 'Why is silver more volatile than gold?'],
    related: ['risk-score', 'data-sources'],
  },
  {
    slug: 'bonds',
    title: 'How bonds work',
    summary: 'Coupons, maturity and yield — and why bond prices fall when interest rates rise.',
    topic: 'Markets',
    sections: [
      {
        id: 'basics',
        heading: 'A loan with a schedule',
        body: [
          'A bond is a loan to a government or company. The borrower pays interest — the coupon — on a fixed schedule and repays the face value at maturity. A 10-year US Treasury note with a 4.25% coupon pays $42.50 a year per $1,000 of face value, in two instalments.',
        ],
      },
      {
        id: 'yield',
        heading: 'Price and yield move in opposite directions',
        body: [
          'Once issued, bonds trade. If market interest rates rise above a bond’s coupon, new buyers can get more elsewhere, so the older bond’s price falls until its yield matches the market. When rates fall, the price rises.',
          'Duration measures how sensitive a bond’s price is to yield changes. A modified duration of 7 means a one-percentage-point rise in yield cuts the price by roughly 7%.',
        ],
      },
      {
        id: 'samples',
        heading: 'VESTORA’s bond samples',
        body: ['Both samples are priced with the standard bond-pricing formula from a live reference yield, so their token prices move with real interest rates.'],
        bullets: [
          'US Treasury 10Y Sample Note: $1,000,000 face value, 4.25% coupon, maturing 15 November 2035, priced from the 10-year Treasury yield (FRED series DGS10).',
          'Investment-Grade Credit Basket: $500,000 face value, 5% coupon, maturing 30 June 2032, priced from the ICE BofA US corporate index effective yield (FRED series BAMLC0A0CMEY).',
          'If no yield is available, a labelled demo yield is used instead — never a guess presented as live.',
        ],
      },
      {
        id: 'risks',
        heading: 'Bond risks',
        body: ['Bonds are often calmer than shares or commodities, but they are not risk-free.'],
        bullets: [
          'Interest-rate risk: rising yields lower prices, more so for long maturities.',
          'Credit risk: a company can default; Treasuries carry far less of this risk.',
          'Inflation risk: fixed coupons buy less when prices rise.',
          'Tokenised bonds add issuer, custody and smart-contract risk on top.',
        ],
      },
    ],
    questions: ['How do bonds work?', 'What happens to bond prices when interest rates rise?'],
    related: ['risk-score', 'data-sources'],
  },
  {
    slug: 'tokenised-real-estate',
    title: 'Tokenised real estate',
    summary: 'How property tokens are usually structured, why their prices can look deceptively smooth, and what VESTORA’s simulated samples show.',
    topic: 'Markets',
    sections: [
      {
        id: 'structure',
        heading: 'How it is usually structured',
        body: [
          'Real tokenised property rarely puts a building’s title on a blockchain. Typically a company or trust (a special-purpose vehicle) owns the property, and tokens represent shares in that vehicle. Rental income, after costs, may be paid out to token holders.',
          'What you hold therefore depends on the vehicle’s legal documents, the jurisdiction and the manager’s honesty and competence.',
        ],
      },
      {
        id: 'valuation',
        heading: 'Smooth prices can hide risk',
        body: [
          'Property is valued by appraisal, often quarterly or annually, not by a live market. That makes reported prices look stable even when the true value has moved. A sudden re-valuation can reveal losses all at once.',
        ],
      },
      {
        id: 'risks',
        heading: 'Main risks',
        body: ['Property-specific risks sit on top of the token structure:'],
        bullets: [
          'Liquidity: there may be few or no buyers for your tokens, and redemptions can be suspended.',
          'Vacancies, repairs and falling rents reduce income.',
          'Rising interest rates tend to lower property values.',
          'Concentration: one or two buildings is far less diversified than a property fund.',
          'Legal: enforceability of token holders’ rights varies by country.',
        ],
      },
      {
        id: 'vestora',
        heading: 'VESTORA’s property samples are fully simulated',
        body: [
          'The Urban Residential Portfolio ($2.4 million across 240,000 tokens) and the Logistics Warehouse ($5 million across 250,000 tokens) are fictional. Their valuations are fixed numbers chosen for illustration, so their token prices never move and they have no price history. They are labelled as simulated everywhere they appear.',
        ],
      },
    ],
    questions: ['What are the risks of tokenised real estate?', 'Does owning a token mean I legally own the asset?'],
    related: ['fractional-ownership', 'tokenisation', 'risk-score'],
  },
  {
    slug: 'data-sources',
    title: 'Market data: sources and labels',
    summary: 'Where VESTORA’s prices come from, what each status label means, and the difference between a market price and a token price.',
    topic: 'Markets',
    sections: [
      {
        id: 'two-prices',
        heading: 'Market price versus token price',
        body: [
          'A market reference price is a real quote for an instrument — gold per troy ounce, WTI crude per barrel, Bitcoin in US dollars. A token price is VESTORA’s illustrative figure: sample asset value divided by token supply. A gold token at $10 does not mean gold costs $10.',
          'Wherever both appear, market prices carry a data-status badge and token prices carry an “Illustrative” badge.',
        ],
      },
      {
        id: 'labels',
        heading: 'Status labels',
        body: ['Every price shows where it came from and how fresh it is.'],
        table: {
          caption: 'Data status labels',
          head: ['Label', 'Meaning'],
          rows: [
            ['Real-time', 'A live or near-live quote from a provider that offers one on the configured plan — CoinGecko for crypto-assets, for example.'],
            ['Delayed', 'A recent quote that lags the market, such as an end-of-day FRED series or exchange data on a free plan.'],
            ['Historical', 'A periodic observation, such as monthly IMF commodity prices on FRED, or past prices used to draw charts.'],
            ['Demo', 'A fixed illustrative value used when no provider is configured or reachable. Never live, never random.'],
            ['Unavailable', 'No data could be obtained. VESTORA shows a gap rather than inventing a number.'],
          ],
        },
      },
      {
        id: 'providers',
        heading: 'Providers',
        body: [
          'The server tries providers in a preferred order for each asset class and uses the first one that is configured and responding. Without any API keys it still works: CoinGecko’s public API covers crypto-assets, and FRED’s public CSV endpoint covers energy, Treasury yields, US indices and IMF monthly commodity series.',
          'When no gold provider key is set, gold can be shown through PAX Gold (PAXG), a gold-backed token, and is labelled as a proxy.',
        ],
        table: {
          caption: 'Provider order by asset class',
          head: ['Asset class', 'Providers (first available wins)'],
          rows: [
            ['Precious metals', 'Metals.Dev, GoldAPI, Twelve Data, Trading Economics, CoinGecko (PAXG proxy)'],
            ['Energy', 'Trading Economics, Alpha Vantage, FRED'],
            ['Industrial metals', 'Metals.Dev, Trading Economics, Alpha Vantage, FRED'],
            ['Agriculture', 'Trading Economics, Alpha Vantage, FRED'],
            ['Digital assets', 'CoinGecko, Twelve Data, FRED'],
            ['Rates and bonds', 'FRED, Alpha Vantage'],
            ['Indices', 'FRED'],
          ],
        },
      },
      {
        id: 'rules',
        heading: 'House rules',
        body: ['A few rules apply to every number on the platform:'],
        bullets: [
          'Responses are cached for between one minute (crypto) and several hours (monthly series) to respect provider rate limits.',
          'If a provider fails, the last good value is shown with its original timestamp — or the instrument is marked unavailable.',
          'Prices are never generated randomly, and price history is never invented to fill a chart.',
          'Daily change uses the provider’s own basis: 24 hours for crypto, previous close for exchange data, previous observation for FRED series.',
        ],
      },
    ],
    questions: ['What affects crude oil prices?', 'Why does gold show a PAXG proxy?'],
    related: ['risk-score', 'volatility-and-drawdown'],
  },
  {
    slug: 'kyc-and-compliance',
    title: 'Why KYC exists — and why ours is simulated',
    summary: 'Regulated platforms must know who their customers are. VESTORA demonstrates the flow without collecting any real identity data.',
    topic: 'Platform',
    sections: [
      {
        id: 'why',
        heading: 'Why platforms verify identity',
        body: [
          'Know-your-customer (KYC) and anti-money-laundering rules require regulated investment platforms to confirm who their customers are, check them against sanctions lists and assess whether products are appropriate. Tokenised securities usually enforce this on-chain by letting only verified wallets hold or receive tokens.',
        ],
      },
      {
        id: 'vestora',
        heading: 'What VESTORA does instead',
        body: [
          'This platform is an educational prototype. KYC is simulated and does not constitute actual identity verification or regulatory approval.',
          'The flow asks for a display name, an email and a country so you can see the steps, then lets you choose the simulated outcome. It never asks for identity documents, and nothing you type is sent to the blockchain.',
        ],
      },
      {
        id: 'onchain',
        heading: 'The on-chain gate',
        body: ['On the testnet, ComplianceManager stores only a status and a hashed case reference for each wallet.'],
        bullets: [
          'Statuses: Not started, Pending, Verified and Rejected.',
          'With self-service approval switched on (the default for demos), recording your verification marks the wallet Verified at once.',
          'With it off, a compliance-officer wallet approves or rejects requests from the Wallet page.',
          'Unverified or frozen wallets cannot buy, and wallet-to-wallet transfers are restricted to verified wallets.',
        ],
      },
    ],
    questions: ['What is KYC and why is it required?'],
    related: ['testnet-and-wallets', 'tokenisation'],
  },
  {
    slug: 'testnet-and-wallets',
    title: 'Wallets, testnets and gas',
    summary: 'How to connect MetaMask, get free test ETH and read a transaction on a block explorer — safely.',
    topic: 'Platform',
    sections: [
      {
        id: 'wallet',
        heading: 'What a wallet is',
        body: [
          'A wallet such as MetaMask holds the keys that let you sign blockchain transactions. Your address is public, like an account number. Your seed phrase and private key are secret: anyone who has them controls the wallet.',
        ],
        bullets: ['VESTORA will never ask for your seed phrase or private key.', 'Use a separate wallet for testing if you can.'],
      },
      {
        id: 'testnet',
        heading: 'Test networks',
        body: [
          'A testnet is a public copy of a blockchain used for development. Its coins have no monetary value and can be obtained free from faucets. VESTORA runs on Sepolia by default; Base Sepolia, Polygon Amoy and a local Hardhat chain are also supported.',
        ],
      },
      {
        id: 'gas',
        heading: 'Gas and demo credits',
        body: [
          'Every transaction pays a small network fee, called gas, in the network’s native coin — test ETH on Sepolia. Purchases themselves are paid in vUSD, demo credits issued by the AssetToken contract: each wallet can claim 10,000 once. vUSD cannot be transferred and has no value.',
        ],
      },
      {
        id: 'steps',
        heading: 'Making a testnet purchase',
        body: ['The investment flow walks you through each step:'],
        bullets: [
          'Connect MetaMask and switch to the target test network when prompted.',
          'Get a little test ETH from a faucet for gas.',
          'Claim your 10,000 vUSD demo credits.',
          'Complete the simulated KYC, then record your verification on-chain.',
          'Confirm the purchase in MetaMask and follow the transaction hash on the block explorer.',
        ],
      },
    ],
    questions: ['What is a testnet?', 'What is a smart contract?'],
    related: ['kyc-and-compliance', 'tokenisation'],
  },
];

export const GUIDE_MAP: Record<string, Guide> = Object.fromEntries(GUIDES.map((g) => [g.slug, g]));

export function readingMinutes(g: Guide): number {
  const words = g.sections
    .flatMap((s) => [s.heading, ...s.body, ...(s.bullets ?? []), ...(s.table ? s.table.rows.flat() : [])])
    .join(' ')
    .split(/\s+/).length;
  return Math.max(1, Math.round(words / 200));
}

export const GLOSSARY: { term: string; definition: string; guide?: string }[] = [
  { term: 'Basis point', definition: 'One hundredth of a percentage point (0.01%). Used for yields and spreads.' },
  { term: 'Coupon', definition: 'The fixed interest a bond pays, as a percentage of its face value.', guide: 'bonds' },
  { term: 'Custodian', definition: 'The firm that holds the real asset behind a token on behalf of holders.', guide: 'tokenisation' },
  { term: 'Drawdown', definition: 'A fall from a peak to a later low, usually quoted as a percentage.', guide: 'volatility-and-drawdown' },
  { term: 'Duration', definition: 'How sensitive a bond’s price is to changes in yield.', guide: 'bonds' },
  { term: 'ERC-1155', definition: 'An Ethereum token standard that lets one contract manage many token types, each with its own id.', guide: 'tokenisation' },
  { term: 'Faucet', definition: 'A website that hands out free testnet coins for development.', guide: 'testnet-and-wallets' },
  { term: 'Fractional ownership', definition: 'Splitting one asset into many smaller units so people can take part with less money.', guide: 'fractional-ownership' },
  { term: 'Gas', definition: 'The fee paid to a blockchain network to process a transaction.', guide: 'testnet-and-wallets' },
  { term: 'KYC', definition: 'Know your customer: identity checks regulated platforms must carry out.', guide: 'kyc-and-compliance' },
  { term: 'Liquidity', definition: 'How quickly something can be sold without accepting a much lower price.', guide: 'risk-score' },
  { term: 'Proxy price', definition: 'A closely related price used when the direct one is unavailable — for example PAXG for gold — and labelled as such.', guide: 'data-sources' },
  { term: 'Reference price', definition: 'The real market price a sample asset’s value is calculated from.', guide: 'data-sources' },
  { term: 'Seed phrase', definition: 'The secret words that control a crypto wallet. Never share them with anyone.', guide: 'testnet-and-wallets' },
  { term: 'Smart contract', definition: 'A program on a blockchain that enforces rules automatically, such as who may hold a token.', guide: 'tokenisation' },
  { term: 'SPV', definition: 'Special-purpose vehicle: a company or trust set up to hold one asset, such as a building.', guide: 'tokenised-real-estate' },
  { term: 'Testnet', definition: 'A public practice blockchain whose coins have no monetary value.', guide: 'testnet-and-wallets' },
  { term: 'Token price', definition: 'On VESTORA, the illustrative sample asset value divided by token supply. Not a market price.', guide: 'data-sources' },
  { term: 'Volatility', definition: 'How widely returns vary, usually annualised. Higher volatility means bigger swings.', guide: 'volatility-and-drawdown' },
  { term: 'Yield', definition: 'The return a bond offers at its current price, as an annual percentage.', guide: 'bonds' },
];
