/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_DISABLE_API?: string;
  readonly VITE_DIRECT_COINGECKO?: string;
  readonly VITE_CHAIN_ID?: string;
  readonly VITE_ASSET_TOKEN_ADDRESS?: string;
  readonly VITE_COMPLIANCE_ADDRESS?: string;
  readonly VITE_DEPLOY_BLOCK?: string;
  readonly VITE_RPC_URL?: string;
  readonly VITE_ROUTER_MODE?: string;
  readonly VITE_BASE_PATH?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
