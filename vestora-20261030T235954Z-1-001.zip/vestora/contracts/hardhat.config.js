require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();
require("./tasks/vestora");

const {
  DEPLOYER_PRIVATE_KEY,
  SEPOLIA_RPC_URL,
  BASE_SEPOLIA_RPC_URL,
  POLYGON_AMOY_RPC_URL,
  ETHERSCAN_API_KEY,
  REPORT_GAS,
} = process.env;

// Never commit a private key. Use a throwaway testnet-only wallet.
const accounts = DEPLOYER_PRIVATE_KEY
  ? [DEPLOYER_PRIVATE_KEY.startsWith("0x") ? DEPLOYER_PRIVATE_KEY : `0x${DEPLOYER_PRIVATE_KEY}`]
  : [];

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.24",
    settings: {
      optimizer: { enabled: true, runs: 200 },
    },
  },
  defaultNetwork: "hardhat",
  networks: {
    hardhat: { chainId: 31337 },
    localhost: { url: "http://127.0.0.1:8545", chainId: 31337 },
    sepolia: {
      url: SEPOLIA_RPC_URL || "https://ethereum-sepolia-rpc.publicnode.com",
      chainId: 11155111,
      accounts,
    },
    baseSepolia: {
      url: BASE_SEPOLIA_RPC_URL || "https://sepolia.base.org",
      chainId: 84532,
      accounts,
    },
    polygonAmoy: {
      url: POLYGON_AMOY_RPC_URL || "https://rpc-amoy.polygon.technology",
      chainId: 80002,
      accounts,
    },
  },
  etherscan: {
    apiKey: ETHERSCAN_API_KEY || "",
  },
  sourcify: { enabled: false },
  gasReporter: {
    enabled: REPORT_GAS === "true",
    currency: "USD",
  },
  mocha: { timeout: 60_000 },
};
