// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {ERC1155} from "@openzeppelin/contracts/token/ERC1155/ERC1155.sol";
import {ERC1155Pausable} from "@openzeppelin/contracts/token/ERC1155/extensions/ERC1155Pausable.sol";
import {ERC1155Supply} from "@openzeppelin/contracts/token/ERC1155/extensions/ERC1155Supply.sol";
import {Base64} from "@openzeppelin/contracts/utils/Base64.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";

/// @notice Minimal view of the ComplianceManager used by AssetToken.
interface IComplianceManager {
    function isVerified(address account) external view returns (bool);

    function canTransfer(address from, address to) external view returns (bool);
}

/**
 * @title AssetToken
 * @notice VESTORA ERC-1155 multi-token for educational sample assets — TESTNETS ONLY.
 *
 *         Token id 0      → vUSD demo credits: claimable once per wallet, non-transferable,
 *                           no monetary value. Spent (burned) when buying sample tokens.
 *         Token ids 1..n  → sample asset tokens with capped supply, minted on purchase.
 *
 *         Asset tokens can only be minted to, and transferred between, wallets that the
 *         ComplianceManager considers verified (mock KYC).
 *
 *         These tokens DO NOT represent ownership of, or any claim on, a real-world asset.
 *         This contract is an unaudited teaching example.
 */
contract AssetToken is ERC1155, AccessControl, ERC1155Pausable, ERC1155Supply {
    using Strings for uint256;

    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant CREDITS_ID = 0;
    uint256 public constant DEMO_CREDIT_GRANT = 10_000;

    struct Asset {
        string symbol;
        string name;
        string category;
        uint256 maxSupply;
        /// @dev Issuance price in vUSD demo credits per whole token.
        uint256 price;
        bool active;
        bool exists;
    }

    IComplianceManager public compliance;

    mapping(uint256 => Asset) private _assets;
    uint256[] private _assetIds;

    mapping(address => bool) public hasClaimedCredits;

    event AssetCreated(uint256 indexed assetId, string symbol, string name, uint256 maxSupply, uint256 price);
    event AssetUpdated(uint256 indexed assetId, uint256 price, bool active);
    event DemoCreditsClaimed(address indexed account, uint256 amount);
    event AssetPurchased(address indexed buyer, uint256 indexed assetId, uint256 amount, uint256 cost);
    event AssetRedeemed(address indexed holder, uint256 indexed assetId, uint256 amount, uint256 credits);
    event AssetIssued(address indexed to, uint256 indexed assetId, uint256 amount);
    event ComplianceUpdated(address indexed compliance);

    error UnknownAsset(uint256 assetId);
    error AssetInactive(uint256 assetId);
    error AssetExists(uint256 assetId);
    error InvalidAsset();
    error InvalidAmount();
    error NotVerified(address account);
    error ExceedsMaxSupply(uint256 assetId, uint256 requested, uint256 available);
    error InsufficientCredits(uint256 balance, uint256 needed);
    error CreditsAlreadyClaimed(address account);
    error CreditsNonTransferable();
    error TransferNotCompliant(address from, address to);
    error ZeroAddress();

    constructor(address admin, address complianceManager) ERC1155("") {
        if (admin == address(0) || complianceManager == address(0)) revert ZeroAddress();
        compliance = IComplianceManager(complianceManager);
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(ISSUER_ROLE, admin);
        _grantRole(PAUSER_ROLE, admin);
    }

    // ---------------------------------------------------------------------
    // Issuer / admin
    // ---------------------------------------------------------------------

    function createAsset(
        uint256 assetId,
        string calldata symbol_,
        string calldata name_,
        string calldata category_,
        uint256 maxSupply,
        uint256 price
    ) external onlyRole(ISSUER_ROLE) {
        if (assetId == CREDITS_ID) revert InvalidAsset();
        if (_assets[assetId].exists) revert AssetExists(assetId);
        if (maxSupply == 0 || price == 0) revert InvalidAmount();
        if (!_validLabel(bytes(symbol_), 16) || !_validLabel(bytes(name_), 64) || !_validLabel(bytes(category_), 32)) {
            revert InvalidAsset();
        }
        _assets[assetId] = Asset({
            symbol: symbol_,
            name: name_,
            category: category_,
            maxSupply: maxSupply,
            price: price,
            active: true,
            exists: true
        });
        _assetIds.push(assetId);
        emit AssetCreated(assetId, symbol_, name_, maxSupply, price);
    }

    function setAssetPrice(uint256 assetId, uint256 price) external onlyRole(ISSUER_ROLE) {
        Asset storage a = _requireAsset(assetId);
        if (price == 0) revert InvalidAmount();
        a.price = price;
        emit AssetUpdated(assetId, price, a.active);
    }

    function setAssetActive(uint256 assetId, bool active) external onlyRole(ISSUER_ROLE) {
        Asset storage a = _requireAsset(assetId);
        a.active = active;
        emit AssetUpdated(assetId, a.price, active);
    }

    /// @notice Controlled minting of sample tokens to a verified wallet (e.g. demo airdrops).
    function issue(address to, uint256 assetId, uint256 amount) external onlyRole(ISSUER_ROLE) {
        Asset storage a = _requireAsset(assetId);
        if (amount == 0) revert InvalidAmount();
        if (!compliance.isVerified(to)) revert NotVerified(to);
        _checkSupply(assetId, a.maxSupply, amount);
        _mint(to, assetId, amount, "");
        emit AssetIssued(to, assetId, amount);
    }

    function setCompliance(address complianceManager) external onlyRole(DEFAULT_ADMIN_ROLE) {
        if (complianceManager == address(0)) revert ZeroAddress();
        compliance = IComplianceManager(complianceManager);
        emit ComplianceUpdated(complianceManager);
    }

    function pause() external onlyRole(PAUSER_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(PAUSER_ROLE) {
        _unpause();
    }

    // ---------------------------------------------------------------------
    // Wallet holders
    // ---------------------------------------------------------------------

    /// @notice Claim the one-time grant of vUSD demo credits (no monetary value).
    function claimDemoCredits() external {
        if (hasClaimedCredits[msg.sender]) revert CreditsAlreadyClaimed(msg.sender);
        hasClaimedCredits[msg.sender] = true;
        _mint(msg.sender, CREDITS_ID, DEMO_CREDIT_GRANT, "");
        emit DemoCreditsClaimed(msg.sender, DEMO_CREDIT_GRANT);
    }

    /// @notice Buy whole sample tokens with demo credits. Requires (mock) KYC verification.
    function buy(uint256 assetId, uint256 amount) external {
        Asset storage a = _requireAsset(assetId);
        if (!a.active) revert AssetInactive(assetId);
        if (amount == 0) revert InvalidAmount();
        if (!compliance.isVerified(msg.sender)) revert NotVerified(msg.sender);
        _checkSupply(assetId, a.maxSupply, amount);

        uint256 cost = a.price * amount;
        uint256 balance = balanceOf(msg.sender, CREDITS_ID);
        if (balance < cost) revert InsufficientCredits(balance, cost);

        _burn(msg.sender, CREDITS_ID, cost);
        _mint(msg.sender, assetId, amount, "");
        emit AssetPurchased(msg.sender, assetId, amount, cost);
    }

    /// @notice Return sample tokens for demo credits at the current issuance price.
    function redeem(uint256 assetId, uint256 amount) external {
        Asset storage a = _requireAsset(assetId);
        if (amount == 0) revert InvalidAmount();
        uint256 credits = a.price * amount;
        _burn(msg.sender, assetId, amount);
        _mint(msg.sender, CREDITS_ID, credits, "");
        emit AssetRedeemed(msg.sender, assetId, amount, credits);
    }

    // ---------------------------------------------------------------------
    // Views
    // ---------------------------------------------------------------------

    function assetCount() external view returns (uint256) {
        return _assetIds.length;
    }

    function assetIds() external view returns (uint256[] memory) {
        return _assetIds;
    }

    function getAsset(uint256 assetId) external view returns (Asset memory) {
        Asset memory a = _requireAsset(assetId);
        return a;
    }

    function availableSupply(uint256 assetId) public view returns (uint256) {
        Asset storage a = _requireAsset(assetId);
        uint256 minted = totalSupply(assetId);
        return a.maxSupply > minted ? a.maxSupply - minted : 0;
    }

    function creditsOf(address account) external view returns (uint256) {
        return balanceOf(account, CREDITS_ID);
    }

    /// @notice On-chain JSON metadata (base64 data URI). States clearly that tokens confer no ownership.
    function uri(uint256 id) public view override returns (string memory) {
        string memory json;
        if (id == CREDITS_ID) {
            json = string.concat(
                '{"name":"VESTORA Demo Credit","symbol":"vUSD","decimals":0,',
                '"description":"Non-transferable testnet demo credit with no monetary value. Educational prototype only.",',
                '"attributes":[{"trait_type":"Network","value":"Testnet only"}]}'
            );
        } else {
            Asset storage a = _requireAsset(id);
            string memory head = string.concat('{"name":"', a.name, '","symbol":"', a.symbol, '","decimals":0,');
            string memory desc = string.concat(
                '"description":"Educational testnet token for a VESTORA sample asset. ',
                'It does not represent ownership of, or any claim on, a real-world asset.",'
            );
            string memory attrs = string.concat(
                '"attributes":[{"trait_type":"Category","value":"',
                a.category,
                '"},{"trait_type":"Max supply","value":',
                a.maxSupply.toString(),
                "},"
            );
            string memory tail = string.concat(
                '{"trait_type":"Issuance price (vUSD)","value":',
                a.price.toString(),
                '},{"trait_type":"Network","value":"Testnet only"}]}'
            );
            json = string.concat(head, desc, attrs, tail);
        }
        return string.concat("data:application/json;base64,", Base64.encode(bytes(json)));
    }

    // ---------------------------------------------------------------------
    // Internal
    // ---------------------------------------------------------------------

    function _requireAsset(uint256 assetId) internal view returns (Asset storage a) {
        a = _assets[assetId];
        if (!a.exists) revert UnknownAsset(assetId);
    }

    function _checkSupply(uint256 assetId, uint256 maxSupply, uint256 amount) internal view {
        uint256 minted = totalSupply(assetId);
        uint256 available = maxSupply > minted ? maxSupply - minted : 0;
        if (amount > available) revert ExceedsMaxSupply(assetId, amount, available);
    }

    /// @dev Labels are embedded in JSON metadata, so quotes, backslashes and control characters are rejected.
    function _validLabel(bytes memory b, uint256 maxLen) internal pure returns (bool) {
        if (b.length == 0 || b.length > maxLen) return false;
        for (uint256 i = 0; i < b.length; ++i) {
            bytes1 c = b[i];
            if (c == 0x22 || c == 0x5c || uint8(c) < 0x20) return false;
        }
        return true;
    }

    /// @dev Enforces credit non-transferability and compliance on wallet-to-wallet transfers.
    ///      Mints (from = 0) and burns (to = 0) are governed by the public functions above.
    function _update(
        address from,
        address to,
        uint256[] memory ids,
        uint256[] memory values
    ) internal override(ERC1155, ERC1155Pausable, ERC1155Supply) {
        if (from != address(0) && to != address(0)) {
            for (uint256 i = 0; i < ids.length; ++i) {
                if (ids[i] == CREDITS_ID) revert CreditsNonTransferable();
            }
            if (!compliance.canTransfer(from, to)) revert TransferNotCompliant(from, to);
        }
        super._update(from, to, ids, values);
    }

    function supportsInterface(bytes4 interfaceId) public view override(ERC1155, AccessControl) returns (bool) {
        return super.supportsInterface(interfaceId);
    }
}
