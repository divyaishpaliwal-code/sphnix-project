/**
 * Verifies the deployed contracts on the network's block explorer.
 *   ETHERSCAN_API_KEY=... npx hardhat run scripts/verify.js --network sepolia
 */
const hre = require("hardhat");
const { loadDeployment } = require("./lib");

async function verify(address, constructorArguments) {
  try {
    await hre.run("verify:verify", { address, constructorArguments });
  } catch (err) {
    const msg = String(err && err.message ? err.message : err);
    if (msg.toLowerCase().includes("already verified")) {
      console.log(`Already verified: ${address}`);
    } else {
      throw err;
    }
  }
}

async function main() {
  const d = loadDeployment(hre.network.name);
  await verify(d.contracts.ComplianceManager, [d.deployer, d.selfServiceKyc]);
  await verify(d.contracts.AssetToken, [d.deployer, d.contracts.ComplianceManager]);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
