/**
 * Deploys ComplianceManager + AssetToken, creates every sample asset from
 * packages/shared/data/onchain-assets.json and writes the deployment record to:
 *   - contracts/deployments/<network>.json
 *   - apps/web/src/contracts/deployments/<chainId>.json   (picked up by the web app)
 *
 * Usage:
 *   npx hardhat node                                  # terminal 1 (local chain)
 *   npx hardhat run scripts/deploy.js --network localhost
 *   npx hardhat run scripts/deploy.js --network sepolia
 *
 * Env:
 *   SELF_SERVICE_KYC=true|false   auto-approve verification requests (default true)
 *   KYC_PREAPPROVE=0xabc,0xdef    wallets to approve right after deployment
 */
const path = require("path");
const hre = require("hardhat");
const { EXPLORERS, deploymentPath, writeJson, loadCatalog, exportAbis, WEB_CONTRACTS_DIR } = require("./lib");

async function main() {
  const { ethers, network } = hre;
  const [deployer] = await ethers.getSigners();
  if (!deployer) {
    throw new Error("No deployer account available. Set DEPLOYER_PRIVATE_KEY in contracts/.env (testnet-only wallet).");
  }

  const chainId = Number((await ethers.provider.getNetwork()).chainId);
  if (chainId === 1) throw new Error("Refusing to deploy to Ethereum mainnet. VESTORA is a testnet-only prototype.");

  const selfService = String(process.env.SELF_SERVICE_KYC ?? "true").toLowerCase() !== "false";
  const balance = await ethers.provider.getBalance(deployer.address);
  console.log(`\nVESTORA deployment → ${network.name} (chainId ${chainId})`);
  console.log(`Deployer: ${deployer.address}  balance: ${ethers.formatEther(balance)} ETH`);
  console.log(`Self-service KYC: ${selfService}\n`);

  const startBlock = await ethers.provider.getBlockNumber();

  const compliance = await ethers.deployContract("ComplianceManager", [deployer.address, selfService]);
  await compliance.waitForDeployment();
  const complianceAddress = await compliance.getAddress();
  console.log(`ComplianceManager: ${complianceAddress}`);

  const token = await ethers.deployContract("AssetToken", [deployer.address, complianceAddress]);
  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();
  console.log(`AssetToken:        ${tokenAddress}\n`);

  const catalog = loadCatalog();
  for (const a of catalog.assets) {
    const tx = await token.createAsset(a.tokenId, a.symbol, a.name, a.category, a.maxSupply, a.price);
    await tx.wait();
    console.log(`  • #${String(a.tokenId).padStart(2, " ")} ${a.symbol.padEnd(7)} supply ${a.maxSupply} @ ${a.price} vUSD`);
  }

  const preapprove = (process.env.KYC_PREAPPROVE || "")
    .split(",")
    .map((s) => s.trim())
    .filter((s) => ethers.isAddress(s));
  if (preapprove.length > 0) {
    const tx = await compliance.approveBatch(preapprove);
    await tx.wait();
    console.log(`\nPre-approved ${preapprove.length} wallet(s) for simulated KYC.`);
  }

  const record = {
    name: "VESTORA",
    network: network.name,
    chainId,
    deployedAt: new Date().toISOString(),
    deployer: deployer.address,
    startBlock,
    selfServiceKyc: selfService,
    explorer: EXPLORERS[chainId] || null,
    contracts: {
      ComplianceManager: complianceAddress,
      AssetToken: tokenAddress,
    },
    assets: catalog.assets.map((a) => a.tokenId),
  };

  writeJson(deploymentPath(network.name), record);
  writeJson(path.join(WEB_CONTRACTS_DIR, "deployments", `${chainId}.json`), record);
  await exportAbis(hre);

  console.log("\nDeployment record written to contracts/deployments and apps/web/src/contracts/deployments.");
  if (record.explorer) {
    console.log(`Explorer: ${record.explorer}/address/${tokenAddress}`);
  }
  console.log("\nOptional — pin these in apps/web/.env.local:");
  console.log(`VITE_CHAIN_ID=${chainId}`);
  console.log(`VITE_ASSET_TOKEN_ADDRESS=${tokenAddress}`);
  console.log(`VITE_COMPLIANCE_ADDRESS=${complianceAddress}`);
  console.log(`VITE_DEPLOY_BLOCK=${startBlock}\n`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
