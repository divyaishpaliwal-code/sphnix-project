const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "../..");
const CONTRACTS_DIR = path.resolve(__dirname, "..");
const WEB_CONTRACTS_DIR = path.join(ROOT, "apps", "web", "src", "contracts");

const EXPLORERS = {
  11155111: "https://sepolia.etherscan.io",
  84532: "https://sepolia.basescan.org",
  80002: "https://amoy.polygonscan.com",
};

function deploymentPath(networkName) {
  return path.join(CONTRACTS_DIR, "deployments", `${networkName}.json`);
}

function loadDeployment(networkName) {
  const file = deploymentPath(networkName);
  if (!fs.existsSync(file)) {
    throw new Error(`No deployment found for network "${networkName}". Run the deploy script first (${file}).`);
  }
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
}

function loadCatalog() {
  const file = path.join(ROOT, "packages", "shared", "data", "onchain-assets.json");
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

/** Copy ABIs from Hardhat artifacts into the web app (useful for other tools and verification). */
async function exportAbis(hre) {
  for (const name of ["AssetToken", "ComplianceManager"]) {
    const artifact = await hre.artifacts.readArtifact(name);
    writeJson(path.join(WEB_CONTRACTS_DIR, "abi", `${name}.json`), { contractName: name, abi: artifact.abi });
  }
}

module.exports = {
  ROOT,
  CONTRACTS_DIR,
  WEB_CONTRACTS_DIR,
  EXPLORERS,
  deploymentPath,
  loadDeployment,
  writeJson,
  loadCatalog,
  exportAbis,
};
