/**
 * Admin helper tasks for a deployed VESTORA instance.
 *
 *   npx hardhat vestora:assets --network sepolia
 *   npx hardhat vestora:kyc --account 0xabc… --network sepolia                 # status
 *   npx hardhat vestora:kyc --account 0xabc… --action approve --network sepolia
 *   npx hardhat vestora:self-service --enabled false --network sepolia
 *   npx hardhat vestora:price --id 1 --price 12 --network sepolia
 */
const { task } = require("hardhat/config");

const STATUS = ["None", "Pending", "Verified", "Rejected"];

async function contracts(hre) {
  const { loadDeployment } = require("../scripts/lib");
  const d = loadDeployment(hre.network.name);
  const compliance = await hre.ethers.getContractAt("ComplianceManager", d.contracts.ComplianceManager);
  const token = await hre.ethers.getContractAt("AssetToken", d.contracts.AssetToken);
  return { d, compliance, token };
}

task("vestora:assets", "List sample assets and their on-chain supply").setAction(async (_, hre) => {
  const { token } = await contracts(hre);
  const ids = await token.assetIds();
  const rows = [];
  for (const id of ids) {
    const a = await token.getAsset(id);
    const minted = await token["totalSupply(uint256)"](id);
    rows.push({
      id: Number(id),
      symbol: a.symbol,
      name: a.name,
      price: Number(a.price),
      minted: Number(minted),
      maxSupply: Number(a.maxSupply),
      active: a.active,
    });
  }
  console.table(rows);
});

task("vestora:kyc", "Show or change a wallet's simulated KYC status")
  .addParam("account", "Wallet address")
  .addOptionalParam("action", "status | approve | reject | revoke | freeze | unfreeze", "status")
  .setAction(async ({ account, action }, hre) => {
    const { compliance } = await contracts(hre);
    if (!hre.ethers.isAddress(account)) throw new Error(`Invalid address: ${account}`);
    const actions = {
      approve: () => compliance.approve(account),
      reject: () => compliance.reject(account),
      revoke: () => compliance.revoke(account),
      freeze: () => compliance.setFrozen(account, true),
      unfreeze: () => compliance.setFrozen(account, false),
    };
    if (action !== "status") {
      if (!actions[action]) throw new Error(`Unknown action "${action}"`);
      const tx = await actions[action]();
      console.log(`Sent ${action}: ${tx.hash}`);
      await tx.wait();
    }
    const status = await compliance.statusOf(account);
    const frozen = await compliance.frozen(account);
    const verified = await compliance.isVerified(account);
    console.log(`${account}: ${STATUS[Number(status)]}${frozen ? " (frozen)" : ""} — isVerified=${verified}`);
  });

task("vestora:self-service", "Enable or disable self-service KYC approval")
  .addParam("enabled", "true | false")
  .setAction(async ({ enabled }, hre) => {
    const { compliance } = await contracts(hre);
    const value = String(enabled).toLowerCase() === "true";
    const tx = await compliance.setSelfServiceApproval(value);
    await tx.wait();
    console.log(`selfServiceApproval = ${await compliance.selfServiceApproval()}`);
  });

task("vestora:price", "Update a sample asset's issuance price (vUSD per token)")
  .addParam("id", "Asset token id")
  .addParam("price", "New integer price in vUSD demo credits")
  .setAction(async ({ id, price }, hre) => {
    const { token } = await contracts(hre);
    const tx = await token.setAssetPrice(BigInt(id), BigInt(price));
    await tx.wait();
    const a = await token.getAsset(BigInt(id));
    console.log(`${a.symbol} price = ${a.price} vUSD`);
  });
