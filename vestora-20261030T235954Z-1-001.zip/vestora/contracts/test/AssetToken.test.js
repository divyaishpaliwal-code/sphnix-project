const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

const GOLD = 1n;
const SILVER = 2n;
const CREDITS = 0n;

describe("AssetToken", function () {
  async function deployFixture() {
    const [admin, alice, bob, mallory] = await ethers.getSigners();
    const compliance = await ethers.deployContract("ComplianceManager", [admin.address, false]);
    await compliance.waitForDeployment();
    const token = await ethers.deployContract("AssetToken", [admin.address, await compliance.getAddress()]);
    await token.waitForDeployment();
    await token.createAsset(GOLD, "vGLD", "Gold Reserve Pool", "Precious Metals", 20_000, 10);
    await token.createAsset(SILVER, "vSLV", "Silver Reserve Pool", "Precious Metals", 5, 10);
    return { admin, alice, bob, mallory, compliance, token };
  }

  /** Alice is verified and holds her demo credits. */
  async function fundedFixture() {
    const ctx = await deployFixture();
    await ctx.compliance.approve(ctx.alice.address);
    await ctx.token.connect(ctx.alice).claimDemoCredits();
    return ctx;
  }

  function decodeUri(uri) {
    expect(uri.startsWith("data:application/json;base64,")).to.equal(true);
    return JSON.parse(Buffer.from(uri.split(",")[1], "base64").toString("utf8"));
  }

  describe("assets and metadata", function () {
    it("registers assets with their parameters", async function () {
      const { token } = await loadFixture(deployFixture);
      expect(await token.assetCount()).to.equal(2n);
      expect([...(await token.assetIds())]).to.deep.equal([GOLD, SILVER]);
      const gold = await token.getAsset(GOLD);
      expect(gold.symbol).to.equal("vGLD");
      expect(gold.maxSupply).to.equal(20_000n);
      expect(gold.price).to.equal(10n);
      expect(gold.active).to.equal(true);
      expect(await token.availableSupply(GOLD)).to.equal(20_000n);
    });

    it("serves on-chain JSON metadata that disclaims real-world ownership", async function () {
      const { token } = await loadFixture(deployFixture);
      const meta = decodeUri(await token.uri(GOLD));
      expect(meta.name).to.equal("Gold Reserve Pool");
      expect(meta.symbol).to.equal("vGLD");
      expect(meta.description).to.contain("does not represent ownership");
      expect(meta.attributes).to.deep.include({ trait_type: "Max supply", value: 20000 });
      const credits = decodeUri(await token.uri(CREDITS));
      expect(credits.symbol).to.equal("vUSD");
      await expect(token.uri(99)).to.be.revertedWithCustomError(token, "UnknownAsset").withArgs(99);
    });

    it("guards asset creation", async function () {
      const { token, alice } = await loadFixture(deployFixture);
      await expect(token.createAsset(0, "X", "X", "X", 1, 1)).to.be.revertedWithCustomError(token, "InvalidAsset");
      await expect(token.createAsset(GOLD, "X", "X", "X", 1, 1))
        .to.be.revertedWithCustomError(token, "AssetExists")
        .withArgs(GOLD);
      await expect(token.createAsset(3, "X", "X", "X", 0, 1)).to.be.revertedWithCustomError(token, "InvalidAmount");
      await expect(token.createAsset(3, 'bad"sym', "X", "X", 1, 1)).to.be.revertedWithCustomError(token, "InvalidAsset");
      await expect(token.connect(alice).createAsset(3, "X", "X", "X", 1, 1)).to.be.revertedWithCustomError(
        token,
        "AccessControlUnauthorizedAccount"
      );
    });

    it("supports ERC-1155 and AccessControl interfaces", async function () {
      const { token } = await loadFixture(deployFixture);
      expect(await token.supportsInterface("0xd9b67a26")).to.equal(true); // ERC-1155
      expect(await token.supportsInterface("0x7965db0b")).to.equal(true); // AccessControl
    });
  });

  describe("demo credits", function () {
    it("can be claimed exactly once", async function () {
      const { token, alice } = await loadFixture(deployFixture);
      await expect(token.connect(alice).claimDemoCredits())
        .to.emit(token, "DemoCreditsClaimed")
        .withArgs(alice.address, 10_000);
      expect(await token.creditsOf(alice.address)).to.equal(10_000n);
      await expect(token.connect(alice).claimDemoCredits())
        .to.be.revertedWithCustomError(token, "CreditsAlreadyClaimed")
        .withArgs(alice.address);
    });

    it("are non-transferable", async function () {
      const { token, alice, bob, compliance } = await loadFixture(fundedFixture);
      await compliance.approve(bob.address);
      await expect(
        token.connect(alice).safeTransferFrom(alice.address, bob.address, CREDITS, 1, "0x")
      ).to.be.revertedWithCustomError(token, "CreditsNonTransferable");
    });
  });

  describe("buying", function () {
    it("requires mock-KYC verification", async function () {
      const { token, bob } = await loadFixture(deployFixture);
      await token.connect(bob).claimDemoCredits();
      await expect(token.connect(bob).buy(GOLD, 1)).to.be.revertedWithCustomError(token, "NotVerified").withArgs(bob.address);
    });

    it("burns credits and mints asset tokens", async function () {
      const { token, alice } = await loadFixture(fundedFixture);
      await expect(token.connect(alice).buy(GOLD, 5))
        .to.emit(token, "AssetPurchased")
        .withArgs(alice.address, GOLD, 5, 50);
      expect(await token.balanceOf(alice.address, GOLD)).to.equal(5n);
      expect(await token.creditsOf(alice.address)).to.equal(9_950n);
      expect(await token["totalSupply(uint256)"](GOLD)).to.equal(5n);
      expect(await token.availableSupply(GOLD)).to.equal(19_995n);
    });

    it("rejects zero amounts, insufficient credits and inactive assets", async function () {
      const { token, alice } = await loadFixture(fundedFixture);
      await expect(token.connect(alice).buy(GOLD, 0)).to.be.revertedWithCustomError(token, "InvalidAmount");
      await expect(token.connect(alice).buy(GOLD, 1_001))
        .to.be.revertedWithCustomError(token, "InsufficientCredits")
        .withArgs(10_000, 10_010);
      await token.setAssetActive(GOLD, false);
      await expect(token.connect(alice).buy(GOLD, 1)).to.be.revertedWithCustomError(token, "AssetInactive").withArgs(GOLD);
      await expect(token.connect(alice).buy(42, 1)).to.be.revertedWithCustomError(token, "UnknownAsset").withArgs(42);
    });

    it("enforces the maximum supply", async function () {
      const { token, alice } = await loadFixture(fundedFixture);
      await token.connect(alice).buy(SILVER, 3);
      await expect(token.connect(alice).buy(SILVER, 3))
        .to.be.revertedWithCustomError(token, "ExceedsMaxSupply")
        .withArgs(SILVER, 3, 2);
      await token.connect(alice).buy(SILVER, 2);
      expect(await token.availableSupply(SILVER)).to.equal(0n);
    });

    it("uses the current issuance price", async function () {
      const { token, alice } = await loadFixture(fundedFixture);
      await token.setAssetPrice(GOLD, 25);
      await token.connect(alice).buy(GOLD, 2);
      expect(await token.creditsOf(alice.address)).to.equal(9_950n);
    });
  });

  describe("redeeming", function () {
    it("burns asset tokens and returns credits", async function () {
      const { token, alice } = await loadFixture(fundedFixture);
      await token.connect(alice).buy(GOLD, 5);
      await expect(token.connect(alice).redeem(GOLD, 2))
        .to.emit(token, "AssetRedeemed")
        .withArgs(alice.address, GOLD, 2, 20);
      expect(await token.balanceOf(alice.address, GOLD)).to.equal(3n);
      expect(await token.creditsOf(alice.address)).to.equal(9_970n);
      await expect(token.connect(alice).redeem(GOLD, 10)).to.be.revertedWithCustomError(token, "ERC1155InsufficientBalance");
    });
  });

  describe("transfer restrictions", function () {
    it("blocks transfers to unverified wallets and allows verified ones", async function () {
      const { token, compliance, alice, bob } = await loadFixture(fundedFixture);
      await token.connect(alice).buy(GOLD, 5);
      await expect(token.connect(alice).safeTransferFrom(alice.address, bob.address, GOLD, 1, "0x"))
        .to.be.revertedWithCustomError(token, "TransferNotCompliant")
        .withArgs(alice.address, bob.address);
      await compliance.approve(bob.address);
      await token.connect(alice).safeTransferFrom(alice.address, bob.address, GOLD, 1, "0x");
      expect(await token.balanceOf(bob.address, GOLD)).to.equal(1n);
    });

    it("blocks transfers from frozen wallets", async function () {
      const { token, compliance, alice, bob } = await loadFixture(fundedFixture);
      await token.connect(alice).buy(GOLD, 2);
      await compliance.approve(bob.address);
      await compliance.setFrozen(alice.address, true);
      await expect(
        token.connect(alice).safeTransferFrom(alice.address, bob.address, GOLD, 1, "0x")
      ).to.be.revertedWithCustomError(token, "TransferNotCompliant");
    });
  });

  describe("controlled minting and pausing", function () {
    it("lets issuers mint to verified wallets within the cap", async function () {
      const { token, compliance, alice, bob } = await loadFixture(deployFixture);
      await expect(token.issue(bob.address, GOLD, 1)).to.be.revertedWithCustomError(token, "NotVerified");
      await compliance.approve(bob.address);
      await expect(token.issue(bob.address, GOLD, 3)).to.emit(token, "AssetIssued").withArgs(bob.address, GOLD, 3);
      await expect(token.issue(bob.address, SILVER, 6)).to.be.revertedWithCustomError(token, "ExceedsMaxSupply");
      await expect(token.connect(alice).issue(bob.address, GOLD, 1)).to.be.revertedWithCustomError(
        token,
        "AccessControlUnauthorizedAccount"
      );
    });

    it("pausing halts claims, purchases and transfers", async function () {
      const { token, alice, bob } = await loadFixture(fundedFixture);
      await token.pause();
      await expect(token.connect(alice).buy(GOLD, 1)).to.be.revertedWithCustomError(token, "EnforcedPause");
      await expect(token.connect(bob).claimDemoCredits()).to.be.revertedWithCustomError(token, "EnforcedPause");
      await expect(token.connect(alice).pause()).to.be.revertedWithCustomError(token, "AccessControlUnauthorizedAccount");
      await token.unpause();
      await token.connect(alice).buy(GOLD, 1);
      expect(await token.balanceOf(alice.address, GOLD)).to.equal(1n);
    });
  });
});
