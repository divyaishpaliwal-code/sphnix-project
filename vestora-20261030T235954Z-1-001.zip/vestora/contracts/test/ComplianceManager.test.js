const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

const Status = { None: 0n, Pending: 1n, Verified: 2n, Rejected: 3n };
const CASE_REF = ethers.id("demo-case-001");

describe("ComplianceManager", function () {
  async function deployFixture() {
    const [admin, officer, alice, bob] = await ethers.getSigners();
    const compliance = await ethers.deployContract("ComplianceManager", [admin.address, false]);
    await compliance.waitForDeployment();
    return { compliance, admin, officer, alice, bob };
  }

  async function selfServiceFixture() {
    const [admin, alice] = await ethers.getSigners();
    const compliance = await ethers.deployContract("ComplianceManager", [admin.address, true]);
    await compliance.waitForDeployment();
    return { compliance, admin, alice };
  }

  describe("deployment", function () {
    it("grants admin and officer roles to the deployer", async function () {
      const { compliance, admin } = await loadFixture(deployFixture);
      expect(await compliance.hasRole(await compliance.DEFAULT_ADMIN_ROLE(), admin.address)).to.equal(true);
      expect(await compliance.hasRole(await compliance.COMPLIANCE_OFFICER_ROLE(), admin.address)).to.equal(true);
      expect(await compliance.selfServiceApproval()).to.equal(false);
      expect(await compliance.transfersRestricted()).to.equal(true);
    });

    it("rejects a zero admin address", async function () {
      const factory = await ethers.getContractFactory("ComplianceManager");
      await expect(factory.deploy(ethers.ZeroAddress, false)).to.be.revertedWithCustomError(factory, "ZeroAddress");
    });
  });

  describe("verification requests", function () {
    it("moves a wallet to Pending and emits events", async function () {
      const { compliance, alice } = await loadFixture(deployFixture);
      await expect(compliance.connect(alice).requestVerification(CASE_REF))
        .to.emit(compliance, "VerificationRequested")
        .withArgs(alice.address, CASE_REF)
        .and.to.emit(compliance, "StatusChanged")
        .withArgs(alice.address, Status.Pending, alice.address);
      expect(await compliance.statusOf(alice.address)).to.equal(Status.Pending);
      expect(await compliance.isVerified(alice.address)).to.equal(false);
      const record = await compliance.recordOf(alice.address);
      expect(record.caseRef).to.equal(CASE_REF);
    });

    it("auto-verifies in self-service mode", async function () {
      const { compliance, alice } = await loadFixture(selfServiceFixture);
      await compliance.connect(alice).requestVerification(CASE_REF);
      expect(await compliance.statusOf(alice.address)).to.equal(Status.Verified);
      expect(await compliance.isVerified(alice.address)).to.equal(true);
    });

    it("reverts when an already verified wallet requests again", async function () {
      const { compliance, alice } = await loadFixture(selfServiceFixture);
      await compliance.connect(alice).requestVerification(CASE_REF);
      await expect(compliance.connect(alice).requestVerification(CASE_REF))
        .to.be.revertedWithCustomError(compliance, "AlreadyVerified")
        .withArgs(alice.address);
    });
  });

  describe("officer actions", function () {
    it("only officers can approve, reject or revoke", async function () {
      const { compliance, alice, bob } = await loadFixture(deployFixture);
      const role = await compliance.COMPLIANCE_OFFICER_ROLE();
      await expect(compliance.connect(alice).approve(bob.address))
        .to.be.revertedWithCustomError(compliance, "AccessControlUnauthorizedAccount")
        .withArgs(alice.address, role);
      await expect(compliance.connect(alice).reject(bob.address)).to.be.revertedWithCustomError(
        compliance,
        "AccessControlUnauthorizedAccount"
      );
    });

    it("supports the full approve → reject → revoke lifecycle", async function () {
      const { compliance, admin, alice } = await loadFixture(deployFixture);
      await compliance.connect(alice).requestVerification(CASE_REF);

      await expect(compliance.approve(alice.address))
        .to.emit(compliance, "StatusChanged")
        .withArgs(alice.address, Status.Verified, admin.address);
      expect(await compliance.isVerified(alice.address)).to.equal(true);

      await compliance.reject(alice.address);
      expect(await compliance.statusOf(alice.address)).to.equal(Status.Rejected);
      expect(await compliance.isVerified(alice.address)).to.equal(false);

      await compliance.revoke(alice.address);
      expect(await compliance.statusOf(alice.address)).to.equal(Status.None);
    });

    it("approves wallets in batches", async function () {
      const { compliance, alice, bob } = await loadFixture(deployFixture);
      await compliance.approveBatch([alice.address, bob.address]);
      expect(await compliance.isVerified(alice.address)).to.equal(true);
      expect(await compliance.isVerified(bob.address)).to.equal(true);
    });

    it("officer role can be delegated", async function () {
      const { compliance, officer, alice } = await loadFixture(deployFixture);
      await compliance.grantRole(await compliance.COMPLIANCE_OFFICER_ROLE(), officer.address);
      await compliance.connect(officer).approve(alice.address);
      expect(await compliance.isVerified(alice.address)).to.equal(true);
    });

    it("rejects the zero address", async function () {
      const { compliance } = await loadFixture(deployFixture);
      await expect(compliance.approve(ethers.ZeroAddress)).to.be.revertedWithCustomError(compliance, "ZeroAddress");
    });
  });

  describe("transfer restrictions", function () {
    it("requires both parties to be verified while restricted", async function () {
      const { compliance, alice, bob } = await loadFixture(deployFixture);
      await compliance.approve(alice.address);
      expect(await compliance.canTransfer(alice.address, bob.address)).to.equal(false);
      await compliance.approve(bob.address);
      expect(await compliance.canTransfer(alice.address, bob.address)).to.equal(true);
    });

    it("frozen wallets fail verification and transfers even when unrestricted", async function () {
      const { compliance, alice, bob } = await loadFixture(deployFixture);
      await compliance.approveBatch([alice.address, bob.address]);
      await expect(compliance.setFrozen(alice.address, true)).to.emit(compliance, "FrozenSet");
      expect(await compliance.isVerified(alice.address)).to.equal(false);
      await compliance.setTransfersRestricted(false);
      expect(await compliance.canTransfer(alice.address, bob.address)).to.equal(false);
      await compliance.setFrozen(alice.address, false);
      expect(await compliance.canTransfer(alice.address, bob.address)).to.equal(true);
    });

    it("only the admin can change global settings", async function () {
      const { compliance, alice } = await loadFixture(deployFixture);
      await expect(compliance.connect(alice).setSelfServiceApproval(true)).to.be.revertedWithCustomError(
        compliance,
        "AccessControlUnauthorizedAccount"
      );
      await expect(compliance.setSelfServiceApproval(true)).to.emit(compliance, "SelfServiceApprovalSet").withArgs(true);
      await expect(compliance.setTransfersRestricted(false)).to.emit(compliance, "TransfersRestrictedSet").withArgs(false);
    });
  });
});
