`scripts/deploy.js` writes one `<network>.json` file per deployment here. The Hardhat
`vestora:*` admin tasks read these files to find the contract addresses.
