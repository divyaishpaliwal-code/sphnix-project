# VESTORA

**Own a fraction. Build a fortune.**

VESTORA is an AI-assisted tokenised micro-investing marketplace — built as an **educational prototype that runs on public testnets only**. It shows how fractional ownership of gold, energy, metals, agriculture, bonds, property and digital assets could work: live market reference prices, illustrative token pricing, a plain-language AI explainer, simulated KYC, and real ERC-1155 transactions on a test network.

> **Educational prototype.** All balances, tokens and transactions are simulated or use testnet tokens with no monetary value. Nothing here is an offer of securities, investment advice, or a claim on any physical commodity, property or bond. KYC is simulated and does not constitute actual identity verification or regulatory approval.

---

## Contents

- [What's inside](#whats-inside)
- [Quick start](#quick-start)
- [Workspace layout](#workspace-layout)
- [Scripts](#scripts)
- [Configuration and API keys](#configuration-and-api-keys)
- [How the numbers work](#how-the-numbers-work)
- [Honesty rules the code enforces](#honesty-rules-the-code-enforces)
- [Deployment](#deployment)
- [Verification status](#verification-status)
- [External dependencies](#external-dependencies)

More detail lives in [`docs/`](docs): [Architecture](docs/ARCHITECTURE.md) · [Data providers](docs/DATA_PROVIDERS.md) · [Deployment](docs/DEPLOYMENT.md) · [Design system](docs/DESIGN.md) · [Demo script](docs/DEMO_SCRIPT.md).

---

## What's inside

| Area | What it does |
| --- | --- |
| **Landing page** | Live ticker (Gold, Silver, Platinum, Crude Oil, Natural Gas, Copper, Bitcoin, Ethereum) with data-status labels and timestamps; how tokenised investing works; featured assets; accessibility comparison; AI preview; blockchain transparency; security and compliance. |
| **Marketplace** | 15 sample assets across Precious Metals, Energy, Industrial Metals, Agriculture, Bonds, Real Estate and Digital Assets. Each card separates the **market reference price** from the **illustrative token price**, with daily change, sparkline, minimum, supply, risk and a one-line AI explanation. Search, category filters, sorting, watchlist, trending and side-by-side comparison (up to 3). |
| **Asset detail** | Live price, interactive chart (1D / 1W / 1M / 3M / 1Y / ALL) of the token or its reference instrument, statistics, methodology, supply, ownership calculator, risk breakdown, AI explanation and a bull/bear scenario simulator. |
| **Markets** | All 34 reference instruments with status, source and timestamp, an indexed gold-vs-silver chart, top movers, a rebased comparison chart and demo price alerts. |
| **Portfolio** | A labelled sample portfolio before you start; your simulated portfolio after a demo purchase; on-chain testnet balances when a wallet is connected. Value, P/L, allocation, performance, risk distribution, top performers, ownership breakdown, transactions and watchlist. |
| **Invest** | The 8-step flow: choose an asset → amount → token calculation → asset details and risk disclosure → simulated KYC → MetaMask or demo mode → confirm → result with hash, status and explorer link (or a `SIM-` reference for simulations). |
| **Wallet** | EIP-6963 MetaMask discovery, short address, network display and switch, vUSD credit claim, balances, holdings, history, copy address, disconnect, demo wallet and a compliance-officer console. |
| **VESTORA Intelligence** | “Understand before you invest.” Seven-part explainers, a published risk methodology, bull and bear scenarios, guardrails against advice and predictions. Uses Claude or OpenAI through the server when configured; otherwise a labelled built-in assistant. |
| **Transactions** | Every simulated and testnet action with filters, a timeline view, a detail drawer, CSV export and a public contract-event explorer. |
| **Learn** | Nine beginner guides and a glossary. |
| **Settings** | Profile, theme, refresh rate, provider health, network and contracts, price alerts, optional server sync, JSON export/import and demo reset. |
| **Everywhere** | Command palette (⌘K / Ctrl K), notifications, toasts, mobile navigation, dark and light themes, empty and error states. |

---

## Quick start

**Requirements:** Node.js 20 or newer and npm 10+. MetaMask is optional (demo mode works without it).

```bash
npm install
npm run dev
```

- Web app: http://localhost:5173
- API: http://localhost:8787 (the web dev server proxies `/api` to it)

That is enough to run everything **without any API keys**: crypto prices come from CoinGecko's public API, energy, Treasury yields, US indices and monthly commodity prices from FRED's public CSV downloads, news from public RSS feeds, and answers from the built-in educational assistant. Anything without a reachable source is labelled **Demo data** or **Unavailable** — never invented.

To unlock more:

1. Copy `apps/server/.env.example` to `apps/server/.env` and add any keys you have (see [Configuration](#configuration-and-api-keys)).
2. To use the testnet contracts, follow [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) — deploy once to Sepolia, and the web app picks up the addresses automatically.

### Frontend only

```bash
npm run build:static -w @vestora/web   # → apps/web/dist, hash routing, relative paths
```

This bundle never calls the API: crypto prices come straight from CoinGecko in the browser, the assistant runs locally, and other instruments show labelled demo values. It can be hosted on any static host.

---

## Workspace layout

```
vestora/
├─ packages/shared     Domain logic shared by web and API: instruments, sample assets,
│                      valuation and bond maths, risk model, knowledge base, the
│                      deterministic assistant, disclaimers, formatters. Unit-tested.
├─ apps/server         Express API: market-data providers with caching and fallbacks,
│                      news, AI proxy with guardrails, optional profile sync (Postgres
│                      or file). Never exposes keys.
├─ apps/web            React 19 + TypeScript + Vite + Tailwind v4 + Radix/shadcn-style UI,
│                      TanStack Query, Zustand, Recharts, Framer Motion, ethers v6.
├─ contracts           Solidity 0.8.24 + OpenZeppelin 5.1 + Hardhat: AssetToken (ERC-1155)
│                      and ComplianceManager (mock KYC), deploy/verify scripts, admin
│                      tasks and tests.
└─ docs                Architecture, data providers, deployment, design, demo script.
```

---

## Scripts

Run from the repository root.

| Command | What it does |
| --- | --- |
| `npm run dev` | API (port 8787) and web (port 5173) together. |
| `npm run dev:web` / `npm run dev:api` | One side only. |
| `npm run build` | Production web build → `apps/web/dist`. |
| `npm run start` | API server; also serves `apps/web/dist` when it exists (single-service deploy). |
| `npm run typecheck` | TypeScript checks for shared, server and web. |
| `npm test` | Shared and server unit tests, then the Hardhat contract tests. |
| `npm run chain` | Local Hardhat node (chain 31337). |
| `npm run contracts:compile` / `contracts:test` | Compile or test the contracts. |
| `npm run contracts:deploy:local` / `contracts:deploy:sepolia` | Deploy and seed the 15 sample assets. |
| `npm run assets:export` | Regenerate `packages/shared/data/onchain-assets.json` after editing sample assets. |

Workspace-specific: `npm run build:static -w @vestora/web`, `npm run deploy:base-sepolia -w @vestora/contracts`, `npm run deploy:amoy -w @vestora/contracts`, `npm run verify:sepolia -w @vestora/contracts`.

---

## Configuration and API keys

Every key is optional. Secrets live only in `apps/server/.env` and `contracts/.env`, both git-ignored. The browser only ever sees `VITE_*` values, which are never secrets.

### API server — `apps/server/.env`

| Variable | Needed for | Where to get it |
| --- | --- | --- |
| `COINGECKO_API_KEY` | Higher crypto rate limits (works without) | [coingecko.com/en/api](https://www.coingecko.com/en/api) — free Demo plan |
| `FRED_API_KEY` | Official FRED API instead of the public CSV download | [fred.stlouisfed.org](https://fred.stlouisfed.org/docs/api/api_key.html) — free |
| `METALSDEV_KEY` | Live gold, silver, platinum, palladium and base metals | [metals.dev](https://metals.dev) — free tier |
| `GOLDAPI_KEY` | Live precious metals (alternative) | [goldapi.io](https://www.goldapi.io) — free tier |
| `TWELVEDATA_KEY` | Metals and crypto quotes with intraday history | [twelvedata.com](https://twelvedata.com) — free tier |
| `ALPHAVANTAGE_KEY` | Daily WTI, Brent, natural gas; monthly metals and agriculture; Treasuries | [alphavantage.co](https://www.alphavantage.co/support/#api-key) — free tier |
| `TRADINGECONOMICS_KEY` | Delayed quotes for most commodities | [tradingeconomics.com](https://tradingeconomics.com/api/) — paid |
| `ANTHROPIC_API_KEY` | Live VESTORA Intelligence with Claude (default model `claude-haiku-5-5`) | [console.anthropic.com](https://console.anthropic.com) |
| `OPENAI_API_KEY` | Live VESTORA Intelligence with OpenAI (default `gpt-4.1-mini`) | [platform.openai.com](https://platform.openai.com) |
| `DATABASE_URL` | Optional profile sync in Postgres / Supabase (otherwise a local JSON file) | Supabase → Project settings → Database |

Other settings (port, CORS origins, cache durations, demo fallback, AI provider choice and rate limit, news feeds) are documented inline in [`apps/server/.env.example`](apps/server/.env.example). The Claude integration sends `anthropic-version: 2026-10-21` and no sampling parameters, as that API version requires.

### Web app — `apps/web/.env.local`

| Variable | Purpose |
| --- | --- |
| `VITE_API_BASE_URL` | API origin when it is not the same origin as the web app. |
| `VITE_DISABLE_API` | `true` for a frontend-only build. |
| `VITE_DIRECT_COINGECKO` | Let the browser call CoinGecko directly when the API is unavailable (default `true`). |
| `VITE_CHAIN_ID` | Target testnet: `11155111` Sepolia (default), `84532` Base Sepolia, `80002` Polygon Amoy, `31337` Hardhat. |
| `VITE_ASSET_TOKEN_ADDRESS`, `VITE_COMPLIANCE_ADDRESS`, `VITE_DEPLOY_BLOCK` | Contract addresses. Optional — the deploy script writes them to `apps/web/src/contracts/deployments/<chainId>.json`, which the app loads automatically. |
| `VITE_RPC_URL` | Read-only RPC for the contract explorer when no wallet is connected. |
| `VITE_ROUTER_MODE` | `browser` (default) or `hash` for static hosts without SPA fallback. |

### Contracts — `contracts/.env`

| Variable | Purpose |
| --- | --- |
| `DEPLOYER_PRIVATE_KEY` | A throwaway wallet that only holds **testnet** ETH. Never a real wallet. |
| `SEPOLIA_RPC_URL`, `BASE_SEPOLIA_RPC_URL`, `POLYGON_AMOY_RPC_URL` | Optional RPC endpoints (public defaults are used when blank). |
| `ETHERSCAN_API_KEY` | Optional, for contract verification. |
| `SELF_SERVICE_KYC` | `true` (default) lets wallets verify themselves after the simulated KYC; `false` requires a compliance officer. |
| `KYC_PREAPPROVE` | Optional comma-separated wallets to approve at deploy time. |

---

## How the numbers work

- **Market reference prices** come from real providers and always carry a status — *Real-time*, *Delayed*, *Historical*, *Demo* or *Unavailable* — plus the source and timestamp. See [docs/DATA_PROVIDERS.md](docs/DATA_PROVIDERS.md).
- **Token prices are illustrative:** sample asset value ÷ token supply. For example, the Gold Reserve Pool is 50 troy oz of gold split into 20,000 tokens, so its token price is 50 × the gold price ÷ 20,000. Bond samples are priced with the bond-pricing formula from a live Treasury or corporate yield. The two property samples are fully simulated with fixed valuations.
- **Risk scores** are deterministic: 30% volatility, 20% drawdown, 15% liquidity, 20% tokenisation and custody structure, 15% macro sensitivity, each 1–10. Volatility and drawdown are measured from a year of real prices when at least 20 observations exist. The AI explains the score but never sets it.
- **On-chain purchases** use whole tokens at an integer issuance price in vUSD — free, non-transferable demo credits (10,000 per wallet). Demo-mode purchases use the illustrative token price and simulated cash ($10,000).

---

## Honesty rules the code enforces

- Real money is never involved. Purchases use testnet tokens or simulated balances, and nothing implies ownership of commodities, property or securities. Token metadata on-chain says so too.
- No price is ever generated at random, and no price history is invented. If a provider fails, VESTORA shows the last good value with its original timestamp, a labelled static demo value, or *Unavailable*.
- Simulated transactions are labelled **“Simulated — no on-chain record”** and get `SIM-` references that cannot be mistaken for transaction hashes.
- The AI never gives buy/sell advice, price targets or return promises. Advice-seeking questions get an explicit notice, output passes guardrail checks, and user text is treated as data, not instructions.
- AI and market-data keys stay on the server. Private keys and seed phrases are never requested or stored.
- KYC is simulated: no identity documents are collected, personal details never leave the browser (not even with sync), and only a status and hashed case reference go on-chain.

---

## Deployment

The short version (full steps in [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)):

1. **Contracts:** add a testnet-only `DEPLOYER_PRIVATE_KEY` to `contracts/.env`, get Sepolia ETH from a faucet, run `npm run contracts:deploy:sepolia`. The script refuses to deploy to Ethereum mainnet.
2. **API + web as one service:** `npm ci && npm run build && npm run start` on any Node host (Render, Railway, Fly.io, a VM). Set `CORS_ORIGIN`, `TRUST_PROXY=true` behind a proxy, and any API keys.
3. **Or split:** host `apps/web/dist` on a static host with `VITE_API_BASE_URL` pointing at the API, or use the frontend-only `build:static` bundle.

---

## Verification status

This repository was produced in a sandbox where the npm registry was unreachable, so dependencies could not be installed there. What was verified, and what was not:

| Check | Result |
| --- | --- |
| Shared package unit tests (ownership calculator, bond maths, valuation and demo fallbacks, volatility and drawdown, risk bands, catalogue integrity, assistant routing and advice refusal, market hours) | ✅ 16 / 16 passing |
| API server unit tests (provider fallbacks and cooldowns, never-fabricated history, FRED CSV and RSS parsing, AI guardrails and safe fallback, profile scrubbing, cache, secret redaction) | ✅ 15 / 15 passing |
| TypeScript (shared, server, web) | ✅ Passes against local type shims for third-party packages — **re-run with real types:** `npm run typecheck` |
| Web bundle | ✅ All 88 modules resolve and bundle with esbuild (third-party packages external) |
| Tailwind CSS | ✅ Compiles with Tailwind v4; every utility class used in the app resolves |
| Rendering | ✅ All routes rendered in Chromium (with stand-ins for third-party UI libraries): no runtime errors, no horizontal overflow at 390 px or 1440 px, dark and light themes; the demo investment flow passes end to end |
| `vite build` with real dependencies | ⚠️ Not run here — run `npm install && npm run build` |
| Solidity compile and Hardhat tests | ⚠️ Not run here — the Solidity compiler could not be downloaded in the sandbox. Run `npm run contracts:test` |

**Before relying on it, run locally:**

```bash
npm install
npm run typecheck
npm test            # shared + server + contracts
npm run build
```

The contracts are unaudited teaching examples. Do not deploy them to a mainnet or use them with real value.

---

## External dependencies

- **Runtime:** Node.js ≥ 20, npm ≥ 10.
- **Market data:** CoinGecko and FRED (no key needed); optional Metals.Dev, GoldAPI, Twelve Data, Alpha Vantage, Trading Economics.
- **AI:** optional Anthropic or OpenAI API key.
- **News:** public RSS feeds from the Federal Reserve, the US EIA, MINING.COM and CoinDesk (configurable).
- **Blockchain:** MetaMask (or any EIP-6963 wallet), a Sepolia RPC (public default provided), testnet ETH from a faucet, optionally an Etherscan API key.
- **Database:** optional Postgres or Supabase (`apps/server/db/schema.sql`).
- **Fonts:** Inter, Manrope and JetBrains Mono, bundled via Fontsource (no external font requests).
