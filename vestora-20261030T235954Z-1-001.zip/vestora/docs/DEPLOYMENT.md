# Deployment

VESTORA has three deployable parts: the **contracts** (testnet only), the **API server** and the **web app**. You can run any subset — the web app degrades gracefully, and every fallback is labelled.

- [1. Prerequisites](#1-prerequisites)
- [2. Local development](#2-local-development)
- [3. A local blockchain](#3-a-local-blockchain)
- [4. Deploy the contracts to Sepolia](#4-deploy-the-contracts-to-sepolia)
- [5. Run a testnet purchase](#5-run-a-testnet-purchase)
- [6. Compliance officer tasks](#6-compliance-officer-tasks)
- [7. Deploy the API and web app](#7-deploy-the-api-and-web-app)
- [8. Security checklist](#8-security-checklist)
- [9. Troubleshooting](#9-troubleshooting)

---

## 1. Prerequisites

- Node.js 20 or newer, npm 10+
- MetaMask (or another EIP-6963 browser wallet) for testnet transactions
- For Sepolia: a **new, testnet-only wallet** and a little Sepolia ETH for gas

```bash
npm install
```

## 2. Local development

```bash
npm run dev          # API on :8787, web on :5173 (proxying /api to the API)
```

No keys are required. Add keys to `apps/server/.env` (copy `apps/server/.env.example`) to enable more data providers or live AI.

## 3. A local blockchain

Useful for trying the on-chain flow without faucets.

```bash
npm run chain                     # terminal 1: Hardhat node on http://127.0.0.1:8545 (chain 31337)
npm run contracts:deploy:local    # terminal 2: deploys and seeds the 15 sample assets
```

Then create `apps/web/.env.local` with:

```bash
VITE_CHAIN_ID=31337
```

Restart `npm run dev`. In MetaMask, import one of the test accounts printed by `npm run chain`. Those keys are public and only meaningful on your local node — never send real funds to them. When you connect, VESTORA asks MetaMask to add and switch to the Hardhat network.

## 4. Deploy the contracts to Sepolia

**1. Create a deployer wallet.** In MetaMask, add a new account used only for testing. Export its private key into `contracts/.env` (copy `contracts/.env.example`):

```bash
DEPLOYER_PRIVATE_KEY=0x…        # testnet-only wallet — never a wallet that holds real funds
SEPOLIA_RPC_URL=                # optional; a public endpoint is used when blank
ETHERSCAN_API_KEY=              # optional, for verification
SELF_SERVICE_KYC=true           # see "KYC modes" below
```

**2. Fund it with Sepolia ETH.** Use a Sepolia faucet such as [Alchemy's](https://www.alchemy.com/faucets/ethereum-sepolia) or [Google Cloud's](https://cloud.google.com/application/web3/faucet/ethereum/sepolia). Deployment plus seeding 15 assets uses a modest amount of gas; 0.05 Sepolia ETH is plenty. Faucet rules change — some ask you to sign in or to hold a small mainnet balance.

**3. Compile, test and deploy.**

```bash
npm run contracts:compile
npm run contracts:test
npm run contracts:deploy:sepolia
```

The script refuses to run on Ethereum mainnet (chain 1). It deploys `ComplianceManager` and `AssetToken`, creates the 15 sample assets from `packages/shared/data/onchain-assets.json`, and writes:

| File | Used by |
| --- | --- |
| `contracts/deployments/sepolia.json` | The `vestora:*` Hardhat admin tasks |
| `apps/web/src/contracts/deployments/11155111.json` | The web app — picked up automatically at build time |
| `apps/web/src/contracts/abi/*.json` | Full JSON ABIs for other tools |

It also prints `VITE_*` lines you can pin in `apps/web/.env.local` instead. Contract addresses are public, so committing the deployment JSON is fine.

**4. Verify the source (optional).**

```bash
npm run verify:sepolia -w @vestora/contracts
```

**Other testnets:** `npm run deploy:base-sepolia -w @vestora/contracts` (set `VITE_CHAIN_ID=84532`) or `npm run deploy:amoy -w @vestora/contracts` (set `VITE_CHAIN_ID=80002`). Fund the deployer on that network first.

### KYC modes

| `SELF_SERVICE_KYC` | Behaviour |
| --- | --- |
| `true` (default) | After the simulated KYC in the app, “Record verification” marks the wallet **Verified** immediately. Best for single-person demos. |
| `false` | Requests stay **Pending** until a compliance officer approves them — from the Wallet page's officer console or with the Hardhat task below. Best for showing a review process. |

`KYC_PREAPPROVE=0xabc…,0xdef…` approves wallets at deploy time. The mode can be changed later with `vestora:self-service`.

## 5. Run a testnet purchase

1. Open **Wallet** and connect MetaMask (or use **Connect wallet** in the top bar). Approve the network switch to Sepolia.
2. On **Wallet**, claim the one-time **10,000 vUSD** demo credits (gas is paid in Sepolia ETH; vUSD has no value and cannot be transferred).
3. Complete the simulated KYC (**Verification**), then **Record verification** on-chain. Only a status and a hashed case reference are written.
4. Go to **Invest**, pick an asset and amount, choose **Testnet transaction**, and confirm in MetaMask.
5. The result shows the transaction hash, status and an explorer link. **Transactions → Contract explorer** lists purchase events from every wallet.

On-chain purchases buy whole tokens at the contract's integer issuance price in vUSD, so quantities can differ slightly from the illustrative calculator.

## 6. Compliance officer tasks

Run from `contracts/` against a deployed network:

```bash
npx hardhat vestora:assets --network sepolia                                   # supply and prices
npx hardhat vestora:kyc --account 0xabc… --network sepolia                     # status
npx hardhat vestora:kyc --account 0xabc… --action approve --network sepolia    # approve | reject | revoke | freeze | unfreeze
npx hardhat vestora:self-service --enabled false --network sepolia
npx hardhat vestora:price --id 1 --price 12 --network sepolia                  # issuance price in vUSD
```

The deployer holds the admin, issuer, pauser and compliance-officer roles. Wallets with the officer role also see an officer console on the Wallet page.

## 7. Deploy the API and web app

### Option A — one service (simplest)

The API serves the built web app when `apps/web/dist` exists.

| Setting | Value |
| --- | --- |
| Build command | `npm ci && npm run build` |
| Start command | `npm run start` |
| Node version | 20 or newer |
| Environment | `HOST=0.0.0.0`, `SERVE_WEB=true`, `TRUST_PROXY=true` (behind a platform proxy), plus any provider or AI keys. `PORT` is usually provided by the platform. |

Works on Render, Railway, Fly.io, Heroku-style platforms or a plain VM. If the platform's disk is ephemeral and you want profile sync to survive restarts, set `DATABASE_URL` (see Supabase below).

### Option B — static web + separate API

1. Deploy the API as in option A (the build step can be skipped) and set `CORS_ORIGIN=https://your-web-domain`.
2. Build the web app with `VITE_API_BASE_URL=https://your-api-domain npm run build` and upload `apps/web/dist` to Vercel, Netlify, Cloudflare Pages or any static host.
3. Configure the host to rewrite unknown paths to `/index.html`, or build with `VITE_ROUTER_MODE=hash`.

### Option C — frontend only

```bash
npm run build:static -w @vestora/web
```

Produces a self-contained bundle with hash routing and relative asset paths. It never calls the API: crypto prices come directly from CoinGecko, the assistant runs in the browser, and every other instrument shows labelled demo values. Wallet and contract features work as long as contracts are deployed.

### Supabase / Postgres (optional)

Profile sync (Settings → Data and privacy) stores preferences, watchlist, simulated portfolio, activity and alerts under an anonymous profile ID. Without a database the API uses a JSON file in `DATA_DIR`.

1. In Supabase, open the SQL editor and run `apps/server/db/schema.sql` (the API also creates the table on start-up).
2. Set `DATABASE_URL` to the connection string from Project settings → Database, and keep `DATABASE_SSL=true`.

Row Level Security stays enabled with no public policies: only the API, holding the connection string, can read or write. Personal KYC fields are scrubbed before anything is stored.

## 8. Security checklist

- [ ] `apps/server/.env` and `contracts/.env` are not committed (both are in `.gitignore`).
- [ ] The deployer key belongs to a testnet-only wallet with no real funds.
- [ ] No secret is set in a `VITE_*` variable — those are bundled into public JavaScript.
- [ ] `CORS_ORIGIN` lists only your web origins.
- [ ] `TRUST_PROXY=true` only when running behind a proxy you control or your platform's load balancer.
- [ ] `AI_RATE_LIMIT_PER_MINUTE` is set to a level your AI budget tolerates.
- [ ] The platform disclaimers remain visible — the app is educational and testnet-only.

## 9. Troubleshooting

| Symptom | Fix |
| --- | --- |
| “Switch your wallet to Sepolia first.” | Use the switch prompt on the Wallet page, or select the network in MetaMask. |
| `NotVerified` when buying | Complete the simulated KYC and **Record verification**. With self-service off, ask an officer to approve. |
| `InsufficientCredits` | Claim the 10,000 vUSD credits (once per wallet) or buy fewer tokens. |
| `CreditsAlreadyClaimed` | Each wallet can claim once. Use another test account. |
| Contract explorer shows an RPC error | Public RPCs limit log queries. Set `VITE_RPC_URL` to a provider endpoint (Alchemy, Infura, QuickNode). |
| Prices show **Demo data** | No provider for that instrument is configured or reachable. Add a key (see `docs/DATA_PROVIDERS.md`) or check provider health in Settings. |
| AI answers say “Educational demo assistant” | No AI key is set on the server, or `AI_PROVIDER=none`. |
| `npm run dev` web app cannot reach the API | Check the API is on port 8787, or set `VITE_DEV_API_PROXY`. |
