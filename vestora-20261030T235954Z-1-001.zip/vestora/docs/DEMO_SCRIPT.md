# Demo script (about 7 minutes)

A walkthrough for presenting VESTORA. Times are a guide; each section notes what to click and what to say. Everything shown is educational and testnet-only — say so early and let the interface's labels back you up.

## Before you start

- [ ] `npm run dev` is running, or the deployed URL is open.
- [ ] Optional keys are set on the server for the data you want live (a metals key makes silver and platinum live; an Anthropic key enables live AI).
- [ ] For the on-chain part: MetaMask on Sepolia with test ETH, contracts deployed, and the wallet's 10,000 vUSD **already claimed** and verification **already recorded** — or do both live if time allows.
- [ ] Settings → Data and privacy → **Reset demo data**, so the portfolio starts from the sample view.
- [ ] Dark theme, browser zoom 100%, notifications cleared.

---

## 1. The problem and the promise — 0:00–0:45

**Show:** Landing page, hero and live ticker.

> “Gold, oil, Treasuries and property usually need thousands of dollars to own directly. VESTORA shows how tokenised fractions could let people start with ten — and, just as importantly, help them understand what they're buying. It's an educational prototype: everything runs on a testnet or in simulation.”

Point at the ticker: each price has a status — *Real-time*, *Delayed*, *Historical* or *Demo* — and a timestamp. “Nothing on screen is a made-up number.”

## 2. The marketplace — 0:45–1:45

**Click:** Explore Marketplace.

- Filter by **Precious Metals**, then open the Gold Reserve Pool card.
- Show the two prices side by side: the **market reference price** (gold per ounce) and the **illustrative token price**.

> “A token here is one twenty-thousandth of a 50-ounce sample pool. So the token price is 50 times the gold price, divided by 20,000. We never pretend the token price is the gold price.”

- Tick **Compare** on gold, silver and the Bitcoin unit; open the comparison to show risk side by side.

## 3. Understand before you invest — 1:45–3:00

**Click:** View details on Gold, then scroll to the AI explanation.

- Show the seven-part explainer: what it is, how it derives value, what moves its price, risks, historical volatility, beginner notes, what could make it fall.
- Open **How is this calculated?** on the risk score:

> “The score is deterministic — 30% volatility, 20% drawdown, 15% liquidity, 20% token structure, 15% macro — with volatility and drawdown measured from a year of real prices. The AI explains the score; it can't change it.”

- Go to **AI Intelligence** and ask: *“Should I buy silver now?”*

> “It won't tell you to buy or sell, or predict prices. It says so, then gives you balanced education instead.”

## 4. Simulate an investment — 3:00–4:45

**Click:** Simulate investment on the Gold card (or Invest in the sidebar).

1. Enter **$250** → the calculation shows whole tokens, cost, unspent cash and share of supply, with the disclaimer: *Illustrative calculations only. Not a representation of a legally enforceable ownership claim.*
2. Tick the risk disclosure.
3. Complete the simulated KYC: name, email, country, run the simulated check, confirm the acknowledgements.

> “Real platforms verify identity with a licensed provider. We simulate the flow and collect nothing — the disclaimer says exactly that.”

4. Choose **Demo mode** → confirm → the result shows a `SIM-` reference and the label *Simulated — no on-chain record*.

**Then (if the wallet is ready):** choose **Invest in another asset**, run through the steps again (verification is already done, so it is quick), pick **Testnet transaction** at step 6, confirm in MetaMask, and open the transaction on Etherscan from the result.

> “Same flow, but now it's a real ERC-1155 transaction on Sepolia, paid with free demo credits. The contract refuses wallets that haven't recorded their simulated verification.”

## 5. Portfolio and transparency — 4:45–6:00

**Click:** View portfolio.

- Show value, P/L, allocation, risk distribution and the ownership breakdown — now from the simulated purchase.
- **Transactions:** filter Simulated vs Testnet; open the detail drawer; switch to **Contract explorer** to show public purchase events from every wallet.

> “Simulated and on-chain activity never get mixed up. Anyone can audit the testnet contract's events.”

## 6. Close — 6:00–7:00

**Click:** Learn → *How the VESTORA risk score works* (or Settings → Market data sources to show provider health).

> “VESTORA is built on three rules: never invent a number, never blur simulation and reality, and never give advice. The same code would let a regulated issuer plug in real custody, real KYC and real assets — but that's the part that needs lawyers, licences and audits, not a hackathon.”

---

## If something goes wrong

| Problem | What to do |
| --- | --- |
| A price shows *Demo data* | Say so — it's the honest fallback when no provider is configured. Point to Settings → Market data sources. |
| MetaMask is slow or on the wrong network | Use demo mode; the flow is identical up to step 6. |
| Live AI is unavailable | The answer is labelled *Curated fallback* or *Educational demo assistant* and still follows the seven sections. |
| No internet | The static demo values and the local assistant keep the whole UI usable; every value is labelled. |
