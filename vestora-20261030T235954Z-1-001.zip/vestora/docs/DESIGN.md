# Design system

VESTORA's look is a quiet, dark trading desk with one warm accent: deep navy surfaces, gold for the actions and the brand, blue for information and charts. Every number shows where it came from, so status labels are part of the design rather than fine print.

Tokens live in `apps/web/src/index.css` (Tailwind v4, CSS-first). Dark is the default theme; light is a separately tuned set, not an automatic inversion. Users switch between dark, light and system in the top bar, Settings or the command palette.

## Colour

### Brand and surfaces

| Token | Dark | Light | Use |
| --- | --- | --- | --- |
| `--background` | `#080D18` | `#F4F6FA` | Page |
| `--surface` | `#101827` | `#EBEFF5` | Sidebar, bands |
| `--card` | `#141F30` | `#FFFFFF` | Cards, chart surface |
| `--foreground` | `#E8EDF6` | `#0C1424` | Primary text |
| `--muted-foreground` | `#9AA5BB` | `#4F5B73` | Secondary text |
| `--gold` | `#D6B36A` | `#9A7428` | Brand, primary actions, selection |
| `--blue` | `#527BFF` | `#3D63E6` | Information, focus ring, chart slot 1, testnet actions |
| `--success` | `#25C997` | `#0F8A62` | Gains, confirmations, verified |
| `--danger` | `#F2647A` | `#D03A55` | Losses, failures, destructive actions |
| `--warning` | `#E9A645` | `#A86B12` | Pending, disclosures |
| `--demo` | `#A993FF` | `#6A4FD6` | “Demo data” and the demo assistant |

The dark values for background, surface, card, gold, blue and success are the brief's palette. Light-mode gold and blue are darkened so text and icons keep contrast on white.

### Data status

Status is always shown with a label, never by colour alone: **Real-time** (success, pulsing dot), **Delayed** (warning), **Historical** (blue), **Demo data** (demo violet), **Unavailable** (neutral). Token prices carry a gold **Illustrative** badge; simulations carry a dashed **Simulated** badge.

### Charts

The categorical palette was run through the dataviz palette validator (`validate_palette.js`) for both themes. Slots are assigned in a fixed order, and each asset category keeps its slot on every chart.

| Slot | Dark (surface `#141F30`) | Light (surface `#FFFFFF`) | Category |
| --- | --- | --- | --- |
| 1 | `#527BFF` | `#3D63E6` | Bonds |
| 2 | `#D95926` | `#EB6834` | Energy |
| 3 | `#199E70` | `#1BAF7A` | Real Estate |
| 4 | `#C98500` | `#EDA100` | Precious Metals |
| 5 | `#D55181` | `#E87BA4` | Digital Assets |
| 6 | `#008300` | `#008300` | Agriculture |
| 7 | `#9085E9` | `#6250D6` | Industrial Metals |
| 8 | `#E66767` | `#E34948` | Overflow |

Validator results:

| Check | Dark | Light |
| --- | --- | --- |
| Lightness band | Pass (L 0.48–0.67) | Pass (L 0.43–0.77) |
| Chroma floor | Pass | Pass |
| Colour-vision-deficiency separation (adjacent pairs) | Pass — worst ΔE 8.4 (protan) | Pass — worst ΔE 9.1 (protan), 5.8 (tritan) |
| Normal-vision floor | Pass — worst ΔE 19.3 | Pass — worst ΔE 19.6 |
| Contrast vs surface | Pass (all ≥ 3:1) | **Warn** — slots 3, 4, 5 below 3:1 |

Because of the light-mode contrast warning, every chart that uses categorical colour also names its series in text: the allocation legend lists each slice's share and value, the comparison legend shows each series' change, movers carry direct value labels, and every chart has a descriptive `aria-label`.

Risk uses a single-hue ordinal ramp, recessive for Low and prominent for Very high, validated as monotone with visible steps in both themes:

| Level | Dark | Light |
| --- | --- | --- |
| Low | `#184F95` | `#86B6EF` |
| Moderate | `#256ABF` | `#5598E7` |
| Elevated | `#3987E5` | `#2A78D6` |
| High | `#6DA7EC` | `#1C5CAB` |
| Very high | `#9EC5F4` | `#104281` |

Chart rules applied throughout: one y-axis per chart (gold and silver are compared as indexed-to-100 lines rather than on two scales); 2 px lines with a 10% area wash; recessive grid and axes; tooltips on every chart; legends for two or more series; status colours never reused as series colours.

## Typography

| Role | Typeface | Notes |
| --- | --- | --- |
| Display (page titles, headings, large figures) | Manrope Variable, 600–700 | Tight negative tracking at large sizes |
| Body and UI | Inter Variable | 13–15 px for dense UI, 15 px with 1.7 line height for guides |
| Addresses, hashes, formulas | JetBrains Mono 400 | Only where characters must be distinguishable |

Figures use tabular numerals (`.tabular`) so columns of prices align. Fonts are bundled with Fontsource; nothing loads from a font CDN.

## Layout

- App shell: fixed 248 px sidebar on desktop with an environment card (mode, network, data source, simulated cash); sticky top bar with search, market status, notifications, wallet and profile; a five-tab bar on mobile.
- Content width is fluid with 16 px side gutters on phones and no horizontal page scroll; wide tables scroll inside their own containers.
- Cards use one radius scale (6/8/10/14/18 px) by hierarchy: small controls are tighter, page sections looser.

## Motion

Motion mostly responds to what the user does: dialogs fade and scale in, sheets slide from their edge, step changes are instant, and price changes do not animate. The landing hero has one orchestrated entrance — the gold ingot assembles cell by cell, a single sheen passes over it, and three cards settle in — over slowly drifting background price lines. The ticker scrolls continuously and pauses on hover or keyboard focus. Every animation is disabled under `prefers-reduced-motion`.

## Accessibility

- Visible focus rings (`--ring`) on every interactive element; skip-free keyboard paths through dialogs, menus and the eight-step flow.
- Radix primitives provide focus management, roles and Escape-to-close for dialogs, menus, selects, tabs and accordions.
- Status, risk and gains or losses always pair colour with text or an icon.
- Live regions announce transaction progress and assistant answers.
- Light and dark themes are each checked for text and chart contrast.

## Voice

Plain, specific and calm. Buttons say what happens (“Confirm simulated purchase”, “Record verification”), and the result echoes the same words. Errors say what went wrong and what to do next. Anything simulated says so in the interface itself, not only in a footer.
