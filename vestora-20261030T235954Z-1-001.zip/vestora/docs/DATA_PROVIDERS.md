# Market data providers

VESTORA shows real market reference prices whenever it can, labels every number with where it came from, and never invents one. This page explains which provider serves which instrument, what each status label means, and how failures are handled.

All provider calls happen on the API server (`apps/server/src/market`). Keys never reach the browser.

## What works without any keys

| Asset class | Keyless source | Status shown |
| --- | --- | --- |
| Digital assets (BTC, ETH, SOL, XRP, PAXG) | CoinGecko public API | Real-time, 24h change |
| Gold | CoinGecko — PAX Gold (PAXG), a gold-backed token, **labelled as a proxy** | Real-time (proxy) |
| Energy (WTI, Brent, Henry Hub gas, gasoline) | FRED public CSV (EIA daily spot series) | Delayed, change vs previous observation |
| Treasury yields, IG corporate yield | FRED public CSV | Delayed |
| S&P 500, Nasdaq Composite, Dow Jones | FRED public CSV | Delayed |
| Base metals and agriculture | FRED public CSV (IMF monthly series) | Historical (monthly) |
| Silver, platinum, palladium | — | Demo data until a metals key is added |

Add **one** of Metals.Dev, GoldAPI or Twelve Data to get live silver, platinum and palladium; Metals.Dev also covers base metals. Alpha Vantage adds daily energy quotes; Trading Economics adds delayed quotes for most commodities.

## Coverage by instrument

For each asset class the server tries providers in a fixed preference order and uses the first one that is configured, maps the instrument and is not cooling down.

| Asset class | Preference order |
| --- | --- |
| Precious metals | Metals.Dev → GoldAPI → Twelve Data → Trading Economics → CoinGecko (PAXG proxy, gold only) |
| Energy | Trading Economics → Alpha Vantage → FRED |
| Industrial metals | Metals.Dev → Trading Economics → Alpha Vantage → FRED |
| Agriculture | Trading Economics → Alpha Vantage → FRED |
| Digital assets | CoinGecko → Twelve Data → FRED |
| Rates and bonds | FRED → Alpha Vantage |
| Indices | FRED |

Provider symbols per instrument (blank = not served by that provider; *m* = monthly series):

| Instrument | Unit | Metals.Dev | GoldAPI | Twelve Data | Alpha Vantage | Trading Economics | CoinGecko | FRED |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Gold | troy oz | gold | XAU | XAU/USD | | XAUUSD:CUR | pax-gold (proxy) | |
| Silver | troy oz | silver | XAG | XAG/USD | | XAGUSD:CUR | | |
| Platinum | troy oz | platinum | XPT | XPT/USD | | XPTUSD:CUR | | |
| Palladium | troy oz | palladium | XPD | XPD/USD | | XPDUSD:CUR | | |
| Crude Oil (WTI) | barrel | | | | WTI | CL1:COM | | DCOILWTICO |
| Brent Crude | barrel | | | | BRENT | CO1:COM | | DCOILBRENTEU |
| Natural Gas (Henry Hub) | MMBtu | | | | NATURAL_GAS | NG1:COM | | DHHNGSP |
| Gasoline | gallon | | | | | XB1:COM | | DGASNYH |
| Copper | metric ton | copper | | | COPPER *m* | HG1:COM | | PCOPPUSDM *m* |
| Aluminium | metric ton | aluminum | | | ALUMINUM *m* | LMAHDS03:COM | | PALUMUSDM *m* |
| Nickel | metric ton | nickel | | | | LMNIDS03:COM | | PNICKUSDM *m* |
| Zinc | metric ton | zinc | | | | LMZSDS03:COM | | PZINCUSDM *m* |
| Lead | metric ton | lead | | | | LMPBDS03:COM | | PLEADUSDM *m* |
| Tin | metric ton | | | | | LMSNDS03:COM | | PTINUSDM *m* |
| Wheat | metric ton | | | | WHEAT *m* | W 1:COM | | PWHEAMTUSDM *m* |
| Corn | metric ton | | | | CORN *m* | C 1:COM | | PMAIZMTUSDM *m* |
| Soybeans | metric ton | | | | | S 1:COM | | PSOYBUSDM *m* |
| Coffee (Arabica) | US cents / lb | | | | COFFEE *m* | KC1:COM | | PCOFFOTMUSDM *m* |
| Cocoa | metric ton | | | | | CC1:COM | | PCOCOUSDM *m* |
| Sugar (No. 11) | US cents / lb | | | | SUGAR *m* | SB1:COM | | PSUGAISAUSDM *m* |
| Cotton | US cents / lb | | | | COTTON *m* | CT1:COM | | PCOTTINDUSDM *m* |
| Bitcoin | BTC | | | BTC/USD | | | bitcoin | CBBTCUSD |
| Ethereum | ETH | | | ETH/USD | | | ethereum | CBETHUSD |
| Solana | SOL | | | SOL/USD | | | solana | |
| XRP | XRP | | | XRP/USD | | | ripple | |
| PAX Gold | PAXG | | | | | | pax-gold | |
| US Treasury 3-month | yield % | | | | TREASURY_YIELD 3month | | | DGS3MO |
| US Treasury 2-year | yield % | | | | TREASURY_YIELD 2year | | | DGS2 |
| US Treasury 10-year | yield % | | | | TREASURY_YIELD 10year | | | DGS10 |
| US Treasury 30-year | yield % | | | | TREASURY_YIELD 30year | | | DGS30 |
| US IG corporate yield | yield % | | | | | | | BAMLC0A0CMEY |
| S&P 500 | index | | | | | | | SP500 |
| Nasdaq Composite | index | | | | | | | NASDAQCOM |
| Dow Jones Industrial Average | index | | | | | | | DJIA |

Units are normalised per instrument: each provider mapping carries a multiplier where needed (for example Metals.Dev quotes base metals per troy ounce and Trading Economics quotes copper per pound; both are converted to US dollars per metric ton, and grains from cents per bushel to dollars per metric ton).

The canonical list lives in `packages/shared/src/instruments.ts`.

## Status labels

| Label | Meaning |
| --- | --- |
| **Real-time** | A live or near-live quote from a provider that offers one on the configured plan (CoinGecko, metals providers, Twelve Data with `TWELVEDATA_REALTIME=true`). |
| **Delayed** | A recent quote that lags the market — end-of-day FRED series, Alpha Vantage daily data, Trading Economics, Twelve Data on a free plan. |
| **Historical** | A periodic observation, such as monthly IMF commodity prices on FRED, or past prices used for charts. |
| **Demo** | A fixed illustrative value used when no provider is configured or reachable (`MARKET_DEMO_FALLBACK=true`). Never live, never random, and excluded from movers, alerts and volatility statistics. |
| **Unavailable** | Nothing could be obtained. The UI shows a gap. Set `MARKET_DEMO_FALLBACK=false` to prefer this over demo values. |

Every quote also carries its **source**, the observation time (`asOf`), the time it was fetched, and a **change basis**: *24h* (crypto), *previous close* (exchange data) or *previous observation* (FRED and Alpha Vantage series).

## Caching and rate limits

| Provider | Quote cache | History cache | Free-tier notes |
| --- | --- | --- | --- |
| CoinGecko | 1 min | 5 min (1D) / 30 min | Public API works without a key; a free Demo key raises limits |
| FRED | 30 min daily / 6 h monthly | same | Public CSV needs no key; the official API needs a free key |
| Metals.Dev | `METALSDEV_TTL_MINUTES` (480) | same | Small monthly quotas — one call covers all metals |
| GoldAPI | `GOLDAPI_TTL_MINUTES` (480) | same | One call per metal |
| Twelve Data | 5 min | 10 min (1D) / 60 min | 429 responses trigger a 60-second cooldown |
| Alpha Vantage | 12 h | 12 h | Very low daily limits; a limit notice triggers a one-hour cooldown |
| Trading Economics | 10 min | 6 h | Paid plans |

- Concurrent requests for the same data share a single upstream call.
- When a provider rate-limits, it cools down (30 seconds to 6 hours, as the provider indicates) and the next provider in the preference order is tried.
- After three consecutive errors a provider backs off exponentially (1 minute doubling, capped at 15 minutes).
- If every provider fails, the last good value is served with its **original** timestamp, then a labelled demo value, then *Unavailable*.
- Upstream URLs are logged with keys redacted.

## Price history

- Charts only ever show observations a provider returned. History is never interpolated, extended or generated.
- Monthly series cannot fill short ranges such as 1D or 1W; the chart says so instead of drawing a line.
- Yield series are not prices, so they are excluded from price-volatility statistics. Bond sample tokens are charted by converting each yield observation into a bond price.
- Volatility and drawdown are only reported when at least 20 observations exist.

## Browser-only fallback

When the API is unreachable (or disabled with `VITE_DISABLE_API=true`), the web app calls CoinGecko directly for crypto prices (`VITE_DIRECT_COINGECKO`, on by default) and shows every other instrument as demo data. The status pill in the sidebar reads **Browser fallback** while this is active.

## News

The API aggregates public RSS and Atom feeds — the Federal Reserve, the US EIA's *Today in Energy*, MINING.COM and CoinDesk — and keeps only `http(s)` links with HTML stripped. Override the list with `NEWS_FEEDS` (JSON) or switch it off with `NEWS_ENABLED=false`.
