# Architecture

VESTORA is an npm-workspaces monorepo with four packages. Domain logic lives in one shared package so the browser, the API and the deploy scripts agree on every asset, price formula and risk score.

```
                         ┌──────────────────────────────────────────────┐
                         │                 apps/web (React)             │
  MetaMask (EIP-6963) ◄──┤ pages · TanStack Query · Zustand · ethers v6 │
          │              └───────────────┬──────────────────────────────┘
          │ signed testnet txs           │ /api/* (JSON)        ▲ browser fallback:
          ▼                              ▼                      │ CoinGecko + local assistant
 ┌──────────────────┐        ┌───────────────────────────────┐ │
 │ contracts (EVM)  │        │ apps/server (Express)         │ │
 │ AssetToken 1155  │        │ market providers · cache      │─┘
 │ ComplianceManager│        │ AI proxy + guardrails · news  │──► CoinGecko, FRED, Metals.Dev,
 └──────────────────┘        │ profile sync (Postgres/file)  │    GoldAPI, Twelve Data, Alpha
          ▲                  └───────────────┬───────────────┘    Vantage, Trading Economics,
          │ deploy + seed                    │                    Anthropic / OpenAI, RSS
          │                                  ▼
          └──────────── packages/shared ◄────┘  instruments · sample assets · valuation ·
                                                bond maths · risk model · knowledge base ·
                                                deterministic assistant · disclaimers
```

## packages/shared

Consumed as TypeScript source by both apps (no build step).

| Module | Responsibility |
| --- | --- |
| `instruments.ts` | 34 market instruments, their units, provider symbols and unit multipliers, provider preference per class, static demo values. |
| `assets.ts` | 15 tokenised sample assets (token ids 1–15), pricing models, supply, minimums, on-chain issuance prices, risk inputs. |
| `finance.ts` | Ownership calculator, bond price and modified duration, `valueAsset` (illustrative valuation from quotes), token price series, volatility and drawdown statistics. |
| `risk.ts` | The five-factor risk methodology, scoring curves and bands. |
| `knowledge.ts` | Curated beginner explanations per asset class and instrument, concept explainers, suggested questions. |
| `assistant.ts` | Deterministic answer engine: subject detection, seven-part asset explainers, comparisons, drawdown maths, concept answers, advice detection. |
| `disclaimers.ts` | The exact disclaimer strings required by the brief. |
| `market-hours.ts`, `format.ts` | NYSE session status with holidays; number, currency and time formatting. |

`scripts/export-onchain-assets.ts` writes `data/onchain-assets.json`, which the contract deploy script reads, so on-chain assets always match the catalogue.

## Valuation model

Token price = sample asset value ÷ token supply. The value comes from one of three pricing models:

| Model | Sample value | Example |
| --- | --- | --- |
| `reference` | quantity × live reference price | Gold Reserve Pool: 50 troy oz × gold price, 20,000 tokens |
| `bond` | face value × clean price from the bond formula at the live reference yield (plus an illustrative spread) | Treasury 10Y Sample Note: $1M face, 4.25% coupon, priced from DGS10 |
| `fixed` | a fixed simulated valuation | Urban Residential Portfolio: $2.4M, 240,000 tokens |

If the reference quote is missing, the instrument's static demo value is used and the valuation is labelled *demo*; if there is no demo value either, the token price is *unavailable*. No code path produces a random number.

## Risk model

`assessRisk(inputs, measured)` combines five factors (each 1–10): volatility 30%, drawdown 20%, liquidity 15%, tokenisation and custody structure 20%, macro sensitivity 15%. Volatility and drawdown use measured values from one year of the token's (or reference instrument's) real price series when at least 20 observations exist, otherwise curated estimates. Every factor records whether it is measured or curated. Cards, the detail page, sorting and the portfolio risk distribution all use the same measured one-year statistics through the shared query cache, so a score never differs between screens.

## apps/server

Express 4 with helmet, CORS allow-list, a 300-requests-per-minute limit, a stricter per-minute limit on AI questions, and a 300 kB JSON body limit.

| Endpoint | Purpose |
| --- | --- |
| `GET /api/health` | Provider health, AI mode, storage mode, news status. |
| `GET /api/market/instruments` | Instrument catalogue. |
| `GET /api/market/quotes?ids=` | Quotes with status, source, timestamps and change basis. |
| `GET /api/market/history?id=&range=` | Real history only (`1D`, `1W`, `1M`, `3M`, `1Y`, `ALL`). |
| `GET /api/news?category=` | Aggregated RSS/Atom headlines. |
| `GET /api/ai/status` · `POST /api/ai/ask` · `GET /api/ai/explain/:assetId` | VESTORA Intelligence. |
| `GET/PUT /api/profile/:id` | Optional profile sync, protected by an `x-profile-key` secret. |

### Market data service

Each provider implements a small interface (`quotes`, `history`, TTLs). For a request, instruments are grouped by their preferred available provider and fetched in batches; failures fall through to the next provider in later rounds. Results are cached per provider and instrument; concurrent loads are de-duplicated. Rate limits put a provider into cooldown; three consecutive errors trigger exponential backoff. When everything fails, the last good value is returned with its original timestamp, then a labelled demo value, then *unavailable*. See [DATA_PROVIDERS.md](DATA_PROVIDERS.md).

### AI pipeline

1. The question is sanitised (length, control characters) and its subject resolved (asset, instrument or category, falling back to page context).
2. Up to two instruments get measured one-year statistics from real history — never from demo values or yield series.
3. The deterministic assistant builds a complete answer, including the risk score. Without an AI key this is the response, labelled *Educational demo assistant*.
4. With a key, the model receives a system prompt with hard rules and a CONTEXT block of curated facts, measured statistics and the fixed risk score. The user's text is wrapped and marked as data.
5. The reply must parse as JSON matching a strict schema, pass guardrails (no guaranteed returns, no buy/sell/hold instructions, no price targets — with negation-aware matching so “we never guarantee returns” is allowed), and, for asset questions, contain all seven required sections, which are re-ordered to the canonical headings.
6. Any failure returns the curated answer labelled *Curated fallback*, with a notice explaining why. The risk score always comes from the deterministic methodology.

Claude requests use the Messages API with `anthropic-version: 2026-10-21`, which rejects sampling parameters, so none are sent. OpenAI requests use the Responses API.

### Storage

`PgProfileStore` (Postgres / Supabase) or `FileProfileStore` (JSON in `DATA_DIR`). Profiles are anonymous, keyed by a random browser-generated id; the secret is stored as a SHA-256 hash and compared in constant time. Payloads are scrubbed of personal fields (names, emails, countries, KYC data) before storage.

## apps/web

- **Routing:** React Router 7, browser or hash history (`VITE_ROUTER_MODE`). Pages are lazy-loaded inside an app shell with sidebar, top bar, mobile tab bar and command palette.
- **Server state:** TanStack Query. One shared `['quotes']` query feeds every price on screen; history is cached per instrument and range; the refresh interval is a user setting.
- **Client state:** a persisted Zustand store (`vestora-store`) for settings, profile id, simulated KYC, simulated cash and holdings, activity, watchlist, comparison, alerts and notifications. Storage access is wrapped so private windows still work in memory. Data restored from sync or import is validated field by field.
- **Fallbacks:** `services/api.ts` tracks API reachability; when it is down, quotes come from CoinGecko in the browser plus labelled demo values, and the assistant runs locally from the shared package.
- **Wallet:** EIP-6963 discovery (with a legacy `window.ethereum` fallback), silent reconnect, `wallet_switchEthereumChain` with `wallet_addEthereumChain` on error 4902, and disconnect via `wallet_revokePermissions`.
- **On-chain hook:** `useOnchain` reads balances, credits, verification status, supply and roles; `send()` wraps every transaction with wallet prompts, toasts, an activity record, receipt confirmation and cache invalidation. Contract errors are translated into plain language. The contract explorer reads events in bounded block windows because public RPCs cap log ranges.
- **Charts:** Recharts with a validated categorical palette, one y-axis per chart, rebased comparisons, tooltips and legends (see [DESIGN.md](DESIGN.md)).

## contracts

| Contract | Role |
| --- | --- |
| `ComplianceManager` | Mock KYC registry: `None`, `Pending`, `Verified`, `Rejected` per wallet, an opaque case-reference hash, freezing, optional self-service approval, transfer-restriction switch. Roles: admin and compliance officer. |
| `AssetToken` | ERC-1155 (OpenZeppelin 5.1: AccessControl, Pausable, Supply). Token id 0 is **vUSD**, non-transferable demo credits (10,000 claimable once per wallet). Ids 1–15 are sample assets with capped supply and an integer issuance price. `buy` requires a verified wallet, burns credits and mints tokens; `redeem` reverses it. Wallet-to-wallet transfers require both parties to pass `canTransfer`. Metadata is generated on-chain and states that tokens confer no ownership. |

Admin roles (issuer, pauser, officer) are granted to the deployer. The deploy script refuses Ethereum mainnet and writes deployment records for the web app and Hardhat tasks.

## Security model

- Secrets live only in `apps/server/.env` and `contracts/.env`; `VITE_*` values are public by design.
- Upstream URLs are logged with API keys redacted.
- The browser never sends personal KYC fields anywhere; only a status and a keccak hash of a random case id reach the chain.
- Private keys and seed phrases are never requested; transactions are signed in the user's wallet.
- The contracts are unaudited and intended for testnets only.
